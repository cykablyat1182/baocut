import { describe, expect, it } from "vitest";

import { parseCompatibleModels } from "../src/model-catalog.js";

describe("provider model catalog", () => {
  it("keeps callable text-generation models and attaches known pricing", () => {
    const models = parseCompatibleModels({
      data: [
        {
          id: "doubao-seed-2-0-mini-260428",
          name: "doubao-seed-2.0-mini",
          domain: "VLM",
          status: "Published",
          task_type: ["TextGeneration", "VQA"],
          modalities: {
            input_modalities: ["text", "image"],
            output_modalities: ["text"],
          },
          token_limits: {
            context_window: 262144,
            max_input_token_length: 229376,
            max_output_token_length: 131072,
          },
          features: { structured_outputs: { json_object: true } },
        },
        {
          id: "embedding-model",
          task_type: ["Embedding"],
          modalities: {
            input_modalities: ["text"],
            output_modalities: ["embedding"],
          },
        },
        {
          id: "retired-chat-model",
          status: "Retired",
          task_type: ["TextGeneration"],
        },
      ],
    });

    expect(models).toHaveLength(1);
    expect(models[0]).toMatchObject({
      id: "doubao-seed-2-0-mini-260428",
      contextWindow: 262144,
      maxOutputTokens: 131072,
      supportsStructuredOutput: true,
      suggestedPricing: {
        profile: "doubao-seed-2.0-mini",
        currency: "cny",
      },
    });
  });
});
