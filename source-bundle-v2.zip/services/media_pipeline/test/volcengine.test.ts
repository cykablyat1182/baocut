import { afterEach, describe, expect, it, vi } from "vitest";

import type { AppConfig } from "../src/config.js";
import {
  extractJsonObject,
  lookupDictionaryStream,
  parseAsrResponse,
  translateCues,
} from "../src/volcengine.js";

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("SeedASR response parsing", () => {
  it("maps timed utterances to player subtitle cues", () => {
    const cues = parseAsrResponse(
      {
        result: {
          text: "Hello there. London is quiet.",
          utterances: [
            { start_time: 0, end_time: 1250, text: "Hello there." },
            {
              start_time: 1510,
              end_time: 3290,
              text: "London is quiet.",
            },
          ],
        },
      },
      "task",
    );

    expect(cues).toEqual([
      {
        id: "task-1",
        startMs: 0,
        endMs: 1250,
        original: "Hello there.",
        translation: "",
      },
      {
        id: "task-2",
        startMs: 1510,
        endMs: 3290,
        original: "London is quiet.",
        translation: "",
      },
    ]);
  });

  it("rejects a completed response without timed utterances", () => {
    expect(() => parseAsrResponse({ result: { text: "hello" } })).toThrow(
      /没有返回可用的分句时间轴/,
    );
  });
});

describe("Ark JSON extraction", () => {
  it("accepts fenced JSON and ignores surrounding whitespace", () => {
    expect(
      extractJsonObject('```json\n{"translations":[{"id":"1","text":"你好"}]}\n```'),
    ).toEqual({ translations: [{ id: "1", text: "你好" }] });
  });

  it("rejects prose without an object", () => {
    expect(() => extractJsonObject("No JSON available")).toThrow(
      /没有返回 JSON/,
    );
  });
});

describe("context-aware subtitle translation", () => {
  it("sends nearby cues as context but translates only the target batch", async () => {
    let requestBody: Record<string, unknown> | undefined;
    vi.stubGlobal(
      "fetch",
      vi.fn(async (_input: unknown, init?: RequestInit) => {
        const apiBody = JSON.parse(String(init?.body)) as {
          messages?: Array<{ role?: string; content?: string }>;
        };
        const userMessage = apiBody.messages?.find(
          (message) => message.role === "user",
        );
        requestBody = JSON.parse(
          userMessage?.content ?? "{}",
        ) as Record<string, unknown>;
        return new Response(
          JSON.stringify({
            choices: [
              {
                message: {
                  content: JSON.stringify({
                    translations: [{ id: "target", text: "穿过" }],
                  }),
                },
              },
            ],
            usage: { prompt_tokens: 20, completion_tokens: 4 },
          }),
          { status: 200, headers: { "content-type": "application/json" } },
        );
      }),
    );

    const config = {
      privateModel: {
        apiKey: "test-key",
        endpoint: "https://example.test/chat/completions",
        apiMode: "chat_completions",
        model: "deepseek-chat",
        maxOutputTokens: 600,
        timeoutMs: 5_000,
      },
    } as unknown as AppConfig;
    const translated = await translateCues(
      [
        {
          id: "previous",
          startMs: 0,
          endMs: 1_000,
          original: "I thought we were done here.",
          translation: "我以为到此为止了。",
        },
        {
          id: "target",
          startMs: 1_100,
          endMs: 2_000,
          original: "through",
          translation: "",
        },
        {
          id: "next",
          startMs: 2_100,
          endMs: 3_000,
          original: "the doors were already locked.",
          translation: "门已经锁上了。",
        },
      ],
      "en-US",
      "zh-CN",
      config,
    );

    expect(translated.value[1]?.translation).toBe("穿过");
    expect(requestBody?.previousSubtitles).toEqual([
      {
        id: "previous",
        text: "I thought we were done here.",
        translation: "我以为到此为止了。",
      },
    ]);
    expect(requestBody?.nextSubtitles).toEqual([
      {
        id: "next",
        text: "the doors were already locked.",
        translation: "门已经锁上了。",
      },
    ]);
    expect(requestBody?.subtitles).toEqual([
      { id: "target", text: "through" },
    ]);
  });
});

describe("streaming dictionary lookup", () => {
  it("publishes partial fields and returns the metered final entry", async () => {
    const output = JSON.stringify({
      word: "through",
      phonetic: "/θruː/",
      partOfSpeech: "介词",
      definition: "穿过门",
      example: "Go through the door.",
      exampleTranslation: "穿过这扇门。",
    });
    const definitionStart = output.indexOf('"definition":"') + '"definition":"'.length;
    const firstDeltaEnd = definitionStart + 1;
    const deltas = [output.slice(0, firstDeltaEnd), output.slice(firstDeltaEnd)];
    const events = deltas
      .map((content) =>
        `data: ${JSON.stringify({ choices: [{ delta: { content } }] })}\n\n`,
      )
      .join("");
    let requestBody: Record<string, unknown> | undefined;
    vi.stubGlobal(
      "fetch",
      vi.fn(async (_input: unknown, init?: RequestInit) => {
        requestBody = JSON.parse(String(init?.body)) as Record<string, unknown>;
        return new Response(`${events}data: [DONE]\n\n`, {
          status: 200,
          headers: { "content-type": "text/event-stream" },
        });
      }),
    );

    const partial: Array<Record<string, string>> = [];
    const result = await lookupDictionaryStream(
      "through",
      "Go through the door.",
      "zh-CN",
      {
        privateModel: {
          apiKey: "test-key",
          endpoint: "https://example.test/chat/completions",
          apiMode: "chat_completions",
          model: "deepseek-chat",
          maxOutputTokens: 600,
          timeoutMs: 5_000,
        },
      } as unknown as AppConfig,
      (fields) => partial.push(fields),
    );

    expect(requestBody?.stream).toBe(true);
    expect(result.value.definition).toBe("穿过门");
    expect(result.usage.inputTokens).toBeGreaterThan(0);
    expect(result.usage.outputTokens).toBeGreaterThan(0);
    expect(partial.some((fields) => fields.definition === "穿")).toBe(true);
  });
});
