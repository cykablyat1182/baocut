import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";

import Stripe from "stripe";
import { afterEach, describe, expect, it } from "vitest";

import {
  BillingService,
  calculateUsageCredits,
  calculateUsageQuote,
  estimateMaximumUsageCredits,
} from "../src/billing.js";
import { config } from "../src/config.js";
import { loadPrivateModelConfig } from "../src/private-model-config.js";
import { StripeBillingService } from "../src/stripe-billing.js";

const temporaryDirectories: string[] = [];

afterEach(async () => {
  await Promise.all(
    temporaryDirectories.splice(0).map((directory) =>
      rm(directory, { recursive: true, force: true }),
    ),
  );
});

describe("private model configuration", () => {
  it("loads the exported model and billing fields without exposing extras", async () => {
    const directory = await mkdtemp(path.join(tmpdir(), "yingyu-model-"));
    temporaryDirectories.push(directory);
    const file = path.join(directory, "model.private.json");
    await writeFile(
      file,
      JSON.stringify({
        billing: {
          InitialCredits: 50,
          InputCreditsPerThousandTokens: 2,
          MinimumBalanceToStart: 3,
          MinimumChargeCredits: 1,
          OutputCreditsPerThousandTokens: 4,
        },
        currentModel: {
          apiKey: "test-secret",
          endpoint: "https://model.example.test/v1",
          model: "private-model",
          maxOutputTokens: 2048,
          timeoutSeconds: 45,
        },
        client: { targetLanguage: "zh-CN" },
      }),
    );

    const loaded = loadPrivateModelConfig(file);
    expect(loaded.model.endpoint).toBe(
      "https://model.example.test/v1/chat/completions",
    );
    expect(loaded.model.timeoutMs).toBe(45_000);
    expect(loaded.model.apiMode).toBe("chat_completions");
    expect(loaded.pricing.initialCredits).toBe(50);
    expect(Object.keys(loaded)).toEqual(["model", "pricing"]);
  });

  it("keeps a Responses API endpoint intact", async () => {
    const directory = await mkdtemp(path.join(tmpdir(), "yingyu-responses-"));
    temporaryDirectories.push(directory);
    const file = path.join(directory, "responses.private.json");
    await writeFile(
      file,
      JSON.stringify({
        billing: {
          InitialCredits: 1,
          InputCreditsPerThousandTokens: 1,
          MinimumBalanceToStart: 1,
          MinimumChargeCredits: 1,
          OutputCreditsPerThousandTokens: 1,
        },
        currentModel: {
          apiKey: "test-secret",
          endpoint: "https://model.example.test/v3/responses",
          model: "private-model",
          maxOutputTokens: 900,
          timeoutSeconds: 60,
        },
      }),
    );
    const loaded = loadPrivateModelConfig(file);
    expect(loaded.model.endpoint).toBe(
      "https://model.example.test/v3/responses",
    );
    expect(loaded.model.apiMode).toBe("responses");
  });
});

describe("credit wallet", () => {
  it("prices each model call against its own input-length tier", () => {
    const tieredConfig = {
      ...config,
      modelPricing: {
        ...config.modelPricing,
        profile: "tier-test",
        tiers: [
          {
            upToInputTokens: 100,
            inputPerMillion: 1,
            outputPerMillion: 10,
          },
          {
            upToInputTokens: 1000,
            inputPerMillion: 2,
            outputPerMillion: 20,
          },
        ],
      },
    };
    const quote = calculateUsageQuote(
      {
        inputTokens: 160,
        outputTokens: 2,
        modelCalls: [
          { inputTokens: 80, outputTokens: 1 },
          { inputTokens: 80, outputTokens: 1 },
        ],
      },
      tieredConfig,
      {
        initialCredits: 0,
        minimumBalanceToStart: 0,
        minimumChargeCredits: 0,
        creditsPerCurrencyUnit: 1_000_000,
        markupMultiplier: 1,
      },
    );
    expect(quote).toMatchObject({
      providerCostMicros: 180,
      chargedCredits: 180,
      billedAmountMicros: 180,
    });
  });

  it("registers users, verifies passwords, and supports local admin management", async () => {
    const dataDir = await mkdtemp(path.join(tmpdir(), "yingyu-accounts-"));
    temporaryDirectories.push(dataDir);
    const testConfig = {
      ...config,
      dataDir,
      authTokenPepper: "account-test-pepper",
      usagePricing: {
        ...config.usagePricing,
        initialCredits: 12,
      },
    };
    const wallet = new BillingService(testConfig);

    await wallet.ensureBootstrapAdmin("local-admin", "admin-password-123");
    const administrator = await wallet.loginAdmin(
      "local-admin",
      "admin-password-123",
    );
    expect(administrator.account.profile.role).toBe("admin");

    const registered = await wallet.registerUser({
      username: "Alice_01",
      email: "Alice@example.com",
      displayName: "Alice",
      password: "user-password-123",
    });
    expect(registered.account.profile).toMatchObject({
      username: "Alice_01",
      email: "alice@example.com",
      emailVerified: true,
      displayName: "Alice",
      role: "user",
      isGuest: false,
    });
    expect(registered.account.balanceCredits).toBe(12);
    await expect(
      wallet.loginAdmin("alice_01", "user-password-123"),
    ).rejects.toMatchObject({ code: "invalid_credentials" });
    await expect(
      wallet.loginUser("alice_01", "wrong-password"),
    ).rejects.toMatchObject({ code: "invalid_credentials" });

    const loggedIn = await wallet.loginUser(
      "alice_01",
      "user-password-123",
    );
    expect(await wallet.authenticate(loggedIn.accessToken)).toBe(
      registered.account.accountId,
    );

    const listed = await wallet.listAccounts(
      administrator.account.accountId,
      "alice",
    );
    expect(listed).toHaveLength(1);
    expect(listed[0]?.displayName).toBe("Alice");
    expect(
      await wallet.listAccounts(
        administrator.account.accountId,
        "alice@example.com",
      ),
    ).toHaveLength(1);

    const guest = await wallet.registerDevice(
      "installation-0000000000100",
      "secret-00000000000000000000000000100",
    );
    await expect(
      wallet.updateAccount(
        administrator.account.accountId,
        guest.accountId,
        { role: "admin" },
      ),
    ).rejects.toMatchObject({ code: "guest_admin_forbidden" });

    const adjusted = await wallet.updateAccount(
      administrator.account.accountId,
      registered.account.accountId,
      { balanceAdjustment: 8 },
    );
    expect(adjusted.balanceCredits).toBe(20);
    await wallet.updateAccount(
      administrator.account.accountId,
      registered.account.accountId,
      { disabled: true },
    );
    expect(await wallet.authenticate(loggedIn.accessToken)).toBeUndefined();
    await expect(
      wallet.loginUser("alice_01", "user-password-123"),
    ).rejects.toMatchObject({ code: "account_disabled" });
    await expect(
      wallet.updateAccount(
        administrator.account.accountId,
        administrator.account.accountId,
        { disabled: true },
      ),
    ).rejects.toMatchObject({ code: "unsafe_self_update" });

    const persisted = await readFile(
      path.join(dataDir, "billing", "wallet.json"),
      "utf8",
    );
    expect(persisted).not.toContain("user-password-123");
    expect(persisted).not.toContain("admin-password-123");
  });

  it("aggregates per-account and global token, billing, and recharge totals", async () => {
    const dataDir = await mkdtemp(path.join(tmpdir(), "yingyu-overview-"));
    temporaryDirectories.push(dataDir);
    const testConfig = {
      ...config,
      dataDir,
      authTokenPepper: "overview-test-pepper",
      modelPricing: {
        ...config.modelPricing,
        profile: "billing-test",
        tiers: [
          {
            upToInputTokens: 1_000_000,
            inputPerMillion: 2000,
            outputPerMillion: 4000,
          },
        ],
      },
      usagePricing: {
        initialCredits: 0,
        inputCreditsPerThousandTokens: 2,
        minimumBalanceToStart: 1,
        minimumChargeCredits: 1,
        outputCreditsPerThousandTokens: 4,
        creditsPerCurrencyUnit: 1,
        markupMultiplier: 1,
      },
    };
    const wallet = new BillingService(testConfig);
    await wallet.ensureBootstrapAdmin("overview-admin", "admin-password-123");
    const administrator = await wallet.loginAdmin(
      "overview-admin",
      "admin-password-123",
    );
    const user = await wallet.registerUser({
      username: "usage-user",
      email: "usage@example.com",
      password: "user-password-123",
    });
    await wallet.creditPayment({
      accountId: user.account.accountId,
      credits: 100,
      externalId: "stripe-checkout:overview-session",
      description: "测试充值",
      amountMinor: 990,
      currency: "cny",
    });
    await wallet.runMetered(user.account.accountId, "测试查词", async () => ({
      value: "ok",
      usage: { inputTokens: 1000, outputTokens: 500 },
    }));

    const dashboard = await wallet.adminDashboard(
      administrator.account.accountId,
      "usage@example.com",
    );
    expect(dashboard.accounts).toHaveLength(1);
    expect(dashboard.accounts[0]).toMatchObject({
      balanceCredits: 96,
      usage: {
        inputTokens: 1000,
        outputTokens: 500,
        totalTokens: 1500,
        chargedCredits: 4,
        estimatedCredits: 4,
        cost: {
          currency: "cny",
          providerCostMicros: 4_000_000,
          actualBilledMicros: 4_000_000,
          estimatedBilledMicros: 4_000_000,
          grossProfitMicros: 0,
        },
      },
      funding: {
        topUpCredits: 100,
        topUpCount: 1,
        paidAmounts: [{ currency: "cny", amountMinor: 990 }],
      },
    });
    expect(dashboard.overview).toMatchObject({
      accountCount: 2,
      registeredAccountCount: 2,
      totalBalanceCredits: 96,
      usage: { totalTokens: 1500, chargedCredits: 4, estimatedCredits: 4 },
      funding: {
        topUpCredits: 100,
        topUpCount: 1,
        paidAmounts: [{ currency: "cny", amountMinor: 990 }],
      },
    });
    expect(dashboard.pricing).toMatchObject({
      profile: "billing-test",
      creditsPerCurrencyUnit: 1,
      markupMultiplier: 1,
    });

    const updatedPricing = await wallet.updatePricing(
      administrator.account.accountId,
      {
        initialCredits: 20,
        minimumBalanceToStart: 2,
        minimumChargeCredits: 1,
        creditsPerCurrencyUnit: 100,
        markupMultiplier: 2,
      },
    );
    expect(updatedPricing).toMatchObject({
      initialCredits: 20,
      creditsPerCurrencyUnit: 100,
      markupMultiplier: 2,
    });
    const reloadedWallet = new BillingService(testConfig);
    const repriced = await reloadedWallet.adminDashboard(
      administrator.account.accountId,
    );
    expect(repriced.overview.usage).toMatchObject({
      chargedCredits: 4,
      estimatedCredits: 800,
      cost: { estimatedBilledMicros: 8_000_000 },
    });
  });

  it("charges measured tokens and credits a payment only once", async () => {
    const dataDir = await mkdtemp(path.join(tmpdir(), "yingyu-wallet-"));
    temporaryDirectories.push(dataDir);
    const testConfig = {
      ...config,
      dataDir,
      authTokenPepper: "test-pepper",
      modelPricing: {
        ...config.modelPricing,
        profile: "billing-test",
        tiers: [
          {
            upToInputTokens: 1_000_000,
            inputPerMillion: 2000,
            outputPerMillion: 4000,
          },
        ],
      },
      usagePricing: {
        initialCredits: 20,
        inputCreditsPerThousandTokens: 2,
        minimumBalanceToStart: 1,
        minimumChargeCredits: 1,
        outputCreditsPerThousandTokens: 4,
        creditsPerCurrencyUnit: 1,
        markupMultiplier: 1,
      },
    };
    const wallet = new BillingService(testConfig);
    const registered = await wallet.registerDevice(
      "installation-0000000000001",
      "secret-00000000000000000000000000001",
    );

    expect(
      await wallet.authenticate(registered.accessToken),
    ).toBe(registered.accountId);
    expect(
      calculateUsageCredits(
        { inputTokens: 1000, outputTokens: 500 },
        testConfig,
      ),
    ).toBe(4);
    expect(
      estimateMaximumUsageCredits("hello", 1, testConfig),
    ).toBeGreaterThanOrEqual(4);
    await expect(
      wallet.runMetered(
        registered.accountId,
        "超额测试",
        async () => ({
          value: "should-not-run",
          usage: { inputTokens: 1, outputTokens: 1 },
        }),
        21,
      ),
    ).rejects.toMatchObject({ status: 402, code: "insufficient_credits" });

    const result = await wallet.runMetered(
      registered.accountId,
      "测试翻译",
      async () => ({
        value: "ok",
        usage: { inputTokens: 1000, outputTokens: 500 },
      }),
    );
    expect(result.billing.chargedCredits).toBe(4);
    expect(result.billing.balanceCredits).toBe(16);
    const publicAccount = await wallet.account(registered.accountId);
    expect(JSON.stringify(publicAccount.transactions)).not.toContain(
      "providerCost",
    );
    expect(JSON.stringify(publicAccount.transactions)).not.toContain(
      "pricingMarkupMultiplier",
    );

    expect(
      await wallet.creditPayment({
        accountId: registered.accountId,
        credits: 10,
        externalId: "stripe-checkout:test-session",
        description: "测试充值",
      }),
    ).toBe(true);
    expect(
      await wallet.creditPayment({
        accountId: registered.accountId,
        credits: 10,
        externalId: "stripe-checkout:test-session",
        description: "测试充值",
      }),
    ).toBe(false);
    expect((await wallet.account(registered.accountId)).balanceCredits).toBe(26);
  });

  it("persists the administrator-selected model and uses it for calls", async () => {
    const dataDir = await mkdtemp(path.join(tmpdir(), "yingyu-model-switch-"));
    temporaryDirectories.push(dataDir);
    const testConfig = {
      ...config,
      dataDir,
      authTokenPepper: "model-switch-test-pepper",
      usagePricing: {
        ...config.usagePricing,
        initialCredits: 100,
        minimumBalanceToStart: 0,
      },
    };
    const wallet = new BillingService(testConfig);
    await wallet.ensureBootstrapAdmin("model-admin", "admin-password-123");
    const administrator = await wallet.loginAdmin(
      "model-admin",
      "admin-password-123",
    );
    const user = await wallet.registerUser({
      username: "model-user",
      email: "model@example.com",
      password: "user-password-123",
    });

    await wallet.updateModel(administrator.account.accountId, {
      id: "doubao-seed-2-0-lite-260428",
      name: "doubao-seed-2.0-lite",
      maxOutputTokens: 4096,
      pricing: {
        profile: "doubao-seed-2.0-lite",
        currency: "cny",
        sourceUrl: "https://www.volcengine.com/product/doubao/",
        checkedAt: "2026-08-01",
        tiers: [
          {
            upToInputTokens: 32_000,
            inputPerMillion: 0.6,
            outputPerMillion: 3.6,
          },
        ],
      },
    });

    let calledModel = "";
    await wallet.runMetered(
      user.account.accountId,
      "模型切换测试",
      async (runtime) => {
        calledModel = runtime.privateModel.model;
        return {
          value: "ok",
          usage: { inputTokens: 100, outputTokens: 20 },
        };
      },
    );
    expect(calledModel).toBe("doubao-seed-2-0-lite-260428");

    const reloaded = new BillingService(testConfig);
    const active = await reloaded.adminModel(administrator.account.accountId);
    expect(active).toMatchObject({
      id: "doubao-seed-2-0-lite-260428",
      maxOutputTokens: 4096,
      pricing: {
        modelId: "doubao-seed-2-0-lite-260428",
        profile: "doubao-seed-2.0-lite",
      },
    });
  });

  it("accepts a signed paid Checkout event exactly once", async () => {
    const dataDir = await mkdtemp(path.join(tmpdir(), "yingyu-stripe-"));
    temporaryDirectories.push(dataDir);
    const webhookSecret = "whsec_test_secret";
    const testConfig = {
      ...config,
      dataDir,
      authTokenPepper: "test-pepper",
      stripeSecretKey: "sk_test_placeholder",
      stripeWebhookSecret: webhookSecret,
      stripeSuccessUrl: "https://example.test/success",
      stripeCancelUrl: "https://example.test/cancel",
      billingPackagesJson: JSON.stringify([
        {
          id: "starter",
          name: "入门额度",
          credits: 25,
          amountMinor: 500,
          currency: "cny",
        },
      ]),
      usagePricing: {
        ...config.usagePricing,
        initialCredits: 0,
      },
    };
    const wallet = new BillingService(testConfig);
    const registered = await wallet.registerDevice(
      "installation-0000000000002",
      "secret-00000000000000000000000000002",
    );
    const stripeBilling = new StripeBillingService(testConfig, wallet);
    const stripe = new Stripe(testConfig.stripeSecretKey);
    const payload = JSON.stringify({
      id: "evt_test_paid",
      object: "event",
      api_version: "2026-07-29.dahlia",
      created: 1_700_000_000,
      livemode: false,
      pending_webhooks: 1,
      type: "checkout.session.completed",
      data: {
        object: {
          id: "cs_test_paid",
          object: "checkout.session",
          payment_status: "paid",
          amount_total: 500,
          currency: "cny",
          metadata: {
            accountId: registered.accountId,
            packageId: "starter",
            credits: "25",
          },
        },
      },
    });
    const signature = stripe.webhooks.generateTestHeaderString({
      payload,
      secret: webhookSecret,
    });

    expect(
      await stripeBilling.handleWebhook(Buffer.from(payload), signature),
    ).toEqual({ received: true, credited: true });
    expect(
      await stripeBilling.handleWebhook(Buffer.from(payload), signature),
    ).toEqual({ received: true, credited: false });
    expect((await wallet.account(registered.accountId)).balanceCredits).toBe(25);
  });
});
