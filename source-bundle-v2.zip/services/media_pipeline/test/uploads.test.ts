import { createHash } from "node:crypto";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";

import { afterEach, describe, expect, it } from "vitest";

import { config } from "../src/config.js";
import {
  assembleUpload,
  chunkSize,
  computeUploadId,
  createOrResumeUpload,
  sanitizeFileName,
  storePart,
} from "../src/uploads.js";

const temporaryDirectories: string[] = [];

afterEach(async () => {
  await Promise.all(
    temporaryDirectories.splice(0).map((directory) =>
      rm(directory, { recursive: true, force: true }),
    ),
  );
});

describe("upload identity", () => {
  it("is deterministic for resumable uploads", () => {
    const metadata = {
      accountId: "test-account",
      fileName: "A Movie.mkv",
      size: 123_456_789,
      lastModifiedMs: 1_700_000_000_000,
    };
    expect(computeUploadId(metadata)).toBe(computeUploadId(metadata));
    expect(computeUploadId(metadata)).toMatch(/^[a-f0-9]{24}$/);
  });

  it("removes path traversal and invalid Windows filename characters", () => {
    expect(sanitizeFileName("../../bad:name?.mkv")).toBe("bad_name_.mkv");
  });

  it("stores, resumes and assembles verified chunks", async () => {
    const dataDir = await mkdtemp(path.join(tmpdir(), "yingyu-upload-"));
    temporaryDirectories.push(dataDir);
    const testConfig = { ...config, dataDir, maxUploadBytes: chunkSize * 2 };
    const first = Buffer.alloc(chunkSize, 0x61);
    const second = Buffer.from("the-end");
    const size = first.length + second.length;
    const session = await createOrResumeUpload(
      {
        accountId: "test-account",
        fileName: "lesson.mkv",
        size,
        lastModifiedMs: 1234,
      },
      testConfig,
    );

    await storePart(
      session.uploadId,
      0,
      first,
      `bytes 0-${first.length - 1}/${size}`,
      createHash("sha256").update(first).digest("hex"),
      testConfig,
    );
    await storePart(
      session.uploadId,
      1,
      second,
      `bytes ${first.length}-${size - 1}/${size}`,
      createHash("sha256").update(second).digest("hex"),
      testConfig,
    );

    const resumed = await createOrResumeUpload(
      {
        accountId: "test-account",
        fileName: "lesson.mkv",
        size,
        lastModifiedMs: 1234,
      },
      testConfig,
    );
    expect(resumed.receivedParts).toEqual([0, 1]);

    const assembled = await assembleUpload(session.uploadId, testConfig);
    const bytes = await readFile(assembled);
    expect(bytes.length).toBe(size);
    expect(bytes.subarray(-second.length)).toEqual(second);
  });
});
