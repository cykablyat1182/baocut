import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";

import { afterEach, describe, expect, it } from "vitest";

import { config } from "../src/config.js";
import {
  EmailVerificationService,
  type MailSender,
} from "../src/email-verification.js";

const temporaryDirectories: string[] = [];

afterEach(async () => {
  await Promise.all(
    temporaryDirectories.splice(0).map((directory) =>
      rm(directory, { recursive: true, force: true }),
    ),
  );
});

describe("email verification", () => {
  it("sends, validates, consumes, and rate-limits six-digit codes", async () => {
    const dataDir = await mkdtemp(path.join(tmpdir(), "yingyu-email-"));
    temporaryDirectories.push(dataDir);
    const messages: Array<{ to: string; text: string }> = [];
    const mailer: MailSender = {
      async sendMail(message) {
        messages.push({ to: message.to, text: message.text });
      },
    };
    const service = new EmailVerificationService(
      {
        ...config,
        dataDir,
        authTokenPepper: "email-test-pepper",
        smtpHost: "smtp.example.test",
        smtpPort: 587,
        smtpSecure: false,
        smtpUser: "",
        smtpPassword: "",
        smtpFrom: "YingYu <no-reply@example.test>",
        emailVerificationTtlSeconds: 600,
      },
      mailer,
    );

    await expect(service.request("Alice@Example.com")).resolves.toEqual({
      expiresInSeconds: 600,
    });
    expect(messages).toHaveLength(1);
    expect(messages[0]?.to).toBe("alice@example.com");
    const code = /\b(\d{6})\b/.exec(messages[0]?.text ?? "")?.[1];
    expect(code).toMatch(/^\d{6}$/);

    await expect(service.request("alice@example.com")).rejects.toMatchObject({
      code: "email_code_rate_limited",
    });
    await expect(
      service.consume("alice@example.com", "000000"),
    ).rejects.toMatchObject({ code: "invalid_email_code" });
    await expect(
      service.consume("alice@example.com", code ?? ""),
    ).resolves.toBeUndefined();
    await expect(
      service.consume("alice@example.com", code ?? ""),
    ).rejects.toMatchObject({ code: "invalid_email_code" });
  });
});
