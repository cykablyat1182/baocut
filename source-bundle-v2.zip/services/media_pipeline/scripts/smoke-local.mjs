import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { once } from "node:events";

const temporaryData = await mkdtemp(path.join(tmpdir(), "yingyu-smoke-"));
process.env.HOST = "127.0.0.1";
process.env.DATA_DIR = temporaryData;
process.env.LOCAL_ADMIN_USERNAME = "smoke_admin";
process.env.LOCAL_ADMIN_PASSWORD = "temporary-admin-password-123";

const { createApp, initializeApp } = await import("../dist/server.js");
await initializeApp();
const server = createApp().listen(0, "127.0.0.1");

async function request(baseUrl, route, options = {}) {
  const response = await fetch(`${baseUrl}${route}`, options);
  const body = response.status === 204 ? {} : await response.json();
  if (!response.ok) {
    throw new Error(`${route}: ${response.status} ${body.error ?? ""}`);
  }
  return body;
}

try {
  await once(server, "listening");
  const address = server.address();
  if (!address || typeof address === "string") {
    throw new Error("temporary server address is unavailable");
  }
  const baseUrl = `http://127.0.0.1:${address.port}`;
  const health = await request(baseUrl, "/health");
  const login = await request(baseUrl, "/api/admin/auth/login", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      username: "smoke_admin",
      password: "temporary-admin-password-123",
    }),
  });
  const authorization = `Bearer ${login.accessToken}`;
  const accountId = login.account.accountId;
  const accounts = await request(baseUrl, "/api/admin/accounts", {
    headers: { authorization },
  });
  await request(baseUrl, `/api/admin/accounts/${accountId}`, {
    method: "PATCH",
    headers: {
      authorization,
      "content-type": "application/json",
    },
    body: JSON.stringify({ balanceAdjustment: 1000 }),
  });

  const result = {
    health: health.status,
    administratorRole: login.account.profile.role,
    managedAccounts: accounts.accounts.length,
    emailVerificationConfigured: health.emailVerificationConfigured,
  };
  if (process.env.SMOKE_DICTIONARY === "1") {
    const dictionary = await request(baseUrl, "/api/dictionary", {
      method: "POST",
      headers: {
        authorization,
        "content-type": "application/json; charset=utf-8",
      },
      body: JSON.stringify({
        word: "対偶福音",
        sentence: "対偶福音の規約",
        targetLanguage: "zh-CN",
      }),
    });
    result.dictionaryWord = dictionary.entry.word;
    result.definitionCharacters = dictionary.entry.definition.length;
    result.chargedCredits = dictionary.billing.chargedCredits;
  }
  console.log(JSON.stringify(result));
} finally {
  await new Promise((resolve) => server.close(resolve));
  await rm(temporaryData, { recursive: true, force: true });
}
