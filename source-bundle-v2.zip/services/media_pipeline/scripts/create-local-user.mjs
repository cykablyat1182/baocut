import { BillingError, BillingService } from "../dist/billing.js";
import { config } from "../dist/config.js";

const username = process.env.CREATE_USERNAME || "";
const password = process.env.CREATE_PASSWORD || "";
const email = process.env.CREATE_EMAIL || "";
if (!username || !password || !email) {
  throw new Error("CREATE_USERNAME, CREATE_PASSWORD and CREATE_EMAIL are required");
}

const billing = new BillingService(config);
try {
  await billing.registerUser({ username, password, email, displayName: username });
  console.log(JSON.stringify({ created: true, username }));
} catch (error) {
  if (error instanceof BillingError && error.code === "username_taken") {
    console.log(JSON.stringify({ created: false, username, reason: "exists" }));
  } else {
    throw error;
  }
}
