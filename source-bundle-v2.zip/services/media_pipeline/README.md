# 影语字幕处理与额度服务

Node.js/TypeScript 服务负责原生播放器之外的云端工作：

```text
匿名设备账户 / 邮箱验证注册 / 独立管理端
  ├─ 已有字幕 → 私有模型翻译 / 上下文查词 → Token 计费
  └─ 无字幕视频 → 分片续传 → FFmpeg → TOS → SeedASR 2.0
                                     → 私有模型翻译 → 双语时间轴
```

模型名称、上游地址和 API Key 不会进入面向普通用户的播放器、健康检查、错误响应或日志。独立管理端只会收到经过筛选的模型目录与模型 ID，不会收到上游地址或 API Key。面向用户公开的是服务价格：账户接口返回输入/输出每千 Token 的额度费率，每次模型调用也返回本次 Token 数、扣除额度和余额。经营者可以让服务费率高于上游成本形成毛利，但不能隐瞒实际扣费。

## 私有模型配置

推荐直接读取 ScreenLingo 导出的私有文件，不复制其中的密钥：

```dotenv
MODEL_CONFIG_PATH=C:/Users/you/AppData/Local/ScreenLingo/private/current-model-config.private.json
```

服务兼容配置中指向 `/responses` 的 Responses API，以及 OpenAI 兼容的 `/chat/completions`。如果不提供该文件，也可使用 `.env.example` 中的 `ARK_API_KEY`、`ARK_MODEL` 与 `ARK_BASE_URL` 兼容配置。

从源码目录直接启动 Windows 播放器时，播放器会自动探测并启动
`services/media_pipeline/dist/server.js`。本机专用的模型配置放在被忽略的
`.env.local`，例如 DeepSeek 的 OpenAI 兼容接口：

```dotenv
MODEL_CONFIG_PATH=
ARK_API_KEY=你的 DeepSeek Key
ARK_MODEL=deepseek-chat
ARK_BASE_URL=https://api.deepseek.com
```

播放器启动本机服务时会优先读取 `.env.local`，避免系统中遗留的
`ARK_*` 环境变量覆盖当前测试模型；远程服务和手动 `npm run start` 仍按
`.env` 配置运行。

服务会按模型官方的“每百万 Token”分档价格先计算供应商成本，再通过“每货币单位点数 × 成本倍率”换算用户扣点。`doubao-seed-2.1-pro/turbo`、`Seed-Evolving`、`2.0-mini/lite/pro/Code` 与 `1.6-flash` 已内置官方价格；其他模型可通过 `MODEL_PRICING_TIERS_JSON` 配置，或在管理端切换时填写目录价。默认换算为 `100 点 = 1 CNY`、成本倍率 `2`，环境变量只提供首次默认值，管理端保存的运行时模型与费率优先。

管理端模型目录通过当前 Ark 凭据读取 `/api/v3/models`，只保留支持文本输入、文本输出及 `TextGeneration` 的可用模型。模型切换写入 `DATA_DIR/billing/wallet.json` 并立即用于后续字幕翻译、查词和自动字幕翻译；正在执行的调用继续使用启动时的模型快照，避免中途切换造成错账。

SeedASR 自动生成功能还需要：

- `VOLC_SPEECH_API_KEY`
- `VOLC_SPEECH_RESOURCE_ID=volc.seedasr.auc`
- `TOS_ACCESS_KEY_ID`、`TOS_SECRET_ACCESS_KEY`、`TOS_BUCKET`
- `FFMPEG_PATH`

TOS Bucket 应保持私有；临时音轨识别后会从 TOS 和本机清理。

## 邮箱验证、独立管理端与计费

服务默认只监听 `127.0.0.1:8787`，可直接作为本机临时账户服务器。播放器只允许注册 `user` 普通账户，并强制使用电子邮箱验证码；注册请求不能提交或提升角色。密码通过 `scrypt` 加盐哈希保存，访问令牌保存在 Android Keystore 或 Windows Credential Manager，服务端只保存令牌摘要。生产环境必须设置随机的 `AUTH_TOKEN_PEPPER`。

邮件通过标准 SMTP 发送，验证码默认 10 分钟失效、60 秒内不可重复发送、最多尝试 5 次。最少需要配置：

```dotenv
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=no-reply@example.com
SMTP_PASSWORD=邮件服务授权码
SMTP_FROM=影语 <no-reply@example.com>
```

管理员不会通过播放器注册，也不能使用普通用户登录入口登录。管理员账户仅由服务端显式配置：

```dotenv
LOCAL_ADMIN_USERNAME=admin
LOCAL_ADMIN_PASSWORD=至少八位的独立密码
```

使用 `apps/yingyu_admin` 构建得到的独立 Windows 原生管理程序登录 `/api/admin/auth/login`，可以检索账户、调整额度、停用账户、分配管理员权限、切换运行模型，以及调整点数换算、成本倍率、最低扣点、最低余额与新账户赠送额度。管理员令牌只保留在管理程序内存中；播放器中没有管理页面或管理 API 客户端。

管理接口同时按账户和全局汇总输入 Token、输出 Token、Token 总量、模型官方目录价预估、历史实际扣点及折算金额、按当前费率重新估算的扣点及金额、扣点与目录价的价差、累计充值额度、充值次数以及 Stripe 实收金额。新模型调用会把模型价格与点数换算快照写入账本；历史记录缺少快照时使用当前官方价格估算。资源包、商务折扣和税费由上游账单结算，目录价预估不冒充实际现金支出；扣点折算金额也不等于已收现金，现金收款以 Stripe 实收汇总为准。升级前已经写入且未记录币种和支付金额的旧充值仍会计入充值额度，但不会反推实收金额。

如果需要让实体 Android 设备临时访问电脑，可将 `HOST` 设置为电脑的局域网地址或 `0.0.0.0`，在播放器中填写 `http://电脑局域网IP:8787`。HTTP 仅适合可信局域网临时调试；正式使用应由 HTTPS 反向代理提供 TLS。

钱包数据以原子替换方式保存在 `DATA_DIR/billing/wallet.json`，适合单实例部署。多实例正式商用时应迁移到支持事务和唯一约束的数据库。

一次性额度充值使用 Stripe Checkout：

```dotenv
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_SUCCESS_URL=https://your-domain.example/payment/success?session_id={CHECKOUT_SESSION_ID}
STRIPE_CANCEL_URL=https://your-domain.example/payment/cancel
BILLING_PACKAGES_JSON=[{"id":"starter","name":"入门额度","description":"用于字幕翻译与查词","credits":1000,"amountMinor":990,"currency":"cny"}]
```

上例只展示字段格式，不代表建议售价。客户端只能提交套餐 ID；金额和额度均由服务端套餐决定。支付完成后，只有通过 Stripe 签名校验且 `payment_status=paid` 的 Webhook 才会入账，同一 Checkout Session 重复通知不会重复充值。

Webhook 地址：

```text
POST /api/billing/stripe/webhook
```

## 启动与验证

```powershell
cd services/media_pipeline
npm install
Copy-Item .env.example .env
npm run dev
```

```powershell
Invoke-RestMethod http://127.0.0.1:8787/health
npm run check
npm test
npm run build
npm run smoke:local
```

如需同时验证当前私有模型的中日文查词链路，可在本机执行（会产生一次实际模型用量）：

```powershell
$env:SMOKE_DICTIONARY='1'
npm run smoke:local
```

## API

除健康检查、注册登录和 Stripe Webhook 外，所有 `/api` 请求都必须携带 Bearer Token。

| 方法 | 路径 | 用途 |
|---|---|---|
| `POST` | `/api/auth/device` | 注册或恢复匿名设备账户 |
| `POST` | `/api/auth/email/request-code` | 向未注册邮箱发送注册验证码 |
| `POST` | `/api/auth/register` | 使用邮箱验证码注册普通账户 |
| `POST` | `/api/auth/login` | 普通用户登录并轮换访问令牌 |
| `POST` | `/api/admin/auth/login` | 独立管理端登录；拒绝普通用户 |
| `GET` | `/api/auth/me` | 当前账户资料、额度与角色 |
| `POST` | `/api/auth/logout` | 注销当前访问令牌 |
| `GET` | `/api/admin/accounts` | 管理员检索账户及全局 Token、计费、充值汇总 |
| `PATCH` | `/api/admin/accounts/:id` | 调整额度、状态或角色 |
| `PATCH` | `/api/admin/pricing` | 调整点数换算、成本倍率及最低扣点策略 |
| `GET` | `/api/admin/models` | 读取上游可用文本模型及当前运行模型 |
| `PATCH` | `/api/admin/model` | 持久化切换运行模型和对应目录价 |
| `GET` | `/api/billing/account` | 余额、公开费率和最近记录 |
| `GET` | `/api/billing/packages` | 服务端定义的充值套餐 |
| `POST` | `/api/billing/checkout` | 创建一次性 Stripe Checkout |
| `POST` | `/api/uploads` | 创建或恢复账户隔离的上传 |
| `PUT` | `/api/uploads/:id/parts/:index` | 上传带 SHA-256 的 4 MB 分片 |
| `POST` | `/api/uploads/:id/complete` | 合并媒体并创建处理任务 |
| `GET` | `/api/jobs/:id` | 查询识别、翻译和对齐进度 |
| `POST` | `/api/translate` | 将已有单语字幕翻译为双语并结算 |
| `POST` | `/api/translate/stream` | 以 SSE 分批返回字幕译文，完成后返回完整时间轴与结算信息 |
| `POST` | `/api/dictionary/stream` | 以 SSE 返回逐字段词典释义与结算信息 |
| `POST` | `/api/dictionary` | 上下文查词并结算 |

生产环境还应启用 TLS、备份、服务级限流和支付告警。不得把 `.env`、私有模型配置、Stripe 密钥或钱包数据提交到仓库。
