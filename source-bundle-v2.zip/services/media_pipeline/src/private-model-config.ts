import { readFileSync } from "node:fs";

import { z } from "zod";

const positiveRate = z.coerce.number().finite().nonnegative();

const exportedModelConfigSchema = z.object({
  billing: z.object({
    InitialCredits: z.coerce.number().int().nonnegative(),
    InputCreditsPerThousandTokens: positiveRate,
    MinimumBalanceToStart: z.coerce.number().int().nonnegative(),
    MinimumChargeCredits: z.coerce.number().int().nonnegative(),
    OutputCreditsPerThousandTokens: positiveRate,
  }),
  currentModel: z.object({
    apiKey: z.string().trim().min(1),
    endpoint: z.string().trim().url(),
    model: z.string().trim().min(1),
    maxOutputTokens: z.coerce.number().int().positive().max(131_072),
    timeoutSeconds: z.coerce.number().int().positive().max(600),
  }),
});

export type UsagePricing = {
  initialCredits: number;
  inputCreditsPerThousandTokens: number;
  minimumBalanceToStart: number;
  minimumChargeCredits: number;
  outputCreditsPerThousandTokens: number;
};

export type PrivateModelRuntime = {
  apiKey: string;
  endpoint: string;
  apiMode: "chat_completions" | "responses";
  model: string;
  maxOutputTokens: number;
  timeoutMs: number;
};

export type LoadedPrivateModelConfig = {
  model: PrivateModelRuntime;
  pricing: UsagePricing;
};

function normalizedEndpoint(endpoint: string): {
  endpoint: string;
  apiMode: PrivateModelRuntime["apiMode"];
} {
  const normalized = endpoint.replace(/\/+$/, "");
  if (normalized.endsWith("/responses")) {
    return { endpoint: normalized, apiMode: "responses" };
  }
  return {
    endpoint: normalized.endsWith("/chat/completions")
      ? normalized
      : `${normalized}/chat/completions`,
    apiMode: "chat_completions",
  };
}

export function loadPrivateModelConfig(
  filePath: string,
): LoadedPrivateModelConfig {
  let parsedJson: unknown;
  try {
    parsedJson = JSON.parse(readFileSync(filePath, "utf8")) as unknown;
  } catch {
    throw new Error("私有模型配置无法读取或不是有效 JSON。");
  }

  const parsed = exportedModelConfigSchema.safeParse(parsedJson);
  if (!parsed.success) {
    throw new Error("私有模型配置缺少必要字段或字段格式无效。");
  }

  const endpoint = normalizedEndpoint(parsed.data.currentModel.endpoint);
  return {
    model: {
      apiKey: parsed.data.currentModel.apiKey,
      ...endpoint,
      model: parsed.data.currentModel.model,
      maxOutputTokens: parsed.data.currentModel.maxOutputTokens,
      timeoutMs: parsed.data.currentModel.timeoutSeconds * 1000,
    },
    pricing: {
      initialCredits: parsed.data.billing.InitialCredits,
      inputCreditsPerThousandTokens:
        parsed.data.billing.InputCreditsPerThousandTokens,
      minimumBalanceToStart: parsed.data.billing.MinimumBalanceToStart,
      minimumChargeCredits: parsed.data.billing.MinimumChargeCredits,
      outputCreditsPerThousandTokens:
        parsed.data.billing.OutputCreditsPerThousandTokens,
    },
  };
}
