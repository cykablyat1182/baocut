import { z } from "zod";

import type { UsagePricing } from "./private-model-config.js";

export type ModelPriceTier = {
  upToInputTokens: number;
  inputPerMillion: number;
  outputPerMillion: number;
};

export type ModelPricing = {
  profile: string;
  currency: string;
  tiers: ModelPriceTier[];
  sourceUrl: string | null;
  checkedAt: string | null;
};

const tiersSchema = z
  .array(
    z.object({
      upToInputTokens: z.number().int().positive(),
      inputPerMillion: z.number().finite().nonnegative(),
      outputPerMillion: z.number().finite().nonnegative(),
    }),
  )
  .min(1)
  .max(16)
  .refine(
    (tiers) =>
      tiers.every(
        (tier, index) =>
          index === 0 ||
          tier.upToInputTokens > (tiers[index - 1]?.upToInputTokens ?? 0),
      ),
    "模型价格分档必须按输入 Token 上限递增",
  );

const officialPricingSource =
  "https://www.volcengine.com/docs/84458/1585097?lang=zh&redirect=1";
const currentProductPricingSource =
  "https://www.volcengine.com/product/doubao";

const doubaoSeed20Mini: ModelPricing = {
  profile: "doubao-seed-2.0-mini",
  currency: "cny",
  tiers: [
    {
      upToInputTokens: 32_000,
      inputPerMillion: 0.2,
      outputPerMillion: 2,
    },
    {
      upToInputTokens: 128_000,
      inputPerMillion: 0.4,
      outputPerMillion: 4,
    },
    {
      upToInputTokens: 256_000,
      inputPerMillion: 0.8,
      outputPerMillion: 8,
    },
  ],
  sourceUrl: officialPricingSource,
  checkedAt: "2026-08-01",
};

const doubaoSeed20Lite: ModelPricing = {
  profile: "doubao-seed-2.0-lite",
  currency: "cny",
  tiers: [
    { upToInputTokens: 32_000, inputPerMillion: 0.6, outputPerMillion: 3.6 },
    { upToInputTokens: 128_000, inputPerMillion: 0.9, outputPerMillion: 5.4 },
    { upToInputTokens: 256_000, inputPerMillion: 1.8, outputPerMillion: 10.8 },
  ],
  sourceUrl: officialPricingSource,
  checkedAt: "2026-08-01",
};

const doubaoSeed20Pro: ModelPricing = {
  profile: "doubao-seed-2.0-pro",
  currency: "cny",
  tiers: [
    { upToInputTokens: 32_000, inputPerMillion: 3.2, outputPerMillion: 16 },
    { upToInputTokens: 128_000, inputPerMillion: 4.8, outputPerMillion: 24 },
    { upToInputTokens: 256_000, inputPerMillion: 9.6, outputPerMillion: 48 },
  ],
  sourceUrl: officialPricingSource,
  checkedAt: "2026-08-01",
};

const doubaoSeed16Flash: ModelPricing = {
  profile: "doubao-seed-1.6-flash",
  currency: "cny",
  tiers: [
    { upToInputTokens: 32_000, inputPerMillion: 0.15, outputPerMillion: 1.5 },
    { upToInputTokens: 128_000, inputPerMillion: 0.3, outputPerMillion: 3 },
    { upToInputTokens: 256_000, inputPerMillion: 0.6, outputPerMillion: 6 },
  ],
  sourceUrl: officialPricingSource,
  checkedAt: "2026-08-01",
};

const doubaoSeed21Pro: ModelPricing = {
  profile: "doubao-seed-2.1-pro",
  currency: "cny",
  tiers: [
    { upToInputTokens: 262_144, inputPerMillion: 6, outputPerMillion: 30 },
  ],
  sourceUrl: currentProductPricingSource,
  checkedAt: "2026-08-01",
};

const doubaoSeed21Turbo: ModelPricing = {
  profile: "doubao-seed-2.1-turbo",
  currency: "cny",
  tiers: [
    { upToInputTokens: 262_144, inputPerMillion: 3, outputPerMillion: 15 },
  ],
  sourceUrl: currentProductPricingSource,
  checkedAt: "2026-08-01",
};

function copyPricing(pricing: ModelPricing): ModelPricing {
  return {
    ...pricing,
    tiers: pricing.tiers.map((tier) => ({ ...tier })),
  };
}

/** Returns an official built-in price table only when the model can be matched safely. */
export function resolveKnownModelPricing(
  modelName: string,
): ModelPricing | undefined {
  const normalized = modelName.toLocaleLowerCase("en-US");
  if (/doubao[-_]seed[-_]2[-_.]?0[-_]mini/.test(normalized)) {
    return copyPricing(doubaoSeed20Mini);
  }
  if (/doubao[-_]seed[-_]2[-_.]?0[-_]lite/.test(normalized)) {
    return copyPricing(doubaoSeed20Lite);
  }
  if (
    /doubao[-_]seed[-_]2[-_.]?0[-_](?:pro|code)/.test(normalized)
  ) {
    return copyPricing(doubaoSeed20Pro);
  }
  if (/doubao[-_]seed[-_]1[-_.]?6[-_]flash/.test(normalized)) {
    return copyPricing(doubaoSeed16Flash);
  }
  if (
    /doubao[-_]seed[-_]2[-_.]?1[-_]pro/.test(normalized) ||
    /doubao[-_]seed[-_]evolving/.test(normalized)
  ) {
    return copyPricing(doubaoSeed21Pro);
  }
  if (/doubao[-_]seed[-_]2[-_.]?1[-_]turbo/.test(normalized)) {
    return copyPricing(doubaoSeed21Turbo);
  }
  return undefined;
}

function customPricing(
  serialized: string,
  profile: string,
  currency: string,
): ModelPricing | undefined {
  if (!serialized.trim()) return undefined;
  let value: unknown;
  try {
    value = JSON.parse(serialized) as unknown;
  } catch {
    throw new Error("MODEL_PRICING_TIERS_JSON 不是有效 JSON。");
  }
  const parsed = tiersSchema.safeParse(value);
  if (!parsed.success) {
    throw new Error("MODEL_PRICING_TIERS_JSON 的模型价格分档无效。");
  }
  return {
    profile: profile === "auto" ? "custom" : profile,
    currency,
    tiers: parsed.data,
    sourceUrl: null,
    checkedAt: null,
  };
}

export function resolveModelPricing(input: {
  modelName: string;
  profile: string;
  currency: string;
  serializedTiers: string;
  legacyPricing: UsagePricing;
  creditsPerCurrencyUnit: number;
  markupMultiplier: number;
}): ModelPricing {
  const custom = customPricing(
    input.serializedTiers,
    input.profile,
    input.currency,
  );
  if (custom) return custom;

  const known = resolveKnownModelPricing(input.modelName);
  if (
    input.profile === "doubao-seed-2.0-mini" ||
    (input.profile === "auto" && known)
  ) {
    return input.profile === "doubao-seed-2.0-mini"
      ? copyPricing(doubaoSeed20Mini)
      : known!;
  }
  if (input.profile !== "auto" && input.profile !== "legacy") {
    throw new Error(
      `未知 MODEL_PRICING_PROFILE：${input.profile}，请同时配置 MODEL_PRICING_TIERS_JSON。`,
    );
  }

  const divisor = input.creditsPerCurrencyUnit * input.markupMultiplier;
  return {
    profile: "legacy-credit-rates",
    currency: input.currency,
    tiers: [
      {
        upToInputTokens: 1_000_000,
        inputPerMillion:
          (input.legacyPricing.inputCreditsPerThousandTokens * 1000) / divisor,
        outputPerMillion:
          (input.legacyPricing.outputCreditsPerThousandTokens * 1000) / divisor,
      },
    ],
    sourceUrl: null,
    checkedAt: null,
  };
}
