import type { AppConfig } from "./config.js";
import {
  resolveKnownModelPricing,
  type ModelPricing,
} from "./model-pricing.js";

export type AvailableModel = {
  id: string;
  name: string;
  version: string | null;
  domain: string | null;
  status: string | null;
  taskTypes: string[];
  contextWindow: number | null;
  maxInputTokens: number | null;
  maxOutputTokens: number | null;
  supportsStructuredOutput: boolean;
  suggestedPricing: ModelPricing | null;
};

export type ModelCatalogView = {
  models: AvailableModel[];
  source: "provider" | "configured";
  refreshedAt: string;
  warning: string | null;
};

type CachedCatalog = ModelCatalogView & { expiresAt: number };

function record(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : undefined;
}

function strings(value: unknown): string[] {
  return Array.isArray(value)
    ? value.filter((item): item is string => typeof item === "string")
    : typeof value === "string"
      ? [value]
      : [];
}

function positiveInteger(...values: unknown[]): number | null {
  for (const value of values) {
    if (typeof value === "number" && Number.isFinite(value) && value > 0) {
      return Math.floor(value);
    }
  }
  return null;
}

function supportsJson(raw: Record<string, unknown>): boolean {
  const features = record(raw.features);
  const structured = record(
    raw.structured_outputs ?? features?.structured_outputs,
  );
  const capabilities = record(raw.capabilities);
  return Boolean(
    raw.supports_structured_output ??
      structured?.json_object ??
      structured?.json_schema ??
      capabilities?.structured_outputs,
  );
}

export function parseCompatibleModels(payload: unknown): AvailableModel[] {
  const root = record(payload);
  const source = Array.isArray(root?.data) ? root.data : [];
  const models: AvailableModel[] = [];
  for (const item of source) {
    const raw = record(item);
    if (!raw || typeof raw.id !== "string" || !raw.id.trim()) continue;
    const taskTypes = strings(raw.task_type ?? raw.task_types);
    if (
      taskTypes.length > 0 &&
      !taskTypes.some((task) => task.toLowerCase() === "textgeneration")
    ) {
      continue;
    }
    const modalities = record(raw.modalities);
    const inputModalities = strings(
      modalities?.input_modalities ?? raw.input_modalities,
    ).map((value) => value.toLowerCase());
    const outputModalities = strings(
      modalities?.output_modalities ?? raw.output_modalities,
    ).map((value) => value.toLowerCase());
    if (inputModalities.length > 0 && !inputModalities.includes("text")) {
      continue;
    }
    if (outputModalities.length > 0 && !outputModalities.includes("text")) {
      continue;
    }
    const status = typeof raw.status === "string" ? raw.status : null;
    if (status && /^(?:retired|deprecated|offline)$/i.test(status)) continue;
    const tokenLimits = record(raw.token_limits);
    const id = raw.id.trim();
    models.push({
      id,
      name:
        typeof raw.name === "string" && raw.name.trim()
          ? raw.name.trim()
          : id,
      version:
        typeof raw.version === "string" && raw.version.trim()
          ? raw.version.trim()
          : null,
      domain:
        typeof raw.domain === "string" && raw.domain.trim()
          ? raw.domain.trim()
          : null,
      status,
      taskTypes,
      contextWindow: positiveInteger(
        tokenLimits?.context_window,
        tokenLimits?.context_length,
        raw.context_window,
      ),
      maxInputTokens: positiveInteger(
        tokenLimits?.max_input_tokens,
        tokenLimits?.max_input_token_length,
        raw.max_input_tokens,
      ),
      maxOutputTokens: positiveInteger(
        tokenLimits?.max_output_tokens,
        tokenLimits?.max_output_token_length,
        raw.max_output_tokens,
      ),
      supportsStructuredOutput: supportsJson(raw),
      suggestedPricing: resolveKnownModelPricing(id) ?? null,
    });
  }
  return models.sort((left, right) => {
    const leftDoubao = left.id.startsWith("doubao-") ? 0 : 1;
    const rightDoubao = right.id.startsWith("doubao-") ? 0 : 1;
    return leftDoubao - rightDoubao || right.id.localeCompare(left.id);
  });
}

function modelsEndpoint(endpoint: string): string {
  const url = new URL(endpoint);
  url.pathname = url.pathname.replace(
    /\/(?:chat\/completions|responses)\/?$/,
    "/models",
  );
  url.search = "";
  url.hash = "";
  return url.toString();
}

function configuredFallback(value: AppConfig, warning: string | null): ModelCatalogView {
  const now = new Date().toISOString();
  return {
    models: value.privateModel.model
      ? [
          {
            id: value.privateModel.model,
            name: value.privateModel.model,
            version: null,
            domain: null,
            status: null,
            taskTypes: ["TextGeneration"],
            contextWindow: null,
            maxInputTokens: null,
            maxOutputTokens: value.privateModel.maxOutputTokens,
            supportsStructuredOutput: true,
            suggestedPricing: resolveKnownModelPricing(
              value.privateModel.model,
            ) ?? null,
          },
        ]
      : [],
    source: "configured",
    refreshedAt: now,
    warning,
  };
}

export class ModelCatalogService {
  private cache?: CachedCatalog;

  constructor(private readonly value: AppConfig) {}

  async list(forceRefresh = false): Promise<ModelCatalogView> {
    if (!forceRefresh && this.cache && this.cache.expiresAt > Date.now()) {
      const { expiresAt: _expiresAt, ...view } = this.cache;
      return view;
    }
    if (!this.value.privateModel.apiKey || !this.value.privateModel.endpoint) {
      return configuredFallback(this.value, "模型服务尚未配置，暂时只能显示本地默认模型。");
    }
    try {
      const response = await fetch(modelsEndpoint(this.value.privateModel.endpoint), {
        headers: {
          authorization: `Bearer ${this.value.privateModel.apiKey}`,
          accept: "application/json",
        },
        signal: AbortSignal.timeout(
          Math.min(30_000, this.value.privateModel.timeoutMs),
        ),
      });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const models = parseCompatibleModels(await response.json());
      if (models.length === 0) throw new Error("empty model catalog");
      const now = new Date().toISOString();
      const view: ModelCatalogView = {
        models,
        source: "provider",
        refreshedAt: now,
        warning: null,
      };
      this.cache = { ...view, expiresAt: Date.now() + 5 * 60_000 };
      return view;
    } catch {
      if (this.cache) {
        const { expiresAt: _expiresAt, ...cached } = this.cache;
        return {
          ...cached,
          warning: "模型目录刷新失败，当前显示最近一次成功读取的结果。",
        };
      }
      return configuredFallback(
        this.value,
        "无法读取模型服务目录，当前仅显示本地默认模型。",
      );
    }
  }
}
