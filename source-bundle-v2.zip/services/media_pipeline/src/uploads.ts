import { createHash, randomUUID } from "node:crypto";
import path from "node:path";
import {
  mkdir,
  open,
  readFile,
  readdir,
  rename,
  rm,
  stat,
  writeFile,
} from "node:fs/promises";

import type { AppConfig } from "./config.js";
import type { UploadMetadata } from "./types.js";

export const chunkSize = 4 * 1024 * 1024;

function uploadRoot(value: AppConfig): string {
  return path.join(value.dataDir, "uploads");
}

function safeUploadId(uploadId: string): void {
  if (!/^[a-f0-9]{24}$/.test(uploadId)) {
    throw new Error("无效的上传任务 ID。");
  }
}

function uploadDirectory(uploadId: string, value: AppConfig): string {
  safeUploadId(uploadId);
  return path.join(uploadRoot(value), uploadId);
}

export function sanitizeFileName(fileName: string): string {
  const base = path.basename(fileName).replace(/[<>:"/\\|?*\u0000-\u001f]/g, "_");
  const normalized = base.replace(/^\.+/, "").trim();
  return (normalized || "media.bin").slice(0, 180);
}

export function computeUploadId(input: {
  accountId: string;
  fileName: string;
  size: number;
  lastModifiedMs: number;
}): string {
  return createHash("sha256")
    .update(
      `${input.accountId}\0${input.fileName}\0${input.size}\0${input.lastModifiedMs}`,
    )
    .digest("hex")
    .slice(0, 24);
}

export async function createOrResumeUpload(
  input: {
    accountId: string;
    fileName: string;
    size: number;
    lastModifiedMs: number;
  },
  value: AppConfig,
): Promise<{ uploadId: string; receivedParts: number[] }> {
  if (input.size <= 0 || input.size > value.maxUploadBytes) {
    throw new Error(
      `媒体大小必须在 1 字节到 ${value.maxUploadBytes} 字节之间。`,
    );
  }
  const uploadId = computeUploadId(input);
  const directory = uploadDirectory(uploadId, value);
  const partsDirectory = path.join(directory, "parts");
  await mkdir(partsDirectory, { recursive: true });
  const metadata: UploadMetadata = {
    uploadId,
    accountId: input.accountId,
    fileName: input.fileName,
    safeFileName: sanitizeFileName(input.fileName),
    size: input.size,
    lastModifiedMs: input.lastModifiedMs,
    createdAt: new Date().toISOString(),
  };
  const metadataPath = path.join(directory, "metadata.json");
  try {
    const existing = JSON.parse(
      await readFile(metadataPath, "utf8"),
    ) as UploadMetadata;
    if (
      existing.size !== metadata.size ||
      existing.accountId !== metadata.accountId ||
      existing.fileName !== metadata.fileName ||
      existing.lastModifiedMs !== metadata.lastModifiedMs
    ) {
      throw new Error("上传任务元数据不一致。");
    }
  } catch (error) {
    const code = (error as NodeJS.ErrnoException).code;
    if (code !== "ENOENT") throw error;
    await writeFile(metadataPath, JSON.stringify(metadata, null, 2), {
      flag: "wx",
    });
  }

  const files = await readdir(partsDirectory);
  const receivedParts = files
    .map((file) => /^part-(\d+)\.bin$/.exec(file))
    .filter((match): match is RegExpExecArray => match !== null)
    .map((match) => Number(match[1]))
    .filter(Number.isSafeInteger)
    .sort((a, b) => a - b);
  return { uploadId, receivedParts };
}

export async function readUploadMetadata(
  uploadId: string,
  value: AppConfig,
): Promise<UploadMetadata> {
  const file = path.join(uploadDirectory(uploadId, value), "metadata.json");
  return JSON.parse(await readFile(file, "utf8")) as UploadMetadata;
}

export async function storePart(
  uploadId: string,
  partIndex: number,
  bytes: Buffer,
  contentRange: string,
  expectedHash: string,
  value: AppConfig,
): Promise<void> {
  if (!Number.isSafeInteger(partIndex) || partIndex < 0) {
    throw new Error("无效的分片序号。");
  }
  if (bytes.length === 0 || bytes.length > chunkSize) {
    throw new Error("分片大小无效。");
  }
  const metadata = await readUploadMetadata(uploadId, value);
  const match = /^bytes (\d+)-(\d+)\/(\d+)$/.exec(contentRange);
  if (!match) throw new Error("Content-Range 格式无效。");
  const start = Number(match[1]);
  const endInclusive = Number(match[2]);
  const total = Number(match[3]);
  if (
    start !== partIndex * chunkSize ||
    endInclusive - start + 1 !== bytes.length ||
    total !== metadata.size ||
    endInclusive >= total
  ) {
    throw new Error("分片范围与上传任务不一致。");
  }
  const actualHash = createHash("sha256").update(bytes).digest("hex");
  if (actualHash !== expectedHash.toLowerCase()) {
    throw new Error("分片 SHA-256 校验失败。");
  }

  const partsDirectory = path.join(uploadDirectory(uploadId, value), "parts");
  const destination = path.join(partsDirectory, `part-${partIndex}.bin`);
  try {
    const existing = await readFile(destination);
    const existingHash = createHash("sha256").update(existing).digest("hex");
    if (existing.length === bytes.length && existingHash === actualHash) return;
    throw new Error(`分片 ${partIndex + 1} 已存在但校验值不同。`);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
  }

  const temporary = `${destination}.${randomUUID()}.tmp`;
  try {
    await writeFile(temporary, bytes, { flag: "wx" });
    await rename(temporary, destination);
  } catch (error) {
    const code = (error as NodeJS.ErrnoException).code;
    if (code !== "EEXIST" && code !== "EPERM") throw error;
    const existing = await readFile(destination);
    const existingHash = createHash("sha256").update(existing).digest("hex");
    if (existing.length !== bytes.length || existingHash !== actualHash) {
      throw error;
    }
  } finally {
    await rm(temporary, { force: true }).catch(() => undefined);
  }
}

export async function assembleUpload(
  uploadId: string,
  value: AppConfig,
): Promise<string> {
  const metadata = await readUploadMetadata(uploadId, value);
  const directory = uploadDirectory(uploadId, value);
  const partCount = Math.ceil(metadata.size / chunkSize);
  const destination = path.join(directory, metadata.safeFileName);
  try {
    const existing = await stat(destination);
    if (existing.size === metadata.size) return destination;
    throw new Error("已合并媒体的大小与上传任务不一致。");
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
  }
  const temporary = path.join(directory, `assembled.${randomUUID()}.tmp`);
  const output = await open(temporary, "w");
  let totalWritten = 0;
  let assemblyError: unknown;
  try {
    for (let index = 0; index < partCount; index += 1) {
      const partPath = path.join(directory, "parts", `part-${index}.bin`);
      const part = await readFile(partPath);
      const expectedSize =
        index === partCount - 1
          ? metadata.size - index * chunkSize
          : chunkSize;
      if (part.length !== expectedSize) {
        throw new Error(`分片 ${index + 1} 大小不正确。`);
      }
      await output.write(part, 0, part.length, totalWritten);
      totalWritten += part.length;
    }
  } catch (error) {
    assemblyError = error;
  } finally {
    await output.close();
  }
  if (assemblyError) {
    await rm(temporary, { force: true });
    throw assemblyError;
  }
  if (totalWritten !== metadata.size) {
    throw new Error("合并后的文件大小与上传任务不一致。");
  }
  await rename(temporary, destination);
  const assembled = await stat(destination);
  if (assembled.size !== metadata.size) {
    throw new Error("合并后的媒体文件校验失败。");
  }
  return destination;
}

export function uploadJobMarkerPath(
  uploadId: string,
  value: AppConfig,
): string {
  return path.join(uploadDirectory(uploadId, value), "job.json");
}
