import {
  createHash,
  randomBytes,
  randomUUID,
  scrypt,
  timingSafeEqual,
} from "node:crypto";
import path from "node:path";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";

import type { AppConfig } from "./config.js";
import type { ModelPricing } from "./model-pricing.js";
import type {
  MeteredResult,
  ModelCallUsage,
  ModelUsage,
} from "./types.js";

type LedgerKind =
  | "initial_grant"
  | "model_usage"
  | "top_up"
  | "admin_adjustment";

export type AccountRole = "user" | "admin";

type StoredAccount = {
  id: string;
  installationIdHash?: string;
  installationSecretHash?: string;
  username?: string;
  usernameNormalized?: string;
  email?: string;
  emailNormalized?: string;
  emailVerifiedAt?: string;
  displayName?: string;
  passwordSalt?: string;
  passwordHash?: string;
  role?: AccountRole;
  disabled?: boolean;
  accessTokenHash: string;
  balanceCredits: number;
  createdAt: string;
  updatedAt: string;
};

type LedgerEntry = {
  id: string;
  accountId: string;
  kind: LedgerKind;
  deltaCredits: number;
  balanceAfter: number;
  description: string;
  inputTokens?: number;
  outputTokens?: number;
  modelCalls?: ModelCallUsage[];
  externalId?: string;
  paymentAmountMinor?: number;
  paymentCurrency?: string;
  providerCostMicros?: number;
  providerCostCurrency?: string;
  billedAmountMicros?: number;
  pricingCreditsPerCurrencyUnit?: number;
  pricingMarkupMultiplier?: number;
  modelId?: string;
  modelPricingProfile?: string;
  createdAt: string;
};

export type PricingPolicy = {
  initialCredits: number;
  minimumBalanceToStart: number;
  minimumChargeCredits: number;
  creditsPerCurrencyUnit: number;
  markupMultiplier: number;
};

type StoredPricingPolicy = PricingPolicy & {
  updatedAt: string;
};

type StoredModelSelection = {
  id: string;
  name: string;
  maxOutputTokens: number;
  pricing: ModelPricing;
  updatedAt: string;
};

type BillingDatabase = {
  version: 1;
  accounts: StoredAccount[];
  ledger: LedgerEntry[];
  processedExternalIds: string[];
  pricingPolicy?: StoredPricingPolicy;
  modelSelection?: StoredModelSelection;
};

function modelFamily(value: string): string | undefined {
  const normalized = value.toLocaleLowerCase("en-US");
  if (normalized.includes("deepseek")) return "deepseek";
  if (normalized.includes("doubao") || normalized.includes("seed-")) {
    return "doubao";
  }
  return undefined;
}

function providerFamily(endpoint: string): string | undefined {
  const normalized = endpoint.toLocaleLowerCase("en-US");
  if (normalized.includes("deepseek")) return "deepseek";
  if (normalized.includes("volces.com") || normalized.includes("ark.cn")) {
    return "doubao";
  }
  return undefined;
}

function isModelSelectionCompatible(
  selection: StoredModelSelection,
  runtime: AppConfig,
): boolean {
  const configuredFamily =
    providerFamily(runtime.privateModel.endpoint) ??
    modelFamily(runtime.privateModel.model);
  const selectedFamily = modelFamily(selection.id);
  // A persisted admin selection may predate a provider change in .env. Do not
  // send a stale Doubao ID to a DeepSeek endpoint (or the reverse); the
  // configured runtime model is the safe fallback until the admin selects a
  // model from the new provider.
  return !configuredFamily || !selectedFamily || configuredFamily === selectedFamily;
}

export type AccountProfile = {
  username: string | null;
  email: string | null;
  emailVerified: boolean;
  displayName: string;
  role: AccountRole;
  isGuest: boolean;
  disabled: boolean;
};

export type AccountTransaction = {
  id: string;
  kind: LedgerKind;
  deltaCredits: number;
  balanceAfter: number;
  description: string;
  inputTokens?: number;
  outputTokens?: number;
  createdAt: string;
};

export type AccountView = {
  accountId: string;
  profile: AccountProfile;
  balanceCredits: number;
  pricing: {
    inputCreditsPerThousandTokens: number;
    outputCreditsPerThousandTokens: number;
    minimumChargeCredits: number;
    minimumBalanceToStart: number;
  };
  transactions: AccountTransaction[];
};

export type ManagedAccountView = {
  accountId: string;
  username: string | null;
  email: string | null;
  emailVerified: boolean;
  displayName: string;
  role: AccountRole;
  isGuest: boolean;
  disabled: boolean;
  balanceCredits: number;
  usage: AccountUsageView;
  funding: AccountFundingView;
  createdAt: string;
  updatedAt: string;
};

export type AccountUsageView = {
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
  chargedCredits: number;
  estimatedCredits: number;
  cost: UsageCostView;
};

export type UsageCostView = {
  currency: string;
  providerCostMicros: number;
  actualBilledMicros: number;
  estimatedBilledMicros: number;
  grossProfitMicros: number;
};

export type PaidAmountView = {
  currency: string;
  amountMinor: number;
};

export type AccountFundingView = {
  initialGrantCredits: number;
  topUpCredits: number;
  topUpCount: number;
  adminAdjustmentCredits: number;
  paidAmounts: PaidAmountView[];
};

export type AdminOverviewView = {
  accountCount: number;
  registeredAccountCount: number;
  verifiedEmailCount: number;
  disabledAccountCount: number;
  totalBalanceCredits: number;
  usage: AccountUsageView;
  funding: AccountFundingView;
};

export type AdminDashboardView = {
  accounts: ManagedAccountView[];
  overview: AdminOverviewView;
  pricing: AdminPricingView;
};

export type AdminPricingView = PricingPolicy & {
  modelId: string;
  profile: string;
  currency: string;
  sourceUrl: string | null;
  checkedAt: string | null;
  tiers: Array<{
    upToInputTokens: number;
    inputPerMillion: number;
    outputPerMillion: number;
  }>;
  updatedAt: string | null;
};

export type AdminModelView = {
  id: string;
  name: string;
  maxOutputTokens: number;
  updatedAt: string | null;
  pricing: AdminPricingView;
};

export type ModelSelectionInput = {
  id: string;
  name: string;
  maxOutputTokens: number;
  pricing: ModelPricing;
};

export type UsageCharge = {
  chargedCredits: number;
  balanceCredits: number;
  inputTokens: number;
  outputTokens: number;
};

export type UsageQuote = {
  chargedCredits: number;
  providerCostMicros: number;
  billedAmountMicros: number;
  currency: string;
};

export class BillingError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly code: string,
  ) {
    super(message);
  }
}

function blankDatabase(): BillingDatabase {
  return {
    version: 1,
    accounts: [],
    ledger: [],
    processedExternalIds: [],
  };
}

function blankUsage(currency = "cny"): AccountUsageView {
  return {
    inputTokens: 0,
    outputTokens: 0,
    totalTokens: 0,
    chargedCredits: 0,
    estimatedCredits: 0,
    cost: {
      currency,
      providerCostMicros: 0,
      actualBilledMicros: 0,
      estimatedBilledMicros: 0,
      grossProfitMicros: 0,
    },
  };
}

function blankFunding(): AccountFundingView {
  return {
    initialGrantCredits: 0,
    topUpCredits: 0,
    topUpCount: 0,
    adminAdjustmentCredits: 0,
    paidAmounts: [],
  };
}

function addPaidAmount(
  amounts: PaidAmountView[],
  currency: string,
  amountMinor: number,
): void {
  const normalized = currency.toLocaleLowerCase("en-US");
  const existing = amounts.find((item) => item.currency === normalized);
  if (existing) {
    existing.amountMinor += amountMinor;
  } else {
    amounts.push({ currency: normalized, amountMinor });
  }
}

function safeHexEqual(left?: string, right?: string): boolean {
  if (!left || !right) return false;
  const leftBuffer = Buffer.from(left, "hex");
  const rightBuffer = Buffer.from(right, "hex");
  return (
    leftBuffer.length === rightBuffer.length &&
    timingSafeEqual(leftBuffer, rightBuffer)
  );
}

function safeEncodedEqual(left?: string, right?: string): boolean {
  if (!left || !right) return false;
  const leftBuffer = Buffer.from(left, "base64url");
  const rightBuffer = Buffer.from(right, "base64url");
  return (
    leftBuffer.length === rightBuffer.length &&
    timingSafeEqual(leftBuffer, rightBuffer)
  );
}

function normalizeUsername(username: string): string {
  return username.normalize("NFKC").trim().toLocaleLowerCase("en-US");
}

function normalizeAccountEmail(email: string): string {
  return email.normalize("NFKC").trim().toLocaleLowerCase("en-US");
}

function derivePassword(
  password: string,
  salt: string,
  pepper: string,
): Promise<string> {
  return new Promise((resolve, reject) => {
    scrypt(`${password}\0${pepper}`, salt, 64, (error, derivedKey) => {
      if (error) {
        reject(error);
        return;
      }
      resolve(Buffer.from(derivedKey).toString("base64url"));
    });
  });
}

function defaultPricingPolicy(value: AppConfig): PricingPolicy {
  return {
    initialCredits: value.usagePricing.initialCredits,
    minimumBalanceToStart: value.usagePricing.minimumBalanceToStart,
    minimumChargeCredits: value.usagePricing.minimumChargeCredits,
    creditsPerCurrencyUnit: value.usagePricing.creditsPerCurrencyUnit,
    markupMultiplier: value.usagePricing.markupMultiplier,
  };
}

export function calculateUsageQuote(
  usage: ModelUsage,
  value: AppConfig,
  policy: PricingPolicy = defaultPricingPolicy(value),
): UsageQuote {
  if (usage.modelCalls?.length) {
    return usage.modelCalls.reduce<UsageQuote>(
      (total, call) => {
        const quote = calculateUsageQuote(call, value, policy);
        total.chargedCredits += quote.chargedCredits;
        total.providerCostMicros += quote.providerCostMicros;
        total.billedAmountMicros += quote.billedAmountMicros;
        return total;
      },
      {
        chargedCredits: 0,
        providerCostMicros: 0,
        billedAmountMicros: 0,
        currency: value.modelPricing.currency,
      },
    );
  }
  const inputTokens = Math.max(0, Math.ceil(usage.inputTokens));
  const outputTokens = Math.max(0, Math.ceil(usage.outputTokens));
  if (inputTokens <= 0 && outputTokens <= 0) {
    return {
      chargedCredits: 0,
      providerCostMicros: 0,
      billedAmountMicros: 0,
      currency: value.modelPricing.currency,
    };
  }
  const tier =
    value.modelPricing.tiers.find(
      (candidate) => inputTokens <= candidate.upToInputTokens,
    ) ?? value.modelPricing.tiers[value.modelPricing.tiers.length - 1]!;
  // 单价单位是“货币/百万 Token”。换算成微货币后，数值恰好为
  // token 数乘以对应单价，最后向上取整以避免低估供应商成本。
  const providerCostMicros = Math.ceil(
    inputTokens * tier.inputPerMillion +
      outputTokens * tier.outputPerMillion,
  );
  const variableCredits = Math.ceil(
    (providerCostMicros *
      policy.creditsPerCurrencyUnit *
      policy.markupMultiplier) /
      1_000_000,
  );
  const chargedCredits = Math.max(
    policy.minimumChargeCredits,
    variableCredits,
  );
  return {
    chargedCredits,
    providerCostMicros,
    billedAmountMicros: Math.ceil(
      (chargedCredits * 1_000_000) / policy.creditsPerCurrencyUnit,
    ),
    currency: value.modelPricing.currency,
  };
}

export function calculateUsageCredits(
  usage: ModelUsage,
  value: AppConfig,
): number {
  return calculateUsageQuote(usage, value).chargedCredits;
}

function repriceProviderCost(
  providerCostMicros: number,
  modelCallCount: number,
  currency: string,
  policy: PricingPolicy,
): UsageQuote {
  const variableCredits = Math.ceil(
    (providerCostMicros *
      policy.creditsPerCurrencyUnit *
      policy.markupMultiplier) /
      1_000_000,
  );
  const chargedCredits = Math.max(
    policy.minimumChargeCredits * Math.max(1, modelCallCount),
    variableCredits,
  );
  return {
    chargedCredits,
    providerCostMicros,
    billedAmountMicros: Math.ceil(
      (chargedCredits * 1_000_000) / policy.creditsPerCurrencyUnit,
    ),
    currency,
  };
}

export function estimateMaximumUsageCredits(
  serializedInput: string,
  modelCalls: number,
  value: AppConfig,
  policy: PricingPolicy = defaultPricingPolicy(value),
): number {
  const calls = Math.max(1, Math.ceil(modelCalls));
  const conservativeInputTokens =
    Math.ceil(Buffer.byteLength(serializedInput, "utf8") / 2) + calls * 400;
  const inputPerCall = Math.ceil(conservativeInputTokens / calls);
  return calculateUsageQuote(
    {
      inputTokens: conservativeInputTokens,
      outputTokens: value.privateModel.maxOutputTokens * calls,
      modelCalls: Array.from({ length: calls }, () => ({
        inputTokens: inputPerCall,
        outputTokens: value.privateModel.maxOutputTokens,
      })),
    },
    value,
    policy,
  ).chargedCredits;
}

export class BillingService {
  private readonly databasePath: string;
  private database?: BillingDatabase;
  private storageTail: Promise<void> = Promise.resolve();
  private readonly accountTails = new Map<string, Promise<void>>();

  constructor(private readonly value: AppConfig) {
    this.databasePath = path.join(value.dataDir, "billing", "wallet.json");
  }

  private effectivePricing(database: BillingDatabase): PricingPolicy {
    return database.pricingPolicy ?? defaultPricingPolicy(this.value);
  }

  private compatibleModelSelection(
    database: BillingDatabase,
  ): StoredModelSelection | undefined {
    const selection = database.modelSelection;
    return selection && isModelSelectionCompatible(selection, this.value)
      ? selection
      : undefined;
  }

  private effectiveModelPricing(database: BillingDatabase): ModelPricing {
    return this.compatibleModelSelection(database)?.pricing ?? this.value.modelPricing;
  }

  private effectiveRuntimeConfig(database: BillingDatabase): AppConfig {
    const selection = this.compatibleModelSelection(database);
    return {
      ...this.value,
      privateModel: selection
        ? {
            ...this.value.privateModel,
            model: selection.id,
            maxOutputTokens: selection.maxOutputTokens,
          }
        : this.value.privateModel,
      modelPricing: this.effectiveModelPricing(database),
    };
  }

  private pricingView(database: BillingDatabase): AdminPricingView {
    const policy = this.effectivePricing(database);
    const modelPricing = this.effectiveModelPricing(database);
    const selection = this.compatibleModelSelection(database);
    return {
      ...policy,
      modelId: selection?.id ?? this.value.privateModel.model,
      profile: modelPricing.profile,
      currency: modelPricing.currency,
      sourceUrl: modelPricing.sourceUrl,
      checkedAt: modelPricing.checkedAt,
      tiers: modelPricing.tiers.map((tier) => ({ ...tier })),
      updatedAt: database.pricingPolicy?.updatedAt ?? null,
    };
  }

  private modelView(database: BillingDatabase): AdminModelView {
    const selection = this.compatibleModelSelection(database);
    return {
      id: selection?.id ?? this.value.privateModel.model,
      name: selection?.name ?? this.value.privateModel.model,
      maxOutputTokens:
        selection?.maxOutputTokens ?? this.value.privateModel.maxOutputTokens,
      updatedAt: selection?.updatedAt ?? null,
      pricing: this.pricingView(database),
    };
  }

  private hash(secret: string): string {
    return createHash("sha256")
      .update(this.value.authTokenPepper)
      .update("\0")
      .update(secret)
      .digest("hex");
  }

  private async load(): Promise<BillingDatabase> {
    if (this.database) return this.database;
    try {
      const parsed = JSON.parse(
        await readFile(this.databasePath, "utf8"),
      ) as BillingDatabase;
      if (
        parsed.version !== 1 ||
        !Array.isArray(parsed.accounts) ||
        !Array.isArray(parsed.ledger) ||
        !Array.isArray(parsed.processedExternalIds)
      ) {
        throw new Error("invalid billing database");
      }
      for (const account of parsed.accounts) {
        account.role ??= "user";
        account.disabled ??= false;
      }
      this.database = parsed;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") {
        throw new Error("额度与账户数据库无法读取。");
      }
      this.database = blankDatabase();
    }
    return this.database;
  }

  private async persist(database: BillingDatabase): Promise<void> {
    await mkdir(path.dirname(this.databasePath), { recursive: true });
    const temporary = `${this.databasePath}.${process.pid}.${randomUUID()}.tmp`;
    await writeFile(temporary, JSON.stringify(database, null, 2), {
      encoding: "utf8",
      mode: 0o600,
    });
    await rename(temporary, this.databasePath);
  }

  private exclusive<T>(
    action: (database: BillingDatabase) => Promise<T> | T,
  ): Promise<T> {
    const result = this.storageTail.then(
      async () => action(await this.load()),
      async () => action(await this.load()),
    );
    this.storageTail = result.then(
      () => undefined,
      () => undefined,
    );
    return result;
  }

  private serializeAccount<T>(
    accountId: string,
    action: () => Promise<T>,
  ): Promise<T> {
    const previous = this.accountTails.get(accountId) ?? Promise.resolve();
    const result = previous.then(action, action);
    const tail = result.then(
      () => undefined,
      () => undefined,
    );
    this.accountTails.set(accountId, tail);
    return result.finally(() => {
      if (this.accountTails.get(accountId) === tail) {
        this.accountTails.delete(accountId);
      }
    });
  }

  private profile(account: StoredAccount): AccountProfile {
    return {
      username: account.username ?? null,
      email: account.email ?? null,
      emailVerified: Boolean(account.emailVerifiedAt),
      displayName: account.displayName ?? account.username ?? "访客账户",
      role: account.role ?? "user",
      isGuest: !account.usernameNormalized,
      disabled: account.disabled ?? false,
    };
  }

  private ledgerStatistics(
    database: BillingDatabase,
  ): Map<string, { usage: AccountUsageView; funding: AccountFundingView }> {
    const runtimeConfig = this.effectiveRuntimeConfig(database);
    const pricingPolicy = this.effectivePricing(database);
    const statistics = new Map<
      string,
      { usage: AccountUsageView; funding: AccountFundingView }
    >();
    const forAccount = (accountId: string) => {
      let current = statistics.get(accountId);
      if (!current) {
        current = {
          usage: blankUsage(runtimeConfig.modelPricing.currency),
          funding: blankFunding(),
        };
        statistics.set(accountId, current);
      }
      return current;
    };

    for (const entry of database.ledger) {
      const current = forAccount(entry.accountId);
      if (entry.kind === "model_usage") {
        const inputTokens = Math.max(0, entry.inputTokens ?? 0);
        const outputTokens = Math.max(0, entry.outputTokens ?? 0);
        current.usage.inputTokens += inputTokens;
        current.usage.outputTokens += outputTokens;
        current.usage.totalTokens += inputTokens + outputTokens;
        const chargedCredits = Math.max(0, -entry.deltaCredits);
        const fallbackQuote = calculateUsageQuote(
          {
            inputTokens,
            outputTokens,
            ...(entry.modelCalls?.length
              ? { modelCalls: entry.modelCalls }
              : {}),
          },
          runtimeConfig,
          pricingPolicy,
        );
        const historicalCreditsPerCurrencyUnit =
          entry.pricingCreditsPerCurrencyUnit ??
          pricingPolicy.creditsPerCurrencyUnit;
        const providerCostMicros =
          entry.providerCostMicros ?? fallbackQuote.providerCostMicros;
        const currentQuote = repriceProviderCost(
          providerCostMicros,
          entry.modelCalls?.length ?? 1,
          entry.providerCostCurrency ?? runtimeConfig.modelPricing.currency,
          pricingPolicy,
        );
        const actualBilledMicros =
          entry.billedAmountMicros ??
          Math.ceil(
            (chargedCredits * 1_000_000) /
              historicalCreditsPerCurrencyUnit,
          );
        current.usage.chargedCredits += chargedCredits;
        current.usage.estimatedCredits += currentQuote.chargedCredits;
        current.usage.cost.providerCostMicros += providerCostMicros;
        current.usage.cost.actualBilledMicros += actualBilledMicros;
        current.usage.cost.estimatedBilledMicros +=
          currentQuote.billedAmountMicros;
        current.usage.cost.grossProfitMicros +=
          actualBilledMicros - providerCostMicros;
        continue;
      }
      if (entry.kind === "initial_grant") {
        current.funding.initialGrantCredits += Math.max(0, entry.deltaCredits);
        continue;
      }
      if (entry.kind === "admin_adjustment") {
        current.funding.adminAdjustmentCredits += entry.deltaCredits;
        continue;
      }
      if (entry.kind === "top_up") {
        current.funding.topUpCredits += Math.max(0, entry.deltaCredits);
        current.funding.topUpCount += 1;
        if (
          entry.paymentCurrency &&
          Number.isInteger(entry.paymentAmountMinor) &&
          (entry.paymentAmountMinor ?? 0) > 0
        ) {
          addPaidAmount(
            current.funding.paidAmounts,
            entry.paymentCurrency,
            entry.paymentAmountMinor ?? 0,
          );
        }
      }
    }
    return statistics;
  }

  private managed(
    account: StoredAccount,
    statistics: Map<
      string,
      { usage: AccountUsageView; funding: AccountFundingView }
    >,
    currency = this.value.modelPricing.currency,
  ): ManagedAccountView {
    const totals = statistics.get(account.id) ?? {
      usage: blankUsage(currency),
      funding: blankFunding(),
    };
    return {
      accountId: account.id,
      ...this.profile(account),
      balanceCredits: account.balanceCredits,
      usage: totals.usage,
      funding: totals.funding,
      createdAt: account.createdAt,
      updatedAt: account.updatedAt,
    };
  }

  private adminOverview(
    database: BillingDatabase,
    statistics: Map<
      string,
      { usage: AccountUsageView; funding: AccountFundingView }
    >,
  ): AdminOverviewView {
    const overview: AdminOverviewView = {
      accountCount: database.accounts.length,
      registeredAccountCount: 0,
      verifiedEmailCount: 0,
      disabledAccountCount: 0,
      totalBalanceCredits: 0,
      usage: blankUsage(this.effectiveModelPricing(database).currency),
      funding: blankFunding(),
    };
    for (const account of database.accounts) {
      if (account.usernameNormalized) overview.registeredAccountCount += 1;
      if (account.emailVerifiedAt) overview.verifiedEmailCount += 1;
      if (account.disabled) overview.disabledAccountCount += 1;
      overview.totalBalanceCredits += account.balanceCredits;
      const totals = statistics.get(account.id);
      if (!totals) continue;
      overview.usage.inputTokens += totals.usage.inputTokens;
      overview.usage.outputTokens += totals.usage.outputTokens;
      overview.usage.totalTokens += totals.usage.totalTokens;
      overview.usage.chargedCredits += totals.usage.chargedCredits;
      overview.usage.estimatedCredits += totals.usage.estimatedCredits;
      overview.usage.cost.providerCostMicros +=
        totals.usage.cost.providerCostMicros;
      overview.usage.cost.actualBilledMicros +=
        totals.usage.cost.actualBilledMicros;
      overview.usage.cost.estimatedBilledMicros +=
        totals.usage.cost.estimatedBilledMicros;
      overview.usage.cost.grossProfitMicros +=
        totals.usage.cost.grossProfitMicros;
      overview.funding.initialGrantCredits +=
        totals.funding.initialGrantCredits;
      overview.funding.topUpCredits += totals.funding.topUpCredits;
      overview.funding.topUpCount += totals.funding.topUpCount;
      overview.funding.adminAdjustmentCredits +=
        totals.funding.adminAdjustmentCredits;
      for (const paid of totals.funding.paidAmounts) {
        addPaidAmount(
          overview.funding.paidAmounts,
          paid.currency,
          paid.amountMinor,
        );
      }
    }
    overview.funding.paidAmounts.sort((left, right) =>
      left.currency.localeCompare(right.currency),
    );
    return overview;
  }

  private issueAccessToken(account: StoredAccount): string {
    const accessToken = randomBytes(32).toString("base64url");
    account.accessTokenHash = this.hash(accessToken);
    account.updatedAt = new Date().toISOString();
    return accessToken;
  }

  private addInitialGrant(
    database: BillingDatabase,
    account: StoredAccount,
    description: string,
  ): void {
    if (account.balanceCredits <= 0) return;
    database.ledger.push({
      id: randomUUID(),
      accountId: account.id,
      kind: "initial_grant",
      deltaCredits: account.balanceCredits,
      balanceAfter: account.balanceCredits,
      description,
      createdAt: account.createdAt,
    });
  }

  async registerDevice(
    installationId: string,
    installationSecret: string,
  ): Promise<{ accountId: string; accessToken: string; balanceCredits: number }> {
    return this.exclusive(async (database) => {
      const idHash = this.hash(installationId);
      const secretHash = this.hash(installationSecret);
      const existing = database.accounts.find((item) =>
        safeHexEqual(item.installationIdHash, idHash),
      );

      if (existing) {
        if (!safeHexEqual(existing.installationSecretHash, secretHash)) {
          throw new BillingError("设备身份验证失败。", 401, "invalid_device");
        }
        if (existing.disabled) {
          throw new BillingError("此账户已被停用。", 403, "account_disabled");
        }
        const accessToken = this.issueAccessToken(existing);
        await this.persist(database);
        return {
          accountId: existing.id,
          accessToken,
          balanceCredits: existing.balanceCredits,
        };
      }

      const now = new Date().toISOString();
      const account: StoredAccount = {
        id: randomUUID(),
        installationIdHash: idHash,
        installationSecretHash: secretHash,
        role: "user",
        disabled: false,
        accessTokenHash: "",
        balanceCredits: this.effectivePricing(database).initialCredits,
        createdAt: now,
        updatedAt: now,
      };
      const accessToken = this.issueAccessToken(account);
      database.accounts.push(account);
      this.addInitialGrant(database, account, "新设备体验额度");
      await this.persist(database);
      return {
        accountId: account.id,
        accessToken,
        balanceCredits: account.balanceCredits,
      };
    });
  }

  async registerUser(input: {
    username: string;
    email: string;
    displayName?: string | undefined;
    password: string;
  }): Promise<{ accessToken: string; account: AccountView }> {
    return this.exclusive(async (database) => {
      const username = input.username.normalize("NFKC").trim();
      const usernameNormalized = normalizeUsername(username);
      const email = normalizeAccountEmail(input.email);
      if (
        database.accounts.some(
          (item) => item.usernameNormalized === usernameNormalized,
        )
      ) {
        throw new BillingError("该用户名已被使用。", 409, "username_taken");
      }
      if (
        database.accounts.some((item) => item.emailNormalized === email)
      ) {
        throw new BillingError("该邮箱已被注册。", 409, "email_taken");
      }

      const now = new Date().toISOString();
      const passwordSalt = randomBytes(16).toString("base64url");
      const account: StoredAccount = {
        id: randomUUID(),
        username,
        usernameNormalized,
        email,
        emailNormalized: email,
        emailVerifiedAt: now,
        displayName: input.displayName?.normalize("NFKC").trim() || username,
        passwordSalt,
        passwordHash: await derivePassword(
          input.password,
          passwordSalt,
          this.value.authTokenPepper,
        ),
        role: "user",
        disabled: false,
        accessTokenHash: "",
        balanceCredits: this.effectivePricing(database).initialCredits,
        createdAt: now,
        updatedAt: now,
      };
      const accessToken = this.issueAccessToken(account);
      database.accounts.push(account);
      this.addInitialGrant(database, account, "新账户体验额度");
      await this.persist(database);
      return { accessToken, account: this.accountView(database, account) };
    });
  }

  async loginUser(
    username: string,
    password: string,
  ): Promise<{ accessToken: string; account: AccountView }> {
    return this.loginForRole(username, password, "user");
  }

  async loginAdmin(
    username: string,
    password: string,
  ): Promise<{ accessToken: string; account: AccountView }> {
    return this.loginForRole(username, password, "admin");
  }

  private loginForRole(
    username: string,
    password: string,
    requiredRole: AccountRole,
  ): Promise<{ accessToken: string; account: AccountView }> {
    return this.exclusive(async (database) => {
      const account = database.accounts.find(
        (item) => item.usernameNormalized === normalizeUsername(username),
      );
      const computed = account?.passwordSalt
        ? await derivePassword(
            password,
            account.passwordSalt,
            this.value.authTokenPepper,
          )
        : undefined;
      if (
        !account ||
        !safeEncodedEqual(account.passwordHash, computed) ||
        (account.role ?? "user") !== requiredRole
      ) {
        throw new BillingError(
          "用户名或密码错误。",
          401,
          "invalid_credentials",
        );
      }
      if (account.disabled) {
        throw new BillingError("此账户已被停用。", 403, "account_disabled");
      }
      const accessToken = this.issueAccessToken(account);
      await this.persist(database);
      return { accessToken, account: this.accountView(database, account) };
    });
  }

  async isEmailRegistered(email: string): Promise<boolean> {
    const normalized = normalizeAccountEmail(email);
    return this.exclusive((database) =>
      database.accounts.some((account) => account.emailNormalized === normalized),
    );
  }

  async logout(accountId: string): Promise<void> {
    await this.exclusive(async (database) => {
      const account = database.accounts.find((item) => item.id === accountId);
      if (!account) return;
      account.accessTokenHash = this.hash(randomBytes(32).toString("base64url"));
      account.updatedAt = new Date().toISOString();
      await this.persist(database);
    });
  }

  async ensureBootstrapAdmin(username: string, password: string): Promise<void> {
    const normalized = normalizeUsername(username);
    if (!normalized || !password) return;
    await this.exclusive(async (database) => {
      const existing = database.accounts.find(
        (item) => item.usernameNormalized === normalized,
      );
      const salt = randomBytes(16).toString("base64url");
      const passwordHash = await derivePassword(
        password,
        salt,
        this.value.authTokenPepper,
      );
      if (existing) {
        existing.username = username.normalize("NFKC").trim();
        existing.displayName ||= "本机管理员";
        existing.passwordSalt = salt;
        existing.passwordHash = passwordHash;
        existing.role = "admin";
        existing.disabled = false;
        existing.updatedAt = new Date().toISOString();
      } else {
        const now = new Date().toISOString();
        database.accounts.push({
          id: randomUUID(),
          username: username.normalize("NFKC").trim(),
          usernameNormalized: normalized,
          displayName: "本机管理员",
          passwordSalt: salt,
          passwordHash,
          role: "admin",
          disabled: false,
          accessTokenHash: this.hash(randomBytes(32).toString("base64url")),
          balanceCredits: this.effectivePricing(database).initialCredits,
          createdAt: now,
          updatedAt: now,
        });
      }
      await this.persist(database);
    });
  }

  async authenticate(accessToken: string): Promise<string | undefined> {
    if (!accessToken) return undefined;
    return this.exclusive((database) => {
      const tokenHash = this.hash(accessToken);
      return database.accounts.find(
        (item) =>
          !item.disabled && safeHexEqual(item.accessTokenHash, tokenHash),
      )?.id;
    });
  }

  private accountView(
    database: BillingDatabase,
    account: StoredAccount,
  ): AccountView {
    const policy = this.effectivePricing(database);
    const baseTier = this.effectiveModelPricing(database).tiers[0]!;
    const transactions = database.ledger
      .filter((item) => item.accountId === account.id)
      .slice(-30)
      .reverse()
      .map<AccountTransaction>((item) => ({
        id: item.id,
        kind: item.kind,
        deltaCredits: item.deltaCredits,
        balanceAfter: item.balanceAfter,
        description: item.description,
        ...(item.inputTokens !== undefined
          ? { inputTokens: item.inputTokens }
          : {}),
        ...(item.outputTokens !== undefined
          ? { outputTokens: item.outputTokens }
          : {}),
        createdAt: item.createdAt,
      }));
    return {
      accountId: account.id,
      profile: this.profile(account),
      balanceCredits: account.balanceCredits,
      pricing: {
        inputCreditsPerThousandTokens:
          (baseTier.inputPerMillion / 1000) *
          policy.creditsPerCurrencyUnit *
          policy.markupMultiplier,
        outputCreditsPerThousandTokens:
          (baseTier.outputPerMillion / 1000) *
          policy.creditsPerCurrencyUnit *
          policy.markupMultiplier,
        minimumChargeCredits: policy.minimumChargeCredits,
        minimumBalanceToStart: policy.minimumBalanceToStart,
      },
      transactions,
    };
  }

  async account(accountId: string): Promise<AccountView> {
    return this.exclusive((database) => {
      const account = database.accounts.find((item) => item.id === accountId);
      if (!account) {
        throw new BillingError("账户不存在。", 401, "invalid_account");
      }
      if (account.disabled) {
        throw new BillingError("此账户已被停用。", 403, "account_disabled");
      }
      return this.accountView(database, account);
    });
  }

  private requireAdmin(
    database: BillingDatabase,
    accountId: string,
  ): StoredAccount {
    const account = database.accounts.find((item) => item.id === accountId);
    if (!account || account.disabled || account.role !== "admin") {
      throw new BillingError("需要管理员权限。", 403, "admin_required");
    }
    return account;
  }

  async listAccounts(
    administratorId: string,
    query = "",
  ): Promise<ManagedAccountView[]> {
    return (await this.adminDashboard(administratorId, query)).accounts;
  }

  async adminDashboard(
    administratorId: string,
    query = "",
  ): Promise<AdminDashboardView> {
    return this.exclusive((database) => {
      this.requireAdmin(database, administratorId);
      const normalized = normalizeUsername(query);
      const statistics = this.ledgerStatistics(database);
      const accounts = database.accounts
        .filter((account) => {
          if (!normalized) return true;
          return (
            account.id.toLowerCase().includes(normalized) ||
            (account.usernameNormalized ?? "").includes(normalized) ||
            (account.emailNormalized ?? "").includes(normalized) ||
            (account.displayName ?? "").toLocaleLowerCase().includes(normalized)
          );
        })
        .sort((left, right) => right.createdAt.localeCompare(left.createdAt))
        .map((account) =>
          this.managed(
            account,
            statistics,
            this.effectiveModelPricing(database).currency,
          ),
        );
      return {
        accounts,
        overview: this.adminOverview(database, statistics),
        pricing: this.pricingView(database),
      };
    });
  }

  async updatePricing(
    administratorId: string,
    input: PricingPolicy,
  ): Promise<AdminPricingView> {
    return this.exclusive(async (database) => {
      this.requireAdmin(database, administratorId);
      database.pricingPolicy = {
        ...input,
        updatedAt: new Date().toISOString(),
      };
      await this.persist(database);
      return this.pricingView(database);
    });
  }

  async adminModel(administratorId: string): Promise<AdminModelView> {
    return this.exclusive((database) => {
      this.requireAdmin(database, administratorId);
      return this.modelView(database);
    });
  }

  async updateModel(
    administratorId: string,
    input: ModelSelectionInput,
  ): Promise<AdminModelView> {
    return this.exclusive(async (database) => {
      this.requireAdmin(database, administratorId);
      if (
        !input.id.trim() ||
        !Number.isInteger(input.maxOutputTokens) ||
        input.maxOutputTokens <= 0 ||
        input.maxOutputTokens > 131_072 ||
        input.pricing.tiers.length === 0
      ) {
        throw new BillingError("模型切换参数无效。", 400, "invalid_model");
      }
      const now = new Date().toISOString();
      database.modelSelection = {
        id: input.id.trim(),
        name: input.name.trim() || input.id.trim(),
        maxOutputTokens: input.maxOutputTokens,
        pricing: {
          ...input.pricing,
          tiers: input.pricing.tiers.map((tier) => ({ ...tier })),
        },
        updatedAt: now,
      };
      await this.persist(database);
      return this.modelView(database);
    });
  }

  async selectedRuntimeConfig(): Promise<AppConfig> {
    return this.exclusive((database) => this.effectiveRuntimeConfig(database));
  }

  async estimateMaximumUsageCredits(
    serializedInput: string,
    modelCalls: number,
  ): Promise<number> {
    return this.exclusive((database) =>
      estimateMaximumUsageCredits(
        serializedInput,
        modelCalls,
        this.effectiveRuntimeConfig(database),
        this.effectivePricing(database),
      ),
    );
  }

  async updateAccount(
    administratorId: string,
    targetAccountId: string,
    input: {
      disabled?: boolean | undefined;
      role?: AccountRole | undefined;
      balanceAdjustment?: number | undefined;
    },
  ): Promise<ManagedAccountView> {
    return this.exclusive(async (database) => {
      this.requireAdmin(database, administratorId);
      const target = database.accounts.find(
        (account) => account.id === targetAccountId,
      );
      if (!target) {
        throw new BillingError("账户不存在。", 404, "account_not_found");
      }
      if (
        target.id === administratorId &&
        (input.disabled === true || input.role === "user")
      ) {
        throw new BillingError(
          "不能停用当前管理员或移除自己的管理员权限。",
          400,
          "unsafe_self_update",
        );
      }
      if (
        input.role === "admin" &&
        (!target.usernameNormalized || !target.passwordHash)
      ) {
        throw new BillingError(
          "匿名设备账户不能设为管理员。",
          400,
          "guest_admin_forbidden",
        );
      }

      const now = new Date().toISOString();
      if (input.disabled !== undefined) target.disabled = input.disabled;
      if (input.role !== undefined) target.role = input.role;
      const adjustment = input.balanceAdjustment ?? 0;
      if (adjustment !== 0) {
        const nextBalance = target.balanceCredits + adjustment;
        if (nextBalance < 0) {
          throw new BillingError(
            "额度调整后不能小于 0。",
            400,
            "invalid_balance_adjustment",
          );
        }
        target.balanceCredits = nextBalance;
        database.ledger.push({
          id: randomUUID(),
          accountId: target.id,
          kind: "admin_adjustment",
          deltaCredits: adjustment,
          balanceAfter: nextBalance,
          description: "管理员调整额度",
          createdAt: now,
        });
      }
      target.updatedAt = now;
      await this.persist(database);
      return this.managed(
        target,
        this.ledgerStatistics(database),
        this.effectiveModelPricing(database).currency,
      );
    });
  }

  private async requireBalance(
    accountId: string,
    reservedCredits = 0,
  ): Promise<void> {
    const view = await this.account(accountId);
    const required = Math.max(
      view.pricing.minimumBalanceToStart,
      Math.ceil(reservedCredits),
    );
    if (view.balanceCredits < required) {
      throw new BillingError(
        `额度不足，本次请求预计至少需要 ${required} 点，请充值后重试。`,
        402,
        "insufficient_credits",
      );
    }
  }

  private async charge(
    accountId: string,
    operation: string,
    usage: ModelUsage,
    runtimeConfig: AppConfig,
  ): Promise<UsageCharge> {
    return this.exclusive(async (database) => {
      const account = database.accounts.find((item) => item.id === accountId);
      if (!account) {
        throw new BillingError("账户不存在。", 401, "invalid_account");
      }
      if (account.disabled) {
        throw new BillingError("此账户已被停用。", 403, "account_disabled");
      }
      const policy = this.effectivePricing(database);
      const quote = calculateUsageQuote(usage, runtimeConfig, policy);
      const chargedCredits = quote.chargedCredits;
      if (chargedCredits > 0) {
        account.balanceCredits -= chargedCredits;
        account.updatedAt = new Date().toISOString();
        database.ledger.push({
          id: randomUUID(),
          accountId,
          kind: "model_usage",
          deltaCredits: -chargedCredits,
          balanceAfter: account.balanceCredits,
          description: operation,
          inputTokens: usage.inputTokens,
          outputTokens: usage.outputTokens,
          ...(usage.modelCalls?.length
            ? { modelCalls: usage.modelCalls.map((call) => ({ ...call })) }
            : {}),
          providerCostMicros: quote.providerCostMicros,
          providerCostCurrency: quote.currency,
          billedAmountMicros: quote.billedAmountMicros,
          pricingCreditsPerCurrencyUnit: policy.creditsPerCurrencyUnit,
          pricingMarkupMultiplier: policy.markupMultiplier,
          modelId: runtimeConfig.privateModel.model,
          modelPricingProfile: runtimeConfig.modelPricing.profile,
          createdAt: account.updatedAt,
        });
        await this.persist(database);
      }
      return {
        chargedCredits,
        balanceCredits: account.balanceCredits,
        inputTokens: usage.inputTokens,
        outputTokens: usage.outputTokens,
      };
    });
  }

  async runMetered<T>(
    accountId: string,
    operation: string,
    action: (runtimeConfig: AppConfig) => Promise<MeteredResult<T>>,
    reservedCredits?: number,
  ): Promise<{ value: T; billing: UsageCharge }> {
    return this.serializeAccount(accountId, async () => {
      const runtimeConfig = await this.selectedRuntimeConfig();
      await this.requireBalance(accountId, reservedCredits);
      const result = await action(runtimeConfig);
      return {
        value: result.value,
        billing: await this.charge(
          accountId,
          operation,
          result.usage,
          runtimeConfig,
        ),
      };
    });
  }

  async creditPayment(input: {
    accountId: string;
    credits: number;
    externalId: string;
    description: string;
    amountMinor?: number | undefined;
    currency?: string | undefined;
  }): Promise<boolean> {
    return this.exclusive(async (database) => {
      if (database.processedExternalIds.includes(input.externalId)) {
        return false;
      }
      const account = database.accounts.find(
        (item) => item.id === input.accountId,
      );
      if (!account) throw new Error("支付对应的账户不存在。");
      if (!Number.isInteger(input.credits) || input.credits <= 0) {
        throw new Error("支付对应的额度无效。");
      }
      if (
        (input.amountMinor !== undefined || input.currency !== undefined) &&
        (!Number.isInteger(input.amountMinor) ||
          (input.amountMinor ?? 0) <= 0 ||
          !/^[a-z]{3}$/i.test(input.currency ?? ""))
      ) {
        throw new Error("支付金额或币种无效。");
      }
      const now = new Date().toISOString();
      account.balanceCredits += input.credits;
      account.updatedAt = now;
      database.processedExternalIds.push(input.externalId);
      database.ledger.push({
        id: randomUUID(),
        accountId: input.accountId,
        kind: "top_up",
        deltaCredits: input.credits,
        balanceAfter: account.balanceCredits,
        description: input.description,
        externalId: input.externalId,
        ...(input.amountMinor !== undefined
          ? { paymentAmountMinor: input.amountMinor }
          : {}),
        ...(input.currency !== undefined
          ? { paymentCurrency: input.currency.toLocaleLowerCase("en-US") }
          : {}),
        createdAt: now,
      });
      await this.persist(database);
      return true;
    });
  }
}
