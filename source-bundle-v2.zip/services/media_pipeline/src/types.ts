export type SubtitleCue = {
  id: string;
  startMs: number;
  endMs: number;
  original: string;
  translation: string;
  speaker?: string;
};

export type DictionaryEntry = {
  word: string;
  phonetic: string;
  partOfSpeech: string;
  definition: string;
  example: string;
  exampleTranslation: string;
};

export type ModelCallUsage = {
  inputTokens: number;
  outputTokens: number;
};

export type ModelUsage = ModelCallUsage & {
  modelCalls?: ModelCallUsage[];
};

export type MeteredResult<T> = {
  value: T;
  usage: ModelUsage;
};

export type JobStage =
  | "uploading"
  | "extracting_audio"
  | "transcribing"
  | "translating"
  | "aligning"
  | "completed"
  | "failed";

export type PipelineJob = {
  id: string;
  accountId: string;
  uploadId: string;
  status: "queued" | "running" | "completed" | "failed";
  stage: JobStage;
  progress: number;
  detail: string;
  createdAt: string;
  updatedAt: string;
  sourceLanguage: string;
  targetLanguage: string;
  cues?: SubtitleCue[];
  error?: string;
};

export type UploadMetadata = {
  uploadId: string;
  accountId: string;
  fileName: string;
  safeFileName: string;
  size: number;
  lastModifiedMs: number;
  createdAt: string;
};
