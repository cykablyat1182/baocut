import Stripe from "stripe";
import { z } from "zod";

import { BillingError, type BillingService } from "./billing.js";
import type { AppConfig } from "./config.js";

const packageSchema = z.object({
  id: z.string().trim().regex(/^[a-z0-9_-]{2,48}$/),
  name: z.string().trim().min(1).max(80),
  description: z.string().trim().max(200).optional(),
  credits: z.number().int().positive(),
  amountMinor: z.number().int().positive(),
  currency: z.string().trim().toLowerCase().regex(/^[a-z]{3}$/),
});

export type BillingPackage = z.infer<typeof packageSchema>;

export type PublicBillingPackage = BillingPackage & {
  formattedAmount: string;
};

function parsePackages(serialized: string): BillingPackage[] {
  let value: unknown;
  try {
    value = JSON.parse(serialized) as unknown;
  } catch {
    throw new Error("BILLING_PACKAGES_JSON 不是有效 JSON。");
  }
  const parsed = z.array(packageSchema).max(20).safeParse(value);
  if (!parsed.success) {
    throw new Error("BILLING_PACKAGES_JSON 的套餐字段无效。");
  }
  const ids = new Set(parsed.data.map((item) => item.id));
  if (ids.size !== parsed.data.length) {
    throw new Error("BILLING_PACKAGES_JSON 包含重复套餐 ID。");
  }
  return parsed.data;
}

function formattedAmount(plan: BillingPackage): string {
  try {
    return new Intl.NumberFormat("zh-CN", {
      style: "currency",
      currency: plan.currency,
    }).format(plan.amountMinor / 100);
  } catch {
    return `${plan.amountMinor} ${plan.currency.toUpperCase()}（最小货币单位）`;
  }
}

export class StripeBillingService {
  private readonly stripe?: Stripe;
  private readonly packages: BillingPackage[];

  constructor(
    private readonly value: AppConfig,
    private readonly billing: BillingService,
  ) {
    this.packages = parsePackages(value.billingPackagesJson);
    if (value.stripeSecretKey) {
      this.stripe = new Stripe(value.stripeSecretKey, {
        maxNetworkRetries: 2,
        timeout: 30_000,
        typescript: true,
      });
    }
  }

  listPackages(): {
    checkoutAvailable: boolean;
    packages: PublicBillingPackage[];
  } {
    const checkoutAvailable =
      Boolean(
        this.stripe &&
          this.value.stripeWebhookSecret &&
          this.value.stripeSuccessUrl &&
          this.value.stripeCancelUrl,
      ) && this.packages.length > 0;
    return {
      checkoutAvailable,
      packages: this.packages.map((item) => ({
        ...item,
        formattedAmount: formattedAmount(item),
      })),
    };
  }

  async createCheckout(
    accountId: string,
    packageId: string,
    idempotencyKey: string,
  ): Promise<string> {
    if (
      !this.stripe ||
      !this.value.stripeWebhookSecret ||
      !this.value.stripeSuccessUrl ||
      !this.value.stripeCancelUrl
    ) {
      throw new BillingError(
        "在线充值尚未配置。",
        503,
        "checkout_unavailable",
      );
    }
    const plan = this.packages.find((item) => item.id === packageId);
    if (!plan) {
      throw new BillingError("充值套餐不存在。", 404, "package_not_found");
    }
    if (!/^[A-Za-z0-9_-]{8,200}$/.test(idempotencyKey)) {
      throw new BillingError("请求幂等键无效。", 400, "invalid_idempotency_key");
    }

    let session: Stripe.Checkout.Session;
    try {
      session = await this.stripe.checkout.sessions.create(
        {
          mode: "payment",
          customer_creation: "always",
          client_reference_id: accountId,
          success_url: this.value.stripeSuccessUrl,
          cancel_url: this.value.stripeCancelUrl,
          line_items: [
            {
              quantity: 1,
              price_data: {
                currency: plan.currency,
                unit_amount: plan.amountMinor,
                product_data: {
                  name: plan.name,
                  description:
                    plan.description ??
                    `影语翻译服务 ${plan.credits} 点额度`,
                },
              },
            },
          ],
          metadata: {
            schemaVersion: "1",
            accountId,
            packageId: plan.id,
            credits: String(plan.credits),
          },
        },
        { idempotencyKey: `${accountId}:${idempotencyKey}` },
      );
    } catch {
      throw new BillingError(
        "支付页面创建失败，请稍后重试。",
        502,
        "checkout_failed",
      );
    }
    if (!session.url) {
      throw new BillingError(
        "支付页面创建失败，请稍后重试。",
        502,
        "checkout_failed",
      );
    }
    return session.url;
  }

  async handleWebhook(
    payload: Buffer,
    signature: string,
  ): Promise<{ received: true; credited: boolean }> {
    if (!this.stripe || !this.value.stripeWebhookSecret) {
      throw new BillingError(
        "支付回调尚未配置。",
        503,
        "webhook_unavailable",
      );
    }
    let event: Stripe.Event;
    try {
      event = this.stripe.webhooks.constructEvent(
        payload,
        signature,
        this.value.stripeWebhookSecret,
      );
    } catch {
      throw new BillingError(
        "支付回调签名无效。",
        400,
        "invalid_webhook_signature",
      );
    }

    if (
      event.type !== "checkout.session.completed" &&
      event.type !== "checkout.session.async_payment_succeeded"
    ) {
      return { received: true, credited: false };
    }

    const session = event.data.object;
    if (session.payment_status !== "paid") {
      return { received: true, credited: false };
    }
    const accountId = session.metadata?.accountId ?? "";
    const packageId = session.metadata?.packageId ?? "";
    const credits = Number(session.metadata?.credits);
    const plan = this.packages.find((item) => item.id === packageId);
    if (
      !accountId ||
      !plan ||
      !Number.isInteger(credits) ||
      credits !== plan.credits ||
      session.amount_total !== plan.amountMinor ||
      session.currency !== plan.currency
    ) {
      throw new BillingError(
        "支付回调元数据无效。",
        400,
        "invalid_payment_metadata",
      );
    }

    const credited = await this.billing.creditPayment({
      accountId,
      credits,
      externalId: `stripe-checkout:${session.id}`,
      description: `${plan.name}充值`,
      amountMinor: plan.amountMinor,
      currency: plan.currency,
    });
    return { received: true, credited };
  }
}
