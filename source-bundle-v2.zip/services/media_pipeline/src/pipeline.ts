import { randomUUID } from "node:crypto";
import { spawn } from "node:child_process";
import path from "node:path";
import { mkdir, readFile, rename, rm, writeFile } from "node:fs/promises";

import type { AppConfig } from "./config.js";
import type { BillingService } from "./billing.js";
import type { PipelineJob } from "./types.js";
import {
  deleteTosObject,
  transcribeSeedAsr,
  translationBatchSize,
  translateCues,
  uploadAudioForAsr,
} from "./volcengine.js";

const jobs = new Map<string, PipelineJob>();

function jobDirectory(value: AppConfig): string {
  return path.join(value.dataDir, "jobs");
}

function safeJobId(jobId: string): void {
  if (!/^[a-f0-9-]{36}$/.test(jobId)) throw new Error("无效的任务 ID。");
}

async function persistJob(job: PipelineJob, value: AppConfig): Promise<void> {
  const directory = jobDirectory(value);
  await mkdir(directory, { recursive: true });
  const destination = path.join(directory, `${job.id}.json`);
  const temporary = `${destination}.${process.pid}.tmp`;
  await writeFile(temporary, JSON.stringify(job, null, 2));
  await rename(temporary, destination);
}

export async function createJob(
  accountId: string,
  uploadId: string,
  sourceLanguage: string,
  targetLanguage: string,
  value: AppConfig,
): Promise<PipelineJob> {
  const now = new Date().toISOString();
  const job: PipelineJob = {
    id: randomUUID(),
    accountId,
    uploadId,
    status: "queued",
    stage: "extracting_audio",
    progress: 0.02,
    detail: "任务已进入处理队列",
    createdAt: now,
    updatedAt: now,
    sourceLanguage,
    targetLanguage,
  };
  jobs.set(job.id, job);
  await persistJob(job, value);
  return job;
}

export async function getJob(
  jobId: string,
  value: AppConfig,
): Promise<PipelineJob | undefined> {
  safeJobId(jobId);
  const memory = jobs.get(jobId);
  if (memory) return memory;
  try {
    const stored = JSON.parse(
      await readFile(path.join(jobDirectory(value), `${jobId}.json`), "utf8"),
    ) as PipelineJob;
    jobs.set(jobId, stored);
    return stored;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return undefined;
    throw error;
  }
}

async function updateJob(
  job: PipelineJob,
  update: Partial<PipelineJob>,
  value: AppConfig,
): Promise<void> {
  Object.assign(job, update, { updatedAt: new Date().toISOString() });
  jobs.set(job.id, job);
  await persistJob(job, value);
}

async function runFfmpeg(
  inputPath: string,
  outputPath: string,
  value: AppConfig,
): Promise<void> {
  const arguments_ = [
    "-hide_banner",
    "-loglevel",
    "error",
    "-y",
    "-i",
    inputPath,
    "-map",
    "0:a:0",
    "-vn",
    "-ac",
    "1",
    "-ar",
    "16000",
    "-codec:a",
    "libmp3lame",
    "-b:a",
    "64k",
    outputPath,
  ];
  await new Promise<void>((resolve, reject) => {
    const process = spawn(value.ffmpegPath, arguments_, {
      windowsHide: true,
      stdio: ["ignore", "ignore", "pipe"],
    });
    let errorOutput = "";
    process.stderr.setEncoding("utf8");
    process.stderr.on("data", (chunk: string) => {
      if (errorOutput.length < 16_000) errorOutput += chunk;
    });
    process.on("error", reject);
    process.on("close", (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(
          new Error(
            `FFmpeg 提取音轨失败（退出码 ${String(code)}）：${errorOutput.trim()}`,
          ),
        );
      }
    });
  });
}

export function startPipeline(
  job: PipelineJob,
  mediaPath: string,
  value: AppConfig,
  billing: BillingService,
): void {
  void (async () => {
    const audioPath = path.join(path.dirname(mediaPath), `${job.id}.mp3`);
    let objectKey: string | undefined;
    try {
      await updateJob(
        job,
        {
          status: "running",
          stage: "extracting_audio",
          progress: 0.08,
          detail: "正在提取 16 kHz 单声道音轨",
        },
        value,
      );
      await runFfmpeg(mediaPath, audioPath, value);

      await updateJob(
        job,
        {
          stage: "transcribing",
          progress: 0.22,
          detail: "正在安全上传音轨并提交 SeedASR 2.0",
        },
        value,
      );
      const upload = await uploadAudioForAsr(audioPath, job.id, value);
      objectKey = upload.objectKey;
      const originalCues = await transcribeSeedAsr(upload, value);

      await updateJob(
        job,
        {
          stage: "translating",
          progress: 0.72,
          detail: `正在翻译 ${originalCues.length} 条字幕`,
        },
        value,
      );
      const estimateRuntime = await billing.selectedRuntimeConfig();
      const translated = await billing.runMetered(
        job.accountId,
        "自动生成双语字幕",
        (runtimeConfig) =>
          translateCues(
            originalCues,
            job.sourceLanguage,
            job.targetLanguage,
            runtimeConfig,
          ),
        await billing.estimateMaximumUsageCredits(
          JSON.stringify({
            sourceLanguage: job.sourceLanguage,
            targetLanguage: job.targetLanguage,
            cues: originalCues.map(({ id, original }) => ({ id, original })),
          }),
          Math.ceil(
            originalCues.length / translationBatchSize(estimateRuntime),
          ),
        ),
      );
      const cues = translated.value;

      await updateJob(
        job,
        {
          stage: "aligning",
          progress: 0.96,
          detail: "正在校验双语字幕时间轴",
        },
        value,
      );
      const aligned = cues
        .filter(
          (cue) =>
            cue.original.trim() &&
            cue.translation.trim() &&
            cue.endMs > cue.startMs,
        )
        .sort((left, right) => left.startMs - right.startMs);
      if (aligned.length === 0) {
        throw new Error("处理完成，但没有生成有效的双语字幕。");
      }

      await updateJob(
        job,
        {
          status: "completed",
          stage: "completed",
          progress: 1,
          detail: `已生成 ${aligned.length} 条双语字幕`,
          cues: aligned,
        },
        value,
      );
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      await updateJob(
        job,
        {
          status: "failed",
          stage: "failed",
          detail: message,
          error: message,
        },
        value,
      );
    } finally {
      await rm(audioPath, { force: true }).catch(() => undefined);
      if (objectKey) {
        await deleteTosObject(objectKey, value).catch(() => undefined);
      }
    }
  })();
}
