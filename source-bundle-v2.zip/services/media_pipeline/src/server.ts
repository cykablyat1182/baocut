import { readFile, writeFile } from "node:fs/promises";
import { pathToFileURL } from "node:url";

import cors from "cors";
import express, {
  type ErrorRequestHandler,
  type NextFunction,
  type Request,
  type RequestHandler,
  type Response,
} from "express";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import { z, ZodError } from "zod";

import {
  BillingError,
  BillingService,
} from "./billing.js";
import {
  assertPipelineConfigured,
  config,
  missingPipelineConfiguration,
} from "./config.js";
import { EmailVerificationService } from "./email-verification.js";
import { ModelCatalogService } from "./model-catalog.js";
import type { ModelPricing } from "./model-pricing.js";
import { OpenListGateway } from "./openlist-gateway.js";
import { createJob, getJob, startPipeline } from "./pipeline.js";
import { StripeBillingService } from "./stripe-billing.js";
import type { SubtitleCue } from "./types.js";
import {
  assembleUpload,
  createOrResumeUpload,
  readUploadMetadata,
  storePart,
  uploadJobMarkerPath,
} from "./uploads.js";
import {
  lookupDictionary,
  lookupDictionaryStream,
  translationBatchSize,
  translateCues,
} from "./volcengine.js";

const billing = new BillingService(config);
const stripeBilling = new StripeBillingService(config, billing);
const emailVerification = new EmailVerificationService(config);
const modelCatalog = new ModelCatalogService(config);
const openListGateway = new OpenListGateway(config);

const deviceAuthSchema = z.object({
  installationId: z.string().trim().min(16).max(160),
  installationSecret: z.string().trim().min(32).max(256),
});

const usernameSchema = z
  .string()
  .trim()
  .min(3, "用户名至少需要 3 个字符")
  .max(32, "用户名最多 32 个字符")
  .refine(
    (value) => /^[\p{L}\p{N}_-]+$/u.test(value),
    "用户名只能包含文字、数字、下划线和连字符",
  );

const passwordSchema = z
  .string()
  .min(8, "密码至少需要 8 个字符")
  .max(128, "密码最多 128 个字符");

const registerSchema = z.object({
  username: usernameSchema,
  email: z.string().trim().email("请输入有效的电子邮箱").max(254),
  verificationCode: z.string().regex(/^\d{6}$/, "请输入 6 位邮箱验证码"),
  displayName: z.string().trim().max(32).optional(),
  password: passwordSchema,
});

const emailCodeSchema = z.object({
  email: z.string().trim().email("请输入有效的电子邮箱").max(254),
});

const loginSchema = z.object({
  username: usernameSchema,
  password: passwordSchema,
});

const adminUpdateSchema = z
  .object({
    disabled: z.boolean().optional(),
    role: z.enum(["user", "admin"]).optional(),
    balanceAdjustment: z.number().int().min(-1_000_000).max(1_000_000).optional(),
  })
  .refine(
    (value) =>
      value.disabled !== undefined ||
      value.role !== undefined ||
      value.balanceAdjustment !== undefined,
    "没有需要修改的账户字段",
  );

const adminPricingSchema = z.object({
  initialCredits: z.number().int().min(0).max(1_000_000),
  minimumBalanceToStart: z.number().int().min(0).max(1_000_000),
  minimumChargeCredits: z.number().int().min(0).max(1_000_000),
  creditsPerCurrencyUnit: z.number().int().min(1).max(1_000_000),
  markupMultiplier: z.number().finite().min(0.01).max(1000),
});

const modelPriceTiersSchema = z
  .array(
    z.object({
      upToInputTokens: z.number().int().positive().max(4_000_000),
      inputPerMillion: z.number().finite().nonnegative().max(1_000_000),
      outputPerMillion: z.number().finite().nonnegative().max(1_000_000),
    }),
  )
  .min(1)
  .max(16)
  .refine(
    (tiers) =>
      tiers.every(
        (tier, index) =>
          index === 0 ||
          tier.upToInputTokens > (tiers[index - 1]?.upToInputTokens ?? 0),
      ),
    "模型价格分档必须按输入 Token 上限递增",
  );

const adminModelSchema = z.object({
  modelId: z.string().trim().min(1).max(200),
  pricing: z
    .object({
      currency: z.string().trim().toLowerCase().regex(/^[a-z]{3}$/),
      tiers: modelPriceTiersSchema,
    })
    .optional(),
});

const uploadSchema = z.object({
  fileName: z.string().trim().min(1).max(255),
  size: z.number().int().positive(),
  lastModifiedMs: z.number().int().nonnegative(),
});

const completeSchema = z.object({
  sourceLanguage: z.string().trim().min(2).max(24),
  targetLanguage: z.string().trim().min(2).max(24),
});

const cueSchema = z.object({
  id: z.string().min(1).max(160),
  startMs: z.number().int().nonnegative(),
  endMs: z.number().int().positive(),
  original: z.string().max(10_000),
  translation: z.string().max(10_000).default(""),
  speaker: z.string().max(160).optional().nullable(),
});

const translateSchema = z.object({
  sourceLanguage: z.string().trim().min(2).max(24),
  targetLanguage: z.string().trim().min(2).max(24),
  cues: z.array(cueSchema).min(1).max(20_000),
});

const dictionarySchema = z.object({
  word: z
    .string()
    .trim()
    .min(1)
    .max(120)
    .refine(
      (word) => /[\p{L}\p{N}]/u.test(word) && !/[\r\n\t]/u.test(word),
      "请选择有效的单词或短语",
    ),
  sentence: z.string().trim().max(2000),
  targetLanguage: z.string().trim().min(2).max(24),
});

const checkoutSchema = z.object({
  packageId: z.string().trim().min(2).max(48),
});

const mediaPathSchema = z.object({
  path: z.string().trim().min(1).max(2048),
  refresh: z.boolean().optional().default(false),
});

const mediaLinkSchema = mediaPathSchema.extend({
  type: z.enum(["streaming", "download"]).default("streaming"),
});

function asyncRoute(
  handler: (request: Request, response: Response) => Promise<void>,
): RequestHandler {
  return (request, response, next): void => {
    void handler(request, response).catch(next);
  };
}

function routeParam(request: Request, name: string): string {
  const value = request.params[name];
  return Array.isArray(value) ? (value[0] ?? "") : (value ?? "");
}

function authenticatedAccount(response: Response): string {
  const accountId = response.locals.accountId as unknown;
  if (typeof accountId !== "string" || !accountId) {
    throw new BillingError("请先登录设备账户。", 401, "authentication_required");
  }
  return accountId;
}

function authenticationMiddleware(): RequestHandler {
  return (request, response, next): void => {
    void (async () => {
      const authorization = request.header("authorization") ?? "";
      const match = /^Bearer\s+([A-Za-z0-9_-]{32,256})$/i.exec(authorization);
      const accountId = match?.[1]
        ? await billing.authenticate(match[1])
        : undefined;
      if (!accountId) {
        throw new BillingError(
          "设备账户凭据无效或已过期。",
          401,
          "authentication_required",
        );
      }
      response.locals.accountId = accountId;
      next();
    })().catch(next);
  };
}

async function assertUploadOwner(
  uploadId: string,
  accountId: string,
): Promise<void> {
  const metadata = await readUploadMetadata(uploadId, config);
  if (metadata.accountId !== accountId) {
    throw new BillingError("上传任务不存在。", 404, "upload_not_found");
  }
}

async function assertManagedMediaAccess(response: Response): Promise<void> {
  const account = await billing.account(authenticatedAccount(response));
  const username = account.profile.username?.toLowerCase() ?? "";
  if (
    config.openListAllowedUsers.length === 0 ||
    !config.openListAllowedUsers.includes(username)
  ) {
    throw new BillingError("该账户未开通云端网盘。", 403, "media_access_denied");
  }
}

export function createApp(): express.Express {
  const app = express();
  app.disable("x-powered-by");
  app.use(helmet({ crossOriginResourcePolicy: false }));
  app.use(
    cors({
      origin:
        config.allowedOrigins.length === 0
          ? false
          : (origin, callback) => {
              if (!origin || config.allowedOrigins.includes(origin)) {
                callback(null, true);
              } else {
                callback(new Error("不允许的客户端来源。"));
              }
            },
    }),
  );
  app.use(
    rateLimit({
      windowMs: 15 * 60 * 1000,
      limit: 3000,
      standardHeaders: "draft-8",
      legacyHeaders: false,
    }),
  );

  // Stripe 必须使用未经 JSON 中间件改写的原始请求体校验签名。
  app.post(
    "/api/billing/stripe/webhook",
    express.raw({ type: "application/json", limit: "2mb" }),
    asyncRoute(async (request, response) => {
      if (!Buffer.isBuffer(request.body)) {
        throw new BillingError(
          "支付回调请求体无效。",
          400,
          "invalid_webhook_body",
        );
      }
      const result = await stripeBilling.handleWebhook(
        request.body,
        request.header("stripe-signature") ?? "",
      );
      response.json(result);
    }),
  );

  app.use(express.json({ limit: "20mb" }));

  app.get("/health", (_request, response) => {
    const missing = missingPipelineConfiguration(config);
    response.json({
      status: "ok",
      service: "yingyu-media-pipeline",
      pipelineConfigured: missing.length === 0,
      modelConfigured: Boolean(
        config.privateModel.apiKey && config.privateModel.model,
      ),
      checkoutConfigured: stripeBilling.listPackages().checkoutAvailable,
      localAccountServer: true,
      emailVerificationConfigured: emailVerification.configured,
      adminConfigured: Boolean(config.localAdminUsername),
      missingConfiguration: missing,
    });
  });

  app.post(
    "/api/auth/device",
    rateLimit({
      windowMs: 60 * 60 * 1000,
      limit: 10,
      standardHeaders: "draft-8",
      legacyHeaders: false,
    }),
    asyncRoute(async (request, response) => {
      const input = deviceAuthSchema.parse(request.body);
      const account = await billing.registerDevice(
        input.installationId,
        input.installationSecret,
      );
      response.status(201).json(account);
    }),
  );

  app.post(
    "/api/auth/email/request-code",
    rateLimit({
      windowMs: 60 * 60 * 1000,
      limit: 10,
      standardHeaders: "draft-8",
      legacyHeaders: false,
    }),
    asyncRoute(async (request, response) => {
      const input = emailCodeSchema.parse(request.body);
      if (await billing.isEmailRegistered(input.email)) {
        throw new BillingError("该邮箱已被注册。", 409, "email_taken");
      }
      const result = await emailVerification.request(input.email);
      response.status(202).json({ sent: true, ...result });
    }),
  );

  app.post(
    "/api/auth/register",
    rateLimit({
      windowMs: 60 * 60 * 1000,
      limit: 20,
      standardHeaders: "draft-8",
      legacyHeaders: false,
    }),
    asyncRoute(async (request, response) => {
      const input = registerSchema.parse(request.body);
      await emailVerification.consume(input.email, input.verificationCode);
      const result = await billing.registerUser({
        username: input.username,
        email: input.email,
        password: input.password,
        ...(input.displayName !== undefined
          ? { displayName: input.displayName }
          : {}),
      });
      response.status(201).json(result);
    }),
  );

  app.post(
    "/api/auth/login",
    rateLimit({
      windowMs: 15 * 60 * 1000,
      limit: 30,
      standardHeaders: "draft-8",
      legacyHeaders: false,
    }),
    asyncRoute(async (request, response) => {
      const input = loginSchema.parse(request.body);
      response.json(await billing.loginUser(input.username, input.password));
    }),
  );

  app.post(
    "/api/admin/auth/login",
    rateLimit({
      windowMs: 15 * 60 * 1000,
      limit: 20,
      standardHeaders: "draft-8",
      legacyHeaders: false,
    }),
    asyncRoute(async (request, response) => {
      if (!config.localAdminUsername || !config.localAdminPassword) {
        throw new BillingError(
          "管理员账户尚未在服务端配置。",
          503,
          "admin_not_configured",
        );
      }
      const input = loginSchema.parse(request.body);
      response.json(await billing.loginAdmin(input.username, input.password));
    }),
  );

  app.use("/api", authenticationMiddleware());

  app.get(
    "/api/auth/me",
    asyncRoute(async (_request, response) => {
      response.json({
        account: await billing.account(authenticatedAccount(response)),
      });
    }),
  );

  app.post(
    "/api/auth/logout",
    asyncRoute(async (_request, response) => {
      await billing.logout(authenticatedAccount(response));
      response.status(204).end();
    }),
  );

  app.post(
    "/api/media/library/list",
    asyncRoute(async (request, response) => {
      await assertManagedMediaAccess(response);
      const input = mediaPathSchema.parse(request.body);
      response.json({
        entries: await openListGateway.list(input.path, input.refresh),
      });
    }),
  );

  app.post(
    "/api/media/library/link",
    asyncRoute(async (request, response) => {
      await assertManagedMediaAccess(response);
      const input = mediaLinkSchema.parse(request.body);
      response.json(await openListGateway.link(input.path, input.type));
    }),
  );

  app.get(
    "/api/admin/accounts",
    asyncRoute(async (request, response) => {
      const query =
        typeof request.query.query === "string" ? request.query.query : "";
      response.json(
        await billing.adminDashboard(
          authenticatedAccount(response),
          query.slice(0, 80),
        ),
      );
    }),
  );

  app.patch(
    "/api/admin/accounts/:accountId",
    asyncRoute(async (request, response) => {
      const input = adminUpdateSchema.parse(request.body);
      response.json({
        account: await billing.updateAccount(
          authenticatedAccount(response),
          routeParam(request, "accountId"),
          input,
        ),
      });
    }),
  );

  app.patch(
    "/api/admin/pricing",
    asyncRoute(async (request, response) => {
      const input = adminPricingSchema.parse(request.body);
      response.json({
        pricing: await billing.updatePricing(
          authenticatedAccount(response),
          input,
        ),
      });
    }),
  );

  app.get(
    "/api/admin/models",
    asyncRoute(async (request, response) => {
      const administratorId = authenticatedAccount(response);
      const active = await billing.adminModel(administratorId);
      const refresh = request.query.refresh === "true";
      const catalog = await modelCatalog.list(refresh);
      const models = [...catalog.models];
      if (!models.some((model) => model.id === active.id)) {
        models.unshift({
          id: active.id,
          name: active.name,
          version: null,
          domain: null,
          status: null,
          taskTypes: ["TextGeneration"],
          contextWindow: null,
          maxInputTokens: null,
          maxOutputTokens: active.maxOutputTokens,
          supportsStructuredOutput: true,
          suggestedPricing: {
            profile: active.pricing.profile,
            currency: active.pricing.currency,
            sourceUrl: active.pricing.sourceUrl,
            checkedAt: active.pricing.checkedAt,
            tiers: active.pricing.tiers,
          },
        });
      }
      response.json({
        active,
        models,
        source: catalog.source,
        refreshedAt: catalog.refreshedAt,
        warning: catalog.warning,
      });
    }),
  );

  app.patch(
    "/api/admin/model",
    asyncRoute(async (request, response) => {
      const administratorId = authenticatedAccount(response);
      await billing.adminModel(administratorId);
      const input = adminModelSchema.parse(request.body);
      let catalog = await modelCatalog.list(false);
      let selected = catalog.models.find((model) => model.id === input.modelId);
      if (!selected) {
        catalog = await modelCatalog.list(true);
        selected = catalog.models.find((model) => model.id === input.modelId);
      }
      if (!selected) {
        throw new BillingError(
          "该模型不在当前模型服务的可用目录中。",
          400,
          "model_not_available",
        );
      }
      const pricing: ModelPricing | undefined = input.pricing
        ? {
            profile: `manual:${selected.id}`,
            currency: input.pricing.currency,
            tiers: input.pricing.tiers,
            sourceUrl: null,
            checkedAt: new Date().toISOString().slice(0, 10),
          }
        : (selected.suggestedPricing ?? undefined);
      if (!pricing) {
        throw new BillingError(
          "该模型没有内置价格，请填写目录价后再切换。",
          400,
          "model_pricing_required",
        );
      }
      const providerOutputLimit =
        selected.maxOutputTokens ?? config.privateModel.maxOutputTokens;
      const active = await billing.updateModel(administratorId, {
        id: selected.id,
        name: selected.name,
        maxOutputTokens: Math.min(
          providerOutputLimit,
          config.privateModel.maxOutputTokens,
        ),
        pricing,
      });
      response.json({ active, pricing: active.pricing });
    }),
  );

  app.get(
    "/api/billing/account",
    asyncRoute(async (_request, response) => {
      response.json({
        account: await billing.account(authenticatedAccount(response)),
      });
    }),
  );

  app.get("/api/billing/packages", (_request, response) => {
    response.json(stripeBilling.listPackages());
  });

  app.post(
    "/api/billing/checkout",
    asyncRoute(async (request, response) => {
      const input = checkoutSchema.parse(request.body);
      const checkoutUrl = await stripeBilling.createCheckout(
        authenticatedAccount(response),
        input.packageId,
        request.header("x-idempotency-key") ?? "",
      );
      response.status(201).json({ checkoutUrl });
    }),
  );

  app.post(
    "/api/uploads",
    asyncRoute(async (request, response) => {
      const input = uploadSchema.parse(request.body);
      const result = await createOrResumeUpload(
        {
          accountId: authenticatedAccount(response),
          ...input,
        },
        config,
      );
      response.status(201).json(result);
    }),
  );

  app.put(
    "/api/uploads/:uploadId/parts/:partIndex",
    express.raw({ type: "application/octet-stream", limit: "4mb" }),
    asyncRoute(async (request, response) => {
      if (!Buffer.isBuffer(request.body)) {
        throw new Error("分片请求体必须是二进制数据。");
      }
      const uploadId = routeParam(request, "uploadId");
      await assertUploadOwner(uploadId, authenticatedAccount(response));
      await storePart(
        uploadId,
        Number(routeParam(request, "partIndex")),
        request.body,
        request.header("content-range") ?? "",
        request.header("x-chunk-sha256") ?? "",
        config,
      );
      response.status(204).end();
    }),
  );

  app.post(
    "/api/uploads/:uploadId/complete",
    asyncRoute(async (request, response) => {
      assertPipelineConfigured(config);
      const input = completeSchema.parse(request.body);
      const uploadId = routeParam(request, "uploadId");
      const accountId = authenticatedAccount(response);
      await assertUploadOwner(uploadId, accountId);
      const markerPath = uploadJobMarkerPath(uploadId, config);
      try {
        const marker = JSON.parse(await readFile(markerPath, "utf8")) as {
          jobId?: string;
        };
        if (marker.jobId) {
          const existing = await getJob(marker.jobId, config);
          if (existing?.accountId === accountId) {
            response.json({ jobId: marker.jobId });
            return;
          }
        }
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
      }

      const mediaPath = await assembleUpload(uploadId, config);
      const job = await createJob(
        accountId,
        uploadId,
        input.sourceLanguage,
        input.targetLanguage,
        config,
      );
      await writeFile(markerPath, JSON.stringify({ jobId: job.id }));
      startPipeline(job, mediaPath, config, billing);
      response.status(202).json({ jobId: job.id });
    }),
  );

  app.get(
    "/api/jobs/:jobId",
    asyncRoute(async (request, response) => {
      const job = await getJob(routeParam(request, "jobId"), config);
      if (!job || job.accountId !== authenticatedAccount(response)) {
        response.status(404).json({ error: "处理任务不存在。" });
        return;
      }
      const { accountId: _accountId, ...publicJob } = job;
      response.json(publicJob);
    }),
  );

  app.post(
    "/api/translate/stream",
    asyncRoute(async (request, response) => {
      const input = translateSchema.parse(request.body);
      const cues: SubtitleCue[] = input.cues.map((cue) => {
        const result: SubtitleCue = {
          id: cue.id,
          startMs: cue.startMs,
          endMs: cue.endMs,
          original: cue.original,
          translation: cue.translation,
        };
        if (cue.speaker) result.speaker = cue.speaker;
        return result;
      });
      const estimateRuntime = await billing.selectedRuntimeConfig();
      const estimate = await billing.estimateMaximumUsageCredits(
        JSON.stringify(input),
        Math.ceil(
          cues.filter((cue) => !cue.translation.trim()).length /
            translationBatchSize(estimateRuntime),
        ),
      );
      const abortController = new AbortController();
      response.status(200).set({
        "content-type": "text/event-stream; charset=utf-8",
        "cache-control": "no-cache, no-transform",
        connection: "keep-alive",
        "x-accel-buffering": "no",
      });
      response.flushHeaders();

      const send = (event: string, value: unknown) => {
        if (response.destroyed || response.writableEnded) return;
        response.write(`event: ${event}\ndata: ${JSON.stringify(value)}\n\n`);
      };
      const heartbeat = setInterval(() => {
        if (!response.destroyed && !response.writableEnded) {
          response.write(": keep-alive\n\n");
        }
      }, 15_000);
      response.on("close", () => {
        if (!response.writableEnded) abortController.abort();
      });

      try {
        send("status", {
          message: `已准备 ${cues.length} 条字幕，正在按批次流式翻译…`,
        });
        const result = await billing.runMetered(
          authenticatedAccount(response),
          "字幕翻译",
          (runtimeConfig) =>
            translateCues(
              cues,
              input.sourceLanguage,
              input.targetLanguage,
              runtimeConfig,
              (batch, completed, total) => {
                send("partial", {
                  cues: batch,
                  completed,
                  total,
                });
              },
              abortController.signal,
            ),
          estimate,
        );
        send("complete", { cues: result.value, billing: result.billing });
      } catch (error) {
        send("error", {
          error: error instanceof Error ? error.message : "字幕翻译失败。",
        });
      } finally {
        clearInterval(heartbeat);
        if (!response.writableEnded) response.end();
      }
    }),
  );

  // Legacy JSON endpoint retained for clients that have not upgraded to the
  // shared SSE client yet. The native player never uses this path.
  app.post(
    "/api/translate",
    asyncRoute(async (request, response) => {
      const input = translateSchema.parse(request.body);
      const cues: SubtitleCue[] = input.cues.map((cue) => {
        const result: SubtitleCue = {
          id: cue.id,
          startMs: cue.startMs,
          endMs: cue.endMs,
          original: cue.original,
          translation: cue.translation,
        };
        if (cue.speaker) result.speaker = cue.speaker;
        return result;
      });
      const estimateRuntime = await billing.selectedRuntimeConfig();
      const result = await billing.runMetered(
        authenticatedAccount(response),
        "字幕翻译",
        (runtimeConfig) =>
          translateCues(
            cues,
            input.sourceLanguage,
            input.targetLanguage,
            runtimeConfig,
          ),
        await billing.estimateMaximumUsageCredits(
          JSON.stringify(input),
          Math.ceil(
            cues.filter((cue) => !cue.translation.trim()).length /
              translationBatchSize(estimateRuntime),
          ),
        ),
      );
      response.json({ cues: result.value, billing: result.billing });
    }),
  );

  app.post(
    "/api/dictionary/stream",
    asyncRoute(async (request, response) => {
      const input = dictionarySchema.parse(request.body);
      const estimate = await billing.estimateMaximumUsageCredits(
        JSON.stringify(input),
        1,
      );
      const abortController = new AbortController();
      response.status(200).set({
        "content-type": "text/event-stream; charset=utf-8",
        "cache-control": "no-cache, no-transform",
        connection: "keep-alive",
        "x-accel-buffering": "no",
      });
      response.flushHeaders();

      const send = (event: string, value: unknown) => {
        if (response.destroyed || response.writableEnded) return;
        response.write(`event: ${event}\ndata: ${JSON.stringify(value)}\n\n`);
      };
      const heartbeat = setInterval(() => {
        if (!response.destroyed && !response.writableEnded) {
          response.write(": keep-alive\n\n");
        }
      }, 15_000);
      response.on("close", () => {
        if (!response.writableEnded) abortController.abort();
      });

      try {
        send("status", { message: "正在连接词典模型…" });
        const result = await billing.runMetered(
          authenticatedAccount(response),
          "字幕点击查词",
          (runtimeConfig) =>
            lookupDictionaryStream(
              input.word,
              input.sentence,
              input.targetLanguage,
              runtimeConfig,
              (fields) => send("partial", fields),
              abortController.signal,
            ),
          estimate,
        );
        send("complete", { entry: result.value, billing: result.billing });
      } catch (error) {
        send("error", {
          error: error instanceof Error ? error.message : "词典查询失败。",
        });
      } finally {
        clearInterval(heartbeat);
        if (!response.writableEnded) response.end();
      }
    }),
  );

  // Legacy JSON endpoint retained for older clients; current word lookup
  // calls /api/dictionary/stream and progressively renders fields.
  app.post(
    "/api/dictionary",
    asyncRoute(async (request, response) => {
      const input = dictionarySchema.parse(request.body);
      const result = await billing.runMetered(
        authenticatedAccount(response),
        "字幕点击查词",
        (runtimeConfig) =>
          lookupDictionary(
            input.word,
            input.sentence,
            input.targetLanguage,
            runtimeConfig,
          ),
        await billing.estimateMaximumUsageCredits(JSON.stringify(input), 1),
      );
      response.json({ entry: result.value, billing: result.billing });
    }),
  );

  app.use((_request, response) => {
    response.status(404).json({ error: "接口不存在。" });
  });

  const errorHandler: ErrorRequestHandler = (
    error,
    _request,
    response,
    _next,
  ) => {
    const message =
      error instanceof ZodError
        ? error.issues.map((issue) => issue.message).join("；")
        : error instanceof Error
          ? error.message
          : "服务端发生未知错误。";
    const status =
      error instanceof ZodError
        ? 400
        : error instanceof BillingError
          ? error.status
          : /尚未配置/.test(message)
            ? 503
            : /暂时不可用/.test(message)
              ? 502
              : 500;
    if (status >= 500) {
      console.error(
        `[request-failed] ${error instanceof Error ? error.name : "Error"}`,
      );
    }
    response.status(status).json({
      error: message,
      ...(error instanceof BillingError ? { code: error.code } : {}),
    });
  };
  app.use(errorHandler);
  return app;
}

export const app = createApp();

export async function initializeApp(): Promise<void> {
  await import("node:fs/promises").then(({ mkdir }) =>
    mkdir(config.dataDir, { recursive: true }),
  );
  if (Boolean(config.localAdminUsername) !== Boolean(config.localAdminPassword)) {
    throw new Error(
      "LOCAL_ADMIN_USERNAME 与 LOCAL_ADMIN_PASSWORD 必须同时配置。",
    );
  }
  await billing.ensureBootstrapAdmin(
    config.localAdminUsername,
    config.localAdminPassword,
  );
}

async function start(): Promise<void> {
  await initializeApp();
  app.listen(config.port, config.host, () => {
    console.log(`影语字幕服务已启动：http://${config.host}:${config.port}`);
  });
}

const entryPoint = process.argv[1]
  ? pathToFileURL(process.argv[1]).href
  : undefined;
if (entryPoint === import.meta.url) {
  void start();
}
