import { createHash, randomInt, randomUUID, timingSafeEqual } from "node:crypto";
import path from "node:path";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";

import nodemailer from "nodemailer";

import { BillingError } from "./billing.js";
import type { AppConfig } from "./config.js";

type VerificationRecord = {
  emailNormalized: string;
  codeHash: string;
  sentAt: string;
  expiresAt: string;
  attempts: number;
};

type VerificationDatabase = {
  version: 1;
  records: VerificationRecord[];
};

export type MailSender = {
  sendMail(options: {
    from: string;
    to: string;
    subject: string;
    text: string;
    html: string;
  }): Promise<unknown>;
};

export function normalizeEmail(email: string): string {
  return email.normalize("NFKC").trim().toLocaleLowerCase("en-US");
}

function safeEqual(left: string, right: string): boolean {
  const leftBuffer = Buffer.from(left, "hex");
  const rightBuffer = Buffer.from(right, "hex");
  return (
    leftBuffer.length === rightBuffer.length &&
    timingSafeEqual(leftBuffer, rightBuffer)
  );
}

export class EmailVerificationService {
  private readonly databasePath: string;
  private readonly mailer: MailSender | undefined;
  private database?: VerificationDatabase;
  private storageTail: Promise<void> = Promise.resolve();

  constructor(
    private readonly value: AppConfig,
    mailer?: MailSender,
  ) {
    this.databasePath = path.join(
      value.dataDir,
      "auth",
      "email-verifications.json",
    );
    this.mailer = mailer ?? this.createMailer();
  }

  get configured(): boolean {
    const authComplete =
      (!this.value.smtpUser && !this.value.smtpPassword) ||
      Boolean(this.value.smtpUser && this.value.smtpPassword);
    return Boolean(
      this.value.smtpHost && this.value.smtpFrom && authComplete && this.mailer,
    );
  }

  private createMailer(): MailSender | undefined {
    if (!this.value.smtpHost || !this.value.smtpFrom) return undefined;
    return nodemailer.createTransport({
      host: this.value.smtpHost,
      port: this.value.smtpPort,
      secure: this.value.smtpSecure,
      ...(this.value.smtpUser && this.value.smtpPassword
        ? {
            auth: {
              user: this.value.smtpUser,
              pass: this.value.smtpPassword,
            },
          }
        : {}),
    });
  }

  private hash(emailNormalized: string, code: string): string {
    return createHash("sha256")
      .update(this.value.authTokenPepper)
      .update("\0email-verification\0")
      .update(emailNormalized)
      .update("\0")
      .update(code)
      .digest("hex");
  }

  private async load(): Promise<VerificationDatabase> {
    if (this.database) return this.database;
    try {
      const parsed = JSON.parse(
        await readFile(this.databasePath, "utf8"),
      ) as VerificationDatabase;
      if (parsed.version !== 1 || !Array.isArray(parsed.records)) {
        throw new Error("invalid email verification database");
      }
      this.database = parsed;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") {
        throw new Error("邮箱验证数据库无法读取。");
      }
      this.database = { version: 1, records: [] };
    }
    return this.database;
  }

  private async persist(database: VerificationDatabase): Promise<void> {
    await mkdir(path.dirname(this.databasePath), { recursive: true });
    const temporary = `${this.databasePath}.${process.pid}.${randomUUID()}.tmp`;
    await writeFile(temporary, JSON.stringify(database, null, 2), {
      encoding: "utf8",
      mode: 0o600,
    });
    await rename(temporary, this.databasePath);
  }

  private exclusive<T>(
    action: (database: VerificationDatabase) => Promise<T> | T,
  ): Promise<T> {
    const result = this.storageTail.then(
      async () => action(await this.load()),
      async () => action(await this.load()),
    );
    this.storageTail = result.then(
      () => undefined,
      () => undefined,
    );
    return result;
  }

  async request(email: string): Promise<{ expiresInSeconds: number }> {
    if (!this.configured || !this.mailer) {
      throw new BillingError(
        "邮箱验证服务尚未配置，请联系管理员。",
        503,
        "email_service_unavailable",
      );
    }
    const emailNormalized = normalizeEmail(email);
    const now = Date.now();
    const code = randomInt(100_000, 1_000_000).toString();
    const codeHash = this.hash(emailNormalized, code);
    const expiresAt = new Date(
      now + this.value.emailVerificationTtlSeconds * 1000,
    ).toISOString();

    await this.exclusive(async (database) => {
      database.records = database.records.filter(
        (record) => Date.parse(record.expiresAt) > now,
      );
      const existing = database.records.find(
        (record) => record.emailNormalized === emailNormalized,
      );
      if (existing && now - Date.parse(existing.sentAt) < 60_000) {
        throw new BillingError(
          "验证码发送过于频繁，请稍后再试。",
          429,
          "email_code_rate_limited",
        );
      }
      database.records = database.records.filter(
        (record) => record.emailNormalized !== emailNormalized,
      );
      database.records.push({
        emailNormalized,
        codeHash,
        sentAt: new Date(now).toISOString(),
        expiresAt,
        attempts: 0,
      });
      await this.persist(database);
    });

    try {
      await this.mailer.sendMail({
        from: this.value.smtpFrom,
        to: emailNormalized,
        subject: "影语注册验证码",
        text: `你的影语注册验证码是 ${code}。验证码将在 ${Math.ceil(this.value.emailVerificationTtlSeconds / 60)} 分钟后失效。若非本人操作，请忽略此邮件。`,
        html: [
          '<div style="font-family:Arial,sans-serif;color:#1b1d1f;line-height:1.6">',
          "<h2>影语注册验证</h2>",
          "<p>你的注册验证码是：</p>",
          `<p style="font-size:28px;font-weight:700;letter-spacing:6px">${code}</p>`,
          `<p>验证码将在 ${Math.ceil(this.value.emailVerificationTtlSeconds / 60)} 分钟后失效。若非本人操作，请忽略此邮件。</p>`,
          "</div>",
        ].join(""),
      });
    } catch {
      await this.invalidate(emailNormalized, codeHash);
      throw new BillingError(
        "验证邮件暂时无法发送，请稍后重试。",
        502,
        "email_delivery_failed",
      );
    }
    return { expiresInSeconds: this.value.emailVerificationTtlSeconds };
  }

  private async invalidate(
    emailNormalized: string,
    codeHash: string,
  ): Promise<void> {
    await this.exclusive(async (database) => {
      const next = database.records.filter(
        (record) =>
          record.emailNormalized !== emailNormalized ||
          record.codeHash !== codeHash,
      );
      if (next.length === database.records.length) return;
      database.records = next;
      await this.persist(database);
    });
  }

  async consume(email: string, code: string): Promise<void> {
    const emailNormalized = normalizeEmail(email);
    await this.exclusive(async (database) => {
      const record = database.records.find(
        (item) => item.emailNormalized === emailNormalized,
      );
      const now = Date.now();
      if (!record || Date.parse(record.expiresAt) <= now) {
        database.records = database.records.filter(
          (item) => item.emailNormalized !== emailNormalized,
        );
        await this.persist(database);
        throw new BillingError(
          "验证码无效或已过期，请重新获取。",
          400,
          "invalid_email_code",
        );
      }
      record.attempts += 1;
      const valid = safeEqual(record.codeHash, this.hash(emailNormalized, code));
      if (!valid) {
        if (record.attempts >= 5) {
          database.records = database.records.filter(
            (item) => item.emailNormalized !== emailNormalized,
          );
        }
        await this.persist(database);
        throw new BillingError(
          "验证码错误。",
          400,
          "invalid_email_code",
        );
      }
      database.records = database.records.filter(
        (item) => item.emailNormalized !== emailNormalized,
      );
      await this.persist(database);
    });
  }
}
