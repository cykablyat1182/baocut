import type { AppConfig } from "./config.js";

type Fetcher = typeof fetch;

interface OpenListResponse {
  code?: number;
  message?: string;
  data?: unknown;
}

export interface ManagedMediaEntry {
  name: string;
  isDirectory: boolean;
  size: number;
}

export interface ManagedMediaLink {
  url: string;
  headers: Record<string, string>;
}

export class OpenListGateway {
  constructor(
    private readonly value: Pick<
      AppConfig,
      | "openListBaseUrl"
      | "openListPublicUrl"
      | "openListToken"
      | "openListMediaRoot"
    >,
    private readonly fetcher: Fetcher = fetch,
  ) {}

  get configured(): boolean {
    return Boolean(this.value.openListToken);
  }

  async list(
    relativePath: string,
    refresh = false,
  ): Promise<ManagedMediaEntry[]> {
    const data = await this.post("/api/fs/list", {
      path: this.storagePath(relativePath),
      password: "",
      page: 1,
      per_page: 0,
      refresh,
    });
    const content = this.record(data)?.content;
    if (!Array.isArray(content)) return [];
    return content.flatMap((raw) => {
      const item = this.record(raw);
      const name = typeof item?.name === "string" ? item.name.trim() : "";
      if (!name || name === "." || name === ".." || name.includes("/")) {
        return [];
      }
      const rawSize = Number(item?.size ?? 0);
      return [
        {
          name,
          isDirectory: item?.is_dir === true || item?.type === 1,
          size: Number.isFinite(rawSize) && rawSize > 0 ? rawSize : 0,
        },
      ];
    });
  }

  async link(
    relativePath: string,
    linkType: "streaming" | "download",
  ): Promise<ManagedMediaLink> {
    let data: unknown;
    try {
      data = await this.post("/api/fs/link", {
        path: this.storagePath(relativePath),
        password: "",
        type: linkType,
      });
    } catch {
      data = await this.post("/api/fs/get", {
        path: this.storagePath(relativePath),
      });
    }
    const record = this.record(data);
    const rawUrl = [
      record?.url,
      record?.raw_url,
      record?.download_url,
      record?.proxy_url,
    ].find((value) => typeof value === "string" && value.trim());
    if (typeof rawUrl !== "string") {
      throw new Error("媒体代理没有返回可播放地址。");
    }
    const url = this.publicUrl(rawUrl.trim());
    const parsed = new URL(url);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
      throw new Error("媒体代理返回了无效地址。");
    }
    const headers: Record<string, string> = {};
    const rawHeaders = this.record(record?.header ?? record?.headers);
    for (const [name, value] of Object.entries(rawHeaders ?? {})) {
      if (typeof value === "string" || typeof value === "number") {
        headers[name] = String(value);
      }
    }
    return { url: parsed.toString(), headers };
  }

  private async post(endpoint: string, body: object): Promise<unknown> {
    if (!this.configured) throw new Error("媒体代理尚未配置。");
    const response = await this.fetcher(`${this.value.openListBaseUrl}${endpoint}`, {
      method: "POST",
      headers: {
        authorization: this.value.openListToken,
        "content-type": "application/json",
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(25_000),
    });
    const decoded = (await response.json()) as OpenListResponse;
    if (!response.ok || decoded.code !== 200) {
      throw new Error(decoded.message?.trim() || `媒体代理请求失败（HTTP ${response.status}）。`);
    }
    return decoded.data;
  }

  private storagePath(relativePath: string): string {
    const normalized = this.relativePath(relativePath);
    const root = `/${this.value.openListMediaRoot}`
      .replaceAll("\\", "/")
      .replace(/\/+/g, "/")
      .replace(/\/$/, "");
    return normalized === "/" ? root : `${root}${normalized}`;
  }

  private relativePath(value: string): string {
    const parts = value
      .trim()
      .replaceAll("\\", "/")
      .split("/")
      .filter(Boolean);
    if (parts.some((part) => part === "." || part === "..")) {
      throw new Error("媒体路径无效。");
    }
    return parts.length === 0 ? "/" : `/${parts.join("/")}`;
  }

  private publicUrl(rawUrl: string): string {
    const resolved = new URL(rawUrl, `${this.value.openListBaseUrl}/`);
    const internal = new URL(this.value.openListBaseUrl);
    if (resolved.origin !== internal.origin) return resolved.toString();
    const publicBase = new URL(`${this.value.openListPublicUrl}/`);
    const internalPrefix = internal.pathname.replace(/\/$/, "");
    const relativePath = resolved.pathname.startsWith(internalPrefix)
      ? resolved.pathname.slice(internalPrefix.length)
      : resolved.pathname;
    publicBase.pathname = `${publicBase.pathname.replace(/\/$/, "")}/${relativePath.replace(/^\//, "")}`;
    publicBase.search = resolved.search;
    return publicBase.toString();
  }

  private record(value: unknown): Record<string, unknown> | undefined {
    return value && typeof value === "object" && !Array.isArray(value)
      ? (value as Record<string, unknown>)
      : undefined;
  }
}
