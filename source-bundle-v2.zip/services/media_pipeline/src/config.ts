import dotenv from "dotenv";

import path from "node:path";

import { z } from "zod";

import {
  loadPrivateModelConfig,
  type PrivateModelRuntime,
  type UsagePricing,
} from "./private-model-config.js";
import { resolveModelPricing } from "./model-pricing.js";

dotenv.config();
if (process.env.YINGYU_LOCAL_PIPELINE === "1") {
  // The source Windows player starts the local service with this marker so a
  // stale shell-level ARK_* variable cannot override the private local model
  // profile. Normal deployments keep the conventional .env behavior.
  dotenv.config({
    path: process.env.YINGYU_LOCAL_ENV_FILE || ".env.local",
    override: true,
  });
}

const environmentSchema = z.object({
  HOST: z.string().trim().min(1).default("127.0.0.1"),
  PORT: z.coerce.number().int().min(1).max(65_535).default(8787),
  DATA_DIR: z.string().trim().min(1).default("./data"),
  FFMPEG_PATH: z.string().trim().min(1).default("ffmpeg"),
  VOLC_SPEECH_API_KEY: z.string().trim().default(""),
  VOLC_SPEECH_RESOURCE_ID: z
    .string()
    .trim()
    .min(1)
    .default("volc.seedasr.auc"),
  TOS_ACCESS_KEY_ID: z.string().trim().default(""),
  TOS_SECRET_ACCESS_KEY: z.string().trim().default(""),
  TOS_REGION: z.string().trim().min(1).default("cn-beijing"),
  TOS_ENDPOINT: z
    .string()
    .trim()
    .min(1)
    .default("tos-cn-beijing.volces.com"),
  TOS_BUCKET: z.string().trim().default(""),
  TOS_SIGNED_URL_TTL_SECONDS: z.coerce
    .number()
    .int()
    .min(900)
    .max(86_400)
    .default(7200),
  ARK_API_KEY: z.string().trim().default(""),
  ARK_MODEL: z.string().trim().default(""),
  ARK_BASE_URL: z
    .string()
    .url()
    .default("https://ark.cn-beijing.volces.com/api/v3"),
  MODEL_CONFIG_PATH: z.string().trim().default(""),
  MODEL_PRICING_PROFILE: z.string().trim().min(1).default("auto"),
  MODEL_PRICING_CURRENCY: z
    .string()
    .trim()
    .toLowerCase()
    .regex(/^[a-z]{3}$/)
    .default("cny"),
  MODEL_PRICING_TIERS_JSON: z.string().trim().default(""),
  BILLING_CREDITS_PER_CURRENCY_UNIT: z.coerce
    .number()
    .int()
    .min(1)
    .max(1_000_000)
    .default(100),
  BILLING_MARKUP_MULTIPLIER: z.coerce
    .number()
    .finite()
    .min(0.01)
    .max(1000)
    .default(2),
  AUTH_TOKEN_PEPPER: z.string().default(""),
  LOCAL_ADMIN_USERNAME: z
    .string()
    .trim()
    .default("")
    .refine(
      (value) =>
        value.length === 0 ||
        (value.length >= 3 &&
          value.length <= 32 &&
          /^[\p{L}\p{N}_-]+$/u.test(value)),
      "LOCAL_ADMIN_USERNAME 必须为 3 至 32 位文字、数字、下划线或连字符",
    ),
  LOCAL_ADMIN_PASSWORD: z
    .string()
    .default("")
    .refine((value) => value.length === 0 || value.length >= 8, {
      message: "LOCAL_ADMIN_PASSWORD 至少需要 8 个字符",
    }),
  SMTP_HOST: z.string().trim().default(""),
  SMTP_PORT: z.coerce.number().int().min(1).max(65_535).default(587),
  SMTP_SECURE: z
    .enum(["true", "false"])
    .default("false")
    .transform((value) => value === "true"),
  SMTP_USER: z.string().trim().default(""),
  SMTP_PASSWORD: z.string().default(""),
  SMTP_FROM: z.string().trim().default(""),
  EMAIL_VERIFICATION_TTL_SECONDS: z.coerce
    .number()
    .int()
    .min(300)
    .max(3600)
    .default(600),
  STRIPE_SECRET_KEY: z.string().trim().default(""),
  STRIPE_WEBHOOK_SECRET: z.string().trim().default(""),
  STRIPE_SUCCESS_URL: z.string().trim().default(""),
  STRIPE_CANCEL_URL: z.string().trim().default(""),
  BILLING_PACKAGES_JSON: z.string().trim().default("[]"),
  ALLOWED_ORIGINS: z.string().default(""),
  OPENLIST_BASE_URL: z.string().trim().url().default("http://127.0.0.1:5244/openlist"),
  OPENLIST_PUBLIC_URL: z.string().trim().url().default("http://117.72.29.101/openlist"),
  OPENLIST_TOKEN: z.string().trim().default(""),
  OPENLIST_MEDIA_ROOT: z.string().trim().min(1).default("/夸克扫码"),
  OPENLIST_ALLOWED_USERS: z.string().default(""),
  MAX_UPLOAD_BYTES: z.coerce
    .number()
    .int()
    .positive()
    .default(50 * 1024 * 1024 * 1024),
});

const environment = environmentSchema.parse(process.env);
const privateModelConfig = environment.MODEL_CONFIG_PATH
  ? loadPrivateModelConfig(path.resolve(environment.MODEL_CONFIG_PATH))
  : undefined;

const fallbackModel: PrivateModelRuntime = {
  apiKey: environment.ARK_API_KEY,
  endpoint: `${environment.ARK_BASE_URL.replace(/\/$/, "")}/chat/completions`,
  apiMode: "chat_completions",
  model: environment.ARK_MODEL,
  maxOutputTokens: 8192,
  timeoutMs: 120_000,
};

const fallbackPricing: UsagePricing = {
  initialCredits: 0,
  inputCreditsPerThousandTokens: 1,
  minimumBalanceToStart: 1,
  minimumChargeCredits: 1,
  outputCreditsPerThousandTokens: 1,
};

const privateModel = privateModelConfig?.model ?? fallbackModel;
const legacyUsagePricing = privateModelConfig?.pricing ?? fallbackPricing;
const modelPricing = resolveModelPricing({
  modelName: privateModel.model,
  profile: environment.MODEL_PRICING_PROFILE,
  currency: environment.MODEL_PRICING_CURRENCY,
  serializedTiers: environment.MODEL_PRICING_TIERS_JSON,
  legacyPricing: legacyUsagePricing,
  creditsPerCurrencyUnit: environment.BILLING_CREDITS_PER_CURRENCY_UNIT,
  markupMultiplier: environment.BILLING_MARKUP_MULTIPLIER,
});
const baseModelPrice = modelPricing.tiers[0]!;
const usagePricing = {
  ...legacyUsagePricing,
  inputCreditsPerThousandTokens:
    (baseModelPrice.inputPerMillion / 1000) *
    environment.BILLING_CREDITS_PER_CURRENCY_UNIT *
    environment.BILLING_MARKUP_MULTIPLIER,
  outputCreditsPerThousandTokens:
    (baseModelPrice.outputPerMillion / 1000) *
    environment.BILLING_CREDITS_PER_CURRENCY_UNIT *
    environment.BILLING_MARKUP_MULTIPLIER,
  creditsPerCurrencyUnit: environment.BILLING_CREDITS_PER_CURRENCY_UNIT,
  markupMultiplier: environment.BILLING_MARKUP_MULTIPLIER,
};

export const config = {
  host: environment.HOST,
  port: environment.PORT,
  dataDir: path.resolve(environment.DATA_DIR),
  ffmpegPath: environment.FFMPEG_PATH,
  speechApiKey: environment.VOLC_SPEECH_API_KEY,
  speechResourceId: environment.VOLC_SPEECH_RESOURCE_ID,
  tosAccessKeyId: environment.TOS_ACCESS_KEY_ID,
  tosSecretAccessKey: environment.TOS_SECRET_ACCESS_KEY,
  tosRegion: environment.TOS_REGION,
  tosEndpoint: environment.TOS_ENDPOINT,
  tosBucket: environment.TOS_BUCKET,
  tosSignedUrlTtlSeconds: environment.TOS_SIGNED_URL_TTL_SECONDS,
  privateModel,
  modelPricing,
  usagePricing,
  modelConfigPath: environment.MODEL_CONFIG_PATH
    ? path.resolve(environment.MODEL_CONFIG_PATH)
    : "",
  authTokenPepper: environment.AUTH_TOKEN_PEPPER,
  localAdminUsername: environment.LOCAL_ADMIN_USERNAME,
  localAdminPassword: environment.LOCAL_ADMIN_PASSWORD,
  smtpHost: environment.SMTP_HOST,
  smtpPort: environment.SMTP_PORT,
  smtpSecure: environment.SMTP_SECURE,
  smtpUser: environment.SMTP_USER,
  smtpPassword: environment.SMTP_PASSWORD,
  smtpFrom: environment.SMTP_FROM,
  emailVerificationTtlSeconds: environment.EMAIL_VERIFICATION_TTL_SECONDS,
  stripeSecretKey: environment.STRIPE_SECRET_KEY,
  stripeWebhookSecret: environment.STRIPE_WEBHOOK_SECRET,
  stripeSuccessUrl: environment.STRIPE_SUCCESS_URL,
  stripeCancelUrl: environment.STRIPE_CANCEL_URL,
  billingPackagesJson: environment.BILLING_PACKAGES_JSON,
  allowedOrigins: environment.ALLOWED_ORIGINS.split(",")
    .map((value) => value.trim())
    .filter(Boolean),
  openListBaseUrl: environment.OPENLIST_BASE_URL.replace(/\/$/, ""),
  openListPublicUrl: environment.OPENLIST_PUBLIC_URL.replace(/\/$/, ""),
  openListToken: environment.OPENLIST_TOKEN,
  openListMediaRoot: environment.OPENLIST_MEDIA_ROOT,
  openListAllowedUsers: environment.OPENLIST_ALLOWED_USERS.split(",")
    .map((value) => value.trim().toLowerCase())
    .filter(Boolean),
  maxUploadBytes: environment.MAX_UPLOAD_BYTES,
} as const;

export type AppConfig = typeof config;

export function missingPipelineConfiguration(value: AppConfig): string[] {
  const required = [
    ["VOLC_SPEECH_API_KEY", value.speechApiKey],
    ["TOS_ACCESS_KEY_ID", value.tosAccessKeyId],
    ["TOS_SECRET_ACCESS_KEY", value.tosSecretAccessKey],
    ["TOS_BUCKET", value.tosBucket],
    ["MODEL_SERVICE", value.privateModel.apiKey],
    ["MODEL_SERVICE", value.privateModel.model],
  ] as const;
  return [
    ...new Set(
      required.filter(([, setting]) => !setting).map(([name]) => name),
    ),
  ];
}

export function assertPipelineConfigured(value: AppConfig): void {
  const missing = missingPipelineConfiguration(value);
  if (missing.length > 0) {
    throw new Error(`字幕处理服务尚未配置：${missing.join(", ")}`);
  }
}

export function assertModelConfigured(value: AppConfig): void {
  const missing = [
    !value.privateModel.apiKey ? "MODEL_SERVICE" : "",
    !value.privateModel.model ? "MODEL_SERVICE" : "",
  ].filter(Boolean);
  if (missing.length > 0) {
    throw new Error("翻译服务尚未配置。");
  }
}
