#!/usr/bin/env bash
set -euo pipefail

token="$(sed -n 's/^Admin token: //p' /root/.openlist-admin-token-output)"
curl -fsS \
  -H "Authorization: $token" \
  -H 'Content-Type: application/json' \
  --data-binary '{"path":"/夸克扫码","password":"","page":1,"per_page":100,"refresh":true}' \
  http://127.0.0.1:5244/openlist/api/fs/list | jq -c '{code,message,data:(if .data == null then null else {total:.data.total,content:(.data.content|map({name,is_dir,type,size,raw_url}))} end)}'
