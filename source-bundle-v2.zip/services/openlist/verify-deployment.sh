#!/usr/bin/env bash
set -euo pipefail

credentials_file=/root/.openlist-admin-credentials
token_file=/root/.openlist-admin-token-output
password="$(sed -n 's/^OPENLIST_ADMIN_PASSWORD=//p' "$credentials_file")"
token="$(sed -n 's/^Admin token: //p' "$token_file")"

login_response="$({
  printf '{"username":"admin","password":"%s"}' "$password"
} | curl -fsS \
  -H 'Content-Type: application/json' \
  --data-binary @- \
  http://127.0.0.1:5244/openlist/api/auth/login)"
printf '%s' "$login_response" | grep -q '"code":200'

list_response="$({
  printf '%s' '{"path":"/","password":"","page":1,"per_page":0,"refresh":false}'
} | curl -fsS \
  -H 'Content-Type: application/json' \
  -H "Authorization: $token" \
  --data-binary @- \
  http://127.0.0.1:5244/openlist/api/fs/list)"

echo 'admin_login=ok'
if printf '%s' "$list_response" | grep -q 'storage not found'; then
  echo 'admin_token=ok; storage=not_configured'
elif printf '%s' "$list_response" | grep -q '"code":200'; then
  echo 'admin_token=ok; storage=configured'
else
  echo 'admin_token_check=failed'
  exit 1
fi

systemctl is-enabled openlist
systemctl is-active openlist
