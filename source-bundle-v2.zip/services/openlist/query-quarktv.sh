#!/usr/bin/env bash
set -euo pipefail

token="$(sed -n 's/^Admin token: //p' /root/.openlist-admin-token-output)"
base_url=http://127.0.0.1:5244/openlist/api

curl -fsS -H "Authorization: $token" "$base_url/admin/storage/list"
printf '\n'
curl -fsS -H "Authorization: $token" "$base_url/admin/driver/info?driver=QuarkTV"
printf '\n'
