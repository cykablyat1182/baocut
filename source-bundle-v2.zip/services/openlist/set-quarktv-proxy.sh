#!/usr/bin/env bash
set -euo pipefail

token="$(sed -n 's/^Admin token: //p' /root/.openlist-admin-token-output)"
base=http://127.0.0.1:5244/openlist/api
storage_id="${1:-2}"
storage="$(curl -fsS -H "Authorization: $token" "$base/admin/storage/get?id=$storage_id" | jq -c '.data')"
printf '%s' "$storage" > /root/quarktv-config-before-proxy.json
printf '%s' "$storage" | jq -c '.web_proxy=true | .webdav_policy="native_proxy" | .disable_proxy_sign=false | .enable_sign=true' | \
  curl -fsS -H 'Content-Type: application/json' -H "Authorization: $token" \
  --data-binary @- "$base/admin/storage/update"
printf '\n'
curl -fsS -H "Authorization: $token" "$base/admin/storage/get?id=$storage_id" | \
  jq -c '{code,message,data:{mount_path:.data.mount_path,driver:.data.driver,status:.data.status,web_proxy:.data.web_proxy,webdav_policy:.data.webdav_policy}}'
