#!/usr/bin/env bash
set -euo pipefail

token="$(sed -n 's/^Admin token: //p' /root/.openlist-admin-token-output)"
base_url=http://127.0.0.1:5244/openlist/api
storage_id="${1:-2}"

for _ in $(seq 1 100); do
  curl -fsS -X POST -H "Authorization: $token" \
    "$base_url/admin/storage/disable?id=$storage_id" >/dev/null
  curl -sS -X POST -H "Authorization: $token" \
    "$base_url/admin/storage/enable?id=$storage_id" >/dev/null

  status="$(curl -fsS -H "Authorization: $token" \
    "$base_url/admin/storage/get?id=$storage_id" | jq -r '.data.status')"
  if [[ "$status" == "work" ]]; then
    echo 'quarktv_login=ok'
    exit 0
  fi
  if [[ "$status" == *'二维码过期'* ]]; then
    echo 'quarktv_login=expired'
    exit 1
  fi
  sleep 3
done

echo 'quarktv_login=timeout'
exit 1
