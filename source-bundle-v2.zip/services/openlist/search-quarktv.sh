#!/usr/bin/env bash
set -euo pipefail

token="$(sed -n 's/^Admin token: //p' /root/.openlist-admin-token-output)"
curl -fsS \
  -H "Authorization: $token" \
  -H 'Content-Type: application/json' \
  --data-binary '{"parent":"/夸克扫码","keywords":"","scope":0,"page":1,"per_page":100}' \
  http://127.0.0.1:5244/openlist/api/fs/search | jq -c .
