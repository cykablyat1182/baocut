#!/usr/bin/env bash
set -euo pipefail

token="$(sed -n 's/^Admin token: //p' /root/.openlist-admin-token-output)"
base=http://127.0.0.1:5244/openlist/api
storage_id="${1:-2}"
storage="$(curl -fsS -H "Authorization: $token" "$base/admin/storage/get?id=$storage_id" | jq -c '.data')"
addition="$(printf '%s' "$storage" | jq -r '.addition' | jq -c '.link_method="streaming"')"
printf '%s' "$storage" | jq -c --arg addition "$addition" '.addition=$addition' | \
  curl -fsS -H 'Content-Type: application/json' -H "Authorization: $token" \
  --data-binary @- "$base/admin/storage/update"
printf '\n'
curl -fsS -H "Authorization: $token" "$base/admin/storage/get?id=$storage_id" | \
  jq -r '.data | {status,addition}'
