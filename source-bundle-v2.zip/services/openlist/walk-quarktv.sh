#!/usr/bin/env bash
set -euo pipefail

token="$(sed -n 's/^Admin token: //p' /root/.openlist-admin-token-output)"
base=http://127.0.0.1:5244/openlist/api

walk() {
  local path="$1"
  local depth="$2"
  if (( depth > 4 )); then return; fi
  local response
  response="$(curl -fsS -H "Authorization: $token" -H 'Content-Type: application/json' \
    --data-binary @- "$base/fs/list" <<JSON
{"path":"$path","password":"","page":1,"per_page":100,"refresh":false}
JSON
)"
  printf '%s\n' "$response" | jq -r --arg path "$path" \
    '.data.content[]? | [$path, .name, (.is_dir // false), (.size // 0)] | @tsv'
  while IFS=$'\t' read -r name is_dir _; do
    if [[ "$is_dir" == "true" ]]; then
      local child="$path/$name"
      child="${child//\/\//\/}"
      walk "$child" "$((depth + 1))"
    fi
  done < <(printf '%s\n' "$response" | jq -r '.data.content[]? | [.name, (.is_dir // false), (.size // 0)] | @tsv')
}

walk /夸克扫码 0
