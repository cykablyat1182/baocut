const base = process.env.PIPELINE_BASE || "http://127.0.0.1";
const username = process.env.LOCAL_ADMIN_USERNAME || "";
const password = process.env.LOCAL_ADMIN_PASSWORD || "";

async function post(path, body, token = "") {
  const response = await fetch(`${base}${path}`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      ...(token ? { authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(body),
  });
  const data = await response.json();
  if (!response.ok) throw new Error(`${path}: HTTP ${response.status}`);
  return data;
}

const login = await post("/api/admin/auth/login", { username, password });
const token = login.accessToken;
if (!token) throw new Error("admin login did not return a token");

const videoExtensions = new Set(["mkv", "mp4", "webm", "avi", "mov"]);
const queue = ["/"];
let visited = 0;
let mediaPath = "";
while (queue.length > 0 && visited < 80 && !mediaPath) {
  const path = queue.shift();
  const result = await post("/api/media/library/list", { path }, token);
  visited += 1;
  for (const entry of result.entries || []) {
    const child = path === "/" ? `/${entry.name}` : `${path}/${entry.name}`;
    if (entry.isDirectory) queue.push(child);
    else if (videoExtensions.has(entry.name.split(".").pop()?.toLowerCase())) {
      mediaPath = child;
      break;
    }
  }
}
if (!mediaPath) throw new Error("managed catalog did not contain a video");

const link = await post(
  "/api/media/library/link",
  { path: mediaPath, type: "streaming" },
  token,
);
const mediaResponse = await fetch(link.url, {
  headers: { ...(link.headers || {}), range: "bytes=0-1" },
});
await mediaResponse.body?.cancel();
console.log(
  JSON.stringify({
    catalogReachable: true,
    directoriesVisited: visited,
    mediaLinkIssued: Boolean(link.url),
    mediaStatus: mediaResponse.status,
    rangeSupported: mediaResponse.status === 206,
  }),
);
