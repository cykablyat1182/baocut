#!/usr/bin/env bash
set -euo pipefail

token="$(sed -n 's/^Admin token: //p' /root/.openlist-admin-token-output)"
base_url=http://127.0.0.1:5244/openlist/api
mount_path=/夸克扫码

storage_list="$(curl -fsS -H "Authorization: $token" "$base_url/admin/storage/list")"
if printf '%s' "$storage_list" | grep -Fq "\"mount_path\":\"$mount_path\""; then
  printf '%s\n' "$storage_list"
  exit 0
fi

curl -fsS \
  -H 'Content-Type: application/json' \
  -H "Authorization: $token" \
  --data-binary @- \
  "$base_url/admin/storage/create" <<'JSON'
{
  "mount_path": "/夸克扫码",
  "order": 0,
  "remark": "夸克TV扫码登录（仅浏览、播放和下载）",
  "cache_expiration": 30,
  "custom_cache_policies": "",
  "web_proxy": false,
  "webdav_policy": "302_redirect",
  "down_proxy_url": "",
  "disable_proxy_sign": false,
  "extract_folder": "",
  "disable_index": false,
  "enable_sign": false,
  "driver": "QuarkTV",
  "addition": "{\"root_folder_id\":\"0\",\"order_by\":\"updated_at\",\"order_direction\":\"desc\",\"refresh_token\":\"\",\"device_id\":\"\",\"query_token\":\"\",\"link_method\":\"download\"}"
}
JSON
printf '\n'
