#!/usr/bin/env bash
set -euo pipefail

token="$(sed -n 's/^Admin token: //p' /root/.openlist-admin-token-output)"
path="${1:?remote path required}"
printf '%s' "$path" | jq -R '{path:.,password:""}' | curl -fsS \
  -H "Authorization: $token" -H 'Content-Type: application/json' \
  --data-binary @- http://127.0.0.1:5244/openlist/api/fs/link | jq -c .
