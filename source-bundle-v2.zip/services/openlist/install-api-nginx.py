from pathlib import Path


CONFIG = Path("/etc/nginx/conf.d/yingyu-default.conf")
MARKER = "location = /health"
ANCHOR = """    location /openlist/ {"""
BLOCK = """    location = /health {
        proxy_set_header Host $http_host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_pass http://127.0.0.1:8787/health;
    }

    location /api/ {
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Host $http_host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_pass http://127.0.0.1:8787;
        proxy_http_version 1.1;
        proxy_request_buffering off;
        client_max_body_size 20000m;
    }

"""


text = CONFIG.read_text(encoding="utf-8")
first_server_end = text.find("\n}\n", text.find("server {"))
first_server = text[:first_server_end]
if MARKER not in first_server:
    anchor_at = text.find(ANCHOR)
    if anchor_at < 0 or anchor_at > first_server_end:
        raise SystemExit("default server OpenList location was not found")
    text = text[:anchor_at] + BLOCK + text[anchor_at:]
    CONFIG.write_text(text, encoding="utf-8")
