#!/usr/bin/env bash
set -euo pipefail

token="$(sed -n 's/^Admin token: //p' /root/.openlist-admin-token-output)"
base_url=http://127.0.0.1:5244/openlist/api
storage_id="${1:-2}"

curl -fsS -X POST -H "Authorization: $token" \
  "$base_url/admin/storage/disable?id=$storage_id"
printf '\n'
curl -fsS -X POST -H "Authorization: $token" \
  "$base_url/admin/storage/enable?id=$storage_id"
printf '\n'
curl -fsS -H "Authorization: $token" \
  "$base_url/admin/storage/get?id=$storage_id"
printf '\n'
