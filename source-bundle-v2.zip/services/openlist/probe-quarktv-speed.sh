#!/usr/bin/env bash
set -euo pipefail

token="$(sed -n 's/^Admin token: //p' /root/.openlist-admin-token-output)"
path="${1:?remote path required}"
payload="$(printf '%s' "$path" | jq -R '{path:.,password:""}')"
url="$(printf '%s' "$payload" | curl -fsS -H "Authorization: $token" \
  -H 'Content-Type: application/json' --data-binary @- \
  http://127.0.0.1:5244/openlist/api/fs/get | jq -r '.data.raw_url')"
curl -L -sS -o /dev/null -r 0-1048575 \
  -w 'http=%{http_code} bytes=%{size_download} speed=%{speed_download} time=%{time_total} type=%{content_type}\n' \
  "$url"
