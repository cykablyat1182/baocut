#!/usr/bin/env bash
set -euo pipefail

token="$(sed -n 's/^Admin token: //p' /root/.openlist-admin-token-output)"
path="${1:?remote path required}"
curl -fsS -H "Authorization: $token" -H 'Content-Type: application/json' \
  --data-binary @- http://127.0.0.1:5244/openlist/api/fs/get <<JSON | jq -c '{code,message,data:(if .data == null then null else {raw_url:(.data.raw_url|split("?")[0]),header:.data.header,size:.data.size} end)}'
{"path":"$path","password":""}
JSON
