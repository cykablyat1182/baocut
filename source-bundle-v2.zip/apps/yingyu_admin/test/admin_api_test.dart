import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:yingyu_admin/admin_api.dart';

void main() {
  test('uses the dedicated administrator login endpoint', () async {
    final client = AdminApi(
      client: MockClient((request) async {
        expect(request.url.path, '/api/admin/auth/login');
        final body = jsonDecode(request.body) as Map<String, dynamic>;
        expect(body['username'], 'operator');
        return http.Response(
          jsonEncode({
            'accessToken': 'a' * 43,
            'account': {
              'accountId': 'admin-1',
              'profile': {
                'username': 'operator',
                'displayName': 'Operator',
                'role': 'admin',
              },
            },
          }),
          200,
          headers: {'content-type': 'application/json; charset=utf-8'},
        );
      }),
    );

    final session = await client.login(
      baseUrl: 'http://127.0.0.1:8787',
      username: 'operator',
      password: 'password-123',
    );

    expect(session.accountId, 'admin-1');
    expect(session.displayName, 'Operator');
    client.close();
  });

  test('rejects a normal user response from the admin endpoint', () async {
    final client = AdminApi(
      client: MockClient(
        (_) async => http.Response(
          jsonEncode({
            'accessToken': 'a' * 43,
            'account': {
              'accountId': 'user-1',
              'profile': {
                'username': 'alice',
                'displayName': 'Alice',
                'role': 'user',
              },
            },
          }),
          200,
          headers: {'content-type': 'application/json; charset=utf-8'},
        ),
      ),
    );

    await expectLater(
      client.login(
        baseUrl: 'http://127.0.0.1:8787',
        username: 'alice',
        password: 'password-123',
      ),
      throwsA(
        isA<AdminApiException>().having(
          (error) => error.message,
          'message',
          '当前账户不是管理员。',
        ),
      ),
    );
    client.close();
  });

  test('parses token, estimated billing, and recharge aggregates', () async {
    final client = AdminApi(
      client: MockClient((request) async {
        if (request.url.path == '/api/admin/auth/login') {
          return http.Response(
            jsonEncode({
              'accessToken': 'a' * 43,
              'account': {
                'accountId': 'admin-1',
                'profile': {
                  'username': 'operator',
                  'displayName': 'Operator',
                  'role': 'admin',
                },
              },
            }),
            200,
            headers: {'content-type': 'application/json; charset=utf-8'},
          );
        }
        return http.Response(
          jsonEncode({
            'accounts': [
              {
                'accountId': 'user-1',
                'usage': {
                  'inputTokens': 1000,
                  'outputTokens': 500,
                  'totalTokens': 1500,
                  'chargedCredits': 4,
                  'estimatedCredits': 5,
                },
                'funding': {
                  'topUpCredits': 100,
                  'topUpCount': 1,
                  'paidAmounts': [
                    {'currency': 'cny', 'amountMinor': 990},
                  ],
                },
              },
            ],
            'overview': {
              'accountCount': 2,
              'usage': {'totalTokens': 1500, 'estimatedCredits': 5},
              'funding': {
                'topUpCredits': 100,
                'paidAmounts': [
                  {'currency': 'cny', 'amountMinor': 990},
                ],
              },
            },
          }),
          200,
          headers: {'content-type': 'application/json; charset=utf-8'},
        );
      }),
    );
    await client.login(
      baseUrl: 'http://127.0.0.1:8787',
      username: 'operator',
      password: 'password-123',
    );

    final dashboard = await client.dashboard();

    expect(dashboard.accounts.single.usage.totalTokens, 1500);
    expect(dashboard.accounts.single.funding.topUpCredits, 100);
    expect(dashboard.overview.usage.estimatedCredits, 5);
    expect(dashboard.overview.funding.paidAmounts.single.amountMinor, 990);
    client.close();
  });

  test('updates the server-side point conversion policy', () async {
    final client = AdminApi(
      client: MockClient((request) async {
        if (request.url.path == '/api/admin/auth/login') {
          return http.Response(
            jsonEncode({
              'accessToken': 'a' * 43,
              'account': {
                'accountId': 'admin-1',
                'profile': {
                  'username': 'operator',
                  'displayName': 'Operator',
                  'role': 'admin',
                },
              },
            }),
            200,
          );
        }
        expect(request.method, 'PATCH');
        expect(request.url.path, '/api/admin/pricing');
        final body = jsonDecode(request.body) as Map<String, dynamic>;
        expect(body['creditsPerCurrencyUnit'], 100);
        expect(body['markupMultiplier'], 2.5);
        return http.Response(
          jsonEncode({
            'pricing': {
              ...body,
              'profile': 'doubao-seed-2.0-mini',
              'currency': 'cny',
              'tiers': [],
            },
          }),
          200,
        );
      }),
    );
    await client.login(
      baseUrl: 'http://127.0.0.1:8787',
      username: 'operator',
      password: 'password-123',
    );

    final pricing = await client.updatePricing(
      initialCredits: 100,
      minimumBalanceToStart: 2,
      minimumChargeCredits: 1,
      creditsPerCurrencyUnit: 100,
      markupMultiplier: 2.5,
    );

    expect(pricing.profile, 'doubao-seed-2.0-mini');
    expect(pricing.markupMultiplier, 2.5);
    client.close();
  });

  test('requires HTTPS for non-loopback administrator services', () async {
    final client = AdminApi(
      client: MockClient((_) async => throw StateError('unused')),
    );

    await expectLater(
      client.login(
        baseUrl: 'http://192.168.1.20:8787',
        username: 'operator',
        password: 'password-123',
      ),
      throwsA(
        isA<AdminApiException>().having(
          (error) => error.message,
          'message',
          '远程后台地址必须使用 HTTPS。',
        ),
      ),
    );
    client.close();
  });
}
