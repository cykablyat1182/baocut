import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:yingyu_admin/admin_api.dart';
import 'package:yingyu_admin/main.dart';

void main() {
  testWidgets('shows the standalone administrator login', (tester) async {
    await tester.pumpWidget(const YingYuAdminApp(persistEndpoint: false));
    await tester.pump();

    expect(find.text('影语后台管理端'), findsOneWidget);
    expect(find.text('管理员用户名'), findsOneWidget);
    expect(find.text('进入管理后台'), findsOneWidget);
    expect(find.text('注册'), findsNothing);
  });

  testWidgets('loads the account dashboard after administrator login', (
    tester,
  ) async {
    await tester.binding.setSurfaceSize(const Size(1440, 900));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    final api = AdminApi(
      client: MockClient((request) async {
        if (request.url.path == '/api/admin/auth/login') {
          return http.Response(
            jsonEncode({
              'accessToken': 'a' * 43,
              'account': {
                'accountId': 'admin-1',
                'profile': {
                  'username': 'operator',
                  'displayName': 'Operator',
                  'role': 'admin',
                },
              },
            }),
            200,
            headers: {'content-type': 'application/json; charset=utf-8'},
          );
        }
        if (request.url.path == '/api/admin/models') {
          return http.Response(
            jsonEncode({
              'active': {
                'id': 'doubao-seed-2-0-mini-260428',
                'name': 'doubao-seed-2.0-mini',
              },
              'source': 'provider',
              'refreshedAt': '2026-08-01T00:00:00.000Z',
              'warning': null,
              'models': [
                {
                  'id': 'doubao-seed-2-0-mini-260428',
                  'name': 'doubao-seed-2.0-mini',
                  'domain': 'VLM',
                  'status': 'Published',
                  'contextWindow': 262144,
                  'maxInputTokens': 229376,
                  'maxOutputTokens': 131072,
                  'supportsStructuredOutput': true,
                  'suggestedPricing': {
                    'profile': 'doubao-seed-2.0-mini',
                    'currency': 'cny',
                    'checkedAt': '2026-08-01',
                    'tiers': [
                      {
                        'upToInputTokens': 32000,
                        'inputPerMillion': 0.2,
                        'outputPerMillion': 2,
                      },
                    ],
                  },
                },
                {
                  'id': 'doubao-seed-translation-250915',
                  'name': 'doubao-seed-translation',
                  'domain': 'LLM',
                  'status': 'Published',
                  'contextWindow': 4096,
                  'maxInputTokens': 1024,
                  'maxOutputTokens': 3072,
                  'supportsStructuredOutput': false,
                  'suggestedPricing': null,
                },
              ],
            }),
            200,
            headers: {'content-type': 'application/json; charset=utf-8'},
          );
        }
        expect(request.url.path, '/api/admin/accounts');
        expect(request.headers['authorization'], 'Bearer ${'a' * 43}');
        return http.Response(
          jsonEncode({
            'accounts': [
              {
                'accountId': 'user-1',
                'username': 'alice',
                'email': 'alice@example.com',
                'emailVerified': true,
                'displayName': 'Alice',
                'role': 'user',
                'isGuest': false,
                'disabled': false,
                'balanceCredits': 120,
                'usage': {
                  'inputTokens': 1000,
                  'outputTokens': 500,
                  'totalTokens': 1500,
                  'chargedCredits': 4,
                  'estimatedCredits': 5,
                },
                'funding': {
                  'initialGrantCredits': 20,
                  'topUpCredits': 100,
                  'topUpCount': 1,
                  'adminAdjustmentCredits': 4,
                  'paidAmounts': [
                    {'currency': 'cny', 'amountMinor': 990},
                  ],
                },
                'createdAt': '2026-08-01T00:00:00.000Z',
                'updatedAt': '2026-08-01T00:00:00.000Z',
              },
            ],
            'overview': {
              'accountCount': 2,
              'registeredAccountCount': 2,
              'verifiedEmailCount': 1,
              'disabledAccountCount': 0,
              'totalBalanceCredits': 120,
              'usage': {
                'inputTokens': 1000,
                'outputTokens': 500,
                'totalTokens': 1500,
                'chargedCredits': 4,
                'estimatedCredits': 5,
              },
              'funding': {
                'initialGrantCredits': 20,
                'topUpCredits': 100,
                'topUpCount': 1,
                'adminAdjustmentCredits': 4,
                'paidAmounts': [
                  {'currency': 'cny', 'amountMinor': 990},
                ],
              },
            },
            'pricing': {
              'modelId': 'doubao-seed-2-0-mini-260428',
              'profile': 'doubao-seed-2.0-mini',
              'currency': 'cny',
              'checkedAt': '2026-08-01',
              'initialCredits': 100,
              'minimumBalanceToStart': 2,
              'minimumChargeCredits': 1,
              'creditsPerCurrencyUnit': 100,
              'markupMultiplier': 2,
              'tiers': [
                {
                  'upToInputTokens': 32000,
                  'inputPerMillion': 0.2,
                  'outputPerMillion': 2,
                },
              ],
            },
          }),
          200,
          headers: {'content-type': 'application/json; charset=utf-8'},
        );
      }),
    );
    addTearDown(api.close);

    await tester.pumpWidget(YingYuAdminApp(api: api, persistEndpoint: false));
    await tester.enterText(
      find.widgetWithText(TextField, '管理员用户名'),
      'operator',
    );
    await tester.enterText(
      find.widgetWithText(TextField, '管理员密码'),
      'password-123',
    );
    await tester.tap(find.text('进入管理后台'));
    await tester.pumpAndSettle();

    expect(find.text('账户控制台'), findsOneWidget);
    expect(find.text('alice@example.com'), findsOneWidget);
    expect(find.text('邮箱已验证'), findsAtLeastNWidgets(1));
    expect(find.text('Token 总量'), findsOneWidget);
    expect(find.text('当前费率预估扣点'), findsOneWidget);
    expect(find.text('模型目录价预估'), findsOneWidget);
    expect(find.text('费率设置'), findsOneWidget);
    expect(find.text('模型切换'), findsOneWidget);
    expect(find.text('累计充值额度'), findsOneWidget);
    expect(find.text('¥9.90'), findsAtLeastNWidgets(1));
    expect(find.text('1.5K'), findsAtLeastNWidgets(1));
    expect(tester.takeException(), isNull);

    await tester.tap(find.text('费率设置'));
    await tester.pumpAndSettle();
    expect(find.text('模型价格与点数费率'), findsOneWidget);
    expect(find.text('doubao-seed-2.0-mini'), findsAtLeastNWidgets(1));
    expect(find.text('保存费率'), findsOneWidget);
    expect(tester.takeException(), isNull);

    await tester.tap(find.text('取消'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('模型切换'));
    await tester.pumpAndSettle();
    expect(find.text('切换运行模型'), findsOneWidget);
    expect(find.text('2 个文本模型'), findsOneWidget);
    expect(find.text('doubao-seed-translation'), findsOneWidget);
    expect(find.text('官方目录价'), findsOneWidget);
    expect(find.text('确认切换'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
