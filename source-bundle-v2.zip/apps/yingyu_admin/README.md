# 影语后台管理端

独立的 Windows 原生 Flutter 管理应用。它与影语播放器分开构建、分开发行，且不提供用户注册入口。

控制台可查看全局和逐账户的输入/输出 Token、Token 总量、模型官方目录价预估、历史扣点折算金额、按当前费率预估的扣点与金额、扣点价差、充值额度、充值次数和实收金额，并支持检索、额度调整、停用及角色管理。顶部“模型切换”会从当前服务凭据实时读取兼容的文本生成模型并持久化选择；有内置官方价格的模型可直接切换，其他模型需先填写目录价。顶部“费率设置”可调整点数换算、成本倍率、最低扣点、最低请求余额和新账户赠送点数。

## 登录

管理员账户仅由服务端环境变量创建：

```env
LOCAL_ADMIN_USERNAME=admin
LOCAL_ADMIN_PASSWORD=请替换为高强度密码
```

启动 `services/media_pipeline` 后，在管理端使用 `/api/admin/auth/login` 登录。普通用户凭据不能登录管理端。

## 本地运行

```powershell
flutter run -d windows
```

默认服务地址为 `http://127.0.0.1:8787`。管理端仅在内存中保留登录令牌，退出应用后需要重新登录。

发布构建：

```powershell
flutter build windows --release
```

可执行文件位于 `build/windows/x64/runner/Release/yingyu_admin.exe`，发布时需要连同同目录 DLL 与 `data` 文件夹一起分发。
