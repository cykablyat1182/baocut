package com.yingyu.yingyu_player

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.Settings
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.android.FlutterActivity
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.nio.ByteBuffer
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class MainActivity : FlutterActivity() {
    companion object {
        private const val SECURE_CHANNEL = "yingyu/secure_credentials"
        private const val STORAGE_CHANNEL = "yingyu/storage_access"
        private const val QUARK_LOGIN_CHANNEL = "yingyu/quark_official_login"
        private const val KEY_ALIAS = "yingyu_secure_credentials_key"
        private const val PREFERENCES = "yingyu_secure_credentials"
        private const val IV_LENGTH = 12
        private const val STORAGE_SETTINGS_REQUEST = 9321
        private const val LEGACY_STORAGE_REQUEST = 9322
        private const val MEDIA_FILE_REQUEST = 9323
    }

    private var pendingStorageResult: MethodChannel.Result? = null
    private var pendingMediaResult: MethodChannel.Result? = null
    private var pendingQuarkLoginResult: MethodChannel.Result? = null
    private var quarkLoginDialog: Dialog? = null
    private var quarkLoginWebView: WebView? = null
    private val quarkLoginHandler = Handler(Looper.getMainLooper())
    private val quarkLoginCookiePoll = object : Runnable {
        override fun run() {
            checkQuarkLoginCookie()
            if (pendingQuarkLoginResult != null) {
                quarkLoginHandler.postDelayed(this, 1200L)
            }
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            SECURE_CHANNEL,
        ).setMethodCallHandler { call, result ->
            val key = call.argument<String>("key")
            if (key.isNullOrBlank()) {
                result.error("invalid_argument", "A credential key is required.", null)
                return@setMethodCallHandler
            }
            try {
                when (call.method) {
                    "read" -> result.success(readCredential(key))
                    "write" -> {
                        val value = call.argument<String>("value")
                            ?: throw IllegalArgumentException("A credential value is required.")
                        writeCredential(key, value)
                        result.success(null)
                    }
                    "delete" -> {
                        preferences().edit().remove(key).apply()
                        result.success(null)
                    }
                    else -> result.notImplemented()
                }
            } catch (_: Exception) {
                result.error(
                    "secure_storage_error",
                    "Android secure credential operation failed.",
                    null,
                )
            }
        }

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            STORAGE_CHANNEL,
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "hasAccess" -> result.success(hasStorageAccess())
                "requestAccess" -> requestStorageAccess(result)
                "pickMediaFile" -> pickMediaFile(result)
                else -> result.notImplemented()
            }
        }

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            QUARK_LOGIN_CHANNEL,
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "openOfficialLogin" -> openQuarkOfficialLogin(result)
                else -> result.notImplemented()
            }
        }
    }

    /**
     * Opens the real pan.quark.cn page inside Android's WebView.  The QR API
     * used by older builds expires easily on mobile networks; the official
     * page owns the QR session and Android's CookieManager gives us the same
     * authenticated cookies that the page uses for playback.
     */
    private fun openQuarkOfficialLogin(result: MethodChannel.Result) {
        if (pendingQuarkLoginResult != null) {
            result.error("already_active", "A Quark login window is already open.", null)
            return
        }
        pendingQuarkLoginResult = result

        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)

        val dialog = Dialog(this).apply {
            window?.setBackgroundDrawable(ColorDrawable(Color.WHITE))
            setOnCancelListener { finishQuarkOfficialLogin(null) }
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(24, 24, 24, 18)
        }
        val title = TextView(this).apply {
            text = "夸克官方扫码登录"
            textSize = 20f
            setTextColor(Color.rgb(26, 26, 26))
            gravity = Gravity.CENTER_VERTICAL
        }
        val hint = TextView(this).apply {
            text = "请在下方官网页面扫码并确认，登录成功后会自动返回影语。"
            textSize = 13f
            setTextColor(Color.rgb(95, 95, 95))
            setPadding(0, 8, 0, 14)
        }
        val webView = WebView(this).apply {
            @Suppress("DEPRECATION")
            cookieManager.setAcceptThirdPartyCookies(this, true)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            // Keep the desktop layout so pan.quark.cn shows the same QR
            // scanner that is visible in the Windows client, rather than
            // redirecting the phone to the app-only mobile login flow.
            settings.userAgentString =
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
                    "AppleWebKit/537.36 (KHTML, like Gecko) " +
                    "Chrome/128.0.0.0 Safari/537.36"
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    checkQuarkLoginCookie()
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?,
                ) {
                    super.onReceivedError(view, request, error)
                    // Keep the official page visible.  Quark often retries a
                    // QR image or a telemetry request after a transient error.
                }
            }
        }
        val cancel = Button(this).apply {
            text = "取消"
            setOnClickListener { finishQuarkOfficialLogin(null) }
        }
        content.addView(title, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
        ))
        content.addView(hint, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
        ))
        content.addView(webView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            0,
            1f,
        ))
        content.addView(cancel, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
        ))
        dialog.setContentView(content)
        dialog.setOnShowListener {
            dialog.window?.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            )
        }
        quarkLoginDialog = dialog
        quarkLoginWebView = webView
        dialog.show()
        // Start a fresh official QR session instead of reusing a stale WebView
        // cookie that could immediately report the old "request expired" state.
        cookieManager.removeAllCookies {
            cookieManager.flush()
            if (pendingQuarkLoginResult != null) {
                webView.loadUrl("https://pan.quark.cn/")
                quarkLoginHandler.removeCallbacks(quarkLoginCookiePoll)
                quarkLoginHandler.postDelayed(quarkLoginCookiePoll, 1200L)
            }
        }
    }

    private fun checkQuarkLoginCookie() {
        if (pendingQuarkLoginResult == null) return
        val cookieManager = CookieManager.getInstance()
        val cookieUrls = arrayOf(
            "https://pan.quark.cn/",
            "https://drive-pc.quark.cn/",
            "https://drive.quark.cn/",
            "https://su.quark.cn/",
            "https://uop.quark.cn/",
        )
        val cookie = cookieUrls
            .mapNotNull { cookieManager.getCookie(it) }
            .flatMap { it.split(';') }
            .map { it.trim() }
            .filter { it.contains('=') }
            .distinctBy { it.substringBefore('=').trim() }
            .joinToString("; ")
        val hasAuthCookie = Regex("(^|;)\\s*(__kps|__pus|__uid)=[^;]+", RegexOption.IGNORE_CASE)
            .containsMatchIn(cookie)
        if (hasAuthCookie) finishQuarkOfficialLogin(cookie)
    }

    override fun onDestroy() {
        if (pendingQuarkLoginResult != null) {
            finishQuarkOfficialLogin(null)
        }
        super.onDestroy()
    }

    private fun finishQuarkOfficialLogin(cookie: String?) {
        quarkLoginHandler.removeCallbacks(quarkLoginCookiePoll)
        val result = pendingQuarkLoginResult ?: return
        pendingQuarkLoginResult = null
        quarkLoginWebView?.apply {
            stopLoading()
            destroy()
        }
        quarkLoginWebView = null
        quarkLoginDialog?.let { dialog ->
            quarkLoginDialog = null
            if (dialog.isShowing) dialog.dismiss()
        }
        result.success(cookie)
    }

    private fun hasStorageAccess(): Boolean {
        return when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R ->
                Environment.isExternalStorageManager()
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ->
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                ) == PackageManager.PERMISSION_GRANTED
            else -> true
        }
    }

    private fun requestStorageAccess(result: MethodChannel.Result) {
        if (hasStorageAccess()) {
            result.success(true)
            return
        }
        if (pendingStorageResult != null) {
            result.error("already_active", "A storage permission request is already active.", null)
            return
        }
        pendingStorageResult = result
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val packageUri = Uri.parse("package:$packageName")
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                data = packageUri
            }
            try {
                startActivityForResult(intent, STORAGE_SETTINGS_REQUEST)
            } catch (_: Exception) {
                startActivityForResult(
                    Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),
                    STORAGE_SETTINGS_REQUEST,
                )
            }
            return
        }
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
            LEGACY_STORAGE_REQUEST,
        )
    }

    private fun pickMediaFile(result: MethodChannel.Result) {
        if (!hasStorageAccess()) {
            result.error("permission_required", "Storage access is required.", null)
            return
        }
        if (pendingMediaResult != null) {
            result.error("already_active", "A media picker is already active.", null)
            return
        }
        pendingMediaResult = result
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf("video/*", "audio/*", "application/octet-stream"),
            )
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION,
            )
        }
        startActivityForResult(intent, MEDIA_FILE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            STORAGE_SETTINGS_REQUEST -> {
                pendingStorageResult?.success(hasStorageAccess())
                pendingStorageResult = null
            }
            MEDIA_FILE_REQUEST -> finishMediaSelection(resultCode, data)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LEGACY_STORAGE_REQUEST) {
            pendingStorageResult?.success(hasStorageAccess())
            pendingStorageResult = null
        }
    }

    private fun finishMediaSelection(resultCode: Int, data: Intent?) {
        val result = pendingMediaResult ?: return
        pendingMediaResult = null
        if (resultCode != Activity.RESULT_OK || data?.data == null) {
            result.success(null)
            return
        }
        val uri = data.data!!
        try {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION,
            )
        } catch (_: SecurityException) {
            // Direct filesystem access is already granted; persistence is optional here.
        }
        val path = resolveDocumentPath(uri)
        if (path == null || !File(path).exists()) {
            result.error(
                "unresolved_path",
                "The selected file has no accessible filesystem path. Select its folder instead.",
                null,
            )
            return
        }
        result.success(path)
    }

    @Suppress("DEPRECATION")
    private fun resolveDocumentPath(uri: Uri): String? {
        if (uri.scheme == "file") return uri.path
        if (DocumentsContract.isDocumentUri(this, uri)) {
            val documentId = DocumentsContract.getDocumentId(uri)
            if (uri.authority == "com.android.externalstorage.documents") {
                val parts = documentId.split(":", limit = 2)
                if (parts.size == 2) {
                    val root = if (parts[0].equals("primary", ignoreCase = true)) {
                        Environment.getExternalStorageDirectory().absolutePath
                    } else {
                        "/storage/${parts[0]}"
                    }
                    return if (parts[1].isEmpty()) root else "$root/${parts[1]}"
                }
            }
            if (uri.authority == "com.android.providers.downloads.documents") {
                if (documentId.startsWith("raw:")) return documentId.removePrefix("raw:")
                documentId.toLongOrNull()?.let { id ->
                    return queryDataColumn(
                        ContentUris.withAppendedId(
                            Uri.parse("content://downloads/public_downloads"),
                            id,
                        ),
                    )
                }
            }
            if (uri.authority == "com.android.providers.media.documents") {
                val parts = documentId.split(":", limit = 2)
                if (parts.size == 2) {
                    val contentUri = when (parts[0]) {
                        "video" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        "audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                        else -> MediaStore.Files.getContentUri("external")
                    }
                    return queryDataColumn(contentUri, "_id=?", arrayOf(parts[1]))
                }
            }
        }
        return queryDataColumn(uri)
    }

    @Suppress("DEPRECATION")
    private fun queryDataColumn(
        uri: Uri,
        selection: String? = null,
        selectionArgs: Array<String>? = null,
    ): String? {
        return try {
            contentResolver.query(
                uri,
                arrayOf(MediaStore.MediaColumns.DATA),
                selection,
                selectionArgs,
                null,
            )?.use { cursor ->
                if (!cursor.moveToFirst()) return@use null
                val index = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)
                if (index < 0) null else cursor.getString(index)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun preferences() =
        getSharedPreferences(PREFERENCES, MODE_PRIVATE)

    private fun secretKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null)
        if (existing is SecretKey) return existing

        return KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            "AndroidKeyStore",
        ).apply {
            init(
                KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build(),
            )
        }.generateKey()
    }

    private fun writeCredential(key: String, value: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val payload = ByteBuffer.allocate(cipher.iv.size + encrypted.size)
            .put(cipher.iv)
            .put(encrypted)
            .array()
        preferences().edit()
            .putString(key, Base64.encodeToString(payload, Base64.NO_WRAP))
            .apply()
    }

    private fun readCredential(key: String): String? {
        val encoded = preferences().getString(key, null) ?: return null
        return try {
            val payload = Base64.decode(encoded, Base64.NO_WRAP)
            if (payload.size <= IV_LENGTH) return null
            val iv = payload.copyOfRange(0, IV_LENGTH)
            val encrypted = payload.copyOfRange(IV_LENGTH, payload.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(encrypted), Charsets.UTF_8)
        } catch (_: Exception) {
            preferences().edit().remove(key).apply()
            null
        }
    }
}
