import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:yingyu_player/data/subtitle_parser.dart';
import 'package:yingyu_player/domain/models/subtitle_cue.dart';

void main() {
  const parser = SubtitleParser();

  test('parses bilingual SRT and keeps millisecond timing', () {
    const source = '''
1
00:00:01,250 --> 00:00:03,800
The weather changes quickly.
天气变化得很快。

2
00:00:04,000 --> 00:00:05,500
I suppose so.
我想是的。
''';

    final cues = parser.parseBytes(utf8.encode(source), fileName: 'sample.srt');

    expect(cues, hasLength(2));
    expect(cues.first.start, const Duration(milliseconds: 1250));
    expect(cues.first.end, const Duration(milliseconds: 3800));
    expect(cues.first.original, 'The weather changes quickly.');
    expect(cues.first.translation, '天气变化得很快。');
    expect(cues.first.isBilingual, isTrue);
  });

  test('parses monolingual WebVTT', () {
    const source = '''WEBVTT

00:00:01.000 --> 00:00:03.000
London is quieter after the rain.
''';

    final cues = parser.parseBytes(utf8.encode(source), fileName: 'sample.vtt');

    expect(cues, hasLength(1));
    expect(cues.single.original, 'London is quieter after the rain.');
    expect(cues.single.translation, isEmpty);
  });

  test('parses ASS dialogue fields and removes style tags', () {
    const source = '''[Script Info]
Title: Sample

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:02.10,0:00:04.30,Default,,0,0,0,,{\\i1}It depends.{\\i0}\\N这取决于情况。
''';

    final cues = parser.parseBytes(utf8.encode(source), fileName: 'sample.ass');

    expect(cues, hasLength(1));
    expect(cues.single.start, const Duration(milliseconds: 2100));
    expect(cues.single.original, 'It depends.');
    expect(cues.single.translation, '这取决于情况。');
  });

  test('keeps a cue crossing a window boundary when ASS time is negative', () {
    const source = '''[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:-00.50,0:00:01.50,Default,,0,0,0,,active at seek point
''';

    final cues = parser.parseBytes(utf8.encode(source), fileName: 'window.ass');

    expect(cues, hasLength(1));
    expect(cues.single.start, const Duration(milliseconds: -500));
    expect(cues.single.end, const Duration(milliseconds: 1500));
  });

  test('merges same-time Japanese and Chinese ASS events as bilingual', () {
    const source = '''[Script Info]
Title: Embedded bilingual track

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:02.52,0:00:03.91,Default - jp,,0,0,0,,クリスマスパーティー？
Dialogue: 0,0:00:02.52,0:00:03.91,Default,,0,0,0,,圣诞派对？
Dialogue: 0,0:00:04.42,0:00:07.55,Default - jp,,0,0,0,,うん　ラボで皆で集まってやろうって
Dialogue: 0,0:00:04.42,0:00:07.55,Default,,0,0,0,,嗯 我想着把大家都叫到研究所来
''';

    final cues = parser.parseBytes(
      utf8.encode(source),
      fileName: 'embedded.ass',
    );

    expect(cues, hasLength(2));
    expect(cues.first.original, 'クリスマスパーティー？');
    expect(cues.first.translation, '圣诞派对？');
    expect(cues.first.isBilingual, isTrue);
  });

  test('filters SDH sound descriptions but keeps spoken dialogue', () {
    const source = '''
1
00:00:01,000 --> 00:00:03,000
(indistinct chatter over TV)

2
00:00:04,000 --> 00:00:06,000
I hear music outside.

3
00:00:07,000 --> 00:00:09,000
Hello.
(door creaks)
你好。

4
00:00:10,000 --> 00:00:12,000
（背景音乐）
（脚步声）

5
00:00:13,000 --> 00:00:15,000
(siren wailing)

6
00:00:16,000 --> 00:00:18,000
-(grunts)
-Benjy!

7
00:00:19,000 --> 00:00:20,000
Come on, Benjy.
Come on, come on.
起来，本吉。

8
00:00:20,500 --> 00:00:21,500
Come on, Benjy.
''';

    final cues = parser.parseBytes(utf8.encode(source), fileName: 'sample.srt');
    final filtered = SubtitleCueFilter.withoutHearingImpaired(cues);

    expect(filtered, hasLength(4));
    expect(filtered.first.original, 'I hear music outside.');
    expect(filtered[1].original, 'Hello.');
    expect(filtered[1].translation, '你好。');
    expect(filtered[2].original, '-Benjy!');
    expect(filtered.last.original, 'Come on, Benjy. Come on, come on.');
    expect(filtered.last.translation, '起来，本吉。');
    expect(filtered.last.end, const Duration(seconds: 21, milliseconds: 500));
  });

  test(
    'hides every standalone parenthesized subtitle when SDH filtering is on',
    () {
      const source = '''
1
00:00:01,000 --> 00:00:02,000
(a soft sound from the hallway)

2
00:00:03,000 --> 00:00:04,000
（unfamiliar accessibility annotation）

3
00:00:05,000 --> 00:00:06,000
I think (maybe) we should go.

4
00:00:07,000 --> 00:00:08,000
The music is getting louder.
''';

      final parsed = parser.parseBytes(
        utf8.encode(source),
        fileName: 'sample.srt',
      );
      final filtered = SubtitleCueFilter.withoutHearingImpaired(parsed);

      expect(filtered, hasLength(2));
      expect(filtered.first.original, 'I think (maybe) we should go.');
      expect(filtered.last.original, 'The music is getting louder.');

      const bilingualSdh = SubtitleCue(
        id: 'bilingual-sdh',
        start: Duration(seconds: 9),
        end: Duration(seconds: 10),
        original: '(an unfamiliar sound in the hallway)',
        translation: '走廊里传来一种声音',
      );
      const mixedDialogue = SubtitleCue(
        id: 'mixed-dialogue',
        start: Duration(seconds: 11),
        end: Duration(seconds: 12),
        original: 'Hello.\n(an unfamiliar sound)',
        translation: '你好。\n（一种声音）',
      );
      final pairedFiltered = SubtitleCueFilter.withoutHearingImpaired([
        bilingualSdh,
        mixedDialogue,
      ]);
      expect(pairedFiltered, hasLength(1));
      expect(pairedFiltered.single.original, 'Hello.');
      expect(pairedFiltered.single.translation, '你好。');
    },
  );
}
