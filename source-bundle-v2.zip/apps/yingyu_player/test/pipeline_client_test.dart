import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:yingyu_player/data/device_auth_store.dart';
import 'package:yingyu_player/data/pipeline_client.dart';
import 'package:yingyu_player/domain/models/subtitle_cue.dart';

class _MemoryAuthStore extends DeviceAuthStore {
  String? token;
  bool userSession = false;

  @override
  Future<DeviceCredentials> credentials() async => const DeviceCredentials(
    installationId: 'test-installation-0001',
    installationSecret: 'test-secret-0000000000000000000001',
  );

  @override
  Future<String?> accessToken(Uri baseUri) async => token;

  @override
  Future<void> saveAccessToken(Uri baseUri, String token) async {
    this.token = token;
  }

  @override
  Future<void> clearAccessToken(Uri baseUri) async {
    token = null;
    userSession = false;
  }

  @override
  Future<bool> isUserSession(Uri baseUri) async => userSession;

  @override
  Future<void> setUserSession(Uri baseUri, bool value) async {
    userSession = value;
  }
}

void main() {
  test('streams dictionary fields and captures the final usage charge', () async {
    final authStore = _MemoryAuthStore()..token = 'a' * 43;
    final partialFields = <Map<String, String>>[];
    final statuses = <String>[];
    final client = PipelineClient(
      baseUrl: 'https://service.example.test',
      authStore: authStore,
      client: MockClient((request) async {
        expect(request.url.path, '/api/dictionary/stream');
        expect(request.headers['accept'], 'text/event-stream');
        return http.Response(
          [
            'event: status\ndata: {"message":"正在生成"}\n\n',
            'event: partial\ndata: {"definition":"穿过门"}\n\n',
            'event: complete\ndata: {"entry":{"word":"through","phonetic":"/θruː/","partOfSpeech":"介词","definition":"穿过门","example":"Go through the door.","exampleTranslation":"穿过这扇门。"},"billing":{"chargedCredits":2,"balanceCredits":98,"inputTokens":10,"outputTokens":4}}\n\n',
          ].join(),
          200,
          headers: {'content-type': 'text/event-stream; charset=utf-8'},
        );
      }),
    );

    final entry = await client.lookupStream(
      word: 'through',
      sentence: 'Go through the door.',
      onPartial: partialFields.add,
      onStatus: statuses.add,
    );

    expect(entry?.definition, '穿过门');
    expect(partialFields, [
      {'definition': '穿过门'},
    ]);
    expect(statuses, ['正在生成']);
    expect(client.lastUsageCharge?.chargedCredits, 2);
    client.close();
  });

  test('streams subtitle translation batches and captures billing', () async {
    final authStore = _MemoryAuthStore()..token = 'a' * 43;
    final partial = <List<SubtitleCue>>[];
    final statuses = <String>[];
    final client = PipelineClient(
      baseUrl: 'https://service.example.test',
      authStore: authStore,
      client: MockClient((request) async {
        expect(request.url.path, '/api/translate/stream');
        expect(request.headers['accept'], 'text/event-stream');
        return http.Response(
          [
            'event: status\ndata: {"message":"正在翻译"}\n\n',
            'event: partial\ndata: {"completed":1,"total":2,"cues":[{"id":"1","startMs":0,"endMs":1000,"original":"Hello","translation":"你好"}]}\n\n',
            'event: complete\ndata: {"cues":[{"id":"1","startMs":0,"endMs":1000,"original":"Hello","translation":"你好"},{"id":"2","startMs":1000,"endMs":2000,"original":"world","translation":"世界"}],"billing":{"chargedCredits":3,"balanceCredits":97,"inputTokens":12,"outputTokens":6}}\n\n',
          ].join(),
          200,
          headers: {'content-type': 'text/event-stream; charset=utf-8'},
        );
      }),
    );

    final translated = await client.translateStream(
      cues: const [
        SubtitleCue(
          id: '1',
          start: Duration.zero,
          end: Duration(seconds: 1),
          original: 'Hello',
        ),
        SubtitleCue(
          id: '2',
          start: Duration(seconds: 1),
          end: Duration(seconds: 2),
          original: 'world',
        ),
      ],
      sourceLanguage: 'en-US',
      targetLanguage: 'zh-CN',
      onPartial: (cues, _, _) => partial.add(cues),
      onStatus: statuses.add,
    );

    expect(statuses, ['正在翻译']);
    expect(partial.single.single.translation, '你好');
    expect(translated.map((cue) => cue.translation), ['你好', '世界']);
    expect(client.lastUsageCharge?.chargedCredits, 3);
    client.close();
  });

  test(
    'dictionary service errors are surfaced instead of being swallowed',
    () async {
      final authStore = _MemoryAuthStore()..token = 'a' * 43;
      final client = PipelineClient(
        baseUrl: 'https://service.example.test',
        authStore: authStore,
        client: MockClient(
          (request) async => http.Response(
            jsonEncode({'error': '本机词典服务暂时不可用'}),
            503,
            headers: {'content-type': 'application/json; charset=utf-8'},
          ),
        ),
      );

      await expectLater(
        client.lookup(word: 'test', sentence: 'This is a test.'),
        throwsA(
          isA<PipelineException>().having(
            (error) => error.message,
            'message',
            '本机词典服务暂时不可用',
          ),
        ),
      );
      client.close();
    },
  );

  test('login stores the returned local account session', () async {
    final authStore = _MemoryAuthStore();
    final client = PipelineClient(
      baseUrl: 'http://127.0.0.1:8787',
      authStore: authStore,
      client: MockClient((request) async {
        expect(request.url.path, '/api/auth/login');
        return http.Response(
          jsonEncode({
            'accessToken': 'b' * 43,
            'account': {
              'accountId': 'account-user-1',
              'profile': {
                'username': 'alice',
                'displayName': 'Alice',
                'role': 'user',
                'isGuest': false,
                'disabled': false,
              },
              'balanceCredits': 25,
              'pricing': {},
              'transactions': [],
            },
          }),
          200,
          headers: {'content-type': 'application/json; charset=utf-8'},
        );
      }),
    );

    final account = await client.loginAccount(
      username: 'alice',
      password: 'password-123',
    );
    expect(account.profile.displayName, 'Alice');
    expect(account.profile.isGuest, isFalse);
    expect(account.balanceCredits, 25);
    expect(authStore.token, 'b' * 43);
    client.close();
  });

  test(
    'registration requests a code and sends verified email fields',
    () async {
      final authStore = _MemoryAuthStore();
      var requestCount = 0;
      final client = PipelineClient(
        baseUrl: 'http://127.0.0.1:8787',
        authStore: authStore,
        client: MockClient((request) async {
          requestCount += 1;
          final body = jsonDecode(request.body) as Map<String, dynamic>;
          if (request.url.path == '/api/auth/email/request-code') {
            expect(body, {'email': 'alice@example.com'});
            return http.Response(
              jsonEncode({'sent': true, 'expiresInSeconds': 600}),
              202,
              headers: {'content-type': 'application/json; charset=utf-8'},
            );
          }
          expect(request.url.path, '/api/auth/register');
          expect(body['email'], 'alice@example.com');
          expect(body['verificationCode'], '123456');
          expect(body.containsKey('role'), isFalse);
          return http.Response(
            jsonEncode({
              'accessToken': 'c' * 43,
              'account': {
                'accountId': 'account-user-2',
                'profile': {
                  'username': 'alice',
                  'email': 'alice@example.com',
                  'emailVerified': true,
                  'displayName': 'Alice',
                  'role': 'user',
                  'isGuest': false,
                  'disabled': false,
                },
                'balanceCredits': 0,
                'pricing': {},
                'transactions': [],
              },
            }),
            201,
            headers: {'content-type': 'application/json; charset=utf-8'},
          );
        }),
      );

      expect(await client.requestEmailVerification('alice@example.com'), 600);
      final account = await client.registerAccount(
        username: 'alice',
        email: 'alice@example.com',
        verificationCode: '123456',
        password: 'password-123',
        displayName: 'Alice',
      );

      expect(requestCount, 2);
      expect(account.profile.role, 'user');
      expect(account.profile.emailVerified, isTrue);
      expect(authStore.token, 'c' * 43);
      client.close();
    },
  );

  test(
    'translation authenticates the device and captures transparent billing',
    () async {
      final authStore = _MemoryAuthStore();
      final client = PipelineClient(
        baseUrl: 'https://service.example.test',
        authStore: authStore,
        client: MockClient((request) async {
          if (request.url.path == '/api/auth/device') {
            return http.Response(
              jsonEncode({
                'accessToken': 'a' * 43,
                'accountId': 'account-1',
                'balanceCredits': 100,
              }),
              201,
              headers: {'content-type': 'application/json; charset=utf-8'},
            );
          }
          expect(request.headers['authorization'], 'Bearer ${'a' * 43}');
          expect(request.url.path, '/api/translate');
          return http.Response(
            jsonEncode({
              'cues': [
                {
                  'id': 'cue-1',
                  'startMs': 0,
                  'endMs': 1000,
                  'original': 'Hello.',
                  'translation': '你好。',
                },
              ],
              'billing': {
                'chargedCredits': 1,
                'balanceCredits': 99,
                'inputTokens': 12,
                'outputTokens': 8,
              },
            }),
            200,
            headers: {'content-type': 'application/json; charset=utf-8'},
          );
        }),
      );

      final translated = await client.translate(
        cues: const [
          SubtitleCue(
            id: 'cue-1',
            start: Duration.zero,
            end: Duration(seconds: 1),
            original: 'Hello.',
          ),
        ],
        sourceLanguage: 'en-US',
        targetLanguage: 'zh-CN',
      );

      expect(translated.single.translation, '你好。');
      expect(client.lastUsageCharge?.chargedCredits, 1);
      expect(client.lastUsageCharge?.balanceCredits, 99);
      client.close();
    },
  );
}
