import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:yingyu_player/data/authenticated_media_proxy.dart';

void main() {
  test('forwards Quark authentication and byte ranges over loopback', () async {
    final upstream = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
    final proxy = AuthenticatedMediaProxy(
      remoteValidator: (uri) =>
          uri.scheme == 'http' &&
          uri.host == InternetAddress.loopbackIPv4.address &&
          uri.port == upstream.port,
    );
    final requests = <HttpRequest>[];
    final subscription = upstream.listen((request) async {
      requests.add(request);
      expect(request.headers.value(HttpHeaders.cookieHeader), '__kps=secret');
      expect(
        request.headers.value(HttpHeaders.refererHeader),
        'https://pan.quark.cn/',
      );
      final range = request.headers.value(HttpHeaders.rangeHeader);
      expect(range, anyOf('bytes=0-1', 'bytes=2-5'));
      final probe = range == 'bytes=0-1';
      request.response
        ..statusCode = HttpStatus.partialContent
        ..headers.set(HttpHeaders.acceptRangesHeader, 'bytes')
        ..headers.set(
          HttpHeaders.contentRangeHeader,
          probe ? 'bytes 0-1/10' : 'bytes 2-5/10',
        )
        ..headers.contentType = ContentType.binary
        ..contentLength = probe ? 2 : 4
        ..add(utf8.encode(probe ? '01' : '2345'));
      await request.response.close();
    });

    try {
      final localUrl = await proxy.register(
        remoteUrl: Uri.parse(
          'http://${InternetAddress.loopbackIPv4.address}:${upstream.port}/movie.mkv',
        ),
        headers: const {
          'Cookie': '__kps=secret',
          'Referer': 'https://pan.quark.cn/',
        },
        fileName: 'movie.mkv',
      );

      final client = http.Client();
      try {
        final request = http.Request('GET', localUrl)
          ..headers[HttpHeaders.rangeHeader] = 'bytes=2-5';
        final response = await client.send(request);
        expect(response.statusCode, HttpStatus.partialContent);
        expect(
          response.headers[HttpHeaders.contentRangeHeader],
          'bytes 2-5/10',
        );
        expect(await response.stream.bytesToString(), '2345');
      } finally {
        client.close();
      }
      expect(requests, hasLength(2));
    } finally {
      await proxy.close();
      await subscription.cancel();
      await upstream.close(force: true);
    }
  });
}
