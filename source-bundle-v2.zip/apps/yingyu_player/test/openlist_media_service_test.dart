import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:yingyu_player/data/openlist_media_service.dart';
import 'package:yingyu_player/domain/models/cloud_media_source.dart';

void main() {
  const source = CloudMediaSource(
    id: 'quark-home',
    name: '我的夸克影视',
    baseUrl: 'https://openlist.example',
    apiToken: 'token-value',
    provider: 'quark',
  );

  test('scans OpenList movies and pairs subtitle sidecars', () async {
    final service = OpenListMediaService(
      MockClient((request) async {
        expect(request.headers['authorization'], 'token-value');
        final body = jsonDecode(request.body) as Map<String, dynamic>;
        final path = body['path'];
        if (request.url.path == '/api/fs/list' && path == '/') {
          return http.Response(
            jsonEncode({
              'code': 200,
              'data': {
                'content': [
                  {'name': 'Movies', 'is_dir': true},
                ],
              },
            }),
            200,
          );
        }
        if (request.url.path == '/api/fs/list' && path == '/Movies') {
          return http.Response(
            jsonEncode({
              'code': 200,
              'data': {
                'content': [
                  {'name': 'Arrival.mkv', 'is_dir': false},
                  {'name': 'Arrival.srt', 'is_dir': false},
                  {'name': 'poster.jpg', 'is_dir': false},
                ],
              },
            }),
            200,
          );
        }
        return http.Response('{}', 404);
      }),
    );

    final items = await service.load(source);

    expect(items, hasLength(1));
    expect(items.single.title, 'Arrival.mkv');
    expect(items.single.isOnline, isTrue);
    expect(items.single.isLive, isFalse);
    expect(items.single.cloudSourceId, 'quark-home');
    expect(items.single.remotePath, '/Movies/Arrival.mkv');
    expect(items.single.remoteSubtitlePaths, ['/Movies/Arrival.srt']);
  });

  test('resolves OpenList playback and download headers', () async {
    final service = OpenListMediaService(
      MockClient((request) async {
        expect(request.url.path, '/api/fs/link');
        final body = jsonDecode(request.body) as Map<String, dynamic>;
        expect(body['type'], 'streaming');
        return http.Response(
          jsonEncode({
            'code': 200,
            'data': {
              'url': 'https://download.example/movie.mkv',
              'header': {'Referer': 'https://openlist.example/'},
            },
          }),
          200,
        );
      }),
    );

    final resolved = await service.resolve(source, '/Movies/Arrival.mkv');

    expect(resolved.url, 'https://download.example/movie.mkv');
    expect(resolved.headers['Referer'], 'https://openlist.example/');
  });
}
