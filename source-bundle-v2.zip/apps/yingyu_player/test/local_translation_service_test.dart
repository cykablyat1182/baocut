import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:flutter_test/flutter_test.dart';
import 'package:yingyu_player/data/local_translation_service.dart';
import 'package:yingyu_player/domain/models/subtitle_cue.dart';

void main() {
  test(
    'loads, translates with nearby context, and unloads the local model',
    () async {
      final client = _FakeOllamaClient();
      final service = LocalTranslationService(client: client);
      final cues = [
        const SubtitleCue(
          id: 'before',
          start: Duration(seconds: 1),
          end: Duration(seconds: 2),
          original: 'The door is open.',
        ),
        const SubtitleCue(
          id: 'target',
          start: Duration(seconds: 2),
          end: Duration(seconds: 3),
          original: 'Go through.',
        ),
        const SubtitleCue(
          id: 'after',
          start: Duration(seconds: 3),
          end: Duration(seconds: 4),
          original: 'Then turn left.',
        ),
      ];

      final translated = await service.translateCues(
        cues: cues,
        sourceLanguage: 'en-US',
        targetLanguage: 'zh-CN',
        modelsDirectory: r'D:\AI\Ollama\models',
        modelName: 'gemma4:e2b-it-qat',
      );

      expect(translated[0].translation, '门是开着的。');
      expect(translated[1].translation, '穿过。');
      expect(translated[2].translation, '然后向左转。');
      final chatRequest = client.requests.singleWhere(
        (request) => request['path'] == '/api/chat',
      );
      expect(chatRequest['body'], contains('The door is open.'));
      expect(chatRequest['body'], contains('Then turn left.'));

      await service.close();
      expect(
        client.requests.any(
          (request) =>
              request['path'] == '/api/generate' &&
              (request['json'] as Map)['keep_alive'] == 0,
        ),
        isTrue,
      );
    },
  );

  test('streams dictionary content from the local model', () async {
    final client = _FakeOllamaClient();
    final service = LocalTranslationService(client: client);
    final partial = <Map<String, String>>[];
    final entry = await service.lookupDictionary(
      word: 'through',
      sentence: 'Go through the door.',
      targetLanguage: '简体中文',
      modelsDirectory: r'D:\AI\Ollama\models',
      modelName: 'gemma4:e2b-it-qat',
      onPartial: partial.add,
    );

    expect(entry.definition, '穿过门');
    expect(partial.last['definition'], '穿过门');
    final chatRequest = client.requests.singleWhere(
      (request) => request['path'] == '/api/chat',
    );
    expect((chatRequest['json'] as Map)['stream'], isTrue);
    await service.close();
  });
}

class _FakeOllamaClient extends http.BaseClient {
  final requests = <Map<String, Object?>>[];

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) async {
    final body = await request.finalize().bytesToString();
    final path = request.url.path;
    final json = body.trim().isEmpty ? <String, Object?>{} : jsonDecode(body);
    requests.add({'path': path, 'body': body, 'json': json});
    if (path == '/api/chat' && body.contains('解释影视字幕中的单词')) {
      final lines = [
        jsonEncode({
          'message': {'content': '{"word":"through","definition":"穿过门"'},
        }),
        jsonEncode({
          'message': {
            'content':
                ',"phonetic":"/θruː/","partOfSpeech":"介词","example":"Go through the door.","exampleTranslation":"穿过这扇门。"}',
          },
          'done': true,
        }),
      ];
      final bytes = utf8.encode('${lines.join('\n')}\n');
      return http.StreamedResponse(
        Stream<List<int>>.value(bytes),
        200,
        contentLength: bytes.length,
        headers: const {'content-type': 'application/x-ndjson'},
        request: request,
      );
    }
    final response = switch (path) {
      '/api/tags' => {
        'models': [
          {'name': 'gemma4:e2b-it-qat', 'size': 4_000_000_000},
        ],
      },
      '/api/ps' => {
        'models': [
          {
            'name': 'gemma4:e2b-it-qat',
            'size': 4_000_000_000,
            'size_vram': 3_200_000_000,
          },
        ],
      },
      '/api/generate' => {'response': '', 'done': true},
      '/api/chat' => {
        'message': {
          'role': 'assistant',
          'content':
              '{"translations":[{"id":"before","translation":"门是开着的。"},{"id":"target","translation":"穿过。"},{"id":"after","translation":"然后向左转。"}]}',
        },
        'done': true,
      },
      _ => {'error': 'unexpected path'},
    };
    final status =
        path == '/api/tags' ||
            path == '/api/ps' ||
            path == '/api/generate' ||
            path == '/api/chat'
        ? 200
        : 404;
    final bytes = utf8.encode(jsonEncode(response));
    return http.StreamedResponse(
      Stream<List<int>>.value(bytes),
      status,
      contentLength: bytes.length,
      headers: const {'content-type': 'application/json'},
      request: request,
    );
  }
}
