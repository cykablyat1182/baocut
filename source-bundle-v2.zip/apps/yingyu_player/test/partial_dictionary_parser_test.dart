import 'package:flutter_test/flutter_test.dart';
import 'package:yingyu_player/data/partial_dictionary_parser.dart';

void main() {
  test('exposes fields as their streamed JSON values are being generated', () {
    expect(
      parsePartialDictionaryFields('{"word":"through","definition":"穿过门，然后'),
      {'word': 'through', 'definition': '穿过门，然后'},
    );
  });

  test('decodes JSON escapes without ending at an escaped quote', () {
    expect(
      parsePartialDictionaryFields(
        r'{"example":"He said \"go\" and left.","exampleTranslation":"他说“走”了。"}',
      ),
      {'example': 'He said "go" and left.', 'exampleTranslation': '他说“走”了。'},
    );
  });

  test('waits for incomplete unicode escape sequences', () {
    expect(parsePartialDictionaryFields(r'''{"definition":"\u4e2d\u658'''), {
      'definition': '中',
    });
  });
}
