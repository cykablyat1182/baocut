import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:yingyu_player/data/online_stream_service.dart';
import 'package:yingyu_player/domain/models/online_stream_source.dart';

void main() {
  test(
    'loads relative TVBox live lists with logo, EPG and user agent',
    () async {
      final client = MockClient((request) async {
        if (request.url.path.endsWith('/tvbox.json')) {
          return http.Response(
            '''
          // TVBox test config
          {
            "sites": [],
            "lives": [{
              "name": "家庭电视",
              "url": "./live.m3u",
              "ua": "YingYu-Test",
              "logo": "https://img.example/{name}.png",
              "epg": "https://epg.example/?ch={name}&date={date}"
            }]
          }
          ''',
            200,
            headers: {'content-type': 'application/json; charset=utf-8'},
          );
        }
        expect(request.url.toString(), 'https://box.example/live.m3u');
        expect(request.headers.values, contains('YingYu-Test'));
        return http.Response(
          '#EXTM3U\n#EXTINF:-1 group-title="央视",CCTV-1\n'
          'https://media.example/cctv1.m3u8',
          200,
          headers: {'content-type': 'text/plain; charset=utf-8'},
        );
      });
      final service = OnlineStreamService(client);

      final channels = await service.load(
        const OnlineStreamSource(
          name: '测试仓',
          url: 'https://box.example/tvbox.json',
        ),
      );

      expect(channels, hasLength(1));
      expect(channels.single.title, 'CCTV-1');
      expect(channels.single.group, '央视');
      expect(channels.single.sourceName, '测试仓 · 家庭电视');
      expect(channels.single.remoteLogoUrl, contains('CCTV-1.png'));
      expect(channels.single.epgUrl, contains('ch=CCTV-1'));
      expect(channels.single.httpHeaders['User-Agent'], 'YingYu-Test');
    },
  );

  test('keeps ordinary M3U and TVBox TXT channel parsing compatible', () {
    const source = OnlineStreamSource(
      name: '基础源',
      url: 'https://example.com/list.txt',
    );
    final channels = OnlineStreamService.parse(
      source,
      '新闻,#genre#\n频道一,https://example.com/one.m3u8\n'
      '#EXTINF:-1 tvg-logo="https://example.com/two.png",频道二\n'
      'https://example.com/two.m3u8',
    );

    expect(channels, hasLength(2));
    expect(channels.first.group, '新闻');
    expect(channels.last.remoteLogoUrl, 'https://example.com/two.png');
  });

  test('keeps a direct media URL declared in TVBox lives', () async {
    final service = OnlineStreamService(
      MockClient((request) async {
        return http.Response(
          '{"sites":[],"lives":[{"name":"直连频道","url":"https://media.example/live/index.m3u8","ua":"YingYu-Test"}]}',
          200,
          headers: {'content-type': 'application/json; charset=utf-8'},
        );
      }),
    );

    final channels = await service.load(
      const OnlineStreamSource(
        name: '直连仓',
        url: 'https://box.example/config.json',
      ),
    );

    expect(channels.single.path, 'https://media.example/live/index.m3u8');
    expect(channels.single.title, '直连频道');
    expect(channels.single.httpHeaders['User-Agent'], 'YingYu-Test');
  });
}
