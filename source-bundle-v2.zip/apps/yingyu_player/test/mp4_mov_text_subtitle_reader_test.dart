import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:yingyu_player/data/mp4_mov_text_subtitle_reader.dart';

void main() {
  test(
    'loads only mov_text samples overlapping the requested window',
    () async {
      final fixture = _buildMp4Fixture(['Hello', 'World', 'Again']);
      final requestedRanges = <(int, int)>[];
      final client = MockClient((request) async {
        expect(request.headers['authorization'], 'Bearer test');
        final range = request.headers['range'];
        final match = RegExp(
          r'^bytes=([0-9]+)-([0-9]+)$',
        ).firstMatch(range ?? '');
        expect(match, isNotNull);
        final start = int.parse(match!.group(1)!);
        final requestedEnd = int.parse(match.group(2)!);
        final end = math.min(requestedEnd, fixture.length - 1);
        requestedRanges.add((start, end));
        return http.Response.bytes(
          fixture.sublist(start, end + 1),
          206,
          headers: {
            'content-range': 'bytes $start-$end/${fixture.length}',
            'content-length': '${end - start + 1}',
          },
        );
      });
      final reader = Mp4MovTextSubtitleReader(client);

      final tracks = await reader.probeTracks(
        uri: Uri.parse('https://media.example.test/episode.mkv'),
        headers: const {'Authorization': 'Bearer test'},
      );
      expect(tracks, isNotNull);
      expect(tracks, hasLength(1));
      expect(tracks!.single.streamIndex, 0);
      expect(tracks.single.subtitleOrdinal, 0);
      expect(tracks.single.language, 'eng');
      expect(tracks.single.codec, 'mov_text');

      final cues = await reader.readWindow(
        uri: Uri.parse('https://media.example.test/episode.mkv'),
        streamIndex: 0,
        subtitleOrdinal: 0,
        language: 'eng',
        start: const Duration(milliseconds: 1500),
        end: const Duration(milliseconds: 3500),
        headers: const {'Authorization': 'Bearer test'},
      );

      expect(cues, isNotNull);
      expect(cues!.map((cue) => cue.original), ['Hello', 'World']);
      expect(cues.map((cue) => cue.start.inSeconds), [0, 2]);
      expect(cues.map((cue) => cue.end.inSeconds), [2, 4]);

      final adjacent = await reader.readWindow(
        uri: Uri.parse('https://media.example.test/episode.mkv'),
        streamIndex: 0,
        subtitleOrdinal: 0,
        language: 'eng',
        start: const Duration(milliseconds: 3500),
        end: const Duration(milliseconds: 5500),
        headers: const {'Authorization': 'Bearer test'},
      );
      expect(adjacent!.map((cue) => cue.original), ['World', 'Again']);
      // Probe + moov index + three tiny text samples across both windows. The
      // overlapping sample and the index are served from memory on expansion.
      expect(requestedRanges.length, 5);
      expect(
        requestedRanges.skip(2).every((range) => range.$2 - range.$1 < 32),
        isTrue,
      );
      client.close();
    },
  );

  test('decodes UTF-16 mov_text payloads and normalizes line endings', () {
    final encoded = BytesBuilder()
      ..add([0xfe, 0xff])
      ..add(_u16('你'.codeUnitAt(0)))
      ..add(_u16('好'.codeUnitAt(0)))
      ..add(_u16(13))
      ..add(_u16('A'.codeUnitAt(0)));
    final text = encoded.takeBytes();
    final packet = Uint8List.fromList([..._u16(text.length), ...text]);

    expect(Mp4MovTextSubtitleReader.decodeMovTextSample(packet), '你好\nA');
  });
}

Uint8List _buildMp4Fixture(List<String> lines) {
  final samples = [
    for (final line in lines)
      Uint8List.fromList([
        ..._u16(utf8.encode(line).length),
        ...utf8.encode(line),
      ]),
  ];
  final ftyp = _box('ftyp', ascii.encode('isom\x00\x00\x02\x00isom'));
  var moov = _buildMoov(List<int>.filled(samples.length, 0), samples);
  final mdatPayloadStart = ftyp.length + moov.length + 8;
  var offset = mdatPayloadStart;
  final offsets = <int>[];
  for (final sample in samples) {
    offsets.add(offset);
    offset += sample.length;
  }
  moov = _buildMoov(offsets, samples);
  final mdat = _box('mdat', [for (final sample in samples) ...sample]);
  return Uint8List.fromList([...ftyp, ...moov, ...mdat]);
}

Uint8List _buildMoov(List<int> offsets, List<Uint8List> samples) {
  final mvhd = _box('mvhd', [
    0,
    0,
    0,
    0,
    ..._u32(0),
    ..._u32(0),
    ..._u32(1000),
    ..._u32(samples.length * 2000),
  ]);
  final tkhd = _box('tkhd', [0, 0, 0, 0, ..._u32(0), ..._u32(0), ..._u32(1)]);
  final mdhd = _box('mdhd', [
    0,
    0,
    0,
    0,
    ..._u32(0),
    ..._u32(0),
    ..._u32(1000),
    ..._u32(samples.length * 2000),
    ..._u16(_packedLanguage('eng')),
    ..._u16(0),
  ]);
  final hdlr = _box('hdlr', [0, 0, 0, 0, ..._u32(0), ...ascii.encode('sbtl')]);
  final stsd = _box('stsd', [
    0,
    0,
    0,
    0,
    ..._u32(1),
    ..._box('tx3g', const []),
  ]);
  final stts = _box('stts', [
    0,
    0,
    0,
    0,
    ..._u32(1),
    ..._u32(samples.length),
    ..._u32(2000),
  ]);
  final stsc = _box('stsc', [
    0,
    0,
    0,
    0,
    ..._u32(1),
    ..._u32(1),
    ..._u32(1),
    ..._u32(1),
  ]);
  final stsz = _box('stsz', [
    0,
    0,
    0,
    0,
    ..._u32(0),
    ..._u32(samples.length),
    for (final sample in samples) ..._u32(sample.length),
  ]);
  final stco = _box('stco', [
    0,
    0,
    0,
    0,
    ..._u32(offsets.length),
    for (final offset in offsets) ..._u32(offset),
  ]);
  final stbl = _box('stbl', [...stsd, ...stts, ...stsc, ...stsz, ...stco]);
  final minf = _box('minf', stbl);
  final mdia = _box('mdia', [...mdhd, ...hdlr, ...minf]);
  final trak = _box('trak', [...tkhd, ...mdia]);
  return _box('moov', [...mvhd, ...trak]);
}

Uint8List _box(String type, List<int> payload) {
  final result = BytesBuilder();
  result.add(_u32(payload.length + 8));
  result.add(ascii.encode(type));
  result.add(payload);
  return result.takeBytes();
}

List<int> _u16(int value) => [(value >> 8) & 0xff, value & 0xff];

List<int> _u32(int value) => [
  (value >> 24) & 0xff,
  (value >> 16) & 0xff,
  (value >> 8) & 0xff,
  value & 0xff,
];

int _packedLanguage(String value) {
  return ((value.codeUnitAt(0) - 0x60) << 10) |
      ((value.codeUnitAt(1) - 0x60) << 5) |
      (value.codeUnitAt(2) - 0x60);
}
