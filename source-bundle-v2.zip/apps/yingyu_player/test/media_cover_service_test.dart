import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:yingyu_player/data/media_cover_service.dart';

void main() {
  test('uses a video-specific sidecar image before a folder poster', () async {
    final directory = await Directory.systemTemp.createTemp(
      'yingyu-cover-test-',
    );
    addTearDown(() => directory.delete(recursive: true));
    final media = File('${directory.path}${Platform.pathSeparator}Movie.mkv');
    final exact = File('${directory.path}${Platform.pathSeparator}Movie.jpg');
    final folder = File('${directory.path}${Platform.pathSeparator}poster.png');
    await media.writeAsBytes([0]);
    await exact.writeAsBytes([1, 2, 3]);
    await folder.writeAsBytes([4, 5, 6]);

    final cover = await MediaCoverService().resolve(media.path);

    expect(cover, exact.path);
  });

  test('recognizes a shared folder cover when no title cover exists', () async {
    final directory = await Directory.systemTemp.createTemp(
      'yingyu-folder-cover-test-',
    );
    addTearDown(() => directory.delete(recursive: true));
    final media = File('${directory.path}${Platform.pathSeparator}Episode.mkv');
    final folder = File(
      '${directory.path}${Platform.pathSeparator}folder.webp',
    );
    await media.writeAsBytes([0]);
    await folder.writeAsBytes([1, 2, 3]);

    final cover = await MediaCoverService().resolve(media.path);

    expect(cover, folder.path);
  });
}
