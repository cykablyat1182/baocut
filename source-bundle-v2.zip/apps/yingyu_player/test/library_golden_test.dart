import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:media_kit/media_kit.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:yingyu_player/core/theme/app_theme.dart';
import 'package:yingyu_player/data/settings_store.dart';
import 'package:yingyu_player/domain/models/media_playlist_item.dart';
import 'package:yingyu_player/features/library/media_library_screen.dart';
import 'package:yingyu_player/features/player/learning_player_controller.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  MediaKit.ensureInitialized();

  testWidgets('media library uses the saved native collection layout', (
    tester,
  ) async {
    await _loadAppFonts();
    SharedPreferences.setMockInitialValues({});
    final settings = await SettingsStore.load();
    final controller = LearningPlayerController(settings: settings);
    addTearDown(controller.dispose);
    addTearDown(() => tester.binding.setSurfaceSize(null));
    await tester.binding.setSurfaceSize(const Size(1440, 900));

    const items = [
      MediaPlaylistItem(
        path: r'D:\Media\Movies\Arrival.mkv',
        title: 'Arrival.mkv',
      ),
      MediaPlaylistItem(
        path: r'D:\Media\Movies\Dune Part Two.mkv',
        title: 'Dune Part Two.mkv',
      ),
      MediaPlaylistItem(
        path: r'D:\Media\Series\Sherlock S01E01.mkv',
        title: 'Sherlock S01E01.mkv',
      ),
      MediaPlaylistItem(
        path: r'D:\Media\Series\The Bear S02E03.mp4',
        title: 'The Bear S02E03.mp4',
      ),
      MediaPlaylistItem(
        path: r'D:\Media\Movies\Past Lives.mp4',
        title: 'Past Lives.mp4',
      ),
      MediaPlaylistItem(
        path: r'D:\Media\Movies\The Grand Budapest Hotel.mkv',
        title: 'The Grand Budapest Hotel.mkv',
      ),
    ];
    controller
      ..libraryFolders = [r'D:\Media\Movies', r'D:\Media\Series']
      ..libraryItems = List.of(items);
    settings
      ..recentMediaPaths = [items[1].path, items[2].path]
      ..playbackPositionsMs = {
        items[1].path: const Duration(minutes: 47).inMilliseconds,
        items[2].path: const Duration(minutes: 18).inMilliseconds,
      }
      ..playbackDurationsMs = {
        items[1].path: const Duration(hours: 2, minutes: 46).inMilliseconds,
        items[2].path: const Duration(hours: 1, minutes: 28).inMilliseconds,
      };

    await tester.pumpWidget(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark(),
        home: MediaLibraryScreen(controller: controller),
      ),
    );
    await tester.pump(const Duration(milliseconds: 300));

    await expectLater(
      find.byType(MediaLibraryScreen),
      matchesGoldenFile('goldens/library_default.png'),
    );
  });

  testWidgets('empty library fits a short 16:9 landscape phone viewport', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    final settings = await SettingsStore.load();
    final controller = LearningPlayerController(settings: settings);
    addTearDown(controller.dispose);
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(640, 360);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark(),
        home: MediaLibraryScreen(controller: controller),
      ),
    );
    await tester.pump(const Duration(milliseconds: 200));

    expect(find.text('建立媒体资料库'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('library fits a portrait phone viewport', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final settings = await SettingsStore.load();
    final controller = LearningPlayerController(settings: settings);
    addTearDown(controller.dispose);
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(360, 640);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark(),
        home: MediaLibraryScreen(controller: controller),
      ),
    );
    await tester.pump(const Duration(milliseconds: 200));

    expect(find.text('资料库'), findsOneWidget);
    expect(find.text('建立你的媒体资料库'), findsOneWidget);
    expect(find.byTooltip('添加文件夹'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await expectLater(
      find.byType(MediaLibraryScreen),
      matchesGoldenFile('goldens/library_portrait.png'),
    );
  });
}

Future<void> _loadAppFonts() async {
  final inter = FontLoader('Inter')
    ..addFont(rootBundle.load('assets/fonts/Inter-Variable.ttf'));
  final noto = FontLoader('NotoSansSC')
    ..addFont(rootBundle.load('assets/fonts/NotoSansSC-Variable.ttf'));
  final lora = FontLoader('Lora')
    ..addFont(rootBundle.load('assets/fonts/Lora-Variable.ttf'));
  await Future.wait([inter.load(), noto.load(), lora.load()]);
}
