import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:yingyu_player/data/quark_share_service.dart';
import 'package:yingyu_player/domain/models/cloud_media_source.dart';

void main() {
  test('logs in to Quark by QR code and collects transfer cookies', () async {
    final requests = <http.Request>[];
    final service = QuarkShareService(
      MockClient((request) async {
        requests.add(request);
        if (request.url.path.endsWith('/getTokenForQrcodeLogin')) {
          return _json(
            {
              'status': 2000000,
              'data': {
                'members': {'token': 'qr-token'},
              },
            },
            headers: {'set-cookie': 'qr_session=first; Path=/'},
          );
        }
        if (request.url.path.endsWith('/getServiceTicketByQrcodeToken')) {
          expect(request.headers['cookie'], contains('qr_session=first'));
          return _json({
            'status': 2000000,
            'data': {
              'members': {'service_ticket': 'ticket-1'},
            },
          });
        }
        if (request.url.path == '/account/info') {
          return _json(
            {'success': true},
            headers: {
              'set-cookie':
                  '__uid=user; Path=/, __kps=kps-secret; Path=/, __pus=pus-secret; Path=/',
            },
          );
        }
        return http.Response('not found', 404);
      }),
    );

    final session = await service.startQrLogin();
    final result = await service.pollQrLogin(session);

    expect(session.qrUrl, contains('su.quark.cn'));
    expect(session.qrUrl, contains('qr-token'));
    expect(result.status, QuarkQrLoginStatus.success);
    expect(result.cookie, contains('__uid=user'));
    expect(result.cookie, contains('__kps=kps-secret'));
    expect(result.cookie, contains('__pus=pus-secret'));
    expect(requests, hasLength(3));
  });

  test('keeps waiting while a Quark QR code has not been confirmed', () async {
    final requestIds = <String>[];
    final service = QuarkShareService(
      MockClient((request) async {
        requestIds.add(request.url.queryParameters['request_id'] ?? '');
        if (request.url.path.endsWith('/getTokenForQrcodeLogin')) {
          return _json({
            'status': 2000000,
            'data': {
              'members': {'token': 'qr-token'},
            },
          });
        }
        return _json({'status': 50004001, 'message': 'waiting'});
      }),
    );

    final session = await service.startQrLogin();
    final result = await service.pollQrLogin(session);
    await service.pollQrLogin(session);

    expect(result.status, QuarkQrLoginStatus.waiting);
    expect(requestIds, hasLength(3));
    expect(requestIds.toSet(), hasLength(3));
  });

  test('imports a Quark share and waits for the save task', () async {
    final requests = <http.Request>[];
    final service = QuarkShareService(
      MockClient((request) async {
        requests.add(request);
        final path = request.url.path;
        if (path.endsWith('/share/sharepage/token')) {
          return _json({
            'status': 200,
            'code': 0,
            'data': {'stoken': 'share-token'},
          });
        }
        if (path.endsWith('/share/sharepage/detail')) {
          return _json({
            'status': 200,
            'code': 0,
            'data': {
              'list': [
                {
                  'fid': 'shared-file',
                  'share_fid_token': 'file-token',
                  'file_name': '测试 4K.mkv',
                },
              ],
            },
          });
        }
        if (path.endsWith('/share/sharepage/save')) {
          return _json({
            'status': 200,
            'code': 0,
            'data': {'task_id': 'task-1'},
          });
        }
        if (path.endsWith('/task')) {
          return _json({
            'status': 200,
            'code': 0,
            'data': {
              'status': 2,
              'save_as': {
                'save_as_top_fids': ['saved-file'],
              },
            },
          });
        }
        return http.Response('not found', 404);
      }),
    );
    const source = CloudMediaSource(
      id: 'cloud',
      name: '我的夸克',
      baseUrl: 'https://openlist.example',
      apiToken: 'openlist-token',
      provider: 'quark',
      transferCredential: '__uid=secret; __kps=secret',
      transferFolderId: 'target-folder',
    );

    final result = await service.importShare(
      source,
      'https://pan.quark.cn/s/share-id?pwd=8899',
    );

    expect(result.savedFileIds, ['saved-file']);
    expect(result.sharedNames, ['测试 4K.mkv']);
    expect(requests, hasLength(4));
    expect(
      requests.every((request) => request.headers['cookie']!.contains('__uid')),
      isTrue,
    );
    final save = requests.firstWhere(
      (request) => request.url.path.endsWith('/share/sharepage/save'),
    );
    expect(jsonDecode(save.body)['to_pdir_fid'], 'target-folder');
  });

  test('expands a shared season folder before saving every episode', () async {
    final savedBodies = <Map<String, dynamic>>[];
    final service = QuarkShareService(
      MockClient((request) async {
        final path = request.url.path;
        if (path.endsWith('/share/sharepage/token')) {
          return _json({
            'status': 200,
            'code': 0,
            'data': {'stoken': 'share-token'},
          });
        }
        if (path.endsWith('/share/sharepage/detail')) {
          final parent = request.url.queryParameters['pdir_fid'];
          return _json({
            'status': 200,
            'code': 0,
            'data': {
              'list': parent == '0'
                  ? [
                      {
                        'fid': 'season-folder',
                        'share_fid_token': 'folder-token',
                        'file_name': 'The Boys S01',
                        'dir': true,
                      },
                    ]
                  : [
                      for (final episode in [1, 2, 3, 4])
                        {
                          'fid': 'episode-$episode',
                          'share_fid_token': 'token-$episode',
                          'file_name': 'The.Boys.S01E0$episode.mkv',
                        },
                    ],
            },
          });
        }
        if (path.endsWith('/share/sharepage/save')) {
          savedBodies.add(
            (jsonDecode(request.body) as Map).cast<String, dynamic>(),
          );
          return _json({
            'status': 200,
            'code': 0,
            'data': {'task_id': 'task-1'},
          });
        }
        if (path.endsWith('/task')) {
          return _json({
            'status': 200,
            'code': 0,
            'data': {
              'status': 2,
              'save_as': {
                'save_as_top_fids': [
                  'saved-1',
                  'saved-2',
                  'saved-3',
                  'saved-4',
                ],
              },
            },
          });
        }
        return http.Response('not found', 404);
      }),
    );
    const source = CloudMediaSource(
      id: 'cloud',
      name: '我的夸克',
      baseUrl: 'https://openlist.example',
      apiToken: 'openlist-token',
      provider: 'quark',
      transferCredential: '__uid=secret; __kps=secret',
    );

    final result = await service.importShare(
      source,
      'https://pan.quark.cn/s/share-id',
    );

    expect(
      result.sharedNames,
      containsAll(['The.Boys.S01E02.mkv', 'The.Boys.S01E04.mkv']),
    );
    expect(savedBodies, hasLength(1));
    expect(savedBodies.single['pdir_fid'], 'season-folder');
    expect(savedBodies.single['fid_list'], [
      'episode-1',
      'episode-2',
      'episode-3',
      'episode-4',
    ]);
  });
}

http.Response _json(
  Map<String, Object> value, {
  Map<String, String> headers = const {},
}) => http.Response(
  jsonEncode(value),
  200,
  headers: {'content-type': 'application/json; charset=utf-8', ...headers},
);
