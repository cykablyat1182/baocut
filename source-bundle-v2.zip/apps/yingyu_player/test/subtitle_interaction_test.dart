import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:yingyu_player/data/subtitle_tokenizer.dart';
import 'package:yingyu_player/domain/models/subtitle_cue.dart';
import 'package:yingyu_player/features/player/widgets/dictionary_overlay.dart';
import 'package:yingyu_player/features/player/widgets/subtitle_overlay.dart';

void main() {
  test('tokenizer keeps English and CJK subtitle phrases queryable', () {
    final tokens = tokenizeSubtitle("Hello, 運命石の扉！这是测试。");
    expect(
      tokens.where((token) => token.queryable).map((token) => token.text),
      ['Hello', '運命石の扉', '这是测试'],
    );
  });

  test('subtitle display spacing is normalized without losing line breaks', () {
    expect(
      normalizeSubtitleDisplaySpacing(
        'that  masterminded\tthis\u00a0\u2003whatever\r\n  cave',
      ),
      'that masterminded this whatever\ncave',
    );
  });

  testWidgets('both original and translated embedded text are clickable', (
    tester,
  ) async {
    String? selected;
    String? sentence;
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SubtitleOverlay(
            cue: const SubtitleCue(
              id: 'embedded-1',
              start: Duration.zero,
              end: Duration(seconds: 2),
              original: '運命石の扉！',
              translation: '这是测试。',
            ),
            mode: SubtitleDisplayMode.bilingual,
            selectedWord: null,
            onWordTap: (word, context) {
              selected = word;
              sentence = context;
            },
            compact: false,
          ),
        ),
      ),
    );

    await tester.tap(find.text('这是测试'));
    expect(selected, '这是测试');
    expect(sentence, '这是测试。');
  });

  testWidgets('subtitle overlay collapses uneven source spaces for display', (
    tester,
  ) async {
    String? queriedSentence;
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SubtitleOverlay(
            cue: const SubtitleCue(
              id: 'uneven-spacing',
              start: Duration.zero,
              end: Duration(seconds: 2),
              original: 'that  masterminded\tthis\u00a0whatever',
              translation: '',
            ),
            mode: SubtitleDisplayMode.original,
            selectedWord: null,
            onWordTap: (_, sentence) => queriedSentence = sentence,
            compact: false,
          ),
        ),
      ),
    );

    expect(find.text('  '), findsNothing);
    expect(find.text('\t'), findsNothing);
    expect(find.text('\u00a0'), findsNothing);
    await tester.tap(find.text('masterminded'));
    expect(queriedSentence, 'that  masterminded\tthis\u00a0whatever');
  });

  testWidgets('bilingual subtitle sizes and vertical order are independent', (
    tester,
  ) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SubtitleOverlay(
            cue: const SubtitleCue(
              id: 'sized-bilingual',
              start: Duration.zero,
              end: Duration(seconds: 2),
              original: 'Original',
              translation: '译文',
            ),
            mode: SubtitleDisplayMode.bilingual,
            selectedWord: null,
            onWordTap: (_, _) {},
            compact: false,
            originalScale: 1.5,
            translationScale: 0.8,
            translationFirst: true,
          ),
        ),
      ),
    );

    expect(
      tester.getTopLeft(find.text('译文')).dy,
      lessThan(tester.getTopLeft(find.text('Original')).dy),
    );
    expect(tester.widget<Text>(find.text('Original')).style?.fontSize, 48);
    expect(
      tester.widget<Text>(find.text('译文')).style?.fontSize,
      closeTo(18.4, 0.001),
    );
  });

  testWidgets('dictionary failures remain visible and retryable', (
    tester,
  ) async {
    var retried = false;
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: DictionaryOverlay(
            entry: null,
            word: 'test',
            loading: false,
            error: '本机服务未启动',
            saved: false,
            onClose: () {},
            onRetry: () => retried = true,
            onToggleSaved: () {},
            compact: false,
          ),
        ),
      ),
    );

    expect(find.text('本机服务未启动'), findsOneWidget);
    await tester.tap(find.text('重新查询'));
    expect(retried, isTrue);
  });
}
