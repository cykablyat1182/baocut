import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:yingyu_player/data/quark_drive_service.dart';
import 'package:yingyu_player/domain/models/cloud_media_source.dart';

void main() {
  const source = CloudMediaSource(
    id: 'quark-direct',
    name: '夸克',
    baseUrl: QuarkDriveService.directBaseUrl,
    apiToken: 'qr-cookie',
    provider: 'quark_direct',
    transferCredential: '__uid=user; __kps=kps-secret; __pus=pus-secret',
  );

  test('scans videos, pairs sidecar subtitles, and keeps the fid', () async {
    final service = QuarkDriveService(
      MockClient((request) async {
        expect(request.headers['cookie'], contains('__kps=kps-secret'));
        if (request.url.path.endsWith('/config')) {
          return _json({
            'code': 0,
            'data': <String, Object>{},
          }, setCookie: '__puus=fresh-puus; Path=/; Domain=.quark.cn');
        }
        if (request.url.path.endsWith('/file/sort')) {
          return _json({
            'code': 0,
            'data': {
              'list': [
                {'fid': 'movie-fid', 'file_name': 'Arrival.mkv', 'dir': false},
                {
                  'fid': 'subtitle-fid',
                  'file_name': 'Arrival.srt',
                  'dir': false,
                },
              ],
            },
          });
        }
        return http.Response('{}', 404);
      }),
    );

    final items = await service.load(source);

    expect(items, hasLength(1));
    expect(items.single.remotePath, 'movie-fid');
    expect(items.single.remoteSubtitlePaths, ['subtitle-fid']);
  });

  test('passes Quark session headers to the signed playback URL', () async {
    final service = QuarkDriveService(
      MockClient((request) async {
        expect(request.headers['cookie'], contains('__uid=user'));
        if (request.url.path.endsWith('/config')) {
          return _json({
            'code': 0,
            'data': <String, Object>{},
          }, setCookie: '__puus=fresh-puus; Path=/; Domain=.quark.cn');
        }
        expect(request.url.path.endsWith('/file/download'), isTrue);
        expect(request.headers['cookie'], contains('__puus=fresh-puus'));
        return _json({
          'code': 0,
          'data': [
            {'download_url': 'https://dl-pc-sz.drive.quark.cn/movie.mkv'},
          ],
        }, setCookie: '__puus=newest-puus; Path=/; Domain=.quark.cn');
      }),
    );

    final resolved = await service.resolve(source, 'movie-fid');

    expect(resolved.url, contains('dl-pc-sz.drive.quark.cn'));
    expect(resolved.headers['Cookie'], '__puus=newest-puus');
    expect(resolved.headers['Referer'], 'https://pan.quark.cn/');
    expect(service.currentCookie(source), contains('__puus=newest-puus'));
  });
}

http.Response _json(Map<String, Object> value, {String? setCookie}) =>
    http.Response(
      jsonEncode(value),
      200,
      headers: {
        'content-type': 'application/json; charset=utf-8',
        'set-cookie': ?setCookie,
      },
    );
