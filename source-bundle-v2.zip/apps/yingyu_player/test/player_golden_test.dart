import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:media_kit/media_kit.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:yingyu_player/core/theme/app_theme.dart';
import 'package:yingyu_player/data/settings_store.dart';
import 'package:yingyu_player/domain/models/media_playlist_item.dart';
import 'package:yingyu_player/features/player/learning_player_controller.dart';
import 'package:yingyu_player/features/player/player_dialogs.dart';
import 'package:yingyu_player/features/player/player_screen.dart';
import 'package:yingyu_player/features/player/widgets/dictionary_overlay.dart';
import 'package:yingyu_player/features/player/widgets/playback_osd.dart';
import 'package:yingyu_player/features/player/widgets/subtitle_pager.dart';
import 'package:yingyu_player/features/player/widgets/subtitle_drawer.dart';
import 'package:yingyu_player/features/player/widgets/playlist_drawer.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  MediaKit.ensureInitialized();
  setUpAll(_loadAppFonts);

  testWidgets('native player default surface matches the approved design', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    final settings = await SettingsStore.load();
    final controller = LearningPlayerController(settings: settings);
    addTearDown(controller.dispose);
    addTearDown(() => tester.binding.setSurfaceSize(null));
    await tester.binding.setSurfaceSize(const Size(1440, 900));

    await tester.pumpWidget(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark(),
        home: PlayerScreen(controller: controller),
      ),
    );
    await tester.pump(const Duration(milliseconds: 100));
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 250)),
    );
    await tester.pump(const Duration(milliseconds: 700));

    await expectLater(
      find.byType(PlayerScreen),
      matchesGoldenFile('goldens/player_default.png'),
    );
  });

  testWidgets('bottom subtitle pages by swipe without visible arrow buttons', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    final settings = await SettingsStore.load();
    final controller = LearningPlayerController(settings: settings);
    addTearDown(controller.dispose);
    final initialIndex = controller.currentCueIndex;

    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.dark(),
        home: Scaffold(
          body: Center(
            child: SizedBox(
              width: 720,
              child: SubtitlePager(controller: controller, compact: false),
            ),
          ),
        ),
      ),
    );

    expect(find.byIcon(Icons.chevron_left_rounded), findsNothing);
    expect(find.byIcon(Icons.chevron_right_rounded), findsNothing);
    await tester.fling(find.byType(SubtitlePager), const Offset(-320, 0), 900);
    await tester.pumpAndSettle();
    expect(controller.currentCueIndex, initialIndex + 1);
  });

  testWidgets('brief seek buffering does not flash the play-button spinner', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    final settings = await SettingsStore.load();
    final controller = LearningPlayerController(settings: settings);
    addTearDown(controller.dispose);

    Widget buildSurface() => MaterialApp(
      theme: AppTheme.dark(),
      home: Scaffold(
        body: Stack(
          children: [
            const Positioned.fill(child: ColoredBox(color: Colors.black)),
            AnimatedBuilder(
              animation: controller,
              builder: (context, _) => PlaybackOsd(
                controller: controller,
                onSubtitleMenu: () {},
                onSourceMenu: () {},
                compact: false,
                dense: false,
                onInteraction: () {},
              ),
            ),
          ],
        ),
      ),
    );

    controller.isBuffering = true;
    await tester.pumpWidget(buildSurface());
    await tester.pump(const Duration(milliseconds: 180));
    controller.isBuffering = false;
    controller.notifyListeners();
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 200));
    expect(find.byType(CircularProgressIndicator), findsNothing);

    controller.isBuffering = true;
    controller.notifyListeners();
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 350));
    expect(find.byType(CircularProgressIndicator), findsOneWidget);

    controller.isBuffering = false;
    controller.notifyListeners();
    await tester.pump();
    expect(find.byType(CircularProgressIndicator), findsNothing);
  });

  testWidgets(
    'dictionary overlay stays open when playback enters the next cue',
    (tester) async {
      SharedPreferences.setMockInitialValues({});
      final settings = await SettingsStore.load();
      final controller = LearningPlayerController(settings: settings);
      addTearDown(controller.dispose);

      await tester.pumpWidget(
        MaterialApp(
          theme: AppTheme.dark(),
          home: PlayerScreen(controller: controller),
        ),
      );
      await controller.selectWord('weather', controller.currentCue?.original);
      expect(controller.selectedWord, 'weather');
      expect(controller.selectedEntry, isNotNull);

      final nextCue = controller.cues[controller.currentCueIndex + 1];
      await controller.seek(nextCue.start);
      await tester.pump();

      expect(controller.currentCueIndex, greaterThan(3));
      expect(controller.selectedWord, 'weather');
      expect(controller.selectedEntry, isNotNull);
      expect(find.byType(DictionaryOverlay), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets('online series playlist exposes previous and next episode', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    final settings = await SettingsStore.load();
    final controller = LearningPlayerController(settings: settings)
      ..playlist = const [
        MediaPlaylistItem(
          path: 'https://media.example/1.m3u8',
          title: '第1集',
          isOnline: true,
        ),
        MediaPlaylistItem(
          path: 'https://media.example/2.m3u8',
          title: '第2集',
          isOnline: true,
        ),
        MediaPlaylistItem(
          path: 'https://media.example/3.m3u8',
          title: '第3集',
          isOnline: true,
        ),
      ]
      ..mediaPath = 'https://media.example/2.m3u8'
      ..playlistOpen = true;
    addTearDown(controller.dispose);

    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.dark(),
        home: Scaffold(
          body: Stack(
            children: [
              PlaylistDrawer(
                controller: controller,
                width: 320,
                top: 0,
                bottom: 0,
                dense: false,
                onOpenFolder: () {},
              ),
            ],
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('3 集 · 当前第 2 集'), findsOneWidget);
    expect(find.text('上一集'), findsOneWidget);
    expect(find.text('下一集'), findsOneWidget);
    expect(controller.hasPreviousPlaylistItem, isTrue);
    expect(controller.hasNextPlaylistItem, isTrue);
  });

  testWidgets('a second surface tap hides controls immediately', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    final settings = await SettingsStore.load();
    final controller = LearningPlayerController(settings: settings);
    addTearDown(controller.dispose);
    controller
      ..setDrawer(false)
      ..closeDictionary();
    controller.setOsdVisible(false);

    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.dark(),
        home: PlayerScreen(controller: controller),
      ),
    );
    await tester.pump();

    tester
        .widget<GestureDetector>(find.byKey(const Key('player-video-surface')))
        .onTap!();
    await tester.pump();
    expect(controller.osdVisible, isTrue);

    tester
        .widget<GestureDetector>(find.byKey(const Key('player-video-surface')))
        .onTap!();
    await tester.pump();
    expect(controller.osdVisible, isFalse);
  });

  testWidgets('locked player keeps subtitles and auto-hides the lock button', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    final settings = await SettingsStore.load();
    final controller = LearningPlayerController(settings: settings);
    addTearDown(controller.dispose);
    controller
      ..setDrawer(false)
      ..closeDictionary();

    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.dark(),
        home: PlayerScreen(controller: controller),
      ),
    );
    controller.toggleLock();
    await tester.pump();
    await tester.pump();

    expect(find.byType(SubtitlePager), findsOneWidget);
    expect(find.byTooltip('解锁控制'), findsOneWidget);
    expect(tester.getCenter(find.byTooltip('解锁控制')).dx, lessThan(100));

    await tester.pump(const Duration(seconds: 2, milliseconds: 100));
    expect(find.byType(SubtitlePager), findsOneWidget);
    expect(find.byTooltip('解锁控制'), findsNothing);

    tester
        .widget<GestureDetector>(find.byKey(const Key('player-video-surface')))
        .onTap!();
    await tester.pump();
    expect(find.byTooltip('解锁控制'), findsOneWidget);
    controller.toggleLock();
    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump(const Duration(seconds: 5));
  });

  testWidgets('opening subtitle navigation jumps to the playing cue', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    final settings = await SettingsStore.load();
    final controller = LearningPlayerController(settings: settings);
    addTearDown(controller.dispose);
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(900, 520);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    controller.setDrawer(false);
    final targetIndex = controller.cues.length - 2;
    await controller.seekCue(targetIndex);
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.dark(),
        home: Scaffold(
          body: Stack(
            children: [
              SubtitleDrawer(
                controller: controller,
                width: 360,
                top: 0,
                bottom: 0,
                dense: false,
                onSearch: () {},
              ),
            ],
          ),
        ),
      ),
    );
    controller.toggleDrawer();
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));

    expect(controller.currentCueIndex, targetIndex);
    expect(find.text(controller.cues[targetIndex].original), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('subtitle display settings adjust both sizes and line order', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    final settings = await SettingsStore.load();
    final controller = LearningPlayerController(settings: settings);
    addTearDown(controller.dispose);
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(640, 360);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.dark(),
        home: Builder(
          builder: (context) => TextButton(
            onPressed: () => showSubtitleDisplaySettings(context, controller),
            child: const Text('字幕显示'),
          ),
        ),
      ),
    );
    await tester.tap(find.text('字幕显示'));
    await tester.pumpAndSettle();

    final sliders = tester.widgetList<Slider>(find.byType(Slider)).toList();
    expect(sliders, hasLength(3));
    sliders[0].onChanged!(1.5);
    sliders[1].onChanged!(0.8);
    tester
        .widget<SwitchListTile>(
          find.byKey(const ValueKey('subtitle-translation-first')),
        )
        .onChanged!(true);
    await tester.pump();

    expect(controller.subtitleOriginalScale, 1.5);
    expect(controller.subtitleTranslationScale, 0.8);
    expect(controller.subtitleTranslationFirst, isTrue);

    tester
        .widget<SwitchListTile>(
          find.byKey(const ValueKey('hide-hearing-impaired-subtitles')),
        )
        .onChanged!(true);
    await tester.pump();
    expect(controller.hideHearingImpairedSubtitles, isTrue);
    expect(settings.hideHearingImpairedSubtitles, isTrue);
    expect(tester.takeException(), isNull);
  });

  testWidgets('compact landscape keeps the subtitle timeline fully bounded', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    final settings = await SettingsStore.load();
    final controller = LearningPlayerController(settings: settings);
    addTearDown(controller.dispose);
    controller.closeDictionary();
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(640, 360);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.dark(),
        home: PlayerScreen(controller: controller),
      ),
    );
    await tester.pump(const Duration(milliseconds: 300));

    final drawerRect = tester.getRect(find.byType(SubtitleDrawer));
    expect(drawerRect.top, greaterThanOrEqualTo(0));
    expect(drawerRect.bottom, lessThanOrEqualTo(360));
    expect(drawerRect.height, greaterThan(180));
    expect(find.text('字幕导航'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('landscape settings expose persisted frame interpolation', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    final settings = await SettingsStore.load();
    final controller = LearningPlayerController(settings: settings);
    addTearDown(controller.dispose);
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(640, 360);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.dark(),
        home: Builder(
          builder: (context) => TextButton(
            onPressed: () => showPlayerSettings(context, controller),
            child: const Text('打开设置'),
          ),
        ),
      ),
    );
    await tester.tap(find.text('打开设置'));
    await tester.pumpAndSettle();
    expect(find.text('播放与画面'), findsOneWidget);
    expect(tester.takeException(), isNull);

    await tester.tap(find.text('播放与画面'));
    await tester.pumpAndSettle();
    expect(find.text('实时视频插帧'), findsOneWidget);
    await tester.tap(find.text('流畅'));
    await tester.pump();

    expect(controller.frameInterpolationMode, FrameInterpolationMode.balanced);
    expect(settings.frameInterpolationMode, 'balanced');
    expect(tester.takeException(), isNull);
  });
}

Future<void> _loadAppFonts() async {
  final inter = FontLoader('Inter')
    ..addFont(rootBundle.load('assets/fonts/Inter-Variable.ttf'));
  final noto = FontLoader('NotoSansSC')
    ..addFont(rootBundle.load('assets/fonts/NotoSansSC-Variable.ttf'));
  final lora = FontLoader('Lora')
    ..addFont(rootBundle.load('assets/fonts/Lora-Variable.ttf'));
  await Future.wait([inter.load(), noto.load(), lora.load()]);
}
