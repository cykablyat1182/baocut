import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:yingyu_player/data/online_movie_service.dart';
import 'package:yingyu_player/domain/models/online_movie.dart';

void main() {
  test('exposes only split native 4K routes', () {
    expect(OnlineMovieService.recommendedWarehouses, hasLength(10));
    expect(
      OnlineMovieService.recommendedWarehouses.map((item) => item.name),
      containsAll(['玩偶 4K', '快映 4K', '木偶 4K', '至臻 4K', '虎斑 4K']),
    );
    expect(
      OnlineMovieService.recommendedWarehouses
          .map((item) => item.siteKey)
          .whereType<String>(),
      hasLength(10),
    );
  });

  test(
    'discovers native CMS providers and ignores custom spider sites',
    () async {
      final service = OnlineMovieService(
        MockClient((request) async {
          return http.Response.bytes(
            utf8.encode(
              jsonEncode({
                'sites': [
                  {
                    'key': 'cms',
                    'name': '原生线路',
                    'type': 1,
                    'api': './api.php/provide/vod/',
                  },
                  {'key': 'jar', 'name': '脚本线路', 'type': 3, 'api': 'csp_Test'},
                ],
              }),
            ),
            200,
            headers: {'content-type': 'application/json; charset=utf-8'},
          );
        }),
      );

      final result = await service.discover(
        const OnlineMovieWarehouse(
          name: '测试仓',
          url: 'https://box.example/config.json',
        ),
      );

      expect(result.providers, hasLength(1));
      expect(
        result.providers.single.api,
        'https://box.example/api.php/provide/vod/',
      );
      expect(result.unsupportedSiteCount, 1);
    },
  );

  test('splits a multi-site aggregate by its selected 4K key', () async {
    final service = OnlineMovieService(
      MockClient((request) async {
        return http.Response.bytes(
          utf8.encode(
            jsonEncode({
              'sites': [
                {
                  'key': '玩偶',
                  'name': '玩偶 • 4K',
                  'type': 3,
                  'api': 'csp_Wogg',
                  'ext': {
                    'site': ['https://wogg.example'],
                  },
                },
                {
                  'key': '快映',
                  'name': '快映 • 4K',
                  'type': 3,
                  'api': 'csp_PanWebShare',
                  'ext': {
                    'site': ['https://kua.example'],
                  },
                },
              ],
            }),
          ),
          200,
          headers: {'content-type': 'application/json'},
        );
      }),
    );

    final result = await service.discover(
      const OnlineMovieWarehouse(
        name: '玩偶 4K',
        url: 'https://box.example/config.json',
        siteKey: '玩偶',
      ),
    );

    expect(result.providers, hasLength(1));
    expect(result.providers.single.name, '玩偶 • 4K');
    expect(result.providers.single.adapter, 'wogg');
  });

  test(
    'uses a fallback config when the published warehouse URL is dead',
    () async {
      final service = OnlineMovieService(
        MockClient((request) async {
          if (request.url.host == 'dead.example') {
            return http.Response('gone', 502);
          }
          return http.Response.bytes(
            utf8.encode(
              jsonEncode({
                'sites': [
                  {
                    'key': 'backup',
                    'name': '兼容备用线路',
                    'type': 1,
                    'api': 'https://cms.example/api.php/provide/vod/',
                  },
                ],
              }),
            ),
            200,
            headers: {'content-type': 'application/json; charset=utf-8'},
          );
        }),
      );

      final result = await service.discover(
        const OnlineMovieWarehouse(
          name: '自动修复仓',
          url: 'https://dead.example/config.json',
          fallbackUrls: ['https://backup.example/config.json'],
        ),
      );

      expect(result.providers.single.name, '兼容备用线路');
      expect(result.failedConfigCount, 0);
    },
  );

  test('loads catalog, detail and playable route episodes', () async {
    final service = OnlineMovieService(
      MockClient((request) async {
        expect(request.url.queryParameters['ac'], 'detail');
        if (request.url.queryParameters['ids'] == '7') {
          return http.Response.bytes(
            utf8.encode(
              jsonEncode({
                'list': [
                  {
                    'vod_id': 7,
                    'vod_name': '示例电影',
                    'vod_pic': 'https://img.example/poster.jpg',
                    'vod_content': '<p>一段简介</p>',
                    'vod_play_from': r'高清$$$备用',
                    'vod_play_url':
                        r'第1集$https://media.example/one.m3u8|Referer=https%3A%2F%2Fbox.example#第2集$not-a-url$$$播放$https://media.example/backup.mp4',
                  },
                ],
              }),
            ),
            200,
            headers: {'content-type': 'application/json; charset=utf-8'},
          );
        }
        expect(request.url.queryParameters['pg'], '2');
        expect(request.url.queryParameters['t'], '1');
        return http.Response.bytes(
          utf8.encode(
            jsonEncode({
              'page': 2,
              'pagecount': 9,
              'class': [
                {'type_id': 1, 'type_name': '电影'},
              ],
              'list': [
                {
                  'vod_id': 7,
                  'vod_name': '示例电影',
                  'vod_pic': 'https://img.example/poster.jpg',
                  'vod_remarks': 'HD',
                },
              ],
            }),
          ),
          200,
          headers: {'content-type': 'application/json; charset=utf-8'},
        );
      }),
    );
    const provider = OnlineMovieProvider(
      key: 'cms',
      name: '线路',
      api: 'https://api.example/vod',
      warehouseName: '测试仓',
    );

    final page = await service.loadCatalog(provider, page: 2, categoryId: '1');
    final detail = await service.loadDetail(page.items.single);

    expect(page.pageCount, 9);
    expect(page.categories.single.name, '电影');
    expect(detail.blurb, '一段简介');
    expect(detail.episodes, hasLength(2));
    expect(detail.episodes.first.route, '高清');
    expect(detail.episodes.first.httpHeaders['Referer'], 'https://box.example');
    expect(detail.episodes.last.route, '备用');
  });

  test('rejects live protocols from the 4K movie episode list', () async {
    final service = OnlineMovieService(
      MockClient((request) async {
        return http.Response.bytes(
          utf8.encode(
            jsonEncode({
              'list': [
                {
                  'vod_id': 8,
                  'vod_name': '协议过滤',
                  'vod_play_from': '直播混入',
                  'vod_play_url':
                      r'直播$rtmp://live.example/channel#电影$https://media.example/movie.mp4',
                },
              ],
            }),
          ),
          200,
          headers: {'content-type': 'application/json; charset=utf-8'},
        );
      }),
    );
    const provider = OnlineMovieProvider(
      key: 'cms',
      name: '线路',
      api: 'https://api.example/vod',
      warehouseName: '测试仓',
    );

    final detail = await service.loadDetail(
      const OnlineMovieSummary(id: '8', name: '协议过滤', provider: provider),
    );

    expect(detail.episodes, hasLength(1));
    expect(detail.episodes.single.name, '电影');
  });

  test(
    'does not wrap direct media or cloud shares with a TVBox resolver',
    () async {
      final service = OnlineMovieService(
        MockClient((request) async {
          return http.Response.bytes(
            utf8.encode(
              jsonEncode({
                'list': [
                  {
                    'vod_id': 9,
                    'vod_name': '解析器测试',
                    'vod_play_from': r'直连$$$网盘$$$解析',
                    'vod_play_url':
                        r'播放$https://media.example/episode/index.m3u8$$$夸克$https://pan.quark.cn/s/share-id$$$播放$https://origin.example/watch/opaque',
                  },
                ],
              }),
            ),
            200,
            headers: {'content-type': 'application/json; charset=utf-8'},
          );
        }),
      );
      const provider = OnlineMovieProvider(
        key: 'resolver',
        name: '带解析器线路',
        api: 'https://api.example/vod',
        warehouseName: '测试仓',
        playUrl: 'https://resolver.example/?url=',
      );

      final detail = await service.loadDetail(
        const OnlineMovieSummary(id: '9', name: '解析器测试', provider: provider),
      );

      expect(
        detail.episodes[0].url,
        'https://media.example/episode/index.m3u8',
      );
      expect(detail.episodes[1].url, 'https://pan.quark.cn/s/share-id');
      expect(
        detail.episodes[2].url,
        'https://resolver.example/?url=https://origin.example/watch/opaque',
      );
    },
  );

  test(
    'global search queries every discovered provider and keeps its line',
    () async {
      final service = OnlineMovieService(
        MockClient((request) async {
          if (request.url.host == 'cms.example') {
            expect(request.url.queryParameters['wd'], '示例');
            return http.Response.bytes(
              utf8.encode(
                jsonEncode({
                  'page': 1,
                  'pagecount': 1,
                  'list': [
                    {
                      'vod_id': 88,
                      'vod_name': '示例电视剧',
                      'vod_remarks': '更新至12集',
                    },
                  ],
                }),
              ),
              200,
              headers: {'content-type': 'application/json; charset=utf-8'},
            );
          }
          return http.Response.bytes(
            utf8.encode(
              jsonEncode({
                'sites': [
                  {
                    'key': 'global',
                    'name': '全局线路',
                    'type': 1,
                    'api': 'https://cms.example/vod',
                  },
                ],
              }),
            ),
            200,
            headers: {'content-type': 'application/json; charset=utf-8'},
          );
        }),
      );

      final result = await service.searchAll('示例');

      expect(result.providerCount, 1);
      expect(result.failedProviderCount, 0);
      expect(result.items.single.name, '示例电视剧');
      expect(result.items.single.provider.name, '全局线路');
    },
  );

  test(
    'loads Wogg HTML through a working fallback and extracts shares',
    () async {
      final service = OnlineMovieService(
        MockClient((request) async {
          if (request.url.host == 'box.example') {
            return http.Response.bytes(
              utf8.encode(
                jsonEncode({
                  'sites': [
                    {
                      'key': 'wogg',
                      'name': '玩偶·4K',
                      'type': 3,
                      'api': 'csp_Wogg',
                      'ext': {
                        'site': [
                          'https://dead.example',
                          'https://wogg.example',
                        ],
                      },
                    },
                  ],
                }),
              ),
              200,
            );
          }
          if (request.url.host == 'dead.example') {
            return http.Response('dead', 503);
          }
          if (request.url.path.contains('vodsearch')) {
            return http.Response.bytes(
              utf8.encode(
                '<div class="module-search-item">'
                '<img class="lazyload" data-src="/cover.jpg" alt="测试 4K">'
                '<a class="video-serial" href="/voddetail/9.html">4K HDR</a>'
                '</div>',
              ),
              200,
            );
          }
          if (request.url.path.contains('voddetail')) {
            return http.Response.bytes(
              utf8.encode(
                '<meta name="description" content="测试资源">'
                '<div class="module-row-title"><h4>原盘</h4>'
                '<p>https://pan.quark.cn/s/share-id</p></div>',
              ),
              200,
            );
          }
          return http.Response('not found', 404);
        }),
      );
      final discovery = await service.discover(
        const OnlineMovieWarehouse(
          name: '4K 聚合',
          url: 'https://box.example/config.json',
        ),
      );

      expect(discovery.providers.single.adapter, 'wogg');
      final page = await service.loadCatalog(
        discovery.providers.single,
        keyword: '测试',
      );
      expect(page.items.single.name, '测试 4K');
      expect(page.items.single.coverUrl, 'https://wogg.example/cover.jpg');

      final detail = await service.loadDetail(page.items.single);
      expect(detail.episodes.single.route, '夸克网盘');
      expect(detail.episodes.single.isCloudShare, isTrue);
    },
  );
}
