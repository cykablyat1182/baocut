import 'package:flutter_test/flutter_test.dart';
import 'package:yingyu_player/data/embedded_subtitle_alignment.dart';
import 'package:yingyu_player/domain/models/subtitle_cue.dart';

void main() {
  test('pairs language tracks and compensates for a small global offset', () {
    final merged = EmbeddedSubtitleAlignment.merge(
      original: const [
        SubtitleCue(
          id: 'en-1',
          start: Duration(seconds: 1),
          end: Duration(seconds: 3),
          original: 'Hello',
        ),
        SubtitleCue(
          id: 'en-2',
          start: Duration(seconds: 5),
          end: Duration(seconds: 7),
          original: 'How are you?',
        ),
      ],
      translation: const [
        SubtitleCue(
          id: 'zh-1',
          start: Duration(milliseconds: 1500),
          end: Duration(milliseconds: 3500),
          original: '你好',
        ),
        SubtitleCue(
          id: 'zh-2',
          start: Duration(milliseconds: 5500),
          end: Duration(milliseconds: 7500),
          original: '你好吗？',
        ),
      ],
    );

    expect(merged, hasLength(2));
    expect(merged[0].original, 'Hello');
    expect(merged[0].translation, '你好');
    expect(merged[1].translation, '你好吗？');
    expect(merged[0].start, const Duration(seconds: 1));
  });

  test('does not attach a later translation to an unmatched middle cue', () {
    final merged = EmbeddedSubtitleAlignment.merge(
      original: const [
        SubtitleCue(
          id: 'en-1',
          start: Duration(seconds: 100),
          end: Duration(seconds: 102),
          original: 'then staying behind for a photo op',
        ),
        SubtitleCue(
          id: 'en-2',
          start: Duration(seconds: 103),
          end: Duration(seconds: 104),
          original: 'Jean? Thanks, Jennifer. And now...',
        ),
        SubtitleCue(
          id: 'en-3',
          start: Duration(seconds: 105),
          end: Duration(seconds: 107),
          original: 'Hughie: so, this is pretty much',
        ),
      ],
      translation: const [
        SubtitleCue(
          id: 'zh-1',
          start: Duration(milliseconds: 100400),
          end: Duration(milliseconds: 102400),
          original: '然后留下来拍照。',
        ),
        SubtitleCue(
          id: 'zh-2',
          start: Duration(milliseconds: 105300),
          end: Duration(milliseconds: 107300),
          original: '这算是全功能一体的蓝牙扬声器。',
        ),
      ],
    );

    expect(merged, hasLength(3));
    expect(merged[0].translation, '然后留下来拍照。');
    expect(merged[1].translation, isEmpty);
    expect(merged[2].translation, '这算是全功能一体的蓝牙扬声器。');
  });
}
