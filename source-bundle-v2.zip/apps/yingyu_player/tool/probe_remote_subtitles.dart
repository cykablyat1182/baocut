import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:yingyu_player/data/embedded_subtitle_alignment.dart';
import 'package:yingyu_player/data/mp4_mov_text_subtitle_reader.dart';

Future<void> main(List<String> arguments) async {
  final mediaUrl = Platform.environment['YINGYU_TEST_MEDIA_URL'];
  if (mediaUrl == null || mediaUrl.isEmpty) {
    stderr.writeln('Set YINGYU_TEST_MEDIA_URL before running this probe.');
    exitCode = 64;
    return;
  }
  final startSeconds = arguments.isEmpty ? 75 : int.parse(arguments.first);
  final client = http.Client();
  final reader = Mp4MovTextSubtitleReader(client);
  final stopwatch = Stopwatch()..start();
  try {
    final results = await Future.wait([
      reader.readWindow(
        uri: Uri.parse(mediaUrl),
        streamIndex: 8,
        subtitleOrdinal: 6,
        language: 'eng',
        start: Duration(seconds: startSeconds),
        end: Duration(seconds: startSeconds + 45),
      ),
      reader.readWindow(
        uri: Uri.parse(mediaUrl),
        streamIndex: 3,
        subtitleOrdinal: 1,
        language: 'chi',
        start: Duration(seconds: startSeconds),
        end: Duration(seconds: startSeconds + 45),
      ),
    ]);
    final merged = EmbeddedSubtitleAlignment.merge(
      original: results[0] ?? const [],
      translation: results[1] ?? const [],
    );
    stdout.writeln(
      'english=${results[0]?.length ?? -1} '
      'chinese=${results[1]?.length ?? -1} '
      'bilingual=${merged.where((cue) => cue.isBilingual).length} '
      'elapsedMs=${stopwatch.elapsedMilliseconds}',
    );
    if ((results[0]?.isEmpty ?? true) || (results[1]?.isEmpty ?? true)) {
      exitCode = 1;
    }
  } finally {
    client.close();
  }
}
