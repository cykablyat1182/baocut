import 'dart:async';

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_wkwebview/webview_flutter_wkwebview.dart';

import '../../core/theme/app_theme.dart';

/// Official Quark login for iOS and iPadOS.
///
/// The login page is hosted by Quark itself. We only read the resulting
/// session cookies from WKWebView; no QR payload or password is sent through
/// the YingYu service.
class AppleQuarkLoginDialog extends StatefulWidget {
  const AppleQuarkLoginDialog({super.key});

  @override
  State<AppleQuarkLoginDialog> createState() => _AppleQuarkLoginDialogState();
}

class _AppleQuarkLoginDialogState extends State<AppleQuarkLoginDialog> {
  WebViewController? _webView;
  final WebViewCookieManager _cookies = WebViewCookieManager();
  Timer? _cookieTimer;
  bool _checking = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    unawaited(_initialize());
  }

  Future<void> _initialize() async {
    _cookieTimer?.cancel();
    try {
      await _cookies.clearCookies();
      final params = WebKitWebViewControllerCreationParams(
        allowsInlineMediaPlayback: true,
        mediaTypesRequiringUserAction: const <PlaybackMediaTypes>{},
        javaScriptCanOpenWindowsAutomatically: true,
      );
      final controller = WebViewController.fromPlatformCreationParams(params)
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setBackgroundColor(Colors.white)
        ..setNavigationDelegate(
          NavigationDelegate(
            onWebResourceError: (error) {
              if (!mounted) return;
              setState(() => _error = error.description);
            },
          ),
        );
      await controller.loadRequest(Uri.parse('https://pan.quark.cn/'));
      if (!mounted) return;
      setState(() {
        _webView = controller;
        _error = null;
      });
      _cookieTimer = Timer.periodic(
        const Duration(milliseconds: 900),
        (_) => _captureLogin(),
      );
    } on Object catch (error) {
      if (!mounted) return;
      setState(() => _error = '无法打开夸克官方登录页：$error');
    }
  }

  Future<void> _captureLogin() async {
    if (_checking || !mounted) return;
    _checking = true;
    try {
      final cookies = <WebViewCookie>[];
      for (final host in const [
        'https://pan.quark.cn/',
        'https://drive.quark.cn/',
        'https://quark.cn/',
      ]) {
        cookies.addAll(await _cookies.getCookies(domain: Uri.parse(host)));
      }
      final unique = <String, WebViewCookie>{
        for (final cookie in cookies)
          if (cookie.name.trim().isNotEmpty && cookie.value.isNotEmpty)
            '${cookie.domain}|${cookie.name}': cookie,
      };
      final values = unique.values.toList(growable: false);
      final names = values.map((cookie) => cookie.name).toSet();
      if (!names.contains('__kps') &&
          !names.contains('__pus') &&
          !names.contains('__uid')) {
        return;
      }
      final cookie = values
          .map((item) => '${item.name}=${item.value}')
          .join('; ');
      _cookieTimer?.cancel();
      if (mounted) Navigator.of(context).pop(cookie);
    } on Object catch (error) {
      if (mounted) setState(() => _error = '读取夸克登录状态失败：$error');
    } finally {
      _checking = false;
    }
  }

  @override
  void dispose() {
    _cookieTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final compact = MediaQuery.sizeOf(context).width < 600;
    return AlertDialog(
      insetPadding: EdgeInsets.symmetric(
        horizontal: compact ? 10 : 32,
        vertical: compact ? 12 : 24,
      ),
      title: const Text('夸克官方扫码登录'),
      content: SizedBox(
        width: compact ? double.infinity : 760,
        height: (MediaQuery.sizeOf(context).height - (compact ? 150 : 190))
            .clamp(compact ? 340.0 : 440.0, compact ? 620.0 : 700.0),
        child: Column(
          children: [
            const Text(
              '下方是夸克官方登录页。请用另一台设备上的夸克 App 扫描二维码并确认。',
              style: TextStyle(color: AppColors.textMuted, fontSize: 12),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: DecoratedBox(
                  decoration: const BoxDecoration(color: Colors.white),
                  child: _buildWebViewContent(),
                ),
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              '确认成功后窗口会自动关闭，登录凭据只保存在本机系统凭据库。',
              style: TextStyle(color: AppColors.textMuted, fontSize: 11),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('取消'),
        ),
        if (_error != null)
          FilledButton(
            onPressed: () {
              setState(() => _error = null);
              unawaited(_initialize());
            },
            child: const Text('重试'),
          ),
      ],
    );
  }

  Widget _buildWebViewContent() {
    final error = _error;
    if (error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            error,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.redAccent),
          ),
        ),
      );
    }
    final controller = _webView;
    return controller == null
        ? const Center(child: CircularProgressIndicator())
        : WebViewWidget(controller: controller);
  }
}
