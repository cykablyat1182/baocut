import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:webview_flutter_windows/webview_flutter_windows.dart';

import '../../core/theme/app_theme.dart';
import '../../data/managed_openlist_media_service.dart';
import '../../data/quark_share_service.dart';
import '../../domain/models/media_playlist_item.dart';
import '../player/account_dialog.dart';
import '../player/learning_player_controller.dart';
import '../player/player_dialogs.dart';
import '../player/widgets/desktop_window_bar.dart';
import 'apple_quark_login_dialog.dart';

enum _LibrarySection { all, recent, favorites }

const _quarkOfficialLoginChannel = MethodChannel('yingyu/quark_official_login');

class MediaLibraryScreen extends StatefulWidget {
  const MediaLibraryScreen({super.key, required this.controller});

  final LearningPlayerController controller;

  @override
  State<MediaLibraryScreen> createState() => _MediaLibraryScreenState();
}

class _MediaLibraryScreenState extends State<MediaLibraryScreen> {
  bool _opening = false;
  String _query = '';
  _LibrarySection _section = _LibrarySection.all;

  Future<void> _run(Future<void> Function() action) async {
    if (_opening) return;
    setState(() => _opening = true);
    try {
      await action();
    } finally {
      if (mounted) setState(() => _opening = false);
    }
  }

  Future<void> _confirmRemoveSource(String folder) async {
    final remove = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('移除媒体来源？'),
        content: Text('“${_fileName(folder)}”会从影语资料库中移除，本地文件不会被删除。'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('移除'),
          ),
        ],
      ),
    );
    if (remove == true) await widget.controller.removeLibraryFolder(folder);
  }

  void _openOnlineMovies() => widget.controller.showOnlineMovieLibrary();

  Future<void> _openCloudManager() =>
      _showCloudManager(context, widget.controller);

  Future<void> _openAccount() => showAccountDialog(context, widget.controller);

  Future<void> _openBilling() => showBillingDialog(context, widget.controller);

  void _selectSection(_LibrarySection section) {
    if (widget.controller.librarySurface != LibrarySurface.movies) {
      widget.controller.showMovieLibrary();
    }
    setState(() => _section = section);
  }

  Future<void> _openItem(MediaPlaylistItem item) => item.isOnline
      ? widget.controller.openOnlineStream(item)
      : widget.controller.openVideo(item.path);

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final compact = size.width < 920 || Platform.isAndroid || Platform.isIOS;
    final shortViewport = size.height < 520;
    final portraitViewport = size.width < 600 && size.height > size.width;
    final query = _query.trim().toLowerCase();
    final allItems = switch (_section) {
      _LibrarySection.all => widget.controller.movieLibraryItems,
      _LibrarySection.recent =>
        widget.controller.recentMediaItems
            .where((item) => !item.isLive)
            .toList(growable: false),
      _LibrarySection.favorites =>
        widget.controller.favoriteMediaItems
            .where((item) => !item.isLive)
            .toList(growable: false),
    };
    final visibleItems = query.isEmpty
        ? allItems
        : allItems
              .where((item) => item.title.toLowerCase().contains(query))
              .toList(growable: false);

    return Scaffold(
      body: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF101820), Color(0xFF080B0E), AppColors.canvas],
            stops: [0, 0.48, 1],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              const DesktopWindowBar(title: '影语 · 影视'),
              if (Platform.isAndroid || Platform.isIOS)
                _MobileLibraryNavigation(
                  section: _section,
                  onSectionChanged: _selectSection,
                  onOnlineMovies: _openOnlineMovies,
                  onCloud: _openCloudManager,
                  onAccount: _openAccount,
                  onBilling: _openBilling,
                  onSettings: () =>
                      showPlayerSettings(context, widget.controller),
                ),
              Expanded(
                child: Row(
                  children: [
                    if (!compact)
                      _LibrarySidebar(
                        controller: widget.controller,
                        onAddSource: () =>
                            _run(widget.controller.importMediaFolder),
                        onOnlineMovies: _openOnlineMovies,
                        onCloud: _openCloudManager,
                        section: _section,
                        onSectionChanged: (value) =>
                            setState(() => _section = value),
                        onRemoveSource: _confirmRemoveSource,
                        onSettings: () =>
                            showPlayerSettings(context, widget.controller),
                      ),
                    Expanded(
                      child: _LibraryContent(
                        controller: widget.controller,
                        compact: compact,
                        shortViewport: shortViewport,
                        portraitViewport: portraitViewport,
                        opening: _opening,
                        query: _query,
                        visibleItems: visibleItems,
                        section: _section,
                        onOpenItem: _openItem,
                        onQueryChanged: (value) =>
                            setState(() => _query = value),
                        onAddSource: () =>
                            _run(widget.controller.importMediaFolder),
                        onOpenFile: () =>
                            _run(widget.controller.openVideoPicker),
                        onOnlineMovies: _openOnlineMovies,
                        onCloud: _openCloudManager,
                        onRefresh: widget.controller.refreshLibrary,
                        onSettings: () =>
                            showPlayerSettings(context, widget.controller),
                        onRemoveSource: _confirmRemoveSource,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MobileLibraryNavigation extends StatelessWidget {
  const _MobileLibraryNavigation({
    required this.section,
    required this.onSectionChanged,
    required this.onOnlineMovies,
    required this.onCloud,
    required this.onAccount,
    required this.onBilling,
    required this.onSettings,
  });

  final _LibrarySection section;
  final ValueChanged<_LibrarySection> onSectionChanged;
  final VoidCallback onOnlineMovies;
  final VoidCallback onCloud;
  final VoidCallback onAccount;
  final VoidCallback onBilling;
  final VoidCallback onSettings;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 51,
      decoration: const BoxDecoration(
        color: Color(0xD90C1115),
        border: Border(bottom: BorderSide(color: AppColors.divider)),
      ),
      child: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        scrollDirection: Axis.horizontal,
        children: [
          _MobileSectionChip(
            icon: Icons.grid_view_rounded,
            label: '影视',
            selected: section == _LibrarySection.all,
            onTap: () => onSectionChanged(_LibrarySection.all),
          ),
          const SizedBox(width: 7),
          _MobileSectionChip(
            icon: Icons.history_rounded,
            label: '最近播放',
            selected: section == _LibrarySection.recent,
            onTap: () => onSectionChanged(_LibrarySection.recent),
          ),
          const SizedBox(width: 7),
          _MobileSectionChip(
            icon: Icons.favorite_outline_rounded,
            label: '收藏',
            selected: section == _LibrarySection.favorites,
            onTap: () => onSectionChanged(_LibrarySection.favorites),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 5),
            child: VerticalDivider(width: 1, indent: 5, endIndent: 5),
          ),
          _MobileActionChip(
            icon: Icons.movie_filter_outlined,
            label: '在线影视',
            onTap: onOnlineMovies,
          ),
          const SizedBox(width: 7),
          _MobileActionChip(
            icon: Icons.cloud_outlined,
            label: '网盘',
            onTap: onCloud,
          ),
          const SizedBox(width: 7),
          _MobileActionChip(
            icon: Icons.person_outline_rounded,
            label: '账户',
            onTap: onAccount,
          ),
          const SizedBox(width: 7),
          _MobileActionChip(
            icon: Icons.account_balance_wallet_outlined,
            label: '额度',
            onTap: onBilling,
          ),
          const SizedBox(width: 7),
          _MobileActionChip(
            icon: Icons.settings_outlined,
            label: '设置',
            onTap: onSettings,
          ),
        ],
      ),
    );
  }
}

class _MobileSectionChip extends StatelessWidget {
  const _MobileSectionChip({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => ChoiceChip(
    avatar: Icon(icon, size: 16),
    label: Text(label),
    selected: selected,
    onSelected: (_) => onTap(),
    visualDensity: VisualDensity.compact,
    padding: const EdgeInsets.symmetric(horizontal: 4),
  );
}

class _MobileActionChip extends StatelessWidget {
  const _MobileActionChip({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => ActionChip(
    avatar: Icon(icon, size: 16),
    label: Text(label),
    onPressed: onTap,
    visualDensity: VisualDensity.compact,
    padding: const EdgeInsets.symmetric(horizontal: 4),
  );
}

class _LibrarySidebar extends StatelessWidget {
  const _LibrarySidebar({
    required this.controller,
    required this.onAddSource,
    required this.onOnlineMovies,
    required this.onCloud,
    required this.section,
    required this.onSectionChanged,
    required this.onRemoveSource,
    required this.onSettings,
  });

  final LearningPlayerController controller;
  final VoidCallback onAddSource;
  final VoidCallback onOnlineMovies;
  final VoidCallback onCloud;
  final _LibrarySection section;
  final ValueChanged<_LibrarySection> onSectionChanged;
  final ValueChanged<String> onRemoveSource;
  final VoidCallback onSettings;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 252,
      decoration: const BoxDecoration(
        color: Color(0xB3090D11),
        border: Border(right: BorderSide(color: AppColors.divider)),
      ),
      padding: const EdgeInsets.fromLTRB(18, 22, 14, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _Brand(),
          const SizedBox(height: 34),
          _SidebarItem(
            icon: Icons.grid_view_rounded,
            label: '影视',
            selected: section == _LibrarySection.all,
            onTap: () => onSectionChanged(_LibrarySection.all),
          ),
          _SidebarItem(
            icon: Icons.history_rounded,
            label: '最近播放',
            selected: section == _LibrarySection.recent,
            onTap: () => onSectionChanged(_LibrarySection.recent),
          ),
          _SidebarItem(
            icon: Icons.favorite_outline_rounded,
            label: '收藏',
            selected: section == _LibrarySection.favorites,
            onTap: () => onSectionChanged(_LibrarySection.favorites),
          ),
          _SidebarItem(
            icon: Icons.movie_filter_outlined,
            label: '在线影视',
            onTap: onOnlineMovies,
          ),
          const SizedBox(height: 26),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              children: [
                const Text(
                  '已保存的来源',
                  style: TextStyle(
                    color: Color(0xFF777F87),
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.7,
                  ),
                ),
                const Spacer(),
                IconButton(
                  tooltip: '添加媒体来源',
                  visualDensity: VisualDensity.compact,
                  onPressed: onAddSource,
                  icon: const Icon(Icons.add_rounded, size: 19),
                ),
                IconButton(
                  tooltip: '连接网盘影视仓',
                  visualDensity: VisualDensity.compact,
                  onPressed: onCloud,
                  icon: const Icon(Icons.cloud_outlined, size: 19),
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Expanded(
            child: controller.libraryFolders.isEmpty
                ? const Padding(
                    padding: EdgeInsets.all(10),
                    child: Text(
                      '还没有连接文件夹',
                      style: TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 12,
                      ),
                    ),
                  )
                : ListView.builder(
                    itemCount: controller.libraryFolders.length,
                    itemBuilder: (context, index) {
                      final folder = controller.libraryFolders[index];
                      return _SourceTile(
                        folder: folder,
                        count: controller.libraryItemCount(folder),
                        onRemove: () => onRemoveSource(folder),
                      );
                    },
                  ),
          ),
          const Divider(),
          _SidebarItem(
            icon: Icons.settings_outlined,
            label: '设置',
            onTap: onSettings,
          ),
        ],
      ),
    );
  }
}

class _LibraryContent extends StatelessWidget {
  const _LibraryContent({
    required this.controller,
    required this.compact,
    required this.shortViewport,
    required this.portraitViewport,
    required this.opening,
    required this.query,
    required this.visibleItems,
    required this.section,
    required this.onOpenItem,
    required this.onQueryChanged,
    required this.onAddSource,
    required this.onOpenFile,
    required this.onOnlineMovies,
    required this.onCloud,
    required this.onRefresh,
    required this.onSettings,
    required this.onRemoveSource,
  });

  final LearningPlayerController controller;
  final bool compact;
  final bool shortViewport;
  final bool portraitViewport;
  final bool opening;
  final String query;
  final List<MediaPlaylistItem> visibleItems;
  final _LibrarySection section;
  final ValueChanged<MediaPlaylistItem> onOpenItem;
  final ValueChanged<String> onQueryChanged;
  final VoidCallback onAddSource;
  final VoidCallback onOpenFile;
  final VoidCallback onOnlineMovies;
  final VoidCallback onCloud;
  final Future<void> Function() onRefresh;
  final VoidCallback onSettings;
  final ValueChanged<String> onRemoveSource;

  @override
  Widget build(BuildContext context) {
    final continueWatching = controller.continueWatchingItems;
    return Padding(
      padding: EdgeInsets.fromLTRB(
        shortViewport
            ? 12
            : portraitViewport
            ? 14
            : compact
            ? 20
            : 38,
        shortViewport
            ? 8
            : portraitViewport
            ? 12
            : compact
            ? 16
            : 28,
        shortViewport
            ? 12
            : portraitViewport
            ? 14
            : compact
            ? 20
            : 38,
        0,
      ),
      child: Column(
        children: [
          _LibraryHeader(
            compact: compact,
            shortViewport: shortViewport,
            portraitViewport: portraitViewport,
            opening: opening,
            itemCount: controller.movieLibraryItems.length,
            sourceCount:
                controller.libraryFolders.length +
                controller.cloudSources.length,
            onQueryChanged: onQueryChanged,
            onAddSource: onAddSource,
            onOpenFile: onOpenFile,
            onOnlineMovies: onOnlineMovies,
            onCloud: onCloud,
            onRefresh: onRefresh,
            onSettings: onSettings,
          ),
          if (controller.lastError != null || controller.lastNotice != null)
            _StatusStrip(
              error: controller.lastError,
              notice: controller.lastNotice,
              onClose: controller.clearMessages,
            ),
          if (compact && !shortViewport && controller.libraryFolders.isNotEmpty)
            _CompactSources(
              controller: controller,
              onRemoveSource: onRemoveSource,
            ),
          SizedBox(height: shortViewport ? 8 : 18),
          Expanded(
            child:
                (controller.libraryLoading || controller.cloudMediaLoading) &&
                    controller.movieLibraryItems.isEmpty
                ? const Center(child: CircularProgressIndicator())
                : controller.movieLibraryItems.isEmpty
                ? _EmptyLibrary(
                    onAddSource: onAddSource,
                    onOpenFile: onOpenFile,
                    shortViewport: shortViewport,
                  )
                : RefreshIndicator(
                    onRefresh: onRefresh,
                    child: CustomScrollView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      slivers: [
                        if (section == _LibrarySection.all &&
                            query.trim().isEmpty &&
                            continueWatching.isNotEmpty) ...[
                          const SliverToBoxAdapter(
                            child: _SectionTitle(
                              title: '继续观看',
                              subtitle: '播放进度已自动保存',
                            ),
                          ),
                          SliverToBoxAdapter(
                            child: SizedBox(
                              height: shortViewport
                                  ? 126
                                  : compact
                                  ? 154
                                  : 184,
                              child: ListView.separated(
                                scrollDirection: Axis.horizontal,
                                itemCount: continueWatching.length,
                                separatorBuilder: (_, _) =>
                                    const SizedBox(width: 14),
                                itemBuilder: (context, index) => _ContinueCard(
                                  item: continueWatching[index],
                                  progress: controller.savedProgressFor(
                                    continueWatching[index].path,
                                  ),
                                  compact: compact,
                                  onTap: () =>
                                      onOpenItem(continueWatching[index]),
                                ),
                              ),
                            ),
                          ),
                          const SliverToBoxAdapter(child: SizedBox(height: 28)),
                        ],
                        SliverToBoxAdapter(
                          child: _SectionTitle(
                            title: query.trim().isNotEmpty
                                ? '搜索结果'
                                : switch (section) {
                                    _LibrarySection.all => '全部影视',
                                    _LibrarySection.recent => '最近播放',
                                    _LibrarySection.favorites => '我的收藏',
                                  },
                            subtitle: '${visibleItems.length} 个项目',
                          ),
                        ),
                        if (visibleItems.isEmpty)
                          const SliverFillRemaining(
                            hasScrollBody: false,
                            child: Center(
                              child: Text(
                                '没有找到匹配的影片',
                                style: TextStyle(color: AppColors.textMuted),
                              ),
                            ),
                          )
                        else
                          SliverPadding(
                            padding: const EdgeInsets.only(bottom: 30),
                            sliver: SliverGrid.builder(
                              gridDelegate:
                                  SliverGridDelegateWithMaxCrossAxisExtent(
                                    maxCrossAxisExtent: shortViewport
                                        ? 148
                                        : compact
                                        ? 168
                                        : 205,
                                    mainAxisExtent: shortViewport
                                        ? 188
                                        : compact
                                        ? 228
                                        : 276,
                                    crossAxisSpacing: compact ? 12 : 18,
                                    mainAxisSpacing: compact ? 16 : 22,
                                  ),
                              itemCount: visibleItems.length,
                              itemBuilder: (context, index) {
                                final item = visibleItems[index];
                                return _MediaCard(
                                  item: item,
                                  progress: controller.savedProgressFor(
                                    item.path,
                                  ),
                                  favorite: controller.isFavorite(item.path),
                                  onFavorite: () =>
                                      controller.toggleFavorite(item),
                                  onDownload: item.isOnline && !item.isLive
                                      ? () =>
                                            controller.downloadRemoteMedia(item)
                                      : null,
                                  onTap: () => onOpenItem(item),
                                );
                              },
                            ),
                          ),
                      ],
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _LibraryHeader extends StatelessWidget {
  const _LibraryHeader({
    required this.compact,
    required this.shortViewport,
    required this.portraitViewport,
    required this.opening,
    required this.itemCount,
    required this.sourceCount,
    required this.onQueryChanged,
    required this.onAddSource,
    required this.onOpenFile,
    required this.onOnlineMovies,
    required this.onCloud,
    required this.onRefresh,
    required this.onSettings,
  });

  final bool compact;
  final bool shortViewport;
  final bool portraitViewport;
  final bool opening;
  final int itemCount;
  final int sourceCount;
  final ValueChanged<String> onQueryChanged;
  final VoidCallback onAddSource;
  final VoidCallback onOpenFile;
  final VoidCallback onOnlineMovies;
  final VoidCallback onCloud;
  final VoidCallback onRefresh;
  final VoidCallback onSettings;

  @override
  Widget build(BuildContext context) {
    if (compact && portraitViewport) {
      return Column(
        children: [
          Row(
            children: [
              const _Brand(compact: true),
              const SizedBox(width: 9),
              const Expanded(
                child: Text(
                  '资料库',
                  style: TextStyle(
                    color: AppColors.ivory,
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              IconButton(
                tooltip: '打开视频',
                visualDensity: VisualDensity.compact,
                onPressed: opening ? null : onOpenFile,
                icon: const Icon(Icons.play_arrow_rounded),
              ),
              IconButton(
                tooltip: '添加文件夹',
                visualDensity: VisualDensity.compact,
                onPressed: opening ? null : onAddSource,
                icon: const Icon(Icons.create_new_folder_outlined),
              ),
              IconButton(
                tooltip: '在线影视',
                visualDensity: VisualDensity.compact,
                onPressed: onOnlineMovies,
                icon: const Icon(Icons.movie_filter_outlined),
              ),
              IconButton(
                tooltip: '连接网盘影视仓',
                visualDensity: VisualDensity.compact,
                onPressed: onCloud,
                icon: const Icon(Icons.cloud_outlined),
              ),
              IconButton(
                tooltip: '设置',
                visualDensity: VisualDensity.compact,
                onPressed: onSettings,
                icon: const Icon(Icons.settings_outlined),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 40,
                  child: TextField(
                    onChanged: onQueryChanged,
                    decoration: InputDecoration(
                      hintText: '搜索资料库',
                      prefixIcon: const Icon(Icons.search_rounded, size: 19),
                      filled: true,
                      fillColor: const Color(0xA6151A1F),
                      contentPadding: EdgeInsets.zero,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(11),
                        borderSide: const BorderSide(color: AppColors.divider),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(11),
                        borderSide: const BorderSide(color: AppColors.divider),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 7),
              IconButton(
                tooltip: '刷新资料库',
                onPressed: opening ? null : onRefresh,
                icon: const Icon(Icons.refresh_rounded),
              ),
            ],
          ),
        ],
      );
    }
    if (compact && shortViewport) {
      return Row(
        children: [
          const _Brand(compact: true),
          const SizedBox(width: 8),
          const Text(
            '资料库',
            style: TextStyle(
              color: AppColors.ivory,
              fontSize: 19,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: SizedBox(
              height: 36,
              child: TextField(
                onChanged: onQueryChanged,
                decoration: InputDecoration(
                  hintText: '搜索',
                  prefixIcon: const Icon(Icons.search_rounded, size: 18),
                  filled: true,
                  fillColor: const Color(0xA6151A1F),
                  contentPadding: EdgeInsets.zero,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: AppColors.divider),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: AppColors.divider),
                  ),
                ),
              ),
            ),
          ),
          IconButton(
            tooltip: '打开视频',
            visualDensity: VisualDensity.compact,
            onPressed: opening ? null : onOpenFile,
            icon: const Icon(Icons.play_arrow_rounded),
          ),
          IconButton(
            tooltip: '添加文件夹',
            visualDensity: VisualDensity.compact,
            onPressed: opening ? null : onAddSource,
            icon: const Icon(Icons.create_new_folder_outlined),
          ),
          IconButton(
            tooltip: '在线影视',
            visualDensity: VisualDensity.compact,
            onPressed: onOnlineMovies,
            icon: const Icon(Icons.movie_filter_outlined),
          ),
          IconButton(
            tooltip: '连接网盘影视仓',
            visualDensity: VisualDensity.compact,
            onPressed: onCloud,
            icon: const Icon(Icons.cloud_outlined),
          ),
          IconButton(
            tooltip: '设置',
            visualDensity: VisualDensity.compact,
            onPressed: onSettings,
            icon: const Icon(Icons.settings_outlined),
          ),
        ],
      );
    }
    return Row(
      children: [
        if (compact) ...[
          const _Brand(compact: true),
          const SizedBox(width: 18),
        ],
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                compact ? '资料库' : '媒体资料库',
                style: TextStyle(
                  color: AppColors.ivory,
                  fontSize: compact ? 24 : 31,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.6,
                ),
              ),
              if (!compact)
                Text(
                  '$sourceCount 个已保存来源 · $itemCount 个媒体文件',
                  style: const TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 12,
                  ),
                ),
            ],
          ),
        ),
        SizedBox(
          width: compact ? 210 : 270,
          height: 40,
          child: TextField(
            onChanged: onQueryChanged,
            decoration: InputDecoration(
              hintText: '搜索资料库',
              prefixIcon: const Icon(Icons.search_rounded, size: 19),
              filled: true,
              fillColor: const Color(0xA6151A1F),
              contentPadding: EdgeInsets.zero,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(11),
                borderSide: const BorderSide(color: AppColors.divider),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(11),
                borderSide: const BorderSide(color: AppColors.divider),
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        IconButton(
          tooltip: '刷新资料库',
          onPressed: opening ? null : onRefresh,
          icon: const Icon(Icons.refresh_rounded),
        ),
        OutlinedButton.icon(
          onPressed: onOnlineMovies,
          icon: const Icon(Icons.movie_filter_outlined, size: 18),
          label: Text(compact ? '在线' : '在线影视'),
        ),
        const SizedBox(width: 8),
        if (!compact) ...[
          OutlinedButton.icon(
            onPressed: onCloud,
            icon: const Icon(Icons.cloud_outlined, size: 18),
            label: const Text('网盘'),
          ),
          const SizedBox(width: 8),
        ],
        if (!compact)
          OutlinedButton.icon(
            onPressed: opening ? null : onOpenFile,
            icon: const Icon(Icons.play_arrow_rounded, size: 18),
            label: const Text('打开文件'),
          ),
        const SizedBox(width: 8),
        FilledButton.icon(
          onPressed: opening ? null : onAddSource,
          icon: const Icon(Icons.add_rounded, size: 19),
          label: Text(compact ? '添加' : '添加文件夹'),
        ),
        if (compact)
          IconButton(
            tooltip: '设置',
            onPressed: onSettings,
            icon: const Icon(Icons.settings_outlined),
          ),
      ],
    );
  }
}

class _Brand extends StatelessWidget {
  const _Brand({this.compact = false});

  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: compact ? 34 : 40,
          height: compact ? 34 : 40,
          decoration: BoxDecoration(
            color: AppColors.amber.withValues(alpha: 0.14),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.amber.withValues(alpha: 0.4)),
          ),
          child: const Icon(Icons.play_arrow_rounded, color: AppColors.amber),
        ),
        const SizedBox(width: 11),
        if (!compact)
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '影语',
                style: TextStyle(
                  color: AppColors.ivory,
                  fontSize: 19,
                  fontWeight: FontWeight.w800,
                ),
              ),
              Text(
                'YINGYU LIBRARY',
                style: TextStyle(
                  color: Color(0xFF777F87),
                  fontSize: 8.5,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
      ],
    );
  }
}

class _SidebarItem extends StatelessWidget {
  const _SidebarItem({
    required this.icon,
    required this.label,
    this.selected = false,
    this.onTap,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 5),
      child: ListTile(
        dense: true,
        selected: selected,
        selectedTileColor: AppColors.amber.withValues(alpha: 0.12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        leading: Icon(icon, size: 20, color: selected ? AppColors.amber : null),
        title: Text(
          label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
        onTap: onTap,
      ),
    );
  }
}

class _SourceTile extends StatelessWidget {
  const _SourceTile({
    required this.folder,
    required this.count,
    required this.onRemove,
  });

  final String folder;
  final int count;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      dense: true,
      minLeadingWidth: 26,
      contentPadding: const EdgeInsets.only(left: 9, right: 0),
      leading: const Icon(
        Icons.folder_rounded,
        color: Color(0xFFD6A64D),
        size: 20,
      ),
      title: Text(
        _fileName(folder),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontSize: 12.5),
      ),
      subtitle: Text(
        '$count 个项目 · 已保存',
        style: const TextStyle(color: AppColors.textMuted, fontSize: 10),
      ),
      trailing: PopupMenuButton<String>(
        tooltip: '管理来源',
        iconSize: 18,
        onSelected: (_) => onRemove(),
        itemBuilder: (_) => const [
          PopupMenuItem(value: 'remove', child: Text('移除来源')),
        ],
      ),
    );
  }
}

class _CompactSources extends StatelessWidget {
  const _CompactSources({
    required this.controller,
    required this.onRemoveSource,
  });

  final LearningPlayerController controller;
  final ValueChanged<String> onRemoveSource;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 42,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: controller.libraryFolders.length,
        separatorBuilder: (_, _) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final folder = controller.libraryFolders[index];
          return InputChip(
            avatar: const Icon(Icons.folder_rounded, size: 17),
            label: Text(
              '${_fileName(folder)} · ${controller.libraryItemCount(folder)}',
            ),
            onDeleted: () => onRemoveSource(folder),
          );
        },
      ),
    );
  }
}

class _StatusStrip extends StatelessWidget {
  const _StatusStrip({this.error, this.notice, required this.onClose});

  final String? error;
  final String? notice;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    final isError = error != null;
    return Container(
      margin: const EdgeInsets.only(top: 14),
      padding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
      decoration: BoxDecoration(
        color: (isError ? AppColors.danger : AppColors.success).withValues(
          alpha: 0.1,
        ),
        borderRadius: BorderRadius.circular(9),
        border: Border.all(
          color: (isError ? AppColors.danger : AppColors.success).withValues(
            alpha: 0.28,
          ),
        ),
      ),
      child: Row(
        children: [
          Icon(
            isError
                ? Icons.error_outline_rounded
                : Icons.check_circle_outline_rounded,
            color: isError ? AppColors.danger : AppColors.success,
            size: 18,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              error ?? notice ?? '',
              style: const TextStyle(fontSize: 12),
            ),
          ),
          IconButton(
            onPressed: onClose,
            icon: const Icon(Icons.close_rounded, size: 18),
          ),
        ],
      ),
    );
  }
}

class _EmptyLibrary extends StatelessWidget {
  const _EmptyLibrary({
    required this.onAddSource,
    required this.onOpenFile,
    required this.shortViewport,
  });

  final VoidCallback onAddSource;
  final VoidCallback onOpenFile;
  final bool shortViewport;

  @override
  Widget build(BuildContext context) {
    if (shortViewport) {
      return SingleChildScrollView(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 700),
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: const Color(0xB212171C),
                borderRadius: BorderRadius.circular(17),
                border: Border.all(color: AppColors.divider),
              ),
              child: Row(
                children: [
                  Container(
                    width: 54,
                    height: 54,
                    decoration: BoxDecoration(
                      color: AppColors.amber.withValues(alpha: 0.12),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.video_library_rounded,
                      color: AppColors.amber,
                      size: 27,
                    ),
                  ),
                  const SizedBox(width: 18),
                  const Expanded(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '建立媒体资料库',
                          style: TextStyle(
                            color: AppColors.ivory,
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        SizedBox(height: 5),
                        Text(
                          '连接文件夹后自动扫描影片和子文件夹。',
                          style: TextStyle(
                            color: AppColors.textMuted,
                            fontSize: 11.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  FilledButton.icon(
                    onPressed: onAddSource,
                    icon: const Icon(Icons.add_rounded, size: 18),
                    label: const Text('添加文件夹'),
                  ),
                  const SizedBox(width: 8),
                  OutlinedButton(
                    onPressed: onOpenFile,
                    child: const Text('打开视频'),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 650),
        child: Container(
          padding: const EdgeInsets.all(38),
          decoration: BoxDecoration(
            color: const Color(0xB212171C),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: AppColors.divider),
            boxShadow: const [
              BoxShadow(
                color: Color(0x66000000),
                blurRadius: 34,
                offset: Offset(0, 18),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 76,
                height: 76,
                decoration: BoxDecoration(
                  color: AppColors.amber.withValues(alpha: 0.12),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.video_library_rounded,
                  color: AppColors.amber,
                  size: 34,
                ),
              ),
              const SizedBox(height: 22),
              const Text(
                '建立你的媒体资料库',
                style: TextStyle(
                  color: AppColors.ivory,
                  fontSize: 25,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                '连接一个影视文件夹，影语会扫描其中的影片和子文件夹。\n来源、最近播放和观看进度都会保存在本机。',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: AppColors.textMuted,
                  fontSize: 13,
                  height: 1.55,
                ),
              ),
              const SizedBox(height: 24),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                alignment: WrapAlignment.center,
                children: [
                  FilledButton.icon(
                    onPressed: onAddSource,
                    icon: const Icon(Icons.add_rounded),
                    label: const Text('添加媒体文件夹'),
                  ),
                  OutlinedButton.icon(
                    onPressed: onOpenFile,
                    icon: const Icon(Icons.play_arrow_rounded),
                    label: const Text('打开单个视频'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title, required this.subtitle});

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: AppColors.ivory,
              fontSize: 19,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(width: 10),
          Text(
            subtitle,
            style: const TextStyle(color: AppColors.textMuted, fontSize: 11),
          ),
        ],
      ),
    );
  }
}

class _ContinueCard extends StatelessWidget {
  const _ContinueCard({
    required this.item,
    required this.progress,
    required this.compact,
    required this.onTap,
  });

  final MediaPlaylistItem item;
  final double progress;
  final bool compact;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: compact ? 245 : 300,
      child: Material(
        color: const Color(0xFF141A20),
        borderRadius: BorderRadius.circular(15),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Stack(
            fit: StackFit.expand,
            children: [
              _CoverBackground(
                seed: item.path.hashCode,
                imagePath: item.coverPath,
                wide: true,
              ),
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Color(0xE8080B0E)],
                  ),
                ),
              ),
              Positioned(
                left: 14,
                right: 14,
                bottom: 16,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _cleanTitle(item.title),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppColors.ivory,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 8),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(99),
                      child: LinearProgressIndicator(
                        value: progress,
                        minHeight: 3,
                        backgroundColor: const Color(0x44FFFFFF),
                        color: AppColors.amber,
                      ),
                    ),
                  ],
                ),
              ),
              const Positioned(
                top: 12,
                right: 12,
                child: CircleAvatar(
                  radius: 17,
                  backgroundColor: Color(0xB3000000),
                  child: Icon(
                    Icons.play_arrow_rounded,
                    color: Colors.white,
                    size: 22,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MediaCard extends StatelessWidget {
  const _MediaCard({
    required this.item,
    required this.progress,
    required this.onTap,
    required this.favorite,
    required this.onFavorite,
    this.onDownload,
  });

  final MediaPlaylistItem item;
  final double progress;
  final VoidCallback onTap;
  final bool favorite;
  final VoidCallback onFavorite;
  final VoidCallback? onDownload;

  @override
  Widget build(BuildContext context) {
    final extension = item.title.contains('.')
        ? item.title.split('.').last.toUpperCase()
        : 'VIDEO';
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.divider),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x66000000),
                      blurRadius: 16,
                      offset: Offset(0, 8),
                    ),
                  ],
                ),
                clipBehavior: Clip.antiAlias,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    _CoverBackground(
                      seed: item.path.hashCode,
                      imagePath: item.coverPath,
                    ),
                    const DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.transparent, Color(0xBB050607)],
                          stops: [0.45, 1],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 10,
                      top: 10,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 7,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xB8000000),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          extension,
                          style: const TextStyle(
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      right: 7,
                      top: 7,
                      child: IconButton.filledTonal(
                        tooltip: favorite ? '取消收藏' : '收藏',
                        visualDensity: VisualDensity.compact,
                        onPressed: onFavorite,
                        icon: Icon(
                          favorite
                              ? Icons.favorite_rounded
                              : Icons.favorite_border_rounded,
                          size: 17,
                          color: favorite ? AppColors.amber : null,
                        ),
                      ),
                    ),
                    if (item.cloudSourceId != null)
                      Positioned(
                        left: 10,
                        bottom: progress > 0 ? 8 : 5,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 7,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xCC101820),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: const Text(
                            '网盘',
                            style: TextStyle(fontSize: 9),
                          ),
                        ),
                      ),
                    if (onDownload != null)
                      Positioned(
                        right: 7,
                        bottom: progress > 0 ? 8 : 5,
                        child: IconButton.filledTonal(
                          tooltip: '下载到本机',
                          visualDensity: VisualDensity.compact,
                          onPressed: onDownload,
                          icon: const Icon(Icons.download_rounded, size: 17),
                        ),
                      ),
                    if (progress > 0)
                      Positioned(
                        left: 0,
                        right: 0,
                        bottom: 0,
                        child: LinearProgressIndicator(
                          value: progress,
                          minHeight: 3,
                          backgroundColor: const Color(0x33FFFFFF),
                          color: AppColors.amber,
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              _cleanTitle(item.title),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: AppColors.ivory,
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
                height: 1.25,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CoverBackground extends StatelessWidget {
  const _CoverBackground({
    required this.seed,
    required this.imagePath,
    this.wide = false,
  });

  final int seed;
  final String? imagePath;
  final bool wide;

  static const palettes = [
    [Color(0xFF2C4553), Color(0xFF10171C)],
    [Color(0xFF534330), Color(0xFF17120C)],
    [Color(0xFF3E3756), Color(0xFF121019)],
    [Color(0xFF284D45), Color(0xFF0B1714)],
    [Color(0xFF56363D), Color(0xFF1A0F12)],
  ];

  @override
  Widget build(BuildContext context) {
    final colors = palettes[seed.abs() % palettes.length];
    return Stack(
      fit: StackFit.expand,
      children: [
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: colors,
            ),
          ),
          child: Stack(
            children: [
              Positioned(
                right: wide ? -25 : -42,
                top: wide ? -36 : 18,
                child: Icon(
                  Icons.movie_filter_rounded,
                  size: wide ? 142 : 156,
                  color: Colors.white.withValues(alpha: 0.065),
                ),
              ),
              Center(
                child: Icon(
                  Icons.play_circle_outline_rounded,
                  size: wide ? 42 : 48,
                  color: Colors.white.withValues(alpha: 0.34),
                ),
              ),
            ],
          ),
        ),
        if (imagePath case final path?)
          Image.file(
            File(path),
            fit: BoxFit.cover,
            filterQuality: FilterQuality.medium,
            gaplessPlayback: true,
            errorBuilder: (_, _, _) => const SizedBox.shrink(),
          ),
      ],
    );
  }
}

Future<void> _showCloudManager(
  BuildContext context,
  LearningPlayerController controller,
) async {
  if (Platform.isAndroid || Platform.isIOS) {
    await _showDirectQuarkManager(context, controller);
    return;
  }
  final nameController = TextEditingController();
  final urlController = TextEditingController();
  final tokenController = TextEditingController();
  final pathController = TextEditingController(text: '/');
  final transferCredentialController = TextEditingController();
  final transferFolderController = TextEditingController(text: '0');
  var provider = 'quark';
  final screenSize = MediaQuery.sizeOf(context);
  final compact = screenSize.width < 600;
  await showDialog<void>(
    context: context,
    builder: (context) => StatefulBuilder(
      builder: (context, setDialogState) => AlertDialog(
        insetPadding: EdgeInsets.symmetric(
          horizontal: compact ? 10 : 40,
          vertical: compact ? 12 : 24,
        ),
        title: const Text('网盘影视仓'),
        content: SizedBox(
          width: compact ? double.infinity : 650,
          height: (screenSize.height - (compact ? 120 : 180)).clamp(
            compact ? 300.0 : 360.0,
            compact ? 560.0 : 650.0,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '通过你自己的 OpenList 连接夸克、阿里、百度、115、WebDAV 等网盘。API Token 仅保存到系统凭据库。',
                style: TextStyle(color: AppColors.textMuted, fontSize: 12),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: controller.cloudSources.isEmpty
                    ? const Center(
                        child: Text(
                          '还没有网盘影视仓',
                          style: TextStyle(color: AppColors.textMuted),
                        ),
                      )
                    : ListView.separated(
                        itemCount: controller.cloudSources.length,
                        separatorBuilder: (_, _) => const Divider(height: 1),
                        itemBuilder: (context, index) {
                          final source = controller.cloudSources[index];
                          return ListTile(
                            leading: const Icon(
                              Icons.cloud_done_outlined,
                              color: AppColors.amber,
                            ),
                            title: Text(source.name),
                            subtitle: Text(
                              '${source.providerLabel} · ${source.rootPath}',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (source.provider == 'quark' ||
                                    source.isDirectQuark)
                                  IconButton(
                                    tooltip: '重新扫码登录夸克',
                                    onPressed: () async {
                                      final cookie =
                                          await _showQuarkQrLoginDialog(
                                            context,
                                            controller,
                                          );
                                      if (cookie != null) {
                                        await controller.updateQuarkLogin(
                                          source,
                                          cookie,
                                        );
                                        setDialogState(() {});
                                      }
                                    },
                                    icon: const Icon(Icons.qr_code_rounded),
                                  ),
                                IconButton(
                                  tooltip: '移除',
                                  onPressed: () async {
                                    await controller.removeCloudSource(source);
                                    setDialogState(() {});
                                  },
                                  icon: const Icon(
                                    Icons.delete_outline_rounded,
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
              ),
              const Divider(),
              if (compact) ...[
                DropdownButtonFormField<String>(
                  initialValue: provider,
                  decoration: const InputDecoration(labelText: '网盘类型'),
                  items: const [
                    DropdownMenuItem(value: 'quark', child: Text('夸克网盘')),
                    DropdownMenuItem(value: 'aliyun', child: Text('阿里云盘')),
                    DropdownMenuItem(value: 'baidu', child: Text('百度网盘')),
                    DropdownMenuItem(value: '115', child: Text('115 网盘')),
                    DropdownMenuItem(
                      value: 'webdav',
                      child: Text('其他 / WebDAV'),
                    ),
                  ],
                  onChanged: (value) =>
                      setDialogState(() => provider = value ?? 'openlist'),
                ),
                const SizedBox(height: 9),
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(labelText: '影视仓名称'),
                ),
              ] else
                Row(
                  children: [
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        initialValue: provider,
                        decoration: const InputDecoration(labelText: '网盘类型'),
                        items: const [
                          DropdownMenuItem(value: 'quark', child: Text('夸克网盘')),
                          DropdownMenuItem(
                            value: 'aliyun',
                            child: Text('阿里云盘'),
                          ),
                          DropdownMenuItem(value: 'baidu', child: Text('百度网盘')),
                          DropdownMenuItem(value: '115', child: Text('115 网盘')),
                          DropdownMenuItem(
                            value: 'webdav',
                            child: Text('其他 / WebDAV'),
                          ),
                        ],
                        onChanged: (value) => setDialogState(
                          () => provider = value ?? 'openlist',
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: nameController,
                        decoration: const InputDecoration(labelText: '影视仓名称'),
                      ),
                    ),
                  ],
                ),
              const SizedBox(height: 9),
              TextField(
                controller: urlController,
                decoration: const InputDecoration(
                  labelText: 'OpenList 地址',
                  hintText: 'https://你的域名',
                ),
              ),
              const SizedBox(height: 9),
              if (compact) ...[
                TextField(
                  controller: tokenController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'OpenList API Token',
                  ),
                ),
                const SizedBox(height: 9),
                TextField(
                  controller: pathController,
                  decoration: const InputDecoration(
                    labelText: '影视根目录',
                    hintText: '/',
                  ),
                ),
              ] else
                Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: TextField(
                        controller: tokenController,
                        obscureText: true,
                        decoration: const InputDecoration(
                          labelText: 'OpenList API Token',
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: pathController,
                        decoration: const InputDecoration(
                          labelText: '影视根目录',
                          hintText: '/',
                        ),
                      ),
                    ),
                  ],
                ),
              if (provider == 'quark') ...[
                const SizedBox(height: 9),
                const Text(
                  '转存功能用于玩偶等 4K 夸克分享线路。扫码凭据仅保存在系统凭据库中，不会写入普通设置。',
                  style: TextStyle(color: AppColors.textMuted, fontSize: 11),
                ),
                const SizedBox(height: 7),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      final cookie = await _showQuarkQrLoginDialog(
                        context,
                        controller,
                      );
                      if (cookie != null) {
                        transferCredentialController.text = cookie;
                        setDialogState(() {});
                      }
                    },
                    icon: const Icon(Icons.qr_code_scanner_rounded),
                    label: Text(
                      transferCredentialController.text.trim().isEmpty
                          ? '扫码登录夸克（推荐）'
                          : '夸克已登录 · 重新扫码',
                    ),
                  ),
                ),
                const SizedBox(height: 7),
                if (compact) ...[
                  TextField(
                    controller: transferCredentialController,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: '夸克转存 Cookie（扫码后自动填充）',
                      hintText: '__uid=...; __kps=...; ...',
                    ),
                  ),
                  const SizedBox(height: 9),
                  TextField(
                    controller: transferFolderController,
                    decoration: const InputDecoration(
                      labelText: '转存目录 fid',
                      hintText: '0',
                    ),
                  ),
                ] else
                  Row(
                    children: [
                      Expanded(
                        flex: 2,
                        child: TextField(
                          controller: transferCredentialController,
                          obscureText: true,
                          decoration: const InputDecoration(
                            labelText: '夸克转存 Cookie（扫码后自动填充）',
                            hintText: '__uid=...; __kps=...; ...',
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextField(
                          controller: transferFolderController,
                          decoration: const InputDecoration(
                            labelText: '转存目录 fid',
                            hintText: '0',
                          ),
                        ),
                      ),
                    ],
                  ),
              ],
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: controller.cloudMediaLoading
                ? null
                : () async {
                    await controller.refreshCloudMedia();
                    setDialogState(() {});
                  },
            child: const Text('同步全部'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('关闭'),
          ),
          FilledButton(
            onPressed: () async {
              await controller.addCloudSource(
                name: nameController.text,
                baseUrl: urlController.text,
                apiToken: tokenController.text,
                rootPath: pathController.text,
                provider: provider,
                transferCredential: transferCredentialController.text,
                transferFolderId: transferFolderController.text,
              );
              if (controller.lastError == null && context.mounted) {
                Navigator.pop(context);
              } else {
                setDialogState(() {});
              }
            },
            child: const Text('连接并扫描'),
          ),
        ],
      ),
    ),
  );
  nameController.dispose();
  urlController.dispose();
  tokenController.dispose();
  pathController.dispose();
  transferCredentialController.dispose();
  transferFolderController.dispose();
}

Future<void> _showDirectQuarkManager(
  BuildContext context,
  LearningPlayerController controller,
) async {
  await showDialog<void>(
    context: context,
    builder: (context) => StatefulBuilder(
      builder: (context, setDialogState) {
        final sources = controller.cloudSources
            .where((source) => source.isDirectQuark)
            .toList(growable: false);
        final compact = MediaQuery.sizeOf(context).width < 600;
        return AlertDialog(
          insetPadding: EdgeInsets.symmetric(
            horizontal: compact ? 10 : 40,
            vertical: compact ? 12 : 24,
          ),
          title: const Text('夸克网盘'),
          content: SizedBox(
            width: compact ? double.infinity : 560,
            height: (MediaQuery.sizeOf(context).height - (compact ? 150 : 220))
                .clamp(compact ? 250.0 : 300.0, compact ? 500.0 : 560.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '手机端只需扫码登录夸克，影视目录、播放与字幕会自动使用统一的云端加速线路，无需填写其他服务器配置。',
                  style: TextStyle(color: AppColors.textMuted, fontSize: 12),
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: sources.isEmpty
                      ? const Center(
                          child: Text(
                            '尚未连接夸克网盘',
                            style: TextStyle(color: AppColors.textMuted),
                          ),
                        )
                      : ListView.separated(
                          itemCount: sources.length,
                          separatorBuilder: (_, _) => const Divider(height: 1),
                          itemBuilder: (context, index) {
                            final source = sources[index];
                            return ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: const Icon(
                                Icons.cloud_done_outlined,
                                color: AppColors.amber,
                              ),
                              title: Text(source.name),
                              subtitle: Text(
                                controller.cloudMediaLoading
                                    ? '正在同步网盘影视…'
                                    : '已连接 · ${controller.cloudMediaItems.where((item) => item.cloudSourceId == ManagedOpenListMediaService.sourceId).length} 个影视文件',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              trailing: Wrap(
                                spacing: 2,
                                children: [
                                  IconButton(
                                    tooltip: '重新扫码',
                                    onPressed: controller.cloudMediaLoading
                                        ? null
                                        : () async {
                                            final cookie =
                                                await _showQuarkQrLoginDialog(
                                                  context,
                                                  controller,
                                                );
                                            if (cookie == null ||
                                                !context.mounted) {
                                              return;
                                            }
                                            await controller.updateQuarkLogin(
                                              source,
                                              cookie,
                                            );
                                            if (context.mounted) {
                                              setDialogState(() {});
                                            }
                                          },
                                    icon: const Icon(Icons.qr_code_rounded),
                                  ),
                                  IconButton(
                                    tooltip: '移除夸克连接',
                                    onPressed: controller.cloudMediaLoading
                                        ? null
                                        : () async {
                                            await controller.removeCloudSource(
                                              source,
                                            );
                                            if (context.mounted) {
                                              setDialogState(() {});
                                            }
                                          },
                                    icon: const Icon(
                                      Icons.delete_outline_rounded,
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                ),
                if (controller.lastError != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    controller.lastError!,
                    style: const TextStyle(
                      color: AppColors.danger,
                      fontSize: 12,
                    ),
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: controller.cloudMediaLoading
                  ? null
                  : () async {
                      await controller.refreshCloudMedia();
                      if (context.mounted) setDialogState(() {});
                    },
              child: const Text('同步网盘'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('关闭'),
            ),
            FilledButton.icon(
              onPressed: controller.cloudMediaLoading
                  ? null
                  : () async {
                      final cookie = await _showQuarkQrLoginDialog(
                        context,
                        controller,
                      );
                      if (cookie == null || !context.mounted) return;
                      await controller.addDirectQuarkSource(cookie);
                      if (context.mounted) setDialogState(() {});
                    },
              icon: const Icon(Icons.qr_code_scanner_rounded),
              label: Text(sources.isEmpty ? '扫码连接夸克' : '重新扫码'),
            ),
          ],
        );
      },
    ),
  );
}

Future<String?> _showQuarkQrLoginDialog(
  BuildContext context,
  LearningPlayerController controller,
) {
  if (Platform.isWindows) {
    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _QuarkOfficialLoginDialog(),
    );
  }
  if (Platform.isIOS) {
    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const AppleQuarkLoginDialog(),
    );
  }
  if (Platform.isAndroid) {
    return _showAndroidQuarkOfficialLogin(context);
  }
  return showDialog<String>(
    context: context,
    barrierDismissible: false,
    builder: (_) => _QuarkQrLoginDialog(controller: controller),
  );
}

Future<String?> _showAndroidQuarkOfficialLogin(BuildContext context) async {
  try {
    final cookie = await _quarkOfficialLoginChannel.invokeMethod<String>(
      'openOfficialLogin',
    );
    final normalized = cookie?.trim() ?? '';
    return normalized.isEmpty ? null : normalized;
  } on PlatformException catch (error) {
    if (context.mounted) {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('无法打开夸克官方登录页'),
          content: Text(
            error.message?.trim().isNotEmpty == true
                ? error.message!
                : '请确认手机已安装系统 WebView 后重试。',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('知道了'),
            ),
          ],
        ),
      );
    }
    return null;
  } on MissingPluginException {
    if (context.mounted) {
      ScaffoldMessenger.maybeOf(context)?.showSnackBar(
        const SnackBar(content: Text('当前 APK 不包含官方登录页，请安装最新版本。')),
      );
    }
    return null;
  }
}

class _QuarkOfficialLoginDialog extends StatefulWidget {
  const _QuarkOfficialLoginDialog();

  @override
  State<_QuarkOfficialLoginDialog> createState() =>
      _QuarkOfficialLoginDialogState();
}

class _QuarkOfficialLoginDialogState extends State<_QuarkOfficialLoginDialog> {
  final WebviewController _webview = WebviewController();
  Timer? _cookieTimer;
  bool _ready = false;
  bool _checking = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      await _webview.initialize();
      await _webview.clearCookies();
      await _webview.setPopupWindowPolicy(WebviewPopupWindowPolicy.deny);
      await _webview.setDefaultContextMenusEnabled(false);
      await _webview.loadUrl('https://pan.quark.cn/');
      if (!mounted) return;
      setState(() => _ready = true);
      _cookieTimer = Timer.periodic(
        const Duration(milliseconds: 1500),
        (_) => _captureLogin(),
      );
    } on Object catch (error) {
      if (!mounted) return;
      setState(() => _error = '无法打开夸克官方登录页：$error');
    }
  }

  Future<void> _captureLogin() async {
    if (_checking || !mounted) return;
    _checking = true;
    try {
      final allCookies = await _webview.getCookies();
      final quarkCookies = allCookies
          .where(
            (cookie) =>
                cookie.domain.toLowerCase().contains('quark.cn') &&
                cookie.name.trim().isNotEmpty &&
                cookie.value.isNotEmpty,
          )
          .toList();
      final names = quarkCookies.map((cookie) => cookie.name).toSet();
      if (!names.contains('__kps') && !names.contains('__pus')) return;
      final cookie = quarkCookies
          .map((item) => '${item.name}=${item.value}')
          .join('; ');
      _cookieTimer?.cancel();
      if (mounted) Navigator.pop(context, cookie);
    } on Object catch (error) {
      _cookieTimer?.cancel();
      if (mounted) setState(() => _error = '读取夸克登录状态失败：$error');
    } finally {
      _checking = false;
    }
  }

  @override
  void dispose() {
    _cookieTimer?.cancel();
    unawaited(_webview.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('夸克官方扫码登录'),
    content: SizedBox(
      width: 760,
      height: (MediaQuery.sizeOf(context).height - 190).clamp(440.0, 650.0),
      child: Column(
        children: [
          const Text(
            '下方是夸克官方登录页。请用夸克 App 扫描页面中的二维码并在手机上确认。',
            style: TextStyle(color: AppColors.textMuted, fontSize: 12),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: DecoratedBox(
                decoration: const BoxDecoration(color: Colors.white),
                child: _error != null
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(24),
                          child: Text(
                            _error!,
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.redAccent),
                          ),
                        ),
                      )
                    : _ready
                    ? Webview(_webview)
                    : const Center(child: CircularProgressIndicator()),
              ),
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            '确认成功后此窗口会自动关闭，登录凭据只保存在本机系统凭据库。',
            style: TextStyle(color: AppColors.textMuted, fontSize: 11),
          ),
        ],
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('取消'),
      ),
      if (_error != null)
        FilledButton(
          onPressed: () {
            setState(() => _error = null);
            _initialize();
          },
          child: const Text('重试'),
        ),
    ],
  );
}

class _QuarkQrLoginDialog extends StatefulWidget {
  const _QuarkQrLoginDialog({required this.controller});

  final LearningPlayerController controller;

  @override
  State<_QuarkQrLoginDialog> createState() => _QuarkQrLoginDialogState();
}

class _QuarkQrLoginDialogState extends State<_QuarkQrLoginDialog> {
  QuarkQrLoginSession? _session;
  Timer? _timer;
  bool _polling = false;
  bool _loading = true;
  bool _canRetry = false;
  String _message = '正在获取夸克登录二维码…';

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    _timer?.cancel();
    if (mounted) {
      setState(() {
        _loading = true;
        _canRetry = false;
        _message = '正在获取夸克登录二维码…';
      });
    }
    try {
      final session = await widget.controller.startQuarkQrLogin();
      if (!mounted) return;
      setState(() {
        _session = session;
        _loading = false;
        _message = '请使用夸克 App 扫码，并在手机上确认登录';
      });
      _timer = Timer.periodic(const Duration(seconds: 2), (_) => _poll());
      await _poll();
    } on QuarkShareException catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _canRetry = true;
        _message = error.message;
      });
    } on Object catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _canRetry = true;
        _message = '无法创建夸克登录二维码：$error';
      });
    }
  }

  Future<void> _poll() async {
    final session = _session;
    if (session == null || _polling || !mounted) return;
    _polling = true;
    try {
      final result = await widget.controller.pollQuarkQrLogin(session);
      if (!mounted) return;
      switch (result.status) {
        case QuarkQrLoginStatus.waiting:
          break;
        case QuarkQrLoginStatus.success:
          _timer?.cancel();
          Navigator.pop(context, result.cookie);
          return;
        case QuarkQrLoginStatus.expired:
          _timer?.cancel();
          setState(() {
            _loading = true;
            _canRetry = false;
            _message = '二维码已过期，正在自动刷新…';
          });
          await Future<void>.delayed(const Duration(milliseconds: 500));
          if (mounted) await _start();
          return;
        case QuarkQrLoginStatus.failed:
          _timer?.cancel();
          setState(() {
            _canRetry = true;
            _message = result.message;
          });
      }
    } on QuarkShareException catch (error) {
      _timer?.cancel();
      if (mounted) {
        setState(() {
          _canRetry = true;
          _message = error.message;
        });
      }
    } finally {
      _polling = false;
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('扫码登录夸克'),
    content: SizedBox(
      width: 330,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_loading)
            const SizedBox(
              width: 240,
              height: 240,
              child: Center(child: CircularProgressIndicator()),
            )
          else if (_session case final session?)
            DecoratedBox(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: QrImageView(
                  data: session.qrUrl,
                  size: 216,
                  backgroundColor: Colors.white,
                  eyeStyle: const QrEyeStyle(
                    eyeShape: QrEyeShape.square,
                    color: Colors.black,
                  ),
                  dataModuleStyle: const QrDataModuleStyle(
                    dataModuleShape: QrDataModuleShape.square,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
          const SizedBox(height: 16),
          Text(
            _message,
            textAlign: TextAlign.center,
            style: const TextStyle(color: AppColors.textMuted),
          ),
          const SizedBox(height: 8),
          const Text(
            '登录凭据只保存在本机系统凭据库，用于你确认后的网盘转存。',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 11, color: AppColors.textMuted),
          ),
        ],
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('取消'),
      ),
      if (_canRetry)
        FilledButton(onPressed: _start, child: const Text('刷新二维码')),
    ],
  );
}

String _fileName(String path) {
  final normalized = path.replaceAll('\\', '/');
  final parts = normalized.split('/').where((part) => part.isNotEmpty).toList();
  return parts.isEmpty ? path : parts.last;
}

String _cleanTitle(String title) {
  final dot = title.lastIndexOf('.');
  return dot > 0 ? title.substring(0, dot) : title;
}
