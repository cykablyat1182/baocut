import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../domain/models/processing_state.dart';
import '../../domain/models/subtitle_cue.dart';
import 'account_dialog.dart';
import 'learning_player_controller.dart';

Future<void> showSubtitleActions(
  BuildContext context,
  LearningPlayerController controller,
) async {
  Future<void> run(Future<void> Function() action) async {
    Navigator.of(context).pop();
    try {
      await action();
    } catch (error) {
      // Do not silently swallow a failed remote extraction.  Previously the
      // sheet closed and the old default subtitle stayed on screen, making a
      // valid tap look ignored.
      controller.reportPlayerActionError(error);
    }
  }

  final content = SafeArea(
    child: Padding(
      padding: const EdgeInsets.fromLTRB(10, 12, 10, 18),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const _SheetHeading(
              title: '字幕与智能处理',
              subtitle: '本机负责稳定播放，密钥与模型调用只保留在处理服务端。',
            ),
            _ActionTile(
              icon: Icons.closed_caption_rounded,
              title: '字幕显示：${controller.subtitleMode.label}',
              subtitle: '双语 / 仅原文 / 仅译文；双轨字幕会同时叠加显示',
              accent: controller.subtitleMode == SubtitleDisplayMode.bilingual,
              onTap: () {
                Navigator.of(context).pop();
                unawaited(showSubtitleModeDialog(context, controller));
              },
            ),
            _ActionTile(
              icon: Icons.tune_rounded,
              title: '字幕样式与位置',
              subtitle: '分别调整两种语言字号、上下顺序与画面位置',
              onTap: () {
                Navigator.of(context).pop();
                unawaited(showSubtitleDisplaySettings(context, controller));
              },
            ),
            _ActionTile(
              icon: Icons.upload_file_outlined,
              title: '载入本地字幕',
              subtitle: '支持 SRT、WebVTT、ASS 与 SSA',
              onTap: () => run(controller.openSubtitlePicker),
            ),
            if (controller.embeddedSubtitleTracks.isNotEmpty) ...[
              const Padding(
                padding: EdgeInsets.fromLTRB(14, 9, 14, 5),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    '字幕轨道（内嵌 + 外挂）',
                    style: TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 11.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
              const Padding(
                padding: EdgeInsets.fromLTRB(14, 0, 14, 7),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    '内嵌字幕与已生成外挂译文轨都可点选；指定“原文 / 译文”即可组合成双语并自动对齐。',
                    style: TextStyle(color: AppColors.textMuted, fontSize: 11),
                  ),
                ),
              ),
              for (final track in controller.embeddedSubtitleTracks)
                _EmbeddedSubtitleTile(
                  label: track.label,
                  isTextBased: track.isTextBased,
                  singleSelected:
                      controller.selectedEmbeddedSubtitleOrdinal ==
                          track.ordinal &&
                      controller.selectedTranslationSubtitleOrdinal == null,
                  originalSelected:
                      controller.selectedOriginalSubtitleOrdinal ==
                      track.ordinal,
                  translationSelected:
                      controller.selectedTranslationSubtitleOrdinal ==
                      track.ordinal,
                  onSingle: () => run(
                    () => controller.selectEmbeddedSubtitleTrack(track.ordinal),
                  ),
                  onRowTap: () => run(
                    () => controller.selectEmbeddedSubtitleTrack(
                      track.ordinal,
                      combineWithCurrent: true,
                    ),
                  ),
                  onOriginal: track.isTextBased
                      ? () => run(
                          () => controller.selectEmbeddedSubtitlePair(
                            originalOrdinal: track.ordinal,
                            translationOrdinal:
                                controller.selectedTranslationSubtitleOrdinal ==
                                    track.ordinal
                                ? null
                                : controller.selectedTranslationSubtitleOrdinal,
                          ),
                        )
                      : null,
                  onTranslation: track.isTextBased
                      ? () => run(
                          () => controller.selectEmbeddedSubtitlePair(
                            originalOrdinal:
                                controller.selectedOriginalSubtitleOrdinal ==
                                    track.ordinal
                                ? null
                                : controller.selectedOriginalSubtitleOrdinal,
                            translationOrdinal: track.ordinal,
                          ),
                        )
                      : null,
                ),
            ],
            _ActionTile(
              icon: Icons.translate_rounded,
              title: '翻译为双语字幕',
              subtitle: controller.localTranslationEnabled
                  ? '翻译全部字幕并生成外挂译文轨 · 本地 Ollama · 不登录、不扣除额度'
                  : '翻译全部字幕并生成外挂译文轨 · 按 Token 透明计费',
              onTap: () => run(controller.translateCurrentSubtitles),
            ),
            _ActionTile(
              icon: Icons.auto_awesome_rounded,
              title: controller.localTranslationEnabled
                  ? '从视频自动生成（需联网模型）'
                  : '从视频自动生成',
              subtitle: controller.localTranslationEnabled
                  ? '本地模式已禁用联网模型；请先载入单语字幕再使用本地翻译'
                  : '提取音轨 → SeedASR 2.0 → 翻译 → 时间轴对齐',
              accent: !controller.localTranslationEnabled,
              onTap: () => run(controller.generateSubtitles),
            ),
            if (!controller.localTranslationEnabled) ...[
              _ActionTile(
                icon: Icons.person_outline_rounded,
                title: '账户与登录',
                subtitle: '邮箱验证注册、登录与普通用户账户',
                onTap: () {
                  Navigator.of(context).pop();
                  unawaited(showAccountDialog(context, controller));
                },
              ),
              _ActionTile(
                icon: Icons.account_balance_wallet_outlined,
                title: '额度与充值',
                subtitle: '查看余额、计费规则与最近扣费',
                onTap: () {
                  Navigator.of(context).pop();
                  unawaited(showBillingDialog(context, controller));
                },
              ),
            ],
          ],
        ),
      ),
    ),
  );

  if (Platform.isAndroid || Platform.isIOS) {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFA141618),
      showDragHandle: true,
      useSafeArea: true,
      builder: (_) => content,
    );
  } else {
    await showDialog<void>(
      context: context,
      builder: (_) => Dialog(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 480),
          child: content,
        ),
      ),
    );
  }
}

Future<void> showSubtitleModeDialog(
  BuildContext context,
  LearningPlayerController controller,
) async {
  await showDialog<void>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: const Text('字幕显示'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (final mode in SubtitleDisplayMode.values)
            ListTile(
              leading: Icon(
                controller.subtitleMode == mode
                    ? Icons.radio_button_checked_rounded
                    : Icons.radio_button_unchecked_rounded,
                color: controller.subtitleMode == mode
                    ? AppColors.amber
                    : AppColors.textMuted,
              ),
              title: Text(mode.label),
              subtitle: Text(
                switch (mode) {
                  SubtitleDisplayMode.bilingual => '原文在上、译文在下，同时显示两条字幕',
                  SubtitleDisplayMode.original => '只显示原文字幕',
                  SubtitleDisplayMode.translation => '只显示译文字幕',
                  SubtitleDisplayMode.off => '关闭字幕画面显示，但保留字幕导航与查词数据',
                },
                style: const TextStyle(
                  color: AppColors.textMuted,
                  fontSize: 11,
                ),
              ),
              onTap: () {
                controller.setSubtitleMode(mode);
                Navigator.of(dialogContext).pop();
              },
            ),
        ],
      ),
    ),
  );
}

Future<void> showNetworkSourceDialog(
  BuildContext context,
  LearningPlayerController controller,
) async {
  final sources = controller.availableNetworkSources;
  if (sources.length < 2) return;
  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: const Color(0xFA141618),
    showDragHandle: true,
    useSafeArea: true,
    builder: (sheetContext) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 4, 12, 18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(8, 6, 8, 4),
              child: Text(
                '播放线路',
                style: TextStyle(
                  color: AppColors.ivory,
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(8, 0, 8, 10),
              child: Text(
                '网络影视按直链播放；当前线路异常时会自动切换到下一条可用线路。',
                style: TextStyle(color: AppColors.textMuted, fontSize: 11.5),
              ),
            ),
            for (var index = 0; index < sources.length; index++)
              ListTile(
                dense: true,
                leading: Icon(
                  index == controller.currentNetworkSourceIndex
                      ? Icons.radio_button_checked_rounded
                      : Icons.radio_button_unchecked_rounded,
                  color: index == controller.currentNetworkSourceIndex
                      ? AppColors.amber
                      : AppColors.textMuted,
                ),
                title: Text(
                  sources[index].sourceName ?? '线路 ${index + 1}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                subtitle: Text(
                  _networkProtocolLabel(sources[index].path),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 10.5,
                  ),
                ),
                onTap: index == controller.currentNetworkSourceIndex
                    ? null
                    : () {
                        Navigator.of(sheetContext).pop();
                        unawaited(controller.switchNetworkSource(index));
                      },
              ),
          ],
        ),
      ),
    ),
  );
}

String _networkProtocolLabel(String path) {
  final scheme = Uri.tryParse(path)?.scheme.toUpperCase();
  if (scheme == null || scheme.isEmpty) return '网络直链';
  return '$scheme 直链 · 原生播放器';
}

Future<void> showBillingDialog(
  BuildContext context,
  LearningPlayerController controller,
) async {
  unawaited(controller.refreshBilling());
  await showDialog<void>(
    context: context,
    builder: (dialogContext) => AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final overview = controller.billingOverview;
        final account = overview?.account;
        final canCheckout =
            overview?.checkoutAvailable == true &&
            controller.externalCheckoutAllowed;
        final compact = MediaQuery.sizeOf(context).width < 600;
        return AlertDialog(
          insetPadding: EdgeInsets.symmetric(
            horizontal: compact ? 12 : 40,
            vertical: 24,
          ),
          titlePadding: const EdgeInsets.fromLTRB(24, 22, 14, 0),
          title: Row(
            children: [
              const Icon(
                Icons.account_balance_wallet_outlined,
                color: AppColors.amber,
              ),
              const SizedBox(width: 11),
              const Expanded(child: Text('翻译额度')),
              IconButton(
                tooltip: '刷新额度',
                onPressed: controller.billingLoading
                    ? null
                    : controller.refreshBilling,
                icon: const Icon(Icons.refresh_rounded),
              ),
            ],
          ),
          content: SizedBox(
            width: compact ? double.infinity : 580,
            child: controller.billingLoading && overview == null
                ? const Padding(
                    padding: EdgeInsets.symmetric(vertical: 52),
                    child: Center(child: CircularProgressIndicator()),
                  )
                : controller.billingError != null && overview == null
                ? _BillingMessage(
                    icon: Icons.cloud_off_rounded,
                    message: controller.billingError!,
                  )
                : SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1B1E21),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: AppColors.divider),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text(
                                      '可用额度',
                                      style: TextStyle(
                                        color: AppColors.textMuted,
                                        fontSize: 12,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      '${account?.balanceCredits ?? 0}',
                                      style: const TextStyle(
                                        color: AppColors.ivory,
                                        fontSize: 30,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const Text(
                                '模型由服务端统一维护\n客户端不保存模型密钥',
                                textAlign: TextAlign.right,
                                style: TextStyle(
                                  color: AppColors.textMuted,
                                  fontSize: 11.5,
                                  height: 1.45,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (account != null) ...[
                          const SizedBox(height: 16),
                          Text(
                            '计费：输入每千 Token ${_rate(account.pricing.inputCreditsPerThousandTokens)} 点，'
                            '输出每千 Token ${_rate(account.pricing.outputCreditsPerThousandTokens)} 点；'
                            '单次最低 ${account.pricing.minimumChargeCredits} 点。',
                            style: const TextStyle(
                              color: AppColors.textMuted,
                              fontSize: 11.5,
                              height: 1.5,
                            ),
                          ),
                        ],
                        const SizedBox(height: 18),
                        const Text(
                          '充值套餐',
                          style: TextStyle(
                            color: AppColors.ivory,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 9),
                        if (overview == null || overview.packages.isEmpty)
                          const _BillingMessage(
                            icon: Icons.info_outline_rounded,
                            message: '商户尚未配置在线充值套餐。',
                          )
                        else
                          for (final plan in overview.packages)
                            Container(
                              margin: const EdgeInsets.only(bottom: 8),
                              padding: const EdgeInsets.fromLTRB(
                                14,
                                10,
                                10,
                                10,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xFF181B1D),
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: AppColors.divider),
                              ),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          plan.name,
                                          style: const TextStyle(
                                            color: AppColors.ivory,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                        const SizedBox(height: 3),
                                        Text(
                                          '${plan.credits} 点 · ${plan.formattedAmount}'
                                          '${plan.description.isEmpty ? '' : ' · ${plan.description}'}',
                                          style: const TextStyle(
                                            color: AppColors.textMuted,
                                            fontSize: 11.5,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  FilledButton(
                                    onPressed:
                                        canCheckout &&
                                            !controller.billingLoading
                                        ? () => controller.openCheckout(plan.id)
                                        : null,
                                    child: const Text('充值'),
                                  ),
                                ],
                              ),
                            ),
                        if (!controller.externalCheckoutAllowed)
                          const Padding(
                            padding: EdgeInsets.only(top: 5),
                            child: Text(
                              'Google Play 发行版的数字内容必须使用 Play 结算；'
                              '外部充值入口已关闭。',
                              style: TextStyle(
                                color: AppColors.textMuted,
                                fontSize: 11.5,
                                height: 1.45,
                              ),
                            ),
                          )
                        else if (overview?.checkoutAvailable == false)
                          const Padding(
                            padding: EdgeInsets.only(top: 5),
                            child: Text(
                              '安全支付尚未由商户开通，当前只能使用已有额度。',
                              style: TextStyle(
                                color: AppColors.textMuted,
                                fontSize: 11.5,
                              ),
                            ),
                          ),
                        if (controller.billingError != null) ...[
                          const SizedBox(height: 12),
                          _BillingMessage(
                            icon: Icons.error_outline_rounded,
                            message: controller.billingError!,
                          ),
                        ],
                        if (account != null &&
                            account.transactions.isNotEmpty) ...[
                          const SizedBox(height: 20),
                          const Text(
                            '最近记录',
                            style: TextStyle(
                              color: AppColors.ivory,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 7),
                          for (final transaction in account.transactions.take(
                            6,
                          ))
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 6),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      transaction.description,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: AppColors.text,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ),
                                  Text(
                                    '${transaction.deltaCredits > 0 ? '+' : ''}'
                                    '${transaction.deltaCredits} 点',
                                    style: TextStyle(
                                      color: transaction.deltaCredits > 0
                                          ? const Color(0xFF7CCB9B)
                                          : AppColors.textMuted,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                        ],
                      ],
                    ),
                  ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('关闭'),
            ),
          ],
        );
      },
    ),
  );
}

String _rate(double value) => value == value.roundToDouble()
    ? value.toStringAsFixed(0)
    : value.toStringAsFixed(2);

Future<void> showPlayerSettings(
  BuildContext context,
  LearningPlayerController controller,
) async {
  await showDialog<void>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      insetPadding: _settingsDialogInset(MediaQuery.sizeOf(dialogContext)),
      title: const Text('设置'),
      content: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: 460,
          maxHeight: _settingsDialogContentHeight(
            MediaQuery.sizeOf(dialogContext),
          ),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _SettingsPageTile(
                icon: Icons.movie_filter_outlined,
                title: '播放与画面',
                subtitle: '视频插帧、流畅度与性能',
                onTap: () {
                  Navigator.of(dialogContext).pop();
                  unawaited(showPlaybackSettings(context, controller));
                },
              ),
              const SizedBox(height: 9),
              _SettingsPageTile(
                icon: Icons.subtitles_rounded,
                title: '字幕显示',
                subtitle: '双语字号、上下顺序、位置与翻页手势',
                onTap: () {
                  Navigator.of(dialogContext).pop();
                  unawaited(showSubtitleDisplaySettings(context, controller));
                },
              ),
              const SizedBox(height: 9),
              _SettingsPageTile(
                icon: Icons.auto_awesome_rounded,
                title: '自动处理与服务器',
                subtitle: '自动补全、语言和服务地址',
                onTap: () {
                  Navigator.of(dialogContext).pop();
                  unawaited(showServiceSettings(context, controller));
                },
              ),
              if (!controller.localTranslationEnabled) ...[
                const SizedBox(height: 9),
                _SettingsPageTile(
                  icon: Icons.person_outline_rounded,
                  title: '账户与登录',
                  subtitle: '邮箱验证注册、登录与普通用户账户',
                  onTap: () {
                    Navigator.of(dialogContext).pop();
                    unawaited(showAccountDialog(context, controller));
                  },
                ),
                const SizedBox(height: 9),
                _SettingsPageTile(
                  icon: Icons.account_balance_wallet_outlined,
                  title: '额度与充值',
                  subtitle: '查看余额、计费规则与最近扣费',
                  onTap: () {
                    Navigator.of(dialogContext).pop();
                    unawaited(showBillingDialog(context, controller));
                  },
                ),
              ],
              if (Platform.isWindows) ...[
                const SizedBox(height: 9),
                _SettingsPageTile(
                  icon: Icons.memory_rounded,
                  title: '本地模型翻译',
                  subtitle: controller.localTranslationEnabled
                      ? '已启用 · ${controller.localModelName.isEmpty ? '正在选择模型' : controller.localModelName}${controller.localModelRuntime == null ? '' : ' · ${controller.localModelRuntime!.deviceLabel}'}'
                      : '使用本机 Ollama，不登录、不扣除额度',
                  onTap: () {
                    Navigator.of(dialogContext).pop();
                    unawaited(
                      showLocalTranslationSettings(context, controller),
                    );
                  },
                ),
              ],
              if (Platform.isAndroid) ...[
                const SizedBox(height: 9),
                _SettingsPageTile(
                  icon: Icons.folder_open_rounded,
                  title: '媒体文件访问',
                  subtitle: '文件夹扫描与同目录视频自动补全',
                  onTap: () {
                    Navigator.of(dialogContext).pop();
                    unawaited(showStorageAccessSettings(context, controller));
                  },
                ),
              ],
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(dialogContext).pop(),
          child: const Text('关闭'),
        ),
      ],
    ),
  );
}

Future<void> showPlaybackSettings(
  BuildContext context,
  LearningPlayerController controller,
) async {
  await showDialog<void>(
    context: context,
    builder: (dialogContext) => AnimatedBuilder(
      animation: controller,
      builder: (context, _) => AlertDialog(
        insetPadding: _settingsDialogInset(MediaQuery.sizeOf(dialogContext)),
        title: const Text('播放与画面'),
        content: ConstrainedBox(
          constraints: BoxConstraints(
            maxWidth: 480,
            maxHeight: _settingsDialogContentHeight(
              MediaQuery.sizeOf(dialogContext),
            ),
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '实时视频插帧',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 5),
                const Text(
                  '根据屏幕刷新率生成过渡帧，减轻低帧率影片的运动卡顿。该功能不是 AI 光流插帧。',
                  style: TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 11.5,
                    height: 1.45,
                  ),
                ),
                const SizedBox(height: 13),
                for (final mode in FrameInterpolationMode.values) ...[
                  _InterpolationModeTile(
                    mode: mode,
                    selected: controller.frameInterpolationMode == mode,
                    onTap: () => controller.setFrameInterpolationMode(mode),
                  ),
                  if (mode != FrameInterpolationMode.values.last)
                    const SizedBox(height: 8),
                ],
                const SizedBox(height: 13),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.amber.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(11),
                    border: Border.all(
                      color: AppColors.amber.withValues(alpha: 0.22),
                    ),
                  ),
                  child: const Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(
                        Icons.battery_alert_outlined,
                        color: AppColors.amber,
                        size: 19,
                      ),
                      SizedBox(width: 9),
                      Expanded(
                        child: Text(
                          '手机播放 1080P/4K 视频时，插帧可能增加耗电和发热；出现掉帧时请选择“关闭”或“流畅”。',
                          style: TextStyle(
                            color: AppColors.text,
                            fontSize: 11.5,
                            height: 1.4,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('完成'),
          ),
        ],
      ),
    ),
  );
}

class _InterpolationModeTile extends StatelessWidget {
  const _InterpolationModeTile({
    required this.mode,
    required this.selected,
    required this.onTap,
  });

  final FrameInterpolationMode mode;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected
          ? AppColors.amber.withValues(alpha: 0.11)
          : const Color(0x66101418),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: selected
              ? AppColors.amber.withValues(alpha: 0.48)
              : AppColors.divider,
        ),
      ),
      clipBehavior: Clip.antiAlias,
      child: ListTile(
        onTap: onTap,
        leading: Icon(
          selected ? Icons.check_circle_rounded : Icons.circle_outlined,
          color: selected ? AppColors.amber : AppColors.textMuted,
        ),
        title: Text(
          mode.label,
          style: TextStyle(
            color: selected ? AppColors.ivory : AppColors.text,
            fontSize: 13.5,
            fontWeight: FontWeight.w700,
          ),
        ),
        subtitle: Text(
          mode.description,
          style: const TextStyle(color: AppColors.textMuted, fontSize: 11),
        ),
        dense: true,
      ),
    );
  }
}

EdgeInsets _settingsDialogInset(Size size) => EdgeInsets.symmetric(
  horizontal: size.width < 720 ? 14 : 40,
  vertical: size.height < 500 ? 10 : 24,
);

double _settingsDialogContentHeight(Size size) =>
    size.height < 500 ? size.height * 0.58 : size.height * 0.68;

Future<void> showSubtitleDisplaySettings(
  BuildContext context,
  LearningPlayerController controller,
) async {
  var subtitleBottomOffset = controller.subtitleBottomOffset;
  var originalScale = controller.subtitleOriginalScale;
  var translationScale = controller.subtitleTranslationScale;
  var translationFirst = controller.subtitleTranslationFirst;
  var hideHearingImpaired = controller.hideHearingImpairedSubtitles;
  await showDialog<void>(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setState) => AlertDialog(
        insetPadding: _settingsDialogInset(MediaQuery.sizeOf(dialogContext)),
        title: const Text('字幕显示'),
        content: ConstrainedBox(
          constraints: BoxConstraints(
            maxWidth: 480,
            maxHeight: _settingsDialogContentHeight(
              MediaQuery.sizeOf(dialogContext),
            ),
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _SubtitleSettingsPreview(
                  originalScale: originalScale,
                  translationScale: translationScale,
                  translationFirst: translationFirst,
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    const Text(
                      '字幕大小',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const Spacer(),
                    TextButton(
                      onPressed: () => setState(() {
                        originalScale = 1;
                        translationScale = 1;
                        controller
                          ..setSubtitleOriginalScale(1)
                          ..setSubtitleTranslationScale(1);
                      }),
                      child: const Text('恢复默认'),
                    ),
                  ],
                ),
                _SubtitleScaleSetting(
                  label: '原文',
                  value: originalScale,
                  onChanged: (value) => setState(() {
                    originalScale = value;
                    controller.setSubtitleOriginalScale(value);
                  }),
                ),
                _SubtitleScaleSetting(
                  label: '译文',
                  value: translationScale,
                  onChanged: (value) => setState(() {
                    translationScale = value;
                    controller.setSubtitleTranslationScale(value);
                  }),
                ),
                const SizedBox(height: 8),
                Material(
                  color: const Color(0x66101418),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: const BorderSide(color: AppColors.divider),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: SwitchListTile.adaptive(
                    key: const ValueKey('subtitle-translation-first'),
                    value: translationFirst,
                    onChanged: (value) => setState(() {
                      translationFirst = value;
                      controller.setSubtitleTranslationFirst(value);
                    }),
                    secondary: const Icon(Icons.swap_vert_rounded),
                    title: const Text(
                      '译文显示在上方',
                      style: TextStyle(fontSize: 13.5),
                    ),
                    subtitle: Text(
                      translationFirst ? '当前：译文在上，原文在下' : '当前：原文在上，译文在下',
                      style: const TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 11,
                      ),
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                  ),
                ),
                const SizedBox(height: 10),
                Material(
                  color: const Color(0x66101418),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: const BorderSide(color: AppColors.divider),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: SwitchListTile.adaptive(
                    key: const ValueKey('hide-hearing-impaired-subtitles'),
                    value: hideHearingImpaired,
                    onChanged: (value) => setState(() {
                      hideHearingImpaired = value;
                      controller.setHideHearingImpairedSubtitles(value);
                    }),
                    secondary: const Icon(Icons.hearing_disabled_rounded),
                    title: const Text(
                      '屏蔽听障辅助字幕',
                      style: TextStyle(fontSize: 13.5),
                    ),
                    subtitle: const Text(
                      '同时隐藏整行括号字幕（包括未识别的声音提示）',
                      style: TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 11,
                      ),
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    const Text(
                      '底部字幕位置',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      subtitleBottomOffset == 0
                          ? '默认'
                          : subtitleBottomOffset > 0
                          ? '上移 ${subtitleBottomOffset.round()} px'
                          : '下移 ${subtitleBottomOffset.abs().round()} px',
                      style: const TextStyle(
                        color: AppColors.amber,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
                Slider(
                  value: subtitleBottomOffset,
                  min: -160,
                  max: 220,
                  divisions: 38,
                  label: '${subtitleBottomOffset.round()} px',
                  onChanged: (value) => setState(() {
                    subtitleBottomOffset = value;
                    controller.setSubtitleBottomOffset(value);
                  }),
                ),
                Row(
                  children: [
                    const Text(
                      '向下',
                      style: TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 11,
                      ),
                    ),
                    const Spacer(),
                    TextButton(
                      onPressed: () => setState(() {
                        subtitleBottomOffset = 0;
                        controller.setSubtitleBottomOffset(0);
                      }),
                      child: const Text('位置归零'),
                    ),
                    const Spacer(),
                    const Text(
                      '向上',
                      style: TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  Platform.isAndroid || Platform.isIOS
                      ? '在字幕卡片范围内左右拖动，会跟手衔接上一句或下一句。'
                      : '使用键盘 ← / → 切换上一句或下一句字幕。',
                  style: const TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 11.5,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('完成'),
          ),
        ],
      ),
    ),
  );
}

class _SubtitleSettingsPreview extends StatelessWidget {
  const _SubtitleSettingsPreview({
    required this.originalScale,
    required this.translationScale,
    required this.translationFirst,
  });

  final double originalScale;
  final double translationScale;
  final bool translationFirst;

  @override
  Widget build(BuildContext context) {
    final original = Text(
      'Swipe through the story.',
      textAlign: TextAlign.center,
      style: TextStyle(
        color: AppColors.ivory,
        fontFamily: AppTheme.subtitleFont,
        fontSize: 21 * originalScale,
        fontWeight: FontWeight.w600,
        height: 1.14,
      ),
    );
    final translation = Text(
      '左右滑动字幕卡片即可翻页',
      textAlign: TextAlign.center,
      style: TextStyle(
        color: AppColors.textMuted,
        fontFamily: AppTheme.subtitleFont,
        fontSize: 15 * translationScale,
        height: 1.14,
      ),
    );
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      decoration: BoxDecoration(
        color: const Color(0x99101418),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: AppColors.divider),
      ),
      child: Column(
        children: translationFirst
            ? [translation, const SizedBox(height: 6), original]
            : [original, const SizedBox(height: 6), translation],
      ),
    );
  }
}

class _SubtitleScaleSetting extends StatelessWidget {
  const _SubtitleScaleSetting({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  final String label;
  final double value;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Text('$label字幕', style: const TextStyle(fontSize: 12.5)),
            const Spacer(),
            Text(
              '${(value * 100).round()}%',
              style: const TextStyle(
                color: AppColors.amber,
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
        Slider(
          value: value,
          min: 0.65,
          max: 1.75,
          divisions: 22,
          label: '${(value * 100).round()}%',
          onChanged: onChanged,
        ),
      ],
    );
  }
}

Future<void> showServiceSettings(
  BuildContext context,
  LearningPlayerController controller,
) async {
  final endpoint = TextEditingController(
    text: controller.settings.pipelineBaseUrl,
  );
  var source = controller.settings.sourceLanguage;
  var target = controller.settings.targetLanguage;
  var autoPrepare = controller.settings.autoPrepareSubtitles;

  await showDialog<void>(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setState) => AlertDialog(
        insetPadding: _settingsDialogInset(MediaQuery.sizeOf(dialogContext)),
        title: const Text('自动处理与服务器'),
        content: ConstrainedBox(
          constraints: BoxConstraints(
            maxWidth: 480,
            maxHeight: _settingsDialogContentHeight(
              MediaQuery.sizeOf(dialogContext),
            ),
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '客户端只保存设备凭据；模型名称、模型密钥与上游接口只存在于影语服务端。',
                  style: TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 12.5,
                    height: 1.45,
                  ),
                ),
                const SizedBox(height: 18),
                TextField(
                  controller: endpoint,
                  keyboardType: TextInputType.url,
                  onChanged: (_) => setState(() {}),
                  decoration: const InputDecoration(
                    labelText: '服务地址',
                    hintText: 'https://subtitle.example.com',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.dns_outlined),
                  ),
                ),
                const SizedBox(height: 15),
                Row(
                  children: [
                    Expanded(
                      child: _LanguageDropdown(
                        label: '原语言',
                        value: source,
                        values: const ['en-US', 'en-GB', 'zh-CN', 'ja-JP'],
                        onChanged: (value) => setState(() => source = value),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _LanguageDropdown(
                        label: '目标语言',
                        value: target,
                        values: const ['zh-CN', 'en-US', 'ja-JP'],
                        onChanged: (value) => setState(() => target = value),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  value: autoPrepare,
                  activeTrackColor: AppColors.amber,
                  title: const Text('自动补全双语字幕', style: TextStyle(fontSize: 14)),
                  subtitle: const Text(
                    '单语字幕自动翻译；无字幕时自动提取音轨并使用 SeedASR 2.0。',
                    style: TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 11.5,
                    ),
                  ),
                  onChanged: (value) => setState(() => autoPrepare = value),
                ),
                const Text(
                  '自动补全会在打开视频后检查字幕：单语字幕自动翻译，无字幕则调用语音识别服务生成。',
                  style: TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 11.5,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: endpoint.text.trim().isEmpty
                ? null
                : () async {
                    await controller.applySettings(
                      pipelineBaseUrl: endpoint.text.trim(),
                      sourceLanguage: source,
                      targetLanguage: target,
                      autoPrepareSubtitles: autoPrepare,
                    );
                    if (dialogContext.mounted) {
                      Navigator.of(dialogContext).pop();
                    }
                  },
            child: const Text('保存'),
          ),
        ],
      ),
    ),
  );
  endpoint.dispose();
}

Future<void> showStorageAccessSettings(
  BuildContext context,
  LearningPlayerController controller,
) async {
  unawaited(controller.refreshStorageAccessStatus());
  await showDialog<void>(
    context: context,
    builder: (dialogContext) => AnimatedBuilder(
      animation: controller,
      builder: (context, _) => AlertDialog(
        insetPadding: _settingsDialogInset(MediaQuery.sizeOf(dialogContext)),
        title: const Text('媒体文件访问'),
        content: ConstrainedBox(
          constraints: BoxConstraints(
            maxWidth: 460,
            maxHeight: _settingsDialogContentHeight(
              MediaQuery.sizeOf(dialogContext),
            ),
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: controller.storageAccessGranted
                        ? AppColors.success.withValues(alpha: 0.1)
                        : AppColors.amber.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(11),
                    border: Border.all(
                      color: controller.storageAccessGranted
                          ? AppColors.success.withValues(alpha: 0.3)
                          : AppColors.amber.withValues(alpha: 0.3),
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        controller.storageAccessGranted
                            ? Icons.check_circle_rounded
                            : Icons.folder_off_outlined,
                        color: controller.storageAccessGranted
                            ? AppColors.success
                            : AppColors.amber,
                      ),
                      const SizedBox(width: 11),
                      Expanded(
                        child: Text(
                          controller.storageAccessGranted
                              ? '已允许扫描本机媒体文件夹'
                              : '尚未允许扫描媒体文件夹',
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 15),
                const Text(
                  'Android 需要“所有文件访问权限”才能读取所选文件夹、发现同目录视频，并让播放列表在重启后继续可用。影语只读取你主动连接的媒体来源。',
                  style: TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 12.5,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: controller.storageAccessChecking
                ? null
                : controller.refreshStorageAccessStatus,
            child: const Text('重新检查'),
          ),
          FilledButton(
            onPressed:
                controller.storageAccessGranted ||
                    controller.storageAccessChecking
                ? () => Navigator.of(dialogContext).pop()
                : controller.requestAndroidStorageAccess,
            child: Text(controller.storageAccessGranted ? '完成' : '前往授权'),
          ),
        ],
      ),
    ),
  );
}

Future<void> showLocalTranslationSettings(
  BuildContext context,
  LearningPlayerController controller,
) async {
  final directory = TextEditingController(
    text: controller.localModelDirectory.isEmpty
        ? r'D:\AI\Ollama\models'
        : controller.localModelDirectory,
  );
  final model = TextEditingController(text: controller.localModelName);
  var enabled = controller.localTranslationEnabled;
  unawaited(controller.refreshLocalModels(modelsDirectory: directory.text));

  await showDialog<void>(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setState) => AnimatedBuilder(
        animation: controller,
        builder: (context, _) => AlertDialog(
          insetPadding: _settingsDialogInset(MediaQuery.sizeOf(dialogContext)),
          title: const Text('本地模型翻译'),
          content: ConstrainedBox(
            constraints: BoxConstraints(
              maxWidth: 500,
              maxHeight: _settingsDialogContentHeight(
                MediaQuery.sizeOf(dialogContext),
              ),
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '使用本机 Ollama 翻译字幕。字幕和模型请求不会发送到影语服务器，也不需要登录或消耗点数。开启时会强制请求 GPU 并校验显存占用；如果只能使用 CPU，会拒绝启用。关闭时会发送卸载指令释放显存。',
                    style: TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 12,
                      height: 1.45,
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: directory,
                    onChanged: (_) => setState(() {}),
                    decoration: const InputDecoration(
                      labelText: 'Ollama 模型目录',
                      hintText: r'D:\AI\Ollama\models',
                      prefixIcon: Icon(Icons.folder_outlined),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 11),
                  TextField(
                    controller: model,
                    onChanged: (_) => setState(() {}),
                    decoration: InputDecoration(
                      labelText: '模型名称（可留空自动选择）',
                      hintText: '例如 gemma4:e2b-it-qat',
                      prefixIcon: const Icon(Icons.memory_rounded),
                      border: const OutlineInputBorder(),
                      suffixIcon: IconButton(
                        tooltip: '扫描模型',
                        onPressed:
                            directory.text.trim().isEmpty ||
                                controller.localTranslationLoading
                            ? null
                            : () => unawaited(
                                controller.refreshLocalModels(
                                  modelsDirectory: directory.text,
                                ),
                              ),
                        icon: const Icon(Icons.refresh_rounded),
                      ),
                    ),
                  ),
                  if (controller.localModels.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 7,
                      runSpacing: 7,
                      children: [
                        for (final item in controller.localModels)
                          ChoiceChip(
                            label: Text(
                              item.sizeLabel.isEmpty
                                  ? item.name
                                  : '${item.name} · ${item.sizeLabel}',
                              style: const TextStyle(fontSize: 11),
                            ),
                            selected: model.text.trim() == item.name,
                            onSelected: (_) {
                              model.text = item.name;
                              setState(() {});
                            },
                          ),
                      ],
                    ),
                  ],
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(11),
                    decoration: BoxDecoration(
                      color: enabled
                          ? AppColors.success.withValues(alpha: 0.1)
                          : const Color(0x66101418),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: enabled
                            ? AppColors.success.withValues(alpha: 0.34)
                            : AppColors.divider,
                      ),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(
                          enabled
                              ? Icons.check_circle_outline_rounded
                              : Icons.cloud_off_outlined,
                          size: 19,
                          color: enabled
                              ? AppColors.success
                              : AppColors.textMuted,
                        ),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Text(
                            controller.localTranslationLoading
                                ? '正在准备 Ollama…'
                                : enabled && controller.localTranslationReady
                                ? '已加载：${controller.localModelName} · ${controller.localModelRuntime?.deviceLabel ?? '已确认显存'}'
                                : enabled
                                ? '已开启，首次翻译时会继续检查模型状态。'
                                : '未启用本地模型。',
                            style: const TextStyle(
                              color: AppColors.text,
                              fontSize: 12,
                              height: 1.35,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (controller.localTranslationError != null) ...[
                    const SizedBox(height: 9),
                    Text(
                      controller.localTranslationError!,
                      style: const TextStyle(
                        color: AppColors.danger,
                        fontSize: 11.5,
                        height: 1.35,
                      ),
                    ),
                  ],
                  const SizedBox(height: 4),
                  SwitchListTile.adaptive(
                    contentPadding: EdgeInsets.zero,
                    value: enabled,
                    activeTrackColor: AppColors.amber,
                    title: const Text(
                      '启用本地模型翻译',
                      style: TextStyle(fontSize: 14),
                    ),
                    subtitle: const Text(
                      '关闭后立即卸载当前模型；再次开启会重新加载。',
                      style: TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 11.5,
                      ),
                    ),
                    onChanged: controller.localTranslationLoading
                        ? null
                        : (value) async {
                            setState(() => enabled = value);
                            final success = await controller
                                .setLocalTranslationEnabled(
                                  value,
                                  modelsDirectory: directory.text,
                                  modelName: model.text,
                                );
                            if (success && value) {
                              model.text = controller.localModelName;
                            }
                            if (!success && dialogContext.mounted) {
                              setState(
                                () => enabled =
                                    controller.localTranslationEnabled,
                              );
                            }
                            if (dialogContext.mounted) setState(() {});
                          },
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('关闭'),
            ),
            FilledButton(
              onPressed: controller.localTranslationLoading
                  ? null
                  : () async {
                      final success = await controller
                          .setLocalTranslationEnabled(
                            enabled,
                            modelsDirectory: directory.text,
                            modelName: model.text,
                          );
                      if (success && enabled) {
                        model.text = controller.localModelName;
                      }
                      if (!success && dialogContext.mounted) {
                        setState(
                          () => enabled = controller.localTranslationEnabled,
                        );
                      }
                      if (dialogContext.mounted) setState(() {});
                    },
              child: Text(enabled ? '应用并加载' : '应用并卸载'),
            ),
          ],
        ),
      ),
    ),
  );
  directory.dispose();
  model.dispose();
}

class _SettingsPageTile extends StatelessWidget {
  const _SettingsPageTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFF1A1D20),
      borderRadius: BorderRadius.circular(12),
      child: ListTile(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        leading: Icon(icon, color: AppColors.amber),
        title: Text(
          title,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
        ),
        subtitle: Text(
          subtitle,
          style: const TextStyle(color: AppColors.textMuted, fontSize: 11.5),
        ),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: onTap,
      ),
    );
  }
}

Future<void> showSubtitleSearch(
  BuildContext context,
  LearningPlayerController controller,
) {
  return showDialog<void>(
    context: context,
    builder: (_) => _SubtitleSearchDialog(controller: controller),
  );
}

class ProcessingOverlay extends StatefulWidget {
  const ProcessingOverlay({super.key, required this.controller});

  final LearningPlayerController controller;

  @override
  State<ProcessingOverlay> createState() => _ProcessingOverlayState();
}

class _ProcessingOverlayState extends State<ProcessingOverlay>
    with SingleTickerProviderStateMixin {
  late final AnimationController _shineController;

  @override
  void initState() {
    super.initState();
    _shineController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1700),
    )..repeat();
  }

  @override
  void dispose() {
    _shineController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.controller.processing,
      builder: (context, _) {
        final state = widget.controller.processing;
        if (!state.isRunning && state.stage != ProcessingStage.failed) {
          return const SizedBox.shrink();
        }
        final failed = state.stage == ProcessingStage.failed;
        return ColoredBox(
          color: const Color(0x99000000),
          child: Center(child: _buildCard(state, failed)),
        );
      },
    );
  }

  Widget _buildCard(ProcessingState state, bool failed) {
    final translating = state.stage == ProcessingStage.translating && !failed;
    return AnimatedBuilder(
      animation: _shineController,
      builder: (context, _) {
        final sweep = _shineController.value;
        return Container(
          width: 420,
          constraints: const BoxConstraints(maxWidth: 560),
          margin: const EdgeInsets.all(24),
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            color: const Color(0xFA151719),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: translating ? AppColors.amber : AppColors.divider,
            ),
            boxShadow: const [
              BoxShadow(
                color: Color(0x99000000),
                blurRadius: 28,
                offset: Offset(0, 12),
              ),
            ],
          ),
          child: Stack(
            children: [
              if (translating)
                Positioned.fill(
                  child: IgnorePointer(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment(-1.4 + sweep * 2.8, -1),
                          end: Alignment(-0.5 + sweep * 2.8, 1),
                          colors: [
                            Colors.transparent,
                            AppColors.amber.withValues(alpha: 0.075),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          failed
                              ? Icons.error_outline_rounded
                              : Icons.auto_awesome_rounded,
                          color: failed ? AppColors.danger : AppColors.amber,
                        ),
                        const SizedBox(width: 11),
                        Expanded(
                          child: Text(
                            translating ? '正在翻译全部字幕' : state.stage.label,
                            style: const TextStyle(
                              color: AppColors.ivory,
                              fontSize: 17,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        if (failed)
                          IconButton(
                            onPressed: state.reset,
                            tooltip: '关闭',
                            icon: const Icon(Icons.close_rounded),
                          ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    if (!failed)
                      LinearProgressIndicator(
                        value: state.progress > 0 ? state.progress : null,
                        minHeight: 4,
                        borderRadius: BorderRadius.circular(8),
                        backgroundColor: Colors.white12,
                        color: AppColors.amber,
                      ),
                    const SizedBox(height: 13),
                    Text(
                      state.detail.isEmpty ? '正在准备处理任务…' : state.detail,
                      style: TextStyle(
                        color: failed ? AppColors.danger : AppColors.textMuted,
                        fontSize: 13,
                        height: 1.45,
                      ),
                    ),
                    if (translating && state.totalUnits > 0) ...[
                      const SizedBox(height: 13),
                      Text(
                        '${state.completedUnits} / ${state.totalUnits} 条字幕',
                        style: const TextStyle(
                          color: AppColors.amber,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      if (state.currentOriginal.trim().isNotEmpty) ...[
                        const SizedBox(height: 9),
                        _ProgressQuote(
                          label: '正在处理',
                          text: state.currentOriginal,
                        ),
                      ],
                      if (state.currentTranslation.trim().isNotEmpty) ...[
                        const SizedBox(height: 7),
                        _ProgressQuote(
                          label: '当前译文',
                          text: state.currentTranslation,
                          translation: true,
                        ),
                      ],
                      if (state.modelThought.trim().isNotEmpty) ...[
                        const SizedBox(height: 10),
                        Text(
                          '模型状态 · ${state.modelThought}',
                          style: const TextStyle(
                            color: Color(0xFF9FA5AA),
                            fontSize: 11.5,
                            height: 1.4,
                          ),
                        ),
                      ],
                    ],
                    if (!failed) ...[
                      const SizedBox(height: 10),
                      const Text(
                        '播放已暂停；翻译完成后会恢复原播放状态。',
                        style: TextStyle(
                          color: Color(0xFF777B80),
                          fontSize: 11.5,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ProgressQuote extends StatelessWidget {
  const _ProgressQuote({
    required this.label,
    required this.text,
    this.translation = false,
  });

  final String label;
  final String text;
  final bool translation;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
      decoration: BoxDecoration(
        color: translation
            ? AppColors.amber.withValues(alpha: 0.09)
            : const Color(0x661E2226),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: translation
              ? AppColors.amber.withValues(alpha: 0.24)
              : AppColors.divider,
        ),
      ),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(
            color: AppColors.text,
            fontSize: 12,
            height: 1.35,
          ),
          children: [
            TextSpan(
              text: '$label  ',
              style: const TextStyle(
                color: AppColors.textMuted,
                fontSize: 10.5,
                fontWeight: FontWeight.w700,
              ),
            ),
            TextSpan(text: text),
          ],
        ),
      ),
    );
  }
}

class _SubtitleSearchDialog extends StatefulWidget {
  const _SubtitleSearchDialog({required this.controller});

  final LearningPlayerController controller;

  @override
  State<_SubtitleSearchDialog> createState() => _SubtitleSearchDialogState();
}

class _SubtitleSearchDialogState extends State<_SubtitleSearchDialog> {
  String query = '';

  @override
  Widget build(BuildContext context) {
    final normalized = query.trim().toLowerCase();
    final matches = <int>[
      for (var index = 0; index < widget.controller.cues.length; index++)
        if (normalized.isNotEmpty &&
            (widget.controller.cues[index].original.toLowerCase().contains(
                  normalized,
                ) ||
                widget.controller.cues[index].translation
                    .toLowerCase()
                    .contains(normalized)))
          index,
    ];
    return AlertDialog(
      title: const Text('搜索字幕'),
      content: SizedBox(
        width: 520,
        height: 390,
        child: Column(
          children: [
            TextField(
              autofocus: true,
              onChanged: (value) => setState(() => query = value),
              onSubmitted: (value) async {
                final found = await widget.controller.searchAndSeek(value);
                if (found && context.mounted) Navigator.of(context).pop();
              },
              decoration: const InputDecoration(
                hintText: '输入英文或中文台词',
                prefixIcon: Icon(Icons.search_rounded),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: normalized.isEmpty
                  ? const Center(
                      child: Text(
                        '输入关键词，选择结果即可跳转到对应画面',
                        style: TextStyle(color: AppColors.textMuted),
                      ),
                    )
                  : matches.isEmpty
                  ? const Center(
                      child: Text(
                        '没有匹配的字幕',
                        style: TextStyle(color: AppColors.textMuted),
                      ),
                    )
                  : ListView.separated(
                      itemCount: matches.length,
                      separatorBuilder: (_, _) => const Divider(height: 1),
                      itemBuilder: (context, listIndex) {
                        final cueIndex = matches[listIndex];
                        final cue = widget.controller.cues[cueIndex];
                        return ListTile(
                          dense: true,
                          title: Text(
                            cue.original,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(
                            cue.translation,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          trailing: const Icon(
                            Icons.arrow_forward_rounded,
                            size: 17,
                          ),
                          onTap: () {
                            widget.controller.seekCue(cueIndex);
                            Navigator.of(context).pop();
                          },
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('关闭'),
        ),
      ],
    );
  }
}

class _SheetHeading extends StatelessWidget {
  const _SheetHeading({required this.title, required this.subtitle});

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 4, 14, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: AppColors.ivory,
              fontSize: 18,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            subtitle,
            style: const TextStyle(
              color: AppColors.textMuted,
              fontSize: 11.5,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }
}

class _BillingMessage extends StatelessWidget {
  const _BillingMessage({required this.icon, required this.message});

  final IconData icon;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: const Color(0xFF1B1E21),
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: AppColors.divider),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: AppColors.textMuted),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              message,
              style: const TextStyle(
                color: AppColors.textMuted,
                fontSize: 11.5,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.accent = false,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final bool accent;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
      leading: Icon(icon, color: accent ? AppColors.amber : AppColors.text),
      title: Text(
        title,
        style: TextStyle(
          color: accent ? AppColors.amber : AppColors.ivory,
          fontWeight: FontWeight.w600,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: const TextStyle(color: AppColors.textMuted, fontSize: 11.5),
      ),
      trailing: const Icon(Icons.chevron_right_rounded),
      onTap: onTap,
    );
  }
}

class _EmbeddedSubtitleTile extends StatelessWidget {
  const _EmbeddedSubtitleTile({
    required this.label,
    required this.isTextBased,
    required this.singleSelected,
    required this.originalSelected,
    required this.translationSelected,
    required this.onSingle,
    required this.onRowTap,
    required this.onOriginal,
    required this.onTranslation,
  });

  final String label;
  final bool isTextBased;
  final bool singleSelected;
  final bool originalSelected;
  final bool translationSelected;
  final VoidCallback onSingle;
  final VoidCallback onRowTap;
  final VoidCallback? onOriginal;
  final VoidCallback? onTranslation;

  @override
  Widget build(BuildContext context) {
    final selected = singleSelected || originalSelected || translationSelected;
    return GestureDetector(
      // The language row itself is an actionable target as well as the
      // smaller role buttons.  This is important on touch screens, where
      // tapping the label used to appear to do nothing.
      onTap: onRowTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 5),
        padding: const EdgeInsets.fromLTRB(12, 9, 8, 7),
        decoration: BoxDecoration(
          color: selected
              ? AppColors.amber.withValues(alpha: 0.08)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(9),
          border: Border.all(
            color: selected
                ? AppColors.amber.withValues(alpha: 0.3)
                : AppColors.divider,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  selected
                      ? Icons.radio_button_checked_rounded
                      : Icons.radio_button_unchecked_rounded,
                  color: selected ? AppColors.amber : AppColors.text,
                  size: 21,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        label,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: selected ? AppColors.amber : AppColors.ivory,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        isTextBased ? '文本轨道：支持字幕导航、跳转与点击查词' : '图形轨道：仅由原生播放内核显示',
                        style: const TextStyle(
                          color: AppColors.textMuted,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: '只使用此轨道',
                  onPressed: onSingle,
                  visualDensity: VisualDensity.compact,
                  icon: Icon(
                    Icons.playlist_play_rounded,
                    color: singleSelected ? AppColors.amber : AppColors.text,
                  ),
                ),
              ],
            ),
            if (isTextBased)
              Padding(
                padding: const EdgeInsets.only(left: 30, top: 2),
                child: Wrap(
                  spacing: 6,
                  children: [
                    _SubtitleRoleChip(
                      label: '原文',
                      selected: originalSelected,
                      onPressed: onOriginal,
                    ),
                    _SubtitleRoleChip(
                      label: '译文',
                      selected: translationSelected,
                      onPressed: onTranslation,
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _SubtitleRoleChip extends StatelessWidget {
  const _SubtitleRoleChip({
    required this.label,
    required this.selected,
    required this.onPressed,
  });

  final String label;
  final bool selected;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: onPressed == null ? null : (_) => onPressed!(),
      labelStyle: TextStyle(
        color: selected ? AppColors.amber : AppColors.textMuted,
        fontSize: 11,
        fontWeight: FontWeight.w600,
      ),
      visualDensity: VisualDensity.compact,
      side: BorderSide(
        color: selected
            ? AppColors.amber.withValues(alpha: 0.55)
            : AppColors.divider,
      ),
      backgroundColor: Colors.transparent,
      selectedColor: AppColors.amber.withValues(alpha: 0.14),
      showCheckmark: false,
    );
  }
}

class _LanguageDropdown extends StatelessWidget {
  const _LanguageDropdown({
    required this.label,
    required this.value,
    required this.values,
    required this.onChanged,
  });

  final String label;
  final String value;
  final List<String> values;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      initialValue: value,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
      items: [
        for (final item in values)
          DropdownMenuItem(value: item, child: Text(item)),
      ],
      onChanged: (item) {
        if (item != null) onChanged(item);
      },
    );
  }
}
