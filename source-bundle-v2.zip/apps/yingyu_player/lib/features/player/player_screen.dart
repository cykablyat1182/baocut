import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:media_kit_video/media_kit_video.dart';

import '../../core/theme/app_theme.dart';
import 'account_dialog.dart';
import 'learning_player_controller.dart';
import 'player_dialogs.dart';
import 'widgets/dictionary_overlay.dart';
import 'widgets/gesture_level_hud.dart';
import 'widgets/playback_osd.dart';
import 'widgets/playlist_drawer.dart';
import 'widgets/player_top_bar.dart';
import 'widgets/subtitle_drawer.dart';
import 'widgets/subtitle_pager.dart';

class PlayerScreen extends StatefulWidget {
  const PlayerScreen({super.key, required this.controller});

  final LearningPlayerController controller;

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  final FocusNode _focusNode = FocusNode(debugLabel: 'player-shortcuts');
  Timer? _hideTimer;
  Timer? _lockHideTimer;
  Timer? _gestureHudHideTimer;
  Timer? _noticeHideTimer;
  bool _gestureOnLeft = false;
  bool _gestureHudVisible = false;
  bool _lockedButtonVisible = false;
  late bool _wasLocked;
  String? _shownError;
  String? _shownNotice;
  String? _topNotice;
  bool _topNoticeIsError = false;
  VoidCallback? _topNoticeAction;

  LearningPlayerController get controller => widget.controller;

  @override
  void initState() {
    super.initState();
    _wasLocked = controller.controlsLocked;
    controller.addListener(_handleControllerUpdate);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _focusNode.requestFocus();
      _scheduleHide();
    });
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    _lockHideTimer?.cancel();
    _gestureHudHideTimer?.cancel();
    _noticeHideTimer?.cancel();
    controller.removeListener(_handleControllerUpdate);
    _focusNode.dispose();
    super.dispose();
  }

  void _handleControllerUpdate() {
    if (!mounted) return;
    if (_wasLocked != controller.controlsLocked) {
      _wasLocked = controller.controlsLocked;
      if (_wasLocked) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) _showLockedButton();
        });
      } else {
        _lockHideTimer?.cancel();
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted) return;
          setState(() => _lockedButtonVisible = false);
          _wakeControls();
        });
      }
    }
    final error = controller.lastError;
    final notice = controller.lastNotice;
    if (error == null) _shownError = null;
    if (notice == null) _shownNotice = null;
    if (error != null && error != _shownError) {
      _shownError = error;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        _showTopNotice(
          error,
          isError: true,
          action: () => showServiceSettings(context, controller),
        );
      });
    } else if (notice != null && notice != _shownNotice) {
      _shownNotice = notice;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        _showTopNotice(notice);
      });
    }
  }

  void _showTopNotice(
    String message, {
    bool isError = false,
    VoidCallback? action,
  }) {
    _noticeHideTimer?.cancel();
    setState(() {
      _topNotice = message;
      _topNoticeIsError = isError;
      _topNoticeAction = action;
    });
    _noticeHideTimer = Timer(const Duration(seconds: 4), () {
      if (mounted) setState(() => _topNotice = null);
    });
  }

  void _showGestureHud() {
    _gestureHudHideTimer?.cancel();
    if (!_gestureHudVisible && mounted) {
      setState(() => _gestureHudVisible = true);
    }
    _gestureHudHideTimer = Timer(const Duration(milliseconds: 850), () {
      if (mounted) setState(() => _gestureHudVisible = false);
    });
  }

  void _wakeControls() {
    if (controller.controlsLocked) {
      _showLockedButton();
      return;
    }
    controller.setOsdVisible(true);
    _scheduleHide();
  }

  void _toggleControls() {
    if (controller.controlsLocked) {
      _showLockedButton();
      return;
    }
    if (controller.osdVisible) {
      _hideTimer?.cancel();
      controller.setOsdVisible(false);
    } else {
      _wakeControls();
    }
  }

  void _showLockedButton() {
    _lockHideTimer?.cancel();
    if (mounted && !_lockedButtonVisible) {
      setState(() => _lockedButtonVisible = true);
    }
    _lockHideTimer = Timer(const Duration(seconds: 2), () {
      if (mounted && controller.controlsLocked) {
        setState(() => _lockedButtonVisible = false);
      }
    });
  }

  void _scheduleHide() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 4), () {
      if (mounted && controller.isPlaying && !controller.controlsLocked) {
        controller.setOsdVisible(false);
      }
    });
  }

  KeyEventResult _handleKey(FocusNode node, KeyEvent event) {
    if (event is! KeyDownEvent) return KeyEventResult.ignored;
    final key = event.logicalKey;
    final ctrlPressed = HardwareKeyboard.instance.isControlPressed;

    if (ctrlPressed && key == LogicalKeyboardKey.keyO) {
      controller.openVideoPicker();
    } else if (ctrlPressed && key == LogicalKeyboardKey.arrowLeft) {
      controller.openAdjacentPlaylistItem(-1);
    } else if (ctrlPressed && key == LogicalKeyboardKey.arrowRight) {
      controller.openAdjacentPlaylistItem(1);
    } else if (key == LogicalKeyboardKey.space) {
      controller.togglePlay();
    } else if (key == LogicalKeyboardKey.arrowLeft) {
      controller.seekAdjacentCue(-1);
    } else if (key == LogicalKeyboardKey.arrowRight) {
      controller.seekAdjacentCue(1);
    } else if (key == LogicalKeyboardKey.pageUp) {
      controller.seekAdjacentCue(-1);
    } else if (key == LogicalKeyboardKey.pageDown) {
      controller.seekAdjacentCue(1);
    } else if (key == LogicalKeyboardKey.arrowUp) {
      controller.adjustVolume(5);
    } else if (key == LogicalKeyboardKey.arrowDown) {
      controller.adjustVolume(-5);
    } else if (key == LogicalKeyboardKey.keyS) {
      controller.toggleDrawer();
    } else if (key == LogicalKeyboardKey.keyR) {
      controller.toggleSentenceLoop();
    } else if (key == LogicalKeyboardKey.keyF) {
      controller.toggleFullscreen();
    } else if (key == LogicalKeyboardKey.escape) {
      if (controller.drawerOpen) {
        controller.setDrawer(false);
      } else if (controller.isFullscreen) {
        controller.toggleFullscreen();
      } else {
        controller.returnToPreviousSurface();
      }
    } else {
      return KeyEventResult.ignored;
    }
    _wakeControls();
    return KeyEventResult.handled;
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (_, _) => controller.returnToPreviousSurface(),
      child: Scaffold(
        body: Focus(
          focusNode: _focusNode,
          autofocus: true,
          onKeyEvent: _handleKey,
          child: MouseRegion(
            cursor: controller.osdVisible
                ? MouseCursor.defer
                : SystemMouseCursors.none,
            onHover: (_) => _wakeControls(),
            child: AnimatedBuilder(
              animation: controller,
              builder: (context, _) => LayoutBuilder(
                builder: (context, constraints) {
                  final size = constraints.biggest;
                  final compact =
                      Platform.isAndroid || Platform.isIOS || size.width < 1050;
                  final denseLandscape = size.height < 500;
                  final gestureHudHeight = math.min(
                    184.0,
                    math.max(132.0, size.height * 0.5),
                  );
                  final drawerWidth = math.min(
                    compact ? 360.0 : 410.0,
                    size.width * (compact ? 0.43 : 0.36),
                  );
                  final playlistWidth = math.min(
                    compact ? 290.0 : 320.0,
                    size.width * (compact ? 0.38 : 0.28),
                  );
                  final osdHeight = denseLandscape
                      ? 104.0
                      : compact
                      ? 128.0
                      : 142.0;
                  final leftInset = controller.playlistOpen
                      ? playlistWidth
                      : 0.0;
                  final rightInset = controller.drawerOpen
                      ? drawerWidth + 78
                      : 54.0;
                  final availableWidth = size.width - leftInset - rightInset;
                  final dictionaryLeft = math.max(
                    leftInset + 22,
                    leftInset + (availableWidth - (compact ? 360 : 390)) / 2,
                  );
                  final controlsShown =
                      !controller.controlsLocked && controller.osdVisible;
                  final subtitleBaseBottom = controlsShown
                      ? osdHeight + (compact ? 10 : 14)
                      : (compact ? 14.0 : 22.0);
                  final minimumSubtitleBottom = controlsShown
                      ? osdHeight + 8
                      : 8.0;
                  final subtitleBottom = math.max(
                    minimumSubtitleBottom,
                    subtitleBaseBottom + controller.subtitleBottomOffset,
                  );

                  return ColoredBox(
                    color: AppColors.canvas,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        _VideoSurface(
                          controller: controller,
                          onInteraction: _toggleControls,
                          onVerticalDragStart: (details) {
                            _gestureOnLeft =
                                details.localPosition.dx < size.width / 2;
                            _showGestureHud();
                          },
                          onVerticalDragUpdate: (details) {
                            final fraction =
                                -details.delta.dy / math.max(1, size.height);
                            if (_gestureOnLeft) {
                              controller.adjustVisualBrightness(fraction * 1.7);
                            } else {
                              controller.adjustVolume(fraction * 140);
                            }
                            _showGestureHud();
                            _wakeControls();
                          },
                        ),
                        IgnorePointer(
                          child: ColoredBox(
                            color: Colors.black.withValues(
                              alpha: (1 - controller.visualBrightness) * 0.78,
                            ),
                          ),
                        ),
                        AnimatedPositioned(
                          duration: const Duration(milliseconds: 240),
                          curve: Curves.easeOutCubic,
                          left: leftInset + 30,
                          right: rightInset,
                          bottom: subtitleBottom,
                          child: Center(
                            child: IgnorePointer(
                              ignoring: controller.controlsLocked,
                              child: SubtitlePager(
                                controller: controller,
                                compact: compact,
                              ),
                            ),
                          ),
                        ),
                        if (!controller.controlsLocked) ...[
                          PlayerTopBar(
                            controller: controller,
                            onBack: controller.returnToPreviousSurface,
                            onLibrary: controller.returnToLibrary,
                            onOpenVideo: controller.openVideoPicker,
                            onSubtitleMenu: () =>
                                showSubtitleActions(context, controller),
                            onAccount: controller.localTranslationEnabled
                                ? null
                                : () => showAccountDialog(context, controller),
                            onSettings: () =>
                                showPlayerSettings(context, controller),
                          ),
                          if (controller.selectedWord != null)
                            Positioned(
                              left: dictionaryLeft,
                              bottom:
                                  subtitleBottom +
                                  (size.height < 650
                                      ? 84
                                      : compact
                                      ? 165
                                      : 195),
                              child: DictionaryOverlay(
                                entry: controller.selectedEntry,
                                word: controller.selectedWord,
                                loading: controller.lookupLoading,
                                partial: controller.dictionaryPreview,
                                status: controller.dictionaryStatus,
                                error: controller.dictionaryError,
                                saved:
                                    controller.selectedEntry != null &&
                                    controller.isSaved(
                                      controller.selectedEntry!.word,
                                    ),
                                onClose: controller.closeDictionary,
                                onRetry: controller.retryWordLookup,
                                onToggleSaved: controller.toggleSavedWord,
                                compact: compact,
                              ),
                            ),
                          SubtitleDrawer(
                            controller: controller,
                            width: drawerWidth,
                            top: denseLandscape ? 46 : 52,
                            bottom: osdHeight - 1,
                            dense: denseLandscape,
                            onSearch: () =>
                                showSubtitleSearch(context, controller),
                          ),
                          PlaylistDrawer(
                            controller: controller,
                            width: playlistWidth,
                            top: denseLandscape ? 46 : 52,
                            bottom: osdHeight - 1,
                            dense: denseLandscape,
                            onOpenFolder: controller.openMediaFolder,
                          ),
                          Positioned(
                            right: 5,
                            top: math.max(70, size.height / 2 - 112),
                            child: LearningToolRail(
                              controller: controller,
                              onSettings: () =>
                                  showPlayerSettings(context, controller),
                            ),
                          ),
                          PlaybackOsd(
                            controller: controller,
                            onSubtitleMenu: () =>
                                showSubtitleActions(context, controller),
                            onSourceMenu: () =>
                                showNetworkSourceDialog(context, controller),
                            compact: compact,
                            dense: denseLandscape,
                            onInteraction: _wakeControls,
                          ),
                        ] else if (_lockedButtonVisible)
                          Positioned(
                            left: 8,
                            top: size.height / 2 - 25,
                            child: Semantics(
                              button: true,
                              label: '解锁播放器控制',
                              child: IconButton.filledTonal(
                                onPressed: controller.toggleLock,
                                tooltip: '解锁控制',
                                icon: const Icon(Icons.lock_rounded),
                              ),
                            ),
                          ),
                        if (!controller.controlsLocked)
                          Positioned(
                            left: 8,
                            top: size.height / 2 - 22,
                            child: IconButton(
                              onPressed: controller.toggleLock,
                              tooltip: '锁定控制',
                              icon: const Icon(
                                Icons.lock_open_rounded,
                                color: AppColors.textMuted,
                                size: 19,
                              ),
                            ),
                          ),
                        ProcessingOverlay(controller: controller),
                        Positioned(
                          left: 20,
                          top: math.max(
                            0,
                            (size.height - gestureHudHeight) / 2,
                          ),
                          child: GestureLevelHud(
                            kind: GestureLevelKind.brightness,
                            value: controller.visualBrightness,
                            visible: _gestureHudVisible && _gestureOnLeft,
                            height: gestureHudHeight,
                          ),
                        ),
                        Positioned(
                          right: 20,
                          top: math.max(
                            0,
                            (size.height - gestureHudHeight) / 2,
                          ),
                          child: GestureLevelHud(
                            kind: GestureLevelKind.volume,
                            value: controller.volume / 100,
                            visible: _gestureHudVisible && !_gestureOnLeft,
                            height: gestureHudHeight,
                          ),
                        ),
                        Positioned(
                          top: MediaQuery.paddingOf(context).top + 58,
                          left: 12,
                          right: 12,
                          child: Center(
                            child: ConstrainedBox(
                              constraints: const BoxConstraints(maxWidth: 680),
                              child: AnimatedSwitcher(
                                duration: const Duration(milliseconds: 220),
                                switchInCurve: Curves.easeOutCubic,
                                switchOutCurve: Curves.easeInCubic,
                                transitionBuilder: (child, animation) =>
                                    FadeTransition(
                                      opacity: animation,
                                      child: SlideTransition(
                                        position: Tween<Offset>(
                                          begin: const Offset(0, -0.16),
                                          end: Offset.zero,
                                        ).animate(animation),
                                        child: child,
                                      ),
                                    ),
                                child: _topNotice == null
                                    ? const SizedBox.shrink(
                                        key: ValueKey('empty-player-notice'),
                                      )
                                    : _PlayerTopNotice(
                                        key: const ValueKey(
                                          'player-top-notice',
                                        ),
                                        message: _topNotice!,
                                        isError: _topNoticeIsError,
                                        onAction: _topNoticeAction,
                                      ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _VideoSurface extends StatelessWidget {
  const _VideoSurface({
    required this.controller,
    required this.onInteraction,
    required this.onVerticalDragStart,
    required this.onVerticalDragUpdate,
  });

  final LearningPlayerController controller;
  final VoidCallback onInteraction;
  final GestureDragStartCallback onVerticalDragStart;
  final GestureDragUpdateCallback onVerticalDragUpdate;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      key: const Key('player-video-surface'),
      behavior: HitTestBehavior.opaque,
      onTap: onInteraction,
      onDoubleTap: controller.togglePlay,
      onVerticalDragStart: onVerticalDragStart,
      onVerticalDragUpdate: onVerticalDragUpdate,
      child: controller.hasMedia
          ? Video(
              controller: controller.videoController,
              fit: BoxFit.contain,
              fill: Colors.black,
              controls: NoVideoControls,
              pauseUponEnteringBackgroundMode: true,
            )
          : Stack(
              fit: StackFit.expand,
              children: [
                Image.asset(
                  'assets/images/demo-poster.png',
                  fit: BoxFit.cover,
                  filterQuality: FilterQuality.high,
                ),
                const DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Color(0x24000000),
                        Color(0x00000000),
                        Color(0x59000000),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

class _PlayerTopNotice extends StatelessWidget {
  const _PlayerTopNotice({
    super.key,
    required this.message,
    required this.isError,
    required this.onAction,
  });

  final String message;
  final bool isError;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final tint = isError ? AppColors.danger : AppColors.amber;
    return Material(
      color: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        decoration: BoxDecoration(
          color: const Color(0xEE15181C),
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: tint.withValues(alpha: 0.38)),
          boxShadow: const [
            BoxShadow(
              color: Color(0x66000000),
              blurRadius: 20,
              offset: Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          children: [
            Icon(
              isError
                  ? Icons.error_outline_rounded
                  : Icons.info_outline_rounded,
              size: 19,
              color: tint,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                message,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: AppColors.ivory,
                  fontSize: 12,
                  height: 1.35,
                ),
              ),
            ),
            if (onAction != null) ...[
              const SizedBox(width: 8),
              TextButton(
                onPressed: onAction,
                style: TextButton.styleFrom(
                  foregroundColor: AppColors.amber,
                  minimumSize: const Size(0, 36),
                  padding: const EdgeInsets.symmetric(horizontal: 9),
                ),
                child: const Text('服务设置', style: TextStyle(fontSize: 12)),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
