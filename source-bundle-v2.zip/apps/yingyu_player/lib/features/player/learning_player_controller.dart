import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:window_manager/window_manager.dart';

import '../../data/android_storage_access.dart';
import '../../data/authenticated_media_proxy.dart';
import '../../data/cloud_source_store.dart';
import '../../data/demo_content.dart';
import '../../data/dictionary_service.dart';
import '../../data/embedded_subtitle_alignment.dart';
import '../../data/embedded_subtitle_service.dart';
import '../../data/local_dictionary.dart';
import '../../data/local_pipeline_service.dart';
import '../../data/local_translation_service.dart';
import '../../data/managed_openlist_media_service.dart';
import '../../data/media_cover_service.dart';
import '../../data/online_stream_service.dart';
import '../../data/openlist_media_service.dart';
import '../../data/pipeline_client.dart';
import '../../data/quark_drive_service.dart';
import '../../data/quark_share_service.dart';
import '../../data/settings_store.dart';
import '../../data/subtitle_parser.dart';
import '../../data/subtitle_writer.dart';
import '../../domain/models/billing.dart';
import '../../domain/models/cloud_media_source.dart';
import '../../domain/models/dictionary_entry.dart';
import '../../domain/models/media_playlist_item.dart';
import '../../domain/models/online_stream_source.dart';
import '../../domain/models/processing_state.dart';
import '../../domain/models/subtitle_cue.dart';

enum FrameInterpolationMode {
  off,
  balanced,
  smooth;

  static FrameInterpolationMode parse(String value) {
    return values.firstWhere(
      (mode) => mode.name == value,
      orElse: () => FrameInterpolationMode.off,
    );
  }

  String get label => switch (this) {
    FrameInterpolationMode.off => '关闭',
    FrameInterpolationMode.balanced => '流畅',
    FrameInterpolationMode.smooth => '更平滑',
  };

  String get description => switch (this) {
    FrameInterpolationMode.off => '保持视频原始帧率，资源占用最低',
    FrameInterpolationMode.balanced => '按屏幕刷新率补帧，兼顾清晰度与功耗',
    FrameInterpolationMode.smooth => '使用更柔和的时间滤镜，运动更连贯',
  };
}

enum LibrarySurface { movies, onlineMovies }

class LearningPlayerController extends ChangeNotifier {
  LearningPlayerController({
    required this.settings,
    this._parser = const SubtitleParser(),
    EmbeddedSubtitleService? embeddedSubtitleService,
    MediaCoverService? mediaCoverService,
    http.Client? onlineStreamClient,
    CloudSourceStore? cloudSourceStore,
    OpenListMediaService? openListMediaService,
    QuarkDriveService? quarkDriveService,
    QuarkShareService? quarkShareService,
    LocalTranslationService? localTranslationService,
  }) : player = Player(
         configuration: PlayerConfiguration(
           // A larger demuxer cache keeps nearby data available when subtitle
           // navigation seeks within high-bitrate remote videos. Keep Android
           // at 32 MiB to limit its forward/back cache memory; desktop can use
           // 128 MiB for 4K cloud streams. Local playback does not prefill this
           // entire limit.
           bufferSize: Platform.isAndroid
               ? 32 * 1024 * 1024
               : 128 * 1024 * 1024,
           logLevel: MPVLogLevel.warn,
         ),
       ) {
    videoController = VideoController(player);
    _onlineStreamClient = onlineStreamClient ?? http.Client();
    _embeddedSubtitles =
        embeddedSubtitleService ??
        EmbeddedSubtitleService(_parser, httpClient: _onlineStreamClient);
    _mediaCovers = mediaCoverService ?? MediaCoverService();
    _onlineStreams = OnlineStreamService(_onlineStreamClient);
    _openList =
        openListMediaService ?? OpenListMediaService(_onlineStreamClient);
    _quarkDrive = quarkDriveService ?? QuarkDriveService(_onlineStreamClient);
    _quarkShares = quarkShareService ?? QuarkShareService(_onlineStreamClient);
    _cloudSourceStore = cloudSourceStore ?? CloudSourceStore();
    _localTranslation = localTranslationService ?? LocalTranslationService();
    _pipeline = PipelineClient(baseUrl: settings.pipelineBaseUrl);
    _managedOpenList = ManagedOpenListMediaService(() => _pipeline);
    _dictionary = DictionaryService(_pipeline);
    _setCues(demoCues);
    selectedWord = 'weather';
    selectedEntry = localDictionary['weather'];
    isFullscreen = Platform.isAndroid;
    subtitleBottomOffset = settings.subtitleBottomOffset;
    subtitleOriginalScale = settings.subtitleOriginalScale;
    subtitleTranslationScale = settings.subtitleTranslationScale;
    subtitleTranslationFirst = settings.subtitleTranslationFirst;
    hideHearingImpairedSubtitles = settings.hideHearingImpairedSubtitles;
    frameInterpolationMode = FrameInterpolationMode.parse(
      settings.frameInterpolationMode,
    );
    localTranslationEnabled = settings.localTranslationEnabled;
    localModelDirectory = settings.localModelDirectory;
    localModelName = settings.localModelName;
    libraryFolders = List<String>.from(settings.libraryFolders);
    onlineStreamSources = _readOnlineSources(settings.onlineStreamSources);
    _bindPlayer();
  }

  static const List<String> mediaExtensions = [
    'mkv',
    'mp4',
    'avi',
    'mov',
    'webm',
    'm4v',
    'ts',
    'mts',
    'm2ts',
    'mpeg',
    'mpg',
    'wmv',
    'flv',
    'vob',
    '3gp',
    'ogv',
    'rmvb',
    'mp3',
    'flac',
    'wav',
  ];
  static const List<double> playbackRates = [0.5, 0.75, 1, 1.25, 1.5, 2];
  // Keep the first navigation result small. Cloud MP4 subtitles are fetched
  // directly from their sample offsets, then adjacent windows are prefetched
  // as playback advances.
  static const _embeddedWindowSpan = Duration(seconds: 45);
  static const _embeddedWindowPadding = Duration(seconds: 8);

  final SettingsStore settings;
  final SubtitleParser _parser;
  final Player player;
  late final VideoController videoController;
  late final EmbeddedSubtitleService _embeddedSubtitles;
  late final MediaCoverService _mediaCovers;
  late final http.Client _onlineStreamClient;
  late final OnlineStreamService _onlineStreams;
  late final OpenListMediaService _openList;
  late final QuarkDriveService _quarkDrive;
  late final QuarkShareService _quarkShares;
  late final LocalTranslationService _localTranslation;
  late final ManagedOpenListMediaService _managedOpenList;
  late final CloudSourceStore _cloudSourceStore;
  final AuthenticatedMediaProxy _authenticatedMediaProxy =
      AuthenticatedMediaProxy();
  late PipelineClient _pipeline;
  late DictionaryService _dictionary;
  final AndroidStorageAccess _androidStorage = const AndroidStorageAccess();

  final ProcessingState processing = ProcessingState();
  final List<StreamSubscription<dynamic>> _subscriptions = [];
  final Set<String> savedWords = {};
  final Set<String> _embeddedWindowCacheKeys = {};
  final Set<String> _embeddedWindowLoadingKeys = {};
  final Set<String> _embeddedWindowPrefetchKeys = {};

  List<SubtitleCue> _cues = [];
  List<SubtitleCue> _rawCues = [];
  List<MediaPlaylistItem> playlist = [];

  /// Files discovered by the most recent share transfer.  The online movie
  /// screen uses this to let the user choose an episode before playback
  /// instead of always starting the first file in a season share.
  List<MediaPlaylistItem> lastImportedCloudItems = const [];
  List<String> libraryFolders = [];
  List<MediaPlaylistItem> libraryItems = [];
  List<OnlineStreamSource> onlineStreamSources = [];
  List<MediaPlaylistItem> onlineStreamItems = [];
  List<MediaPlaylistItem> onlineMoviePlaybackItems = [];

  /// Alternate direct URLs for the currently selected online episode.  This
  /// is separate from [playlist] so changing a route never breaks previous /
  /// next episode navigation.
  List<MediaPlaylistItem> networkSourceItems = [];
  List<CloudMediaSource> cloudSources = [];
  List<MediaPlaylistItem> cloudMediaItems = [];
  List<EmbeddedSubtitleTrack> embeddedSubtitleTracks = [];
  Duration position = const Duration(seconds: 82);
  Duration duration = const Duration(minutes: 3, seconds: 42);
  bool isPlaying = false;
  bool isBuffering = false;
  bool hasMedia = false;
  bool drawerOpen = true;
  bool playlistOpen = false;
  bool osdVisible = true;
  bool sentenceLoop = false;
  bool controlsLocked = false;
  bool isFullscreen = false;
  bool subtitleLoading = false;
  bool libraryLoading = false;
  bool onlineStreamsLoading = false;
  bool cloudMediaLoading = false;
  bool downloadLoading = false;
  double? downloadProgress;
  LibrarySurface librarySurface = LibrarySurface.movies;
  bool _libraryRefreshPending = false;
  bool _mediaCompleted = false;
  bool _playbackSourceReady = false;
  bool _playbackDurationReady = false;
  Duration? _pendingResumePosition;
  String? _pendingResumePath;
  bool storageAccessGranted = !Platform.isAndroid;
  bool storageAccessChecking = false;
  double playbackRate = 1;
  double volume = 72;
  double visualBrightness = 1;
  double subtitleBottomOffset = 0;
  double subtitleOriginalScale = 1;
  double subtitleTranslationScale = 1;
  bool subtitleTranslationFirst = false;
  bool hideHearingImpairedSubtitles = false;
  FrameInterpolationMode frameInterpolationMode = FrameInterpolationMode.off;
  bool localTranslationEnabled = false;
  bool localTranslationLoading = false;
  bool localTranslationReady = false;
  String localModelDirectory = '';
  String localModelName = '';
  List<LocalModelInfo> localModels = const [];
  LocalModelRuntime? localModelRuntime;
  String? localTranslationError;
  SubtitleDisplayMode subtitleMode = SubtitleDisplayMode.bilingual;
  String mediaTitle = 'The London Story.mkv';
  String mediaMeta = '1080p · EN';
  String? mediaPath;
  DictionaryEntry? selectedEntry;
  String? selectedWord;
  bool lookupLoading = false;
  String? dictionaryError;
  Map<String, String> dictionaryPreview = const {};
  String? dictionaryStatus;
  bool billingLoading = false;
  BillingOverview? billingOverview;
  BillingAccount? accountSession;
  bool accountLoading = false;
  bool emailCodeLoading = false;
  String? accountError;
  UsageCharge? lastUsageCharge;
  String? billingError;
  String? lastError;
  String? lastNotice;
  int? selectedEmbeddedSubtitleOrdinal;
  int? selectedOriginalSubtitleOrdinal;
  int? selectedTranslationSubtitleOrdinal;

  bool get externalCheckoutAllowed =>
      Platform.isWindows ||
      (Platform.isAndroid &&
          const bool.fromEnvironment(
            'ALLOW_EXTERNAL_CHECKOUT',
            defaultValue: false,
          ));

  int _currentCueIndex = 3;
  int _mediaLoadToken = 0;
  int _coverLoadToken = 0;
  int _lookupToken = 0;
  String _selectedSentence = '';
  Timer? _demoTicker;
  int _lastSavedPositionSeconds = -1;
  bool _activeMediaIsLive = false;
  bool _activeNetworkPlayback = false;
  bool _networkRetrying = false;
  int _networkSourceIndex = 0;
  int _activePlaylistIndex = -1;
  String? _activePlaybackUrl;
  Map<String, String> _activePlaybackHeaders = const {};
  int _embeddedSelectionRevision = 0;
  bool _embeddedWindowedMode = false;
  Duration? _embeddedSubtitleAlignmentOffset;

  void _setCues(Iterable<SubtitleCue> cues) {
    _rawCues = SubtitleCueFilter.coalesceNearDuplicates(cues);
    _cues = hideHearingImpairedSubtitles
        ? SubtitleCueFilter.withoutHearingImpaired(_rawCues)
        : List<SubtitleCue>.from(_rawCues);
  }

  void _refreshVisibleCues() {
    _cues = hideHearingImpairedSubtitles
        ? SubtitleCueFilter.withoutHearingImpaired(_rawCues)
        : List<SubtitleCue>.from(_rawCues);
  }

  List<SubtitleCue> get cues => List.unmodifiable(_cues);
  SubtitleCue? get currentCue =>
      _currentCueIndex >= 0 && _currentCueIndex < _cues.length
      ? _cues[_currentCueIndex]
      : null;
  int get currentCueIndex => _currentCueIndex;
  int get currentPlaylistIndex {
    if (_activePlaylistIndex >= 0 &&
        _activePlaylistIndex < playlist.length &&
        playlist[_activePlaylistIndex].path == mediaPath) {
      return _activePlaylistIndex;
    }
    return playlist.indexWhere((item) => item.path == mediaPath);
  }

  bool get hasPreviousPlaylistItem => currentPlaylistIndex > 0;
  bool get hasNextPlaylistItem =>
      currentPlaylistIndex >= 0 && currentPlaylistIndex < playlist.length - 1;
  bool get hasNetworkSourceAlternatives =>
      _activeNetworkPlayback && networkSourceItems.length > 1;
  int get currentNetworkSourceIndex => _networkSourceIndex;
  List<MediaPlaylistItem> get availableNetworkSources =>
      List.unmodifiable(networkSourceItems);
  List<MediaPlaylistItem> get movieLibraryItems => [
    ...libraryItems,
    ...cloudMediaItems,
  ];

  List<MediaPlaylistItem> get allKnownMediaItems => [
    ...movieLibraryItems,
    ...onlineMoviePlaybackItems,
  ];

  List<MediaPlaylistItem> get recentMediaItems {
    final byPath = {for (final item in allKnownMediaItems) item.path: item};
    return [
      for (final path in settings.recentMediaPaths)
        byPath[path] ?? _historyItemForPath(path),
    ];
  }

  List<MediaPlaylistItem> get favoriteMediaItems {
    final byPath = {for (final item in allKnownMediaItems) item.path: item};
    return [
      for (final path in settings.favoriteMediaPaths)
        byPath[path] ?? _historyItemForPath(path),
    ];
  }

  bool isFavorite(String path) => settings.favoriteMediaPaths.contains(path);

  Future<void> toggleFavorite(MediaPlaylistItem item) async {
    _rememberMediaMetadata(item);
    if (isFavorite(item.path)) {
      settings.favoriteMediaPaths.remove(item.path);
      lastNotice = '已取消收藏“${item.title}”。';
    } else {
      settings.favoriteMediaPaths.insert(0, item.path);
      lastNotice = '已收藏“${item.title}”。';
    }
    await settings.save();
    notifyListeners();
  }

  MediaPlaylistItem _historyItemForPath(String path) {
    final stored = MediaPlaylistItem.fromJson(settings.mediaHistory[path]);
    if (stored != null) return stored;
    final title = path
        .split(RegExp(r'[/\\]'))
        .where((part) => part.isNotEmpty)
        .lastOrNull;
    return MediaPlaylistItem(
      path: path,
      title: title == null || title.isEmpty ? path : title,
      isOnline: path.startsWith('http://') || path.startsWith('https://'),
    );
  }

  void _rememberMediaMetadata(MediaPlaylistItem item) {
    settings.mediaHistory[item.path] = item.toJson();
    if (settings.mediaHistory.length <= 240) return;
    final keep = <String>{
      ...settings.recentMediaPaths.take(20),
      ...settings.favoriteMediaPaths,
    };
    for (final path in settings.mediaHistory.keys.toList()) {
      if (settings.mediaHistory.length <= 240) break;
      if (!keep.contains(path)) settings.mediaHistory.remove(path);
    }
  }

  List<MediaPlaylistItem> get continueWatchingItems => recentMediaItems
      .where((item) {
        final value = savedProgressFor(item.path);
        return value >= 0.01 && value < 0.97;
      })
      .toList(growable: false);

  double savedProgressFor(String path) {
    final positionMs = _savedPlaybackValue(settings.playbackPositionsMs, path);
    final durationMs = _savedPlaybackValue(settings.playbackDurationsMs, path);
    if (durationMs <= 0) return 0;
    return (positionMs / durationMs).clamp(0, 1);
  }

  int _savedPlaybackValue(Map<String, int> values, String path) {
    final exact = values[path];
    if (exact != null) return exact;
    if (!Platform.isWindows) return 0;
    for (final entry in values.entries) {
      if (entry.key.toLowerCase() == path.toLowerCase()) return entry.value;
    }
    return 0;
  }

  void _prepareResumePosition(String path, {required bool allowResume}) {
    _clearPendingResume();
    if (!allowResume) return;
    final milliseconds = _savedPlaybackValue(
      settings.playbackPositionsMs,
      path,
    );
    if (milliseconds < 5000) return;
    _pendingResumePath = path;
    _pendingResumePosition = Duration(milliseconds: milliseconds);
    final savedDurationMs = _savedPlaybackValue(
      settings.playbackDurationsMs,
      path,
    );
    if (savedDurationMs > 0) {
      duration = Duration(milliseconds: savedDurationMs);
    }
    // Show the saved playhead immediately while the new source is resolving.
    // The actual player seek is performed after its duration becomes known.
    position = _pendingResumePosition!;
  }

  void _clearPendingResume() {
    _pendingResumePosition = null;
    _pendingResumePath = null;
  }

  Future<void> _restoreSavedPosition(String path, int loadToken) async {
    final requested = _pendingResumePosition;
    if (requested == null || _pendingResumePath != path) return;
    var knownDuration = _playbackDurationReady ? duration : Duration.zero;
    if (knownDuration <= Duration.zero) {
      try {
        knownDuration = await player.stream.duration
            .firstWhere((value) => value > Duration.zero)
            .timeout(const Duration(seconds: 8));
      } on TimeoutException {
        // Some remote streams reveal their duration only after playback starts.
        // Keep the stored timestamp and still attempt to seek at the timeout.
      }
    }
    if (loadToken != _mediaLoadToken ||
        mediaPath != path ||
        _pendingResumePath != path ||
        _pendingResumePosition != requested) {
      return;
    }
    if (_playbackDurationReady && duration > Duration.zero) {
      knownDuration = duration;
    } else if (knownDuration <= Duration.zero && duration > Duration.zero) {
      // If the stream has not reported yet, this is the locally saved duration
      // from the previous session and is still a useful seek clamp.
      knownDuration = duration;
    }
    if (_pendingResumePosition != requested) return;
    final targetMilliseconds = knownDuration <= Duration.zero
        ? requested.inMilliseconds
        : math
              .min(
                requested.inMilliseconds,
                math.max(0, knownDuration.inMilliseconds - 300),
              )
              .toInt();
    final target = Duration(milliseconds: targetMilliseconds);
    try {
      await player.seek(target);
    } catch (_) {
      _clearPendingResume();
      return;
    }
    if (loadToken != _mediaLoadToken ||
        mediaPath != path ||
        _pendingResumePosition != requested) {
      return;
    }
    _clearPendingResume();
    position = target;
    if (knownDuration > Duration.zero) duration = knownDuration;
    _lastSavedPositionSeconds = target.inSeconds;
    _syncCurrentCue(force: true);
    notifyListeners();
  }

  int libraryItemCount(String folder) =>
      libraryItems.where((item) => _isInsideFolder(item.path, folder)).length;
  EmbeddedSubtitleTrack? get selectedEmbeddedSubtitleTrack {
    final ordinal = selectedEmbeddedSubtitleOrdinal;
    if (ordinal == null) return null;
    for (final track in embeddedSubtitleTracks) {
      if (track.ordinal == ordinal) return track;
    }
    return null;
  }

  EmbeddedSubtitleTrack? get selectedOriginalSubtitleTrack =>
      _trackForOrdinal(selectedOriginalSubtitleOrdinal);

  EmbeddedSubtitleTrack? get selectedTranslationSubtitleTrack =>
      _trackForOrdinal(selectedTranslationSubtitleOrdinal);

  EmbeddedSubtitleTrack? _trackForOrdinal(int? ordinal) {
    if (ordinal == null) return null;
    return embeddedSubtitleTracks
        .where((track) => track.ordinal == ordinal)
        .firstOrNull;
  }

  String get subtitleStatusLabel {
    if (!hasMedia) return 'SeedASR 2.0 · 双语字幕';
    final embedded = selectedEmbeddedSubtitleTrack;
    if (embedded != null) {
      if (embedded.isGenerated) {
        return '外挂 ${embedded.codec.toUpperCase()} · 译文轨';
      }
      final mode = _cues.isEmpty
          ? '原生显示'
          : _isEffectivelyBilingual(_cues)
          ? '双语字幕'
          : '文本字幕';
      return '内嵌 ${embedded.codec.toUpperCase()} · $mode';
    }
    if (subtitleLoading && embeddedSubtitleTracks.isNotEmpty) {
      return '内嵌字幕 · 正在载入当前片段';
    }
    if (_cues.isEmpty) return '未载入字幕';
    return _isEffectivelyBilingual(_cues) ? '双语字幕' : '单语字幕';
  }

  double get progress {
    if (duration.inMilliseconds <= 0) return 0;
    return (position.inMilliseconds / duration.inMilliseconds).clamp(0, 1);
  }

  void _bindPlayer() {
    _subscriptions
      ..add(
        player.stream.position.listen((value) {
          if (!hasMedia || !_playbackSourceReady) return;
          final pendingResume = _pendingResumePosition;
          if (_pendingResumePath == mediaPath &&
              pendingResume != null &&
              value + const Duration(seconds: 2) < pendingResume) {
            return;
          }
          position = value;
          _syncCurrentCue();
          if (_embeddedWindowedMode) {
            unawaited(_ensureEmbeddedSubtitleWindow(value));
          }
          _recordPlaybackProgress();
          notifyListeners();
        }),
      )
      ..add(
        player.stream.duration.listen((value) {
          if (!hasMedia || !_playbackSourceReady || value <= Duration.zero) {
            return;
          }
          duration = value;
          _playbackDurationReady = true;
          final pendingResume = _pendingResumePosition;
          if (_pendingResumePath == mediaPath && pendingResume != null) {
            position = Duration(
              milliseconds: math
                  .min(
                    pendingResume.inMilliseconds,
                    math.max(0, value.inMilliseconds - 300),
                  )
                  .toInt(),
            );
          }
          final path = mediaPath;
          if (path != null) {
            settings.playbackDurationsMs[path] = value.inMilliseconds;
          }
          notifyListeners();
        }),
      )
      ..add(
        player.stream.playing.listen((value) {
          if (!hasMedia || !_playbackSourceReady) return;
          isPlaying = value;
          notifyListeners();
        }),
      )
      ..add(
        player.stream.buffering.listen((value) {
          isBuffering = value;
          notifyListeners();
        }),
      )
      ..add(
        player.stream.volume.listen((value) {
          volume = value.clamp(0, 100);
          notifyListeners();
        }),
      )
      ..add(
        player.stream.rate.listen((value) {
          playbackRate = value;
          notifyListeners();
        }),
      )
      ..add(
        player.stream.error.listen((value) {
          if (!_playbackSourceReady) return;
          lastError = _friendlyPlaybackError(value);
          if (_activeNetworkPlayback &&
              networkSourceItems.length > 1 &&
              !_networkRetrying) {
            // TVBox/Baohe-style direct playback: if a route dies, move to
            // the next known direct URL instead of leaving a dead player.
            unawaited(_tryNextNetworkSource());
          }
          notifyListeners();
        }),
      )
      ..add(
        player.stream.completed.listen((value) {
          if (!value || !_playbackSourceReady) return;
          final path = mediaPath;
          if (path == null || _activeMediaIsLive) return;
          _mediaCompleted = true;
          _lastSavedPositionSeconds = position.inSeconds;
          settings.playbackPositionsMs[path] = 0;
          unawaited(settings.save());
          if (hasNextPlaylistItem) {
            unawaited(openAdjacentPlaylistItem(1));
          }
        }),
      );
  }

  Future<void> initializeLibrary() async {
    if (Platform.isAndroid) {
      await refreshStorageAccessStatus();
      if (!storageAccessGranted) return;
    }
    await refreshLibrary();
  }

  /// Restores the optional local translation mode after the first frame.  It
  /// intentionally does not require an account or contact the remote
  /// subtitle service; Ollama is loaded only when the user enabled this mode.
  Future<void> initializeLocalTranslation() async {
    if (!localTranslationEnabled) return;
    await setLocalTranslationEnabled(
      true,
      modelsDirectory: localModelDirectory,
      modelName: localModelName,
      persist: false,
    );
  }

  Future<List<LocalModelInfo>> refreshLocalModels({
    String? modelsDirectory,
  }) async {
    final directory = (modelsDirectory ?? localModelDirectory).trim();
    if (directory.isEmpty) {
      localTranslationError = '请先填写 Ollama 模型目录。';
      localModels = const [];
      notifyListeners();
      return const [];
    }
    try {
      final models = await _localTranslation.listModels(
        modelsDirectory: directory,
      );
      localModels = models;
      localTranslationError = null;
      notifyListeners();
      return models;
    } catch (error) {
      localTranslationError = error.toString();
      localModels = const [];
      notifyListeners();
      return const [];
    }
  }

  Future<bool> setLocalTranslationEnabled(
    bool enabled, {
    String? modelsDirectory,
    String? modelName,
    bool persist = true,
  }) async {
    if (localTranslationLoading) return false;
    final directory = (modelsDirectory ?? localModelDirectory).trim();
    final selectedModel = (modelName ?? localModelName).trim();
    localTranslationLoading = true;
    localTranslationError = null;
    notifyListeners();
    try {
      if (enabled) {
        final selected = await _localTranslation.ensureReady(
          modelsDirectory: directory,
          modelName: selectedModel,
        );
        localTranslationEnabled = true;
        localTranslationReady = true;
        localModelRuntime = _localTranslation.runtime;
        localModelDirectory = directory;
        localModelName = selected.name;
        settings
          ..localTranslationEnabled = true
          ..localModelDirectory = directory
          ..localModelName = selected.name;
        _setRemoteModelAccess(enabled: false);
        lastUsageCharge = null;
        localModels = await _localTranslation.listModels(
          modelsDirectory: directory,
        );
        lastNotice = '已加载本地模型 ${selected.name}；字幕翻译不需要登录且不扣除点数。';
      } else {
        await _localTranslation.unload();
        // The bundled remote pipeline is deliberately not started while
        // local mode is active.  Start it only when the user explicitly
        // switches back to network processing.
        await LocalPipelineService.ensureStarted(settings.pipelineBaseUrl);
        localTranslationEnabled = false;
        localTranslationReady = false;
        localModelRuntime = null;
        localModelDirectory = directory;
        localModelName = selectedModel;
        settings
          ..localTranslationEnabled = false
          ..localModelDirectory = directory
          ..localModelName = selectedModel;
        _setRemoteModelAccess(enabled: true);
        lastNotice = '本地模型已卸载，后续翻译将使用影语服务。';
      }
      if (persist) await settings.save();
      return true;
    } catch (error) {
      localTranslationError = error.toString();
      if (enabled) {
        localTranslationReady = false;
        localTranslationEnabled = false;
        localModelRuntime = null;
        try {
          await _localTranslation.unload();
        } catch (_) {
          // Preserve the original activation error in the UI.
        }
        await LocalPipelineService.ensureStarted(settings.pipelineBaseUrl);
        _setRemoteModelAccess(enabled: true);
      }
      return false;
    } finally {
      localTranslationLoading = false;
      notifyListeners();
    }
  }

  void _setRemoteModelAccess({required bool enabled}) {
    _pipeline.close();
    _pipeline = PipelineClient(baseUrl: settings.pipelineBaseUrl);
    _dictionary = DictionaryService(_pipeline);
    if (!enabled) {
      accountSession = null;
      accountError = null;
      billingOverview = null;
      billingError = null;
      accountLoading = false;
      emailCodeLoading = false;
      billingLoading = false;
    }
  }

  Future<void> initializeCloudLibrary() async {
    // Keep the controller-owned collection mutable because add/remove source
    // operations run immediately after initialization.
    cloudSources = List<CloudMediaSource>.from(await _cloudSourceStore.read());
    // Android uses the QR-only direct Quark connector. Do not attempt to
    // contact legacy OpenList entries that may have been copied from Windows.
    if (Platform.isAndroid) {
      cloudSources = cloudSources
          .where((source) => source.isDirectQuark)
          .toList(growable: true);
      cloudSources.add(
        CloudMediaSource(
          id: ManagedOpenListMediaService.sourceId,
          name: '云端网盘',
          baseUrl: settings.pipelineBaseUrl,
          apiToken: 'account-session',
          provider: 'managed_openlist',
        ),
      );
    }
    if (cloudSources.isNotEmpty) await refreshCloudMedia();
  }

  Future<void> addDirectQuarkSource(String cookie) async {
    clearMessages();
    final normalizedCookie = cookie.trim();
    final names = RegExp(
      r'(?:^|;\s*)(__kps|__pus|__uid)=',
    ).allMatches(normalizedCookie);
    if (normalizedCookie.isEmpty || names.isEmpty) {
      lastError = '夸克扫码成功但没有返回有效登录凭据，请重新扫码。';
      notifyListeners();
      return;
    }
    cloudMediaLoading = true;
    notifyListeners();
    final source = CloudMediaSource(
      id: 'quark-direct',
      name: '夸克',
      baseUrl: QuarkDriveService.directBaseUrl,
      apiToken: 'qr-cookie',
      rootPath: '0',
      provider: 'quark_direct',
      transferCredential: normalizedCookie,
    );
    try {
      _quarkDrive.resetSession(source);
      final preview = await _quarkDrive.load(source);
      final storedSource = source.copyWith(
        transferCredential: _quarkDrive.currentCookie(source),
      );
      cloudSources = [
        ...cloudSources.where((item) => !item.isDirectQuark),
        storedSource,
      ];
      await _cloudSourceStore.write(cloudSources);
      cloudMediaItems.removeWhere((item) => item.cloudSourceId == source.id);
      if (!Platform.isAndroid) cloudMediaItems.addAll(preview);
      lastError = null;
      lastNotice = '已连接夸克，发现 ${preview.length} 个影视文件。';
    } on QuarkDriveException catch (error) {
      lastError = error.message;
    } on CloudSourceStoreException catch (error) {
      lastError = error.message;
    } on Object catch (error) {
      lastError = '连接夸克网盘失败：$error';
    } finally {
      cloudMediaLoading = false;
    }
    notifyListeners();
  }

  Future<void> addCloudSource({
    required String name,
    required String baseUrl,
    required String apiToken,
    String rootPath = '/',
    String provider = 'openlist',
    String transferCredential = '',
    String transferFolderId = '0',
  }) async {
    clearMessages();
    final normalizedUrl = baseUrl.trim().replaceAll(RegExp(r'/$'), '');
    final uri = Uri.tryParse(normalizedUrl);
    if (name.trim().isEmpty ||
        uri == null ||
        (uri.scheme != 'http' && uri.scheme != 'https') ||
        apiToken.trim().isEmpty) {
      lastError = '请填写名称、有效的 OpenList 地址和 API Token。';
      notifyListeners();
      return;
    }
    final source = CloudMediaSource(
      id: DateTime.now().microsecondsSinceEpoch.toRadixString(36),
      name: name.trim(),
      baseUrl: normalizedUrl,
      apiToken: apiToken.trim(),
      rootPath: rootPath.trim().isEmpty ? '/' : rootPath.trim(),
      provider: provider,
      transferCredential: transferCredential.trim(),
      transferFolderId: transferFolderId.trim().isEmpty
          ? '0'
          : transferFolderId.trim(),
    );
    try {
      final preview = await _openList.load(source);
      final replacedIds = cloudSources
          .where(
            (item) =>
                item.baseUrl.toLowerCase() == source.baseUrl.toLowerCase() &&
                item.rootPath == source.rootPath,
          )
          .map((item) => item.id)
          .toSet();
      cloudSources.removeWhere(
        (item) =>
            item.baseUrl.toLowerCase() == source.baseUrl.toLowerCase() &&
            item.rootPath == source.rootPath,
      );
      cloudSources.add(source);
      await _cloudSourceStore.write(cloudSources);
      cloudMediaItems.removeWhere(
        (item) => replacedIds.contains(item.cloudSourceId),
      );
      cloudMediaItems.addAll(preview);
      lastNotice = '已连接“${source.name}”，发现 ${preview.length} 个影视文件。';
    } on OpenListException catch (error) {
      lastError = error.message;
    } on QuarkDriveException catch (error) {
      lastError = error.message;
    } on CloudSourceStoreException catch (error) {
      lastError = error.message;
    } on Object catch (error) {
      lastError = '连接网盘失败：$error';
    }
    notifyListeners();
  }

  Future<QuarkQrLoginSession> startQuarkQrLogin() =>
      _quarkShares.startQrLogin();

  Future<QuarkQrLoginResult> pollQuarkQrLogin(QuarkQrLoginSession session) =>
      _quarkShares.pollQrLogin(session);

  Future<void> updateQuarkLogin(CloudMediaSource source, String cookie) async {
    final index = cloudSources.indexWhere((item) => item.id == source.id);
    if (index < 0) return;
    cloudSources[index] = source.copyWith(transferCredential: cookie.trim());
    if (source.isDirectQuark) {
      _quarkDrive.resetSession(cloudSources[index]);
    }
    try {
      await _cloudSourceStore.write(cloudSources);
      lastNotice = '“${source.name}”的夸克扫码登录已更新。';
      lastError = null;
    } on CloudSourceStoreException catch (error) {
      lastError = error.message;
    }
    if (source.isDirectQuark && lastError == null) {
      await refreshCloudMedia();
    }
    notifyListeners();
  }

  Future<bool> importQuarkShareAndPlay({
    required CloudMediaSource source,
    required String shareUrl,
    required String titleHint,
    bool autoPlay = true,
  }) async {
    if (cloudMediaLoading) return false;
    clearMessages();
    cloudMediaLoading = true;
    notifyListeners();
    final refreshedSourceId = Platform.isAndroid && source.isDirectQuark
        ? ManagedOpenListMediaService.sourceId
        : source.id;
    final previousPaths = cloudMediaItems
        .where((item) => item.cloudSourceId == refreshedSourceId)
        .map((item) => item.remotePath)
        .whereType<String>()
        .toSet();
    try {
      final imported = await _quarkShares.importShare(source, shareUrl);
      final expectedNames = imported.sharedNames
          .where(_isVideoMediaName)
          .map(_normalizedMediaName)
          .where((value) => value.isNotEmpty)
          .toSet();
      List<MediaPlaylistItem> refreshed = const [];
      // Quark may finish the transfer task before OpenList invalidates every
      // directory cache. Refresh and verify the imported episode names rather
      // than presenting a partial season after the first scan.
      for (var attempt = 0; attempt < 6; attempt++) {
        if (attempt > 0) {
          await Future<void>.delayed(
            Duration(milliseconds: 650 + attempt * 250),
          );
        }
        refreshed = Platform.isAndroid && source.isDirectQuark
            ? await _managedOpenList.load(refresh: true)
            : source.isDirectQuark
            ? await _quarkDrive.load(source)
            : await _openList.load(source);
        final foundNames = refreshed
            .map((item) => _normalizedMediaName(item.title))
            .where(expectedNames.contains)
            .toSet();
        if (expectedNames.isNotEmpty &&
            foundNames.length >= expectedNames.length) {
          break;
        }
      }
      cloudMediaItems.removeWhere(
        (item) => item.cloudSourceId == refreshedSourceId,
      );
      cloudMediaItems.addAll(refreshed);
      final added = refreshed
          .where(
            (item) =>
                item.remotePath != null &&
                !previousPaths.contains(item.remotePath),
          )
          .toList();
      final matched = refreshed
          .where(
            (item) => expectedNames.contains(_normalizedMediaName(item.title)),
          )
          .toList();
      final addedMatched = added
          .where(
            (item) => expectedNames.contains(_normalizedMediaName(item.title)),
          )
          .toList();
      final candidates = addedMatched.isNotEmpty
          ? addedMatched
          : matched.isNotEmpty
          ? matched
          : added.isNotEmpty
          ? added
          : refreshed;
      if (candidates.isEmpty) {
        if (source.isDirectQuark) {
          throw const QuarkDriveException('转存已完成，但夸克网盘暂未同步到影视文件。');
        }
        throw const OpenListException('转存已完成，但 OpenList 还没有扫描到影视文件。');
      }
      final hints = [
        titleHint,
        ...imported.sharedNames,
      ].map(_normalizedMediaName).where((value) => value.isNotEmpty).toList();
      candidates.sort((first, second) {
        int score(MediaPlaylistItem item) {
          final title = _normalizedMediaName(item.title);
          if (hints.any((hint) => title == hint)) return 0;
          if (hints.any(
            (hint) => title.contains(hint) || hint.contains(title),
          )) {
            return 1;
          }
          return previousPaths.contains(item.remotePath) ? 3 : 2;
        }

        final byScore = score(first).compareTo(score(second));
        if (byScore != 0) return byScore;
        final byEpisode = _episodeNumber(
          first.title,
        ).compareTo(_episodeNumber(second.title));
        return byEpisode != 0 ? byEpisode : first.title.compareTo(second.title);
      });
      lastImportedCloudItems = List<MediaPlaylistItem>.unmodifiable(candidates);
      cloudMediaLoading = false;
      if (autoPlay) {
        await openOnlineStream(candidates.first, relatedItems: refreshed);
        lastNotice = '已转存到“${source.name}”并开始播放。';
      } else {
        lastNotice = '已转存到“${source.name}”，请选择要播放的剧集。';
      }
      notifyListeners();
      return true;
    } on QuarkShareException catch (error) {
      lastError = error.message;
    } on OpenListException catch (error) {
      lastError = error.message;
    } on QuarkDriveException catch (error) {
      lastError = error.message;
    } on Object catch (error) {
      lastError = '转存或播放失败：$error';
    }
    cloudMediaLoading = false;
    notifyListeners();
    return false;
  }

  static String _normalizedMediaName(String value) => value
      .toLowerCase()
      .replaceAll(RegExp(r'\.[a-z0-9]{2,5}$'), '')
      .replaceAll(RegExp(r'[^\p{L}\p{N}]+', unicode: true), '');

  static int _episodeNumber(String value) {
    final seasonEpisode = RegExp(
      r'\bS\d{1,2}E(\d{1,3})\b',
      caseSensitive: false,
    ).firstMatch(value);
    if (seasonEpisode != null) {
      return int.tryParse(seasonEpisode.group(1) ?? '') ?? 1 << 20;
    }
    final chineseEpisode = RegExp(r'第\s*(\d{1,3})\s*集').firstMatch(value);
    return int.tryParse(chineseEpisode?.group(1) ?? '') ?? 1 << 20;
  }

  static bool _isVideoMediaName(String value) {
    final dot = value.lastIndexOf('.');
    if (dot < 0) return false;
    return const {
      'mkv',
      'mp4',
      'avi',
      'mov',
      'webm',
      'm4v',
      'ts',
      'mts',
      'm2ts',
      'mpeg',
      'mpg',
      'wmv',
      'flv',
      'vob',
      'rmvb',
    }.contains(value.substring(dot + 1).toLowerCase());
  }

  Future<void> removeCloudSource(CloudMediaSource source) async {
    cloudSources.removeWhere((item) => item.id == source.id);
    cloudMediaItems.removeWhere((item) => item.cloudSourceId == source.id);
    await _cloudSourceStore.write(cloudSources);
    lastNotice = '已移除网盘“${source.name}”。';
    notifyListeners();
  }

  Future<void> refreshCloudMedia() async {
    if (cloudMediaLoading) return;
    cloudMediaLoading = true;
    notifyListeners();
    final refreshed = <MediaPlaylistItem>[];
    final failed = <String>[];
    var cookieChanged = false;
    for (var index = 0; index < cloudSources.length; index++) {
      final source = cloudSources[index];
      try {
        if (source.isManagedOpenList) {
          refreshed.addAll(await _managedOpenList.load());
        } else if (Platform.isAndroid && source.isDirectQuark) {
          // Android keeps the QR session only for share-transfer operations.
          // Library browsing and playback use the account-authenticated
          // server gateway so video and subtitle traffic follow one route.
          continue;
        } else if (source.isDirectQuark) {
          refreshed.addAll(await _quarkDrive.load(source));
          final latestCookie = _quarkDrive.currentCookie(source);
          if (latestCookie != source.transferCredential) {
            cloudSources[index] = source.copyWith(
              transferCredential: latestCookie,
            );
            cookieChanged = true;
          }
        } else {
          refreshed.addAll(await _openList.load(source));
        }
      } on Object {
        failed.add(source.name);
      }
    }
    if (cookieChanged) {
      try {
        await _cloudSourceStore.write(cloudSources);
      } on CloudSourceStoreException {
        failed.add('夸克登录状态保存');
      }
    }
    cloudMediaItems = refreshed;
    cloudMediaLoading = false;
    if (cloudSources.isNotEmpty) {
      lastNotice = failed.isEmpty
          ? '网盘影视已同步，共 ${refreshed.length} 个文件。'
          : '同步 ${refreshed.length} 个文件；${failed.join('、')} 暂时不可用。';
    }
    notifyListeners();
  }

  Future<void> _persistQuarkSessionCookie(CloudMediaSource source) async {
    final latestCookie = _quarkDrive.currentCookie(source);
    final index = cloudSources.indexWhere((item) => item.id == source.id);
    if (index < 0 ||
        latestCookie.isEmpty ||
        cloudSources[index].transferCredential == latestCookie) {
      return;
    }
    cloudSources[index] = cloudSources[index].copyWith(
      transferCredential: latestCookie,
    );
    try {
      await _cloudSourceStore.write(cloudSources);
    } on CloudSourceStoreException {
      // Playback can continue with the in-memory cookie. The next successful
      // sync will try to persist the rotated value again.
    }
  }

  Future<void> refreshStorageAccessStatus() async {
    if (!Platform.isAndroid || storageAccessChecking) return;
    storageAccessChecking = true;
    notifyListeners();
    try {
      storageAccessGranted = await _androidStorage.hasAccess();
    } on PlatformException {
      storageAccessGranted = false;
    } finally {
      storageAccessChecking = false;
      notifyListeners();
    }
  }

  Future<bool> requestAndroidStorageAccess() async {
    if (!Platform.isAndroid) return true;
    if (storageAccessChecking) return storageAccessGranted;
    storageAccessChecking = true;
    notifyListeners();
    try {
      storageAccessGranted = await _androidStorage.requestAccess();
      if (storageAccessGranted) {
        lastNotice = '媒体文件访问权限已开启。';
      } else {
        lastError = '需要允许“所有文件访问权限”，才能扫描文件夹并自动补全同目录视频。';
      }
    } on PlatformException {
      storageAccessGranted = false;
      lastError = '无法打开媒体文件访问设置，请在系统应用设置中手动授权。';
    } finally {
      storageAccessChecking = false;
      notifyListeners();
    }
    if (storageAccessGranted) unawaited(refreshLibrary());
    return storageAccessGranted;
  }

  Future<bool> _ensureAndroidStorageAccess() async {
    if (!Platform.isAndroid) return true;
    await refreshStorageAccessStatus();
    if (storageAccessGranted) return true;
    return requestAndroidStorageAccess();
  }

  Future<void> importMediaFolder() async {
    clearMessages();
    if (!await _ensureAndroidStorageAccess()) return;
    final directory = await FilePicker.getDirectoryPath(dialogTitle: '添加媒体来源');
    if (directory == null) return;
    await addLibraryFolder(directory);
  }

  Future<void> addLibraryFolder(String directory) async {
    final files = await _scanLibraryFolder(directory);
    if (files.isEmpty) {
      lastError = '该文件夹及其子文件夹中没有可播放的媒体。';
      notifyListeners();
      return;
    }
    if (!libraryFolders.any((item) => _samePath(item, directory))) {
      libraryFolders.add(directory);
      settings.libraryFolders = List<String>.from(libraryFolders);
      await settings.save();
    }
    await refreshLibrary();
    lastNotice = '媒体来源已保存，共发现 ${files.length} 个文件。';
    notifyListeners();
  }

  Future<void> removeLibraryFolder(String directory) async {
    libraryFolders.removeWhere((item) => _samePath(item, directory));
    settings.libraryFolders = List<String>.from(libraryFolders);
    settings.recentMediaPaths.removeWhere(
      (path) => _isInsideFolder(path, directory),
    );
    await settings.save();
    await refreshLibrary();
  }

  Future<void> refreshLibrary() async {
    if (libraryLoading) {
      _libraryRefreshPending = true;
      return;
    }
    libraryLoading = true;
    _coverLoadToken++;
    _mediaCovers.invalidateDirectoryIndex();
    notifyListeners();
    try {
      if (Platform.isAndroid) {
        storageAccessGranted = await _androidStorage.hasAccess();
        if (!storageAccessGranted) {
          libraryItems = [];
          return;
        }
      }
      do {
        _libraryRefreshPending = false;
        final scanned = <MediaPlaylistItem>[];
        final paths = <String>{};
        final folders = List<String>.from(libraryFolders);
        for (final folder in folders) {
          final files = await _scanLibraryFolder(folder);
          for (final item in files) {
            final key = Platform.isWindows
                ? item.path.toLowerCase()
                : item.path;
            if (paths.add(key)) scanned.add(item);
          }
        }
        scanned.sort(
          (first, second) =>
              first.title.toLowerCase().compareTo(second.title.toLowerCase()),
        );
        final existingCovers = {
          for (final item in libraryItems)
            if (item.coverPath != null) item.path: item.coverPath!,
        };
        libraryItems = [
          for (final item in scanned)
            item.copyWith(coverPath: existingCovers[item.path]),
        ];
        final coverToken = ++_coverLoadToken;
        notifyListeners();
        unawaited(_populateLibraryCovers(libraryItems, coverToken));
      } while (_libraryRefreshPending);
    } finally {
      libraryLoading = false;
      notifyListeners();
    }
  }

  Future<void> refreshOnlineStreams() async {
    if (onlineStreamsLoading) return;
    onlineStreamsLoading = true;
    notifyListeners();
    try {
      final refreshed = <MediaPlaylistItem>[];
      final failed = <String>[];
      for (final source in onlineStreamSources) {
        try {
          refreshed.addAll(await _onlineStreams.load(source));
        } on OnlineStreamException {
          failed.add(source.name);
        }
      }
      onlineStreamItems = refreshed;
      lastNotice = onlineStreamSources.isEmpty
          ? null
          : failed.isEmpty
          ? '已加载 ${refreshed.length} 个在线频道。'
          : '已加载 ${refreshed.length} 个频道；${failed.join('、')} 暂时不可用。';
    } finally {
      onlineStreamsLoading = false;
      notifyListeners();
    }
  }

  Future<void> installRecommendedTvBoxSource() async {
    const url = 'https://jinenge.us.kg/app/tvbox/tvbox.json';
    if (onlineStreamSources.any((source) => source.url == url)) {
      await refreshOnlineStreams();
      return;
    }
    onlineStreamSources.add(
      const OnlineStreamSource(name: 'TVBox 在线仓', url: url),
    );
    await _persistOnlineSources();
    await refreshOnlineStreams();
  }

  Future<void> addOnlineStreamSource({
    required String name,
    required String url,
  }) async {
    final normalizedName = name.trim();
    final normalizedUrl = url.trim();
    final uri = Uri.tryParse(normalizedUrl);
    if (normalizedName.isEmpty) {
      lastError = '请填写在线源名称。';
      notifyListeners();
      return;
    }
    if (uri == null || (uri.scheme != 'http' && uri.scheme != 'https')) {
      lastError = '请输入有效的 http 或 https 播放列表地址。';
      notifyListeners();
      return;
    }
    final source = OnlineStreamSource(name: normalizedName, url: normalizedUrl);
    try {
      final channels = await _onlineStreams.load(source);
      onlineStreamSources.removeWhere(
        (item) => item.url.toLowerCase() == normalizedUrl.toLowerCase(),
      );
      onlineStreamSources.add(source);
      await _persistOnlineSources();
      onlineStreamItems.removeWhere(
        (item) => item.sourceName == source.name || item.path.isEmpty,
      );
      onlineStreamItems.addAll(channels);
      lastError = null;
      lastNotice = '已添加“${source.name}”，载入 ${channels.length} 个频道。';
    } on OnlineStreamException catch (error) {
      lastError = error.message;
    }
    notifyListeners();
  }

  Future<void> removeOnlineStreamSource(OnlineStreamSource source) async {
    onlineStreamSources.removeWhere((item) => item.url == source.url);
    onlineStreamItems.removeWhere((item) => item.sourceName == source.name);
    await _persistOnlineSources();
    lastNotice = '已移除在线源“${source.name}”。';
    notifyListeners();
  }

  Future<void> openOnlineStream(
    MediaPlaylistItem item, {
    List<MediaPlaylistItem>? relatedItems,
    List<MediaPlaylistItem>? sourceItems,
  }) async {
    if (!item.isOnline) return openVideo(item.path);
    if (item.isLive) {
      lastError = '在线直播功能已移除，请选择 4K 影视线路。';
      notifyListeners();
      return;
    }
    clearMessages();
    await _persistPlaybackProgress(force: true);
    final loadToken = ++_mediaLoadToken;
    librarySurface = item.cloudSourceId == null
        ? LibrarySurface.onlineMovies
        : LibrarySurface.movies;
    if (item.isOnline && !item.isLive && item.cloudSourceId == null) {
      final remembered = relatedItems ?? [item];
      for (final candidate in remembered.reversed) {
        onlineMoviePlaybackItems.removeWhere(
          (existing) => existing.path == candidate.path,
        );
        onlineMoviePlaybackItems.insert(0, candidate);
      }
      if (onlineMoviePlaybackItems.length > 120) {
        onlineMoviePlaybackItems.removeRange(
          120,
          onlineMoviePlaybackItems.length,
        );
      }
    }
    final requestedPlaylist =
        relatedItems ?? (item.cloudSourceId != null ? cloudMediaItems : [item]);
    playlist = List<MediaPlaylistItem>.from(requestedPlaylist);
    // Episode URLs are not guaranteed to be unique (a season share may use
    // one URL for every named episode). Keep the selected list index so the
    // playlist can still activate and open the exact row the user tapped.
    _activePlaylistIndex = playlist.indexWhere(
      (candidate) =>
          candidate.path == item.path && candidate.title == item.title,
    );
    if (_activePlaylistIndex < 0) {
      _activePlaylistIndex = playlist.indexWhere(
        (candidate) => candidate.path == item.path,
      );
    }
    _demoTicker?.cancel();
    hasMedia = true;
    _activeNetworkPlayback = item.isOnline;
    networkSourceItems = _dedupeNetworkSources(sourceItems ?? [item]);
    _networkSourceIndex = networkSourceItems.indexWhere(
      (candidate) => candidate.path == item.path,
    );
    if (_networkSourceIndex < 0) {
      networkSourceItems = _dedupeNetworkSources([item, ...networkSourceItems]);
      _networkSourceIndex = 0;
    }
    mediaPath = item.path;
    _playbackSourceReady = false;
    _playbackDurationReady = false;
    mediaTitle = item.title;
    mediaMeta = [
      item.cloudSourceId != null ? '网盘影视' : '在线 4K 影视',
      if (item.group?.isNotEmpty == true) item.group!,
      if (item.sourceName?.isNotEmpty == true) item.sourceName!,
    ].join(' · ');
    position = Duration.zero;
    duration = Duration.zero;
    _prepareResumePosition(item.path, allowResume: true);
    selectedEntry = null;
    selectedWord = null;
    embeddedSubtitleTracks = [];
    selectedEmbeddedSubtitleOrdinal = null;
    selectedOriginalSubtitleOrdinal = null;
    selectedTranslationSubtitleOrdinal = null;
    _embeddedSelectionRevision++;
    _embeddedWindowCacheKeys.clear();
    _embeddedWindowLoadingKeys.clear();
    _embeddedWindowPrefetchKeys.clear();
    _embeddedWindowedMode = false;
    _embeddedSubtitleAlignmentOffset = null;
    _activePlaybackHeaders = const {};
    _setCues(const []);
    subtitleLoading = false;
    _mediaCompleted = false;
    _activeMediaIsLive = false;
    _lastSavedPositionSeconds = -1;
    _rememberRecentMedia(item.path, item: item);
    var playbackUrl = item.path;
    var playbackHeaders = _networkPlaybackHeaders(item.httpHeaders);
    var hasExplicitPlaybackHeaders = item.httpHeaders.isNotEmpty;
    CloudMediaSource? cloudSource;
    if (item.cloudSourceId case final sourceId?) {
      cloudSource = cloudSources
          .where((source) => source.id == sourceId)
          .firstOrNull;
      if (cloudSource == null || item.remotePath == null) {
        hasMedia = false;
        _clearPendingResume();
        lastError = '找不到该网盘来源，请重新同步。';
        notifyListeners();
        return;
      }
      try {
        if (Platform.isAndroid && cloudSource.isDirectQuark) {
          Uri? localUrl;
          AuthenticatedMediaProxyException? proxyError;
          for (var attempt = 0; attempt < 2; attempt++) {
            final resolved = await _quarkDrive.resolve(
              cloudSource,
              item.remotePath!,
            );
            await _persistQuarkSessionCookie(cloudSource);
            try {
              localUrl = await _authenticatedMediaProxy.register(
                remoteUrl: Uri.parse(resolved.url),
                headers: resolved.headers,
                fileName: item.title,
              );
              break;
            } on AuthenticatedMediaProxyException catch (error) {
              proxyError = error;
              if (error.statusCode != HttpStatus.preconditionFailed ||
                  attempt > 0) {
                rethrow;
              }
            }
          }
          if (localUrl == null) throw proxyError!;
          playbackUrl = localUrl.toString();
          playbackHeaders = const {};
          hasExplicitPlaybackHeaders = false;
        } else {
          final resolved = cloudSource.isManagedOpenList
              ? await _managedOpenList.resolve(item.remotePath!)
              : cloudSource.isDirectQuark
              ? await _quarkDrive.resolve(cloudSource, item.remotePath!)
              : await _openList.resolve(cloudSource, item.remotePath!);
          if (cloudSource.isDirectQuark) {
            await _persistQuarkSessionCookie(cloudSource);
          }
          playbackUrl = resolved.url;
          playbackHeaders = _networkPlaybackHeaders(resolved.headers);
          hasExplicitPlaybackHeaders = resolved.headers.isNotEmpty;
        }
      } on OpenListException catch (error) {
        hasMedia = false;
        _clearPendingResume();
        lastError = error.message;
        notifyListeners();
        return;
      } on QuarkDriveException catch (error) {
        hasMedia = false;
        _clearPendingResume();
        lastError = error.message;
        notifyListeners();
        return;
      } on AuthenticatedMediaProxyException catch (error) {
        hasMedia = false;
        _clearPendingResume();
        lastError = error.message;
        notifyListeners();
        return;
      } on Object catch (error) {
        hasMedia = false;
        _clearPendingResume();
        lastError = '无法解析网盘视频：$error';
        notifyListeners();
        return;
      }
    }
    try {
      _activePlaybackHeaders = Map.unmodifiable(playbackHeaders);
      await player.open(
        Media(playbackUrl, httpHeaders: playbackHeaders),
        play: true,
      );
    } catch (error) {
      _playbackSourceReady = false;
      _clearPendingResume();
      hasMedia = false;
      lastError = '线路打开失败：$error';
      notifyListeners();
      if (_networkRetrying) rethrow;
      if (_activeNetworkPlayback && networkSourceItems.length > 1) {
        unawaited(_tryNextNetworkSource());
      }
      return;
    }
    _activePlaybackUrl = playbackUrl;
    if (loadToken != _mediaLoadToken || mediaPath != item.path) return;
    _playbackSourceReady = true;
    unawaited(_restoreSavedPosition(item.path, loadToken));
    notifyListeners();
    await _restoreFrameInterpolation();
    if (!item.isLive) {
      var subtitleLoaded = false;
      if (cloudSource != null && item.remoteSubtitlePaths.isNotEmpty) {
        subtitleLoaded = await _loadRemoteSubtitle(
          cloudSource,
          item.remoteSubtitlePaths.first,
          loadToken,
        );
      } else if (item.remoteSubtitleUrls.isNotEmpty) {
        final subtitleUrl = item.remoteSubtitleUrls.first;
        subtitleLoaded = await _loadRemoteSubtitleUrl(
          subtitleUrl,
          const {},
          Uri.parse(subtitleUrl).pathSegments.last,
          loadToken,
        );
      }
      // A network video can carry embedded tracks while exposing no sidecar
      // file. Ask the player for those tracks immediately so playback does
      // not wait on a full remote ffprobe of a multi‑GB file. Text extraction
      // is started in the background for clickable/translation subtitles.
      if (!subtitleLoaded && playbackUrl.startsWith('http')) {
        subtitleLoaded = await _useNativeProbeFallback();
        if (subtitleLoaded) {
          unawaited(
            _loadEmbeddedSubtitles(
              playbackUrl,
              loadToken,
              identityPath: item.path,
            ),
          );
        }
      }
      if (!subtitleLoaded && !hasExplicitPlaybackHeaders) {
        subtitleLoaded = await _loadEmbeddedSubtitles(
          playbackUrl,
          loadToken,
          identityPath: item.path,
        );
      }
      if (!subtitleLoaded) {
        subtitleLoaded = await _useNativeProbeFallback();
      }
      if (!subtitleLoaded) {
        lastNotice = '该在线影片未发现可查询字幕；下载到本机后可自动生成双语字幕。';
      }
    }
    await player.setRate(playbackRate);
    notifyListeners();
  }

  Map<String, String> _networkPlaybackHeaders(Map<String, String> headers) {
    final normalized = <String, String>{...headers};
    if (normalized.keys.every((key) => key.toLowerCase() != 'user-agent')) {
      normalized['User-Agent'] =
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128.0.0.0 Safari/537.36';
    }
    return normalized;
  }

  String _friendlyPlaybackError(String error) {
    final normalized = error.toLowerCase();
    if (normalized.contains('failed to recognize file format') ||
        normalized.contains('format')) {
      return '网络地址没有返回可识别的视频流，可能是失效链接、网页地址或需要登录的线路。正在尝试其他线路。';
    }
    if (normalized.contains('404') || normalized.contains('not found')) {
      return '网络播放地址已失效（404），正在尝试其他线路。';
    }
    return error;
  }

  List<MediaPlaylistItem> _dedupeNetworkSources(
    Iterable<MediaPlaylistItem> items,
  ) {
    final seen = <String>{};
    return [
      for (final candidate in items)
        if (candidate.isOnline &&
            candidate.path.trim().isNotEmpty &&
            seen.add(candidate.path.trim()))
          candidate,
    ];
  }

  Future<void> switchNetworkSource(int index) async {
    if (index < 0 || index >= networkSourceItems.length) return;
    if (index == _networkSourceIndex) return;
    final candidate = networkSourceItems[index];
    _networkRetrying = true;
    lastNotice = '正在切换线路：${candidate.sourceName ?? '线路 ${index + 1}'}';
    lastError = null;
    notifyListeners();
    try {
      await openOnlineStream(
        candidate,
        relatedItems: List<MediaPlaylistItem>.from(playlist),
        sourceItems: List<MediaPlaylistItem>.from(networkSourceItems),
      );
    } on Object catch (error) {
      lastError = '线路切换失败：$error';
      notifyListeners();
    } finally {
      _networkRetrying = false;
    }
  }

  Future<void> _tryNextNetworkSource() async {
    if (_networkRetrying || !_activeNetworkPlayback) return;
    final nextIndex = _networkSourceIndex + 1;
    if (nextIndex >= networkSourceItems.length) return;
    _networkRetrying = true;
    final candidate = networkSourceItems[nextIndex];
    lastNotice =
        '当前线路无法播放，正在自动切换到“${candidate.sourceName ?? '线路 ${nextIndex + 1}'}”…';
    notifyListeners();
    try {
      await openOnlineStream(
        candidate,
        relatedItems: List<MediaPlaylistItem>.from(playlist),
        sourceItems: List<MediaPlaylistItem>.from(networkSourceItems),
      );
    } on Object {
      // An immediate open failure is uncommon (most failures arrive through
      // player.stream.error), but keep trying the remaining direct routes.
      _networkRetrying = false;
      await _tryNextNetworkSource();
    } finally {
      _networkRetrying = false;
    }
  }

  Future<bool> _loadRemoteSubtitle(
    CloudMediaSource source,
    String remotePath,
    int loadToken,
  ) async {
    try {
      final resolved = source.isDirectQuark
          ? await _quarkDrive.resolve(source, remotePath, linkType: 'download')
          : source.isManagedOpenList
          ? await _managedOpenList.resolve(remotePath, linkType: 'download')
          : await _openList.resolve(source, remotePath, linkType: 'download');
      return _loadRemoteSubtitleUrl(
        resolved.url,
        resolved.headers,
        remotePath.split('/').last,
        loadToken,
      );
    } on Object {
      return false;
    }
  }

  Future<bool> _loadRemoteSubtitleUrl(
    String url,
    Map<String, String> headers,
    String fileName,
    int loadToken,
  ) async {
    try {
      final response = await _onlineStreamClient
          .get(Uri.parse(url), headers: headers)
          .timeout(const Duration(seconds: 20));
      if (response.statusCode < 200 || response.statusCode >= 300) return false;
      if (loadToken != _mediaLoadToken) return false;
      final cues = _parser.parseBytes(response.bodyBytes, fileName: fileName);
      if (cues.isEmpty) return false;
      _setCues(cues);
      _syncCurrentCue(force: true, clearLookup: true);
      await _disableNativeSubtitleTracks();
      if (settings.autoPrepareSubtitles &&
          !_isEffectivelyBilingual(cues) &&
          !processing.isRunning) {
        unawaited(translateCurrentSubtitles());
      }
      return true;
    } on Object {
      return false;
    }
  }

  Future<void> downloadRemoteMedia(MediaPlaylistItem item) async {
    if (!item.isOnline || item.isLive || downloadLoading) return;
    final source = item.cloudSourceId == null
        ? null
        : cloudSources
              .where((candidate) => candidate.id == item.cloudSourceId)
              .firstOrNull;
    if (item.cloudSourceId != null &&
        (source == null || item.remotePath == null)) {
      return;
    }
    final directory = await FilePicker.getDirectoryPath(dialogTitle: '选择下载位置');
    if (directory == null) return;
    downloadLoading = true;
    downloadProgress = 0;
    notifyListeners();
    IOSink? sink;
    try {
      final resolved = source == null
          ? OpenListResolvedFile(url: item.path, headers: item.httpHeaders)
          : source.isDirectQuark
          ? await _quarkDrive.resolve(
              source,
              item.remotePath!,
              linkType: 'download',
            )
          : source.isManagedOpenList
          ? await _managedOpenList.resolve(
              item.remotePath!,
              linkType: 'download',
            )
          : await _openList.resolve(
              source,
              item.remotePath!,
              linkType: 'download',
            );
      final request = http.Request('GET', Uri.parse(resolved.url));
      request.headers.addAll(resolved.headers);
      final response = await _onlineStreamClient.send(request);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw OpenListException('下载失败（HTTP ${response.statusCode}）。');
      }
      final target = await _availableDownloadFile(directory, item.title);
      sink = target.openWrite();
      var received = 0;
      final total = response.contentLength ?? 0;
      await for (final chunk in response.stream) {
        sink.add(chunk);
        received += chunk.length;
        if (total > 0) {
          downloadProgress = received / total;
          notifyListeners();
        }
      }
      await sink.flush();
      await sink.close();
      sink = null;
      final subtitleFiles =
          <({String url, Map<String, String> headers, String name})>[];
      if (source != null) {
        for (final subtitlePath in item.remoteSubtitlePaths) {
          try {
            final subtitle = source.isDirectQuark
                ? await _quarkDrive.resolve(
                    source,
                    subtitlePath,
                    linkType: 'download',
                  )
                : source.isManagedOpenList
                ? await _managedOpenList.resolve(
                    subtitlePath,
                    linkType: 'download',
                  )
                : await _openList.resolve(
                    source,
                    subtitlePath,
                    linkType: 'download',
                  );
            subtitleFiles.add((
              url: subtitle.url,
              headers: subtitle.headers,
              name: subtitlePath.split('/').last,
            ));
          } on Object {
            // Optional subtitle resolution may fail independently.
          }
        }
      } else {
        for (final subtitleUrl in item.remoteSubtitleUrls) {
          subtitleFiles.add((
            url: subtitleUrl,
            headers: const {},
            name: Uri.parse(subtitleUrl).pathSegments.last,
          ));
        }
      }
      for (final subtitle in subtitleFiles) {
        try {
          final subtitleResponse = await _onlineStreamClient.get(
            Uri.parse(subtitle.url),
            headers: subtitle.headers,
          );
          if (subtitleResponse.statusCode >= 200 &&
              subtitleResponse.statusCode < 300) {
            final subtitleFile = File(
              '$directory${Platform.pathSeparator}${subtitle.name}',
            );
            if (!await subtitleFile.exists()) {
              await subtitleFile.writeAsBytes(subtitleResponse.bodyBytes);
            }
          }
        } on Object {
          // The video download remains usable when an optional sidecar fails.
        }
      }
      await _rememberLibraryFolder(directory);
      lastNotice = '已下载到 ${target.path}，并加入影视资料库。';
    } on OpenListException catch (error) {
      lastError = error.message;
    } on QuarkDriveException catch (error) {
      lastError = error.message;
    } on Object catch (error) {
      lastError = '下载失败：$error';
    } finally {
      await sink?.close();
      downloadLoading = false;
      downloadProgress = null;
      notifyListeners();
    }
  }

  Future<File> _availableDownloadFile(String directory, String fileName) async {
    final safeName = fileName.replaceAll(RegExp(r'[<>:"/\\|?*]'), '_');
    var candidate = File(
      '${Directory(directory).path}${Platform.pathSeparator}$safeName',
    );
    if (!await candidate.exists()) return candidate;
    final dot = safeName.lastIndexOf('.');
    final stem = dot > 0 ? safeName.substring(0, dot) : safeName;
    final extension = dot > 0 ? safeName.substring(dot) : '';
    for (var index = 2; ; index++) {
      candidate = File(
        '${Directory(directory).path}${Platform.pathSeparator}$stem ($index)$extension',
      );
      if (!await candidate.exists()) return candidate;
    }
  }

  List<OnlineStreamSource> _readOnlineSources(List<String> serialized) {
    final output = <OnlineStreamSource>[];
    final seenUrls = <String>{};
    for (final source in serialized) {
      try {
        final parsed = OnlineStreamSource.fromJson(jsonDecode(source));
        if (parsed != null && seenUrls.add(parsed.url.toLowerCase())) {
          output.add(parsed);
        }
      } on FormatException {
        // Ignore malformed legacy entries.
      }
    }
    return output;
  }

  Future<void> _persistOnlineSources() {
    settings.onlineStreamSources = [
      for (final source in onlineStreamSources) jsonEncode(source.toJson()),
    ];
    return settings.save();
  }

  Future<void> _populateLibraryCovers(
    List<MediaPlaylistItem> items,
    int token,
  ) async {
    for (final item in items) {
      if (token != _coverLoadToken) return;
      final coverPath = await _mediaCovers.resolve(item.path);
      if (token != _coverLoadToken) return;
      if (coverPath == null || coverPath == item.coverPath) continue;
      final index = libraryItems.indexWhere(
        (candidate) => candidate.path == item.path,
      );
      if (index < 0) continue;
      libraryItems[index] = libraryItems[index].copyWith(coverPath: coverPath);
      notifyListeners();
    }
  }

  Future<void> openVideoPicker() async {
    clearMessages();
    if (!await _ensureAndroidStorageAccess()) return;
    String? path;
    if (Platform.isAndroid) {
      try {
        path = await _androidStorage.pickMediaFile();
      } on PlatformException catch (error) {
        lastError = error.code == 'unresolved_path'
            ? '无法取得该文件的原始路径，请改用“添加文件夹”导入。'
            : '无法打开所选媒体文件。';
        notifyListeners();
        return;
      }
    } else {
      final result = await FilePicker.pickFiles(
        type: FileType.custom,
        allowMultiple: false,
        allowedExtensions: mediaExtensions,
      );
      path = result?.files.single.path;
    }
    if (path == null) return;
    await openVideo(path);
  }

  Future<void> openMediaFolder() async {
    clearMessages();
    if (!await _ensureAndroidStorageAccess()) return;
    final directory = await FilePicker.getDirectoryPath(dialogTitle: '选择影视文件夹');
    if (directory == null) return;
    await _rememberLibraryFolder(directory);
    await openMediaFolderPath(directory);
  }

  Future<void> openMediaFolderPath(
    String directory, {
    String? preferredPath,
  }) async {
    final files = await _scanMediaFolder(directory);
    if (files.isEmpty) {
      lastError = '该文件夹中没有可播放的影视或音频文件。';
      notifyListeners();
      return;
    }
    playlist = files;
    final selected = files.firstWhere(
      (item) => item.path == preferredPath,
      orElse: () => files.first,
    );
    await openVideo(selected.path, refreshPlaylist: false);
  }

  Future<List<MediaPlaylistItem>> _scanMediaFolder(String directory) async {
    try {
      final contents = await Directory(
        directory,
      ).list(followLinks: false).toList();
      final media = <MediaPlaylistItem>[
        for (final entity in contents)
          if (entity is File && _isSupportedMediaPath(entity.path))
            MediaPlaylistItem(
              path: entity.path,
              title: entity.uri.pathSegments.last,
            ),
      ];
      media.sort(
        (first, second) =>
            first.title.toLowerCase().compareTo(second.title.toLowerCase()),
      );
      return media;
    } on FileSystemException {
      return const [];
    }
  }

  Future<List<MediaPlaylistItem>> _scanLibraryFolder(String directory) async {
    try {
      final media = <MediaPlaylistItem>[];
      await for (final entity in Directory(
        directory,
      ).list(recursive: true, followLinks: false)) {
        if (entity is File && _isSupportedMediaPath(entity.path)) {
          media.add(
            MediaPlaylistItem(
              path: entity.path,
              title: entity.uri.pathSegments.last,
            ),
          );
        }
      }
      return media;
    } on FileSystemException {
      return const [];
    }
  }

  bool _isSupportedMediaPath(String path) {
    final dot = path.lastIndexOf('.');
    if (dot < 0 || dot == path.length - 1) return false;
    return mediaExtensions.contains(path.substring(dot + 1).toLowerCase());
  }

  Future<void> openVideo(String path, {bool refreshPlaylist = true}) async {
    clearMessages();
    await _persistPlaybackProgress(force: true);
    final loadToken = ++_mediaLoadToken;
    final file = File(path);
    if (!await file.exists()) {
      lastError = '找不到所选媒体文件。';
      notifyListeners();
      return;
    }

    if (refreshPlaylist) {
      final parent = file.parent.path;
      final files = await _scanMediaFolder(parent);
      if (files.isNotEmpty) playlist = files;
      await _rememberLibraryFolder(parent);
    }
    if (playlist.isEmpty || !playlist.any((item) => item.path == path)) {
      playlist = [
        MediaPlaylistItem(path: path, title: file.uri.pathSegments.last),
      ];
    }
    _activePlaylistIndex = playlist.indexWhere((item) => item.path == path);

    _demoTicker?.cancel();
    librarySurface = LibrarySurface.movies;
    hasMedia = true;
    mediaPath = path;
    _playbackSourceReady = false;
    _playbackDurationReady = false;
    mediaTitle = file.uri.pathSegments.last;
    mediaMeta = '本地媒体';
    position = Duration.zero;
    duration = Duration.zero;
    _prepareResumePosition(path, allowResume: true);
    selectedEntry = null;
    selectedWord = null;
    embeddedSubtitleTracks = [];
    selectedEmbeddedSubtitleOrdinal = null;
    selectedOriginalSubtitleOrdinal = null;
    selectedTranslationSubtitleOrdinal = null;
    _embeddedSelectionRevision++;
    _embeddedWindowCacheKeys.clear();
    _embeddedWindowLoadingKeys.clear();
    _embeddedWindowPrefetchKeys.clear();
    _embeddedWindowedMode = false;
    _embeddedSubtitleAlignmentOffset = null;
    _activePlaybackHeaders = const {};
    subtitleLoading = false;
    _mediaCompleted = false;
    _activeMediaIsLive = false;
    _activeNetworkPlayback = false;
    _networkRetrying = false;
    networkSourceItems = [];
    _networkSourceIndex = 0;
    _lastSavedPositionSeconds = -1;
    _rememberRecentMedia(
      path,
      item: MediaPlaylistItem(path: path, title: file.uri.pathSegments.last),
    );
    try {
      await player.open(Media(path), play: true);
    } catch (error) {
      _playbackSourceReady = false;
      _clearPendingResume();
      hasMedia = false;
      lastError = '无法打开视频：$error';
      notifyListeners();
      return;
    }
    _activePlaybackUrl = path;
    if (loadToken != _mediaLoadToken || mediaPath != path) return;
    _playbackSourceReady = true;
    unawaited(_restoreSavedPosition(path, loadToken));
    notifyListeners();
    await _restoreFrameInterpolation();
    await player.setRate(playbackRate);
    final sidecarLoaded = await _loadMatchingSidecar(path);
    if (loadToken != _mediaLoadToken || mediaPath != path) return;
    final embeddedFound = sidecarLoaded
        ? false
        : await _loadEmbeddedSubtitles(path, loadToken);
    if (loadToken != _mediaLoadToken || mediaPath != path) return;
    if (_cues.isEmpty && !embeddedFound) {
      if (settings.autoPrepareSubtitles) {
        lastNotice = '未找到同名字幕，正在自动生成双语字幕。';
        unawaited(generateSubtitles());
      } else {
        lastNotice = '未找到同名字幕，可从字幕菜单加载或用 SeedASR 2.0 生成。';
      }
    }
    notifyListeners();
  }

  Future<void> openPlaylistItem(int index) async {
    if (index < 0 || index >= playlist.length) return;
    final item = playlist[index];
    if (item.isOnline) {
      await openOnlineStream(
        item,
        relatedItems: List<MediaPlaylistItem>.from(playlist),
      );
    } else {
      await openVideo(item.path, refreshPlaylist: false);
    }
  }

  Future<void> openAdjacentPlaylistItem(int delta) async {
    final current = currentPlaylistIndex;
    if (current < 0) return;
    final next = (current + delta).clamp(0, playlist.length - 1);
    if (next == current) return;
    await openPlaylistItem(next);
  }

  void showOnlineMovieLibrary() {
    librarySurface = LibrarySurface.onlineMovies;
    notifyListeners();
  }

  void showMovieLibrary() {
    librarySurface = LibrarySurface.movies;
    notifyListeners();
  }

  Future<void> returnToLibrary() async {
    librarySurface = LibrarySurface.movies;
    await _leavePlayer();
  }

  Future<void> returnToPreviousSurface() => _leavePlayer();

  Future<void> _leavePlayer() async {
    await _persistPlaybackProgress(force: true);
    _mediaLoadToken++;
    _playbackSourceReady = false;
    _playbackDurationReady = false;
    _clearPendingResume();
    _demoTicker?.cancel();
    _demoTicker = null;
    await player.stop();
    hasMedia = false;
    _mediaCompleted = false;
    _activeMediaIsLive = false;
    _activeNetworkPlayback = false;
    _networkRetrying = false;
    networkSourceItems = [];
    _networkSourceIndex = 0;
    isPlaying = false;
    playlistOpen = false;
    _activePlaylistIndex = -1;
    drawerOpen = false;
    mediaPath = null;
    _activePlaybackUrl = null;
    _activePlaybackHeaders = const {};
    mediaTitle = '影语媒体库';
    mediaMeta = '选择影视文件夹开始';
    position = Duration.zero;
    duration = Duration.zero;
    embeddedSubtitleTracks = [];
    selectedEmbeddedSubtitleOrdinal = null;
    selectedOriginalSubtitleOrdinal = null;
    selectedTranslationSubtitleOrdinal = null;
    _embeddedSelectionRevision++;
    _setCues(const []);
    _currentCueIndex = -1;
    _embeddedWindowCacheKeys.clear();
    _embeddedWindowLoadingKeys.clear();
    _embeddedWindowPrefetchKeys.clear();
    _embeddedWindowedMode = false;
    _embeddedSubtitleAlignmentOffset = null;
    closeDictionary();
    notifyListeners();
  }

  Future<void> _rememberLibraryFolder(String directory) async {
    if (libraryFolders.any((item) => _samePath(item, directory))) return;
    libraryFolders.add(directory);
    settings.libraryFolders = List<String>.from(libraryFolders);
    await settings.save();
    unawaited(refreshLibrary());
  }

  void _rememberRecentMedia(String path, {MediaPlaylistItem? item}) {
    _rememberMediaMetadata(item ?? _historyItemForPath(path));
    settings.recentMediaPaths.remove(path);
    settings.recentMediaPaths.insert(0, path);
    if (settings.recentMediaPaths.length > 20) {
      settings.recentMediaPaths.removeRange(
        20,
        settings.recentMediaPaths.length,
      );
    }
    unawaited(settings.save());
  }

  void _recordPlaybackProgress() {
    final seconds = position.inSeconds;
    if (_lastSavedPositionSeconds >= 0 &&
        (seconds - _lastSavedPositionSeconds).abs() < 10) {
      return;
    }
    _lastSavedPositionSeconds = seconds;
    unawaited(_persistPlaybackProgress());
  }

  Future<void> _persistPlaybackProgress({bool force = false}) async {
    final path = mediaPath;
    if (path == null || !hasMedia || !_playbackSourceReady) return;
    if (_activeMediaIsLive) return;
    if (!force && position < const Duration(seconds: 2)) return;
    settings.playbackPositionsMs[path] = _mediaCompleted
        ? 0
        : position.inMilliseconds;
    if (duration > Duration.zero) {
      settings.playbackDurationsMs[path] = duration.inMilliseconds;
    }
    await settings.save();
  }

  bool _samePath(String first, String second) => Platform.isWindows
      ? first.toLowerCase() == second.toLowerCase()
      : first == second;

  bool _isInsideFolder(String path, String folder) {
    final separator = Platform.pathSeparator;
    final normalizedFolder = folder.endsWith(separator)
        ? folder
        : '$folder$separator';
    if (Platform.isWindows) {
      return path.toLowerCase().startsWith(normalizedFolder.toLowerCase());
    }
    return path.startsWith(normalizedFolder);
  }

  Future<bool> _loadMatchingSidecar(String mediaFile) async {
    _setCues(const []);
    _currentCueIndex = -1;
    final base = mediaFile.replaceFirst(RegExp(r'\.[^.\\/]+$'), '');
    for (final extension in const ['srt', 'vtt', 'ass', 'ssa']) {
      final sidecar = File('$base.$extension');
      if (await sidecar.exists()) {
        await loadSubtitle(sidecar.path);
        if (_cues.isNotEmpty) return true;
      }
    }
    return false;
  }

  EmbeddedSubtitleTrack? _windowOriginalTrack() {
    final original = selectedOriginalSubtitleTrack;
    if (original != null) return original;
    // A single-track selection is stored as selectedEmbeddedSubtitleOrdinal.
    // When the user selected only a translation track, keep it in the
    // translation slot so the overlay does not relabel it as English.
    if (selectedTranslationSubtitleTrack == null) {
      return selectedEmbeddedSubtitleTrack;
    }
    return null;
  }

  EmbeddedSubtitleTrack? _windowTranslationTrack() {
    return selectedTranslationSubtitleTrack;
  }

  (Duration, Duration, int) _embeddedWindowBounds(Duration target) {
    final spanMs = _embeddedWindowSpan.inMilliseconds;
    final bucket = target.inMilliseconds < 0
        ? 0
        : target.inMilliseconds ~/ spanMs;
    final bucketStart = Duration(milliseconds: bucket * spanMs);
    final start = bucketStart > _embeddedWindowPadding
        ? bucketStart - _embeddedWindowPadding
        : Duration.zero;
    var end = bucketStart + _embeddedWindowSpan + _embeddedWindowPadding;
    if (duration > Duration.zero && end > duration) end = duration;
    if (end <= start) end = start + const Duration(seconds: 1);
    return (start, end, bucket);
  }

  String _embeddedWindowKey({
    required int bucket,
    required EmbeddedSubtitleTrack? original,
    required EmbeddedSubtitleTrack? translation,
  }) {
    return '$_embeddedSelectionRevision:${original?.ordinal ?? '-'}:'
        '${translation?.ordinal ?? '-'}:$bucket';
  }

  Future<List<SubtitleCue>> _extractEmbeddedWindowCues({
    required String mediaPath,
    required EmbeddedSubtitleTrack? original,
    required EmbeddedSubtitleTrack? translation,
    required Duration start,
    required Duration end,
  }) async {
    Future<List<SubtitleCue>> extract(EmbeddedSubtitleTrack? track) async {
      if (track == null || !track.isTextBased) return const <SubtitleCue>[];
      if (track.isGenerated) {
        return track.generatedCues
            .where((cue) => cue.end >= start && cue.start <= end)
            .toList(growable: false);
      }
      try {
        return await _embeddedSubtitles.extractWindow(
          mediaPath: mediaPath,
          track: track,
          start: start,
          end: end,
          headers: _activePlaybackHeaders,
        );
      } on EmbeddedSubtitleException {
        return const <SubtitleCue>[];
      } on Object {
        return const <SubtitleCue>[];
      }
    }

    final results = await Future.wait([
      extract(original),
      extract(translation),
    ]);
    final alignmentOffset = results[0].isNotEmpty && results[1].isNotEmpty
        ? (_embeddedSubtitleAlignmentOffset ??=
              EmbeddedSubtitleAlignment.estimateOffset(
                original: results[0],
                translation: results[1],
              ))
        : null;
    return EmbeddedSubtitleAlignment.merge(
      original: results[0],
      translation: results[1],
      offset: alignmentOffset,
    );
  }

  Future<void> _ensureEmbeddedSubtitleWindow(
    Duration target, {
    bool prefetch = false,
  }) async {
    if (!_embeddedWindowedMode || !hasMedia || mediaPath == null) return;
    final mediaUrl = _activePlaybackUrl ?? mediaPath;
    final original = _windowOriginalTrack();
    final translation = _windowTranslationTrack();
    if (mediaUrl == null || (original == null && translation == null)) return;
    if ((original != null && !original.isTextBased) ||
        (translation != null && !translation.isTextBased)) {
      return;
    }

    final (start, end, bucket) = _embeddedWindowBounds(target);
    final key = _embeddedWindowKey(
      bucket: bucket,
      original: original,
      translation: translation,
    );
    if (_embeddedWindowCacheKeys.contains(key)) {
      if (!prefetch) unawaited(_prefetchAdjacentSubtitleWindows(bucket));
      return;
    }
    if (!_embeddedWindowLoadingKeys.add(key)) {
      return;
    }
    final selectionRevision = _embeddedSelectionRevision;
    final expectedMediaPath = mediaPath;
    try {
      final loaded = await _extractEmbeddedWindowCues(
        mediaPath: mediaUrl,
        original: original,
        translation: translation,
        start: start,
        end: end,
      );
      if (selectionRevision != _embeddedSelectionRevision ||
          mediaPath != expectedMediaPath ||
          !hasMedia) {
        return;
      }
      _embeddedWindowCacheKeys.add(key);
      if (loaded.isEmpty) return;
      _mergeEmbeddedWindowCues(loaded);
      _syncCurrentCue(force: true);
      if (!prefetch) {
        lastNotice = '已先载入 ${_formatSubtitleWindow(start, end)}，其余字幕将随播放动态补全。';
      }
      notifyListeners();
    } finally {
      _embeddedWindowLoadingKeys.remove(key);
      if (!prefetch) unawaited(_prefetchAdjacentSubtitleWindows(bucket));
    }
  }

  Future<void> _prefetchAdjacentSubtitleWindows(int currentBucket) async {
    final prefetchKey = '$_embeddedSelectionRevision:$currentBucket';
    if (!_embeddedWindowPrefetchKeys.add(prefetchKey)) return;
    final spanMs = _embeddedWindowSpan.inMilliseconds;
    final lastBucket = duration > Duration.zero
        ? math.max(0, (duration.inMilliseconds - 1) ~/ spanMs)
        : currentBucket + 1;
    for (final bucket in [currentBucket + 1, currentBucket - 1]) {
      if (bucket < 0 || bucket > lastBucket) continue;
      final target = Duration(milliseconds: bucket * spanMs + spanMs ~/ 2);
      await _ensureEmbeddedSubtitleWindow(target, prefetch: true);
    }
  }

  void _mergeEmbeddedWindowCues(List<SubtitleCue> incoming) {
    final merged = List<SubtitleCue>.from(_rawCues);
    for (final cue in incoming) {
      final index = merged.indexWhere(
        (existing) =>
            (existing.start - cue.start).abs() <=
                const Duration(milliseconds: 700) &&
            (_sameSubtitleText(existing.original, cue.original) ||
                (existing.original.isEmpty && cue.original.isEmpty) ||
                (existing.translation.isNotEmpty &&
                    _sameSubtitleText(existing.translation, cue.translation))),
      );
      if (index < 0) {
        merged.add(cue);
      } else if (cue.isBilingual || !merged[index].isBilingual) {
        merged[index] = cue;
      }
    }
    merged.sort((first, second) {
      final byStart = first.start.compareTo(second.start);
      return byStart != 0 ? byStart : first.end.compareTo(second.end);
    });
    _setCues(merged);
  }

  bool _sameSubtitleText(String first, String second) {
    return first.trim().toLowerCase() == second.trim().toLowerCase();
  }

  String _formatSubtitleWindow(Duration start, Duration end) {
    String stamp(Duration value) {
      final totalSeconds = value.inSeconds;
      final hours = totalSeconds ~/ 3600;
      final minutes = (totalSeconds % 3600) ~/ 60;
      final seconds = totalSeconds % 60;
      return hours > 0
          ? '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}'
                ':${seconds.toString().padLeft(2, '0')}'
          : '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
    }

    return '${stamp(start)}–${stamp(end)}';
  }

  Future<bool> _loadEmbeddedSubtitles(
    String path,
    int loadToken, {
    String? identityPath,
  }) async {
    final expectedMediaPath = identityPath ?? path;
    final selectionRevision = _embeddedSelectionRevision;
    // The controller identity for cloud items is openlist://..., while FFmpeg
    // needs the resolved signed HTTP URL. Keep extraction on the real media
    // source even when this method is reached from a subtitle picker.
    final extractionPath = path.startsWith('http')
        ? path
        : (_activePlaybackUrl ?? path);
    subtitleLoading = true;
    lastNotice = '正在检查视频内嵌字幕…';
    notifyListeners();
    try {
      // Cloud playback already exposes a native track list while the full
      // ffprobe scan may still be waiting on a multi‑GB remote file. Reuse
      // that list and load only the current time window first; local files and
      // ordinary direct URLs still use ffprobe to obtain global stream ids.
      var tracks = embeddedSubtitleTracks;
      final hasNativeTrackIds =
          tracks.isNotEmpty &&
          tracks.every((track) => track.nativeTrackId != null);
      if (!hasNativeTrackIds) {
        tracks = await _embeddedSubtitles.probe(
          extractionPath,
          headers: _activePlaybackHeaders,
        );
      }
      if (loadToken != _mediaLoadToken || mediaPath != expectedMediaPath) {
        return false;
      }
      final generatedTracks = embeddedSubtitleTracks
          .where((track) => track.isGenerated)
          .toList(growable: false);
      embeddedSubtitleTracks = [...tracks, ...generatedTracks];
      if (tracks.isEmpty) return _useNativeProbeFallback();

      // Do not blindly honor the container's default subtitle.  Multi-track
      // releases often mark an unrelated language (for example Arabic) as
      // default even when the user's source/target languages are English and
      // Chinese.  Prefer the configured pair, while keeping every track in
      // the picker for manual selection.
      final textTracks = tracks.where((track) => track.isTextBased).toList();
      final preferredOriginal = _preferredSubtitleTrack(
        textTracks,
        settings.sourceLanguage,
      );
      final preferredTranslation = _preferredSubtitleTrack(
        textTracks,
        settings.targetLanguage,
        excludingOrdinal: preferredOriginal?.ordinal,
      );
      final remainingTextTracks = textTracks
        ..removeWhere(
          (track) =>
              track.ordinal == preferredOriginal?.ordinal ||
              track.ordinal == preferredTranslation?.ordinal,
        )
        ..sort((first, second) {
          return (second.isDefault ? 1 : 0).compareTo(first.isDefault ? 1 : 0);
        });
      final candidates = <EmbeddedSubtitleTrack>[
        ?preferredOriginal,
        ?preferredTranslation,
        ...remainingTextTracks,
        ...tracks.where((track) => !track.isTextBased),
      ];

      final (windowStart, windowEnd, windowBucket) = _embeddedWindowBounds(
        position,
      );
      _embeddedWindowedMode = true;
      if (preferredOriginal != null || preferredTranslation != null) {
        final preferredCues = await _extractEmbeddedWindowCues(
          mediaPath: extractionPath,
          original: preferredOriginal,
          translation: preferredTranslation,
          start: windowStart,
          end: windowEnd,
        );
        if (loadToken != _mediaLoadToken || mediaPath != expectedMediaPath) {
          return true;
        }
        if (selectionRevision != _embeddedSelectionRevision) return true;
        if (preferredCues.isNotEmpty) {
          _embeddedWindowCacheKeys.add(
            _embeddedWindowKey(
              bucket: windowBucket,
              original: preferredOriginal,
              translation: preferredTranslation,
            ),
          );
          await _useEmbeddedTextTracks(
            originalTrack: preferredOriginal,
            translationTrack: preferredTranslation,
            cues: preferredCues,
            automatic: true,
          );
          unawaited(_ensureEmbeddedSubtitleWindow(position));
          return true;
        }
      }

      for (final track in candidates.where((item) => item.isTextBased)) {
        final cues = await _extractEmbeddedWindowCues(
          mediaPath: extractionPath,
          original: track,
          translation: null,
          start: windowStart,
          end: windowEnd,
        );
        if (loadToken != _mediaLoadToken || mediaPath != expectedMediaPath) {
          return true;
        }
        if (selectionRevision != _embeddedSelectionRevision) return true;
        if (cues.isEmpty) continue;
        _embeddedWindowCacheKeys.add(
          _embeddedWindowKey(
            bucket: windowBucket,
            original: track,
            translation: null,
          ),
        );
        await _useEmbeddedTextTrack(track, cues, automatic: true);
        unawaited(_ensureEmbeddedSubtitleWindow(position));
        return true;
      }

      final fallback =
          _preferredSubtitleTrack(tracks, settings.sourceLanguage) ??
          tracks.firstWhere(
            (track) => track.isDefault,
            orElse: () => candidates.first,
          );
      final translation = _preferredSubtitleTrack(
        tracks,
        settings.targetLanguage,
        excludingOrdinal: fallback.ordinal,
      );
      _embeddedWindowedMode = true;
      await _useNativeEmbeddedPair(
        originalTrack: fallback,
        translationTrack: translation,
        extractionError: '当前时间附近文本暂未提取，将按播放进度继续尝试',
      );
      return true;
    } on EmbeddedSubtitleException {
      return _useNativeProbeFallback();
    } catch (_) {
      return _useNativeProbeFallback();
    } finally {
      if (loadToken == _mediaLoadToken && mediaPath == expectedMediaPath) {
        subtitleLoading = false;
        notifyListeners();
      }
    }
  }

  EmbeddedSubtitleTrack? _preferredSubtitleTrack(
    Iterable<EmbeddedSubtitleTrack> tracks,
    String language, {
    int? excludingOrdinal,
  }) {
    final wanted = _subtitleLanguageKey(language);
    if (wanted.isEmpty) return null;
    for (final track in tracks) {
      if (track.ordinal == excludingOrdinal) continue;
      if (_subtitleLanguageKey(track.language) == wanted) return track;
    }
    return null;
  }

  String _subtitleLanguageKey(String? value) {
    final normalized = value
        ?.trim()
        .toLowerCase()
        .replaceAll('_', '-')
        .replaceAll(' ', '');
    if (normalized == null || normalized.isEmpty) return '';
    if (normalized == 'eng' ||
        normalized.startsWith('en-') ||
        normalized == 'en') {
      return 'en';
    }
    if (normalized == 'chi' ||
        normalized == 'zho' ||
        normalized == 'zh' ||
        normalized.startsWith('zh-')) {
      return 'zh';
    }
    if (normalized == 'jpn' ||
        normalized.startsWith('ja-') ||
        normalized == 'ja') {
      return 'ja';
    }
    if (normalized == 'ara' ||
        normalized.startsWith('ar-') ||
        normalized == 'ar') {
      return 'ar';
    }
    return normalized;
  }

  Future<bool> _useNativeProbeFallback() async {
    var nativeTracks = player.state.tracks.subtitle;
    if (nativeTracks.isEmpty) {
      try {
        final tracks = await player.stream.tracks
            .firstWhere((value) => value.subtitle.isNotEmpty)
            .timeout(const Duration(seconds: 2));
        nativeTracks = tracks.subtitle;
      } on TimeoutException {
        return false;
      }
    }
    if (nativeTracks.isEmpty) return false;

    // media_kit always exposes the synthetic `auto` and `no` entries before
    // the real subtitle streams.  They are commands, not selectable media
    // tracks, so including them shifts every ordinal and makes a click on
    // English/Chinese select the default stream again.
    final availableNativeTracks = nativeTracks
        .where((track) => track.id != 'auto' && track.id != 'no')
        .toList(growable: false);
    if (availableNativeTracks.isEmpty) return false;

    final generatedTracks = embeddedSubtitleTracks
        .where((track) => track.isGenerated)
        .toList(growable: false);
    embeddedSubtitleTracks = [
      for (var index = 0; index < availableNativeTracks.length; index++)
        EmbeddedSubtitleTrack(
          ordinal: index,
          streamIndex: -1,
          codec: availableNativeTracks[index].codec ?? 'subtitle',
          language: availableNativeTracks[index].language,
          title: availableNativeTracks[index].title,
          isDefault: availableNativeTracks[index].isDefault ?? index == 0,
          isForced: false,
          nativeTrackId: availableNativeTracks[index].id,
        ),
      ...generatedTracks,
    ];
    final fallback =
        _preferredSubtitleTrack(
          embeddedSubtitleTracks,
          settings.sourceLanguage,
        ) ??
        embeddedSubtitleTracks.firstWhere(
          (track) => track.isDefault,
          orElse: () => embeddedSubtitleTracks.first,
        );
    final translation = _preferredSubtitleTrack(
      embeddedSubtitleTracks,
      settings.targetLanguage,
      excludingOrdinal: fallback.ordinal,
    );
    _embeddedWindowedMode =
        fallback.isTextBased || (translation?.isTextBased ?? false);
    await _useNativeEmbeddedPair(
      originalTrack: fallback,
      translationTrack: translation,
      extractionError: '轨道文本正在后台提取',
    );
    return true;
  }

  Future<void> openSubtitlePicker() async {
    clearMessages();
    final result = await FilePicker.pickFiles(
      type: FileType.custom,
      allowMultiple: false,
      allowedExtensions: const ['srt', 'vtt', 'ass', 'ssa'],
    );
    final path = result?.files.single.path;
    if (path == null) return;
    await loadSubtitle(path);
  }

  Future<void> loadSubtitle(String path) async {
    final file = File(path);
    final parsed = _parser.parseBytes(
      await file.readAsBytes(),
      fileName: file.uri.pathSegments.last,
    );
    if (parsed.isEmpty) {
      lastError = '没有从该文件中解析出有效字幕。';
      notifyListeners();
      return;
    }

    _setCues(parsed);
    _embeddedWindowedMode = false;
    _embeddedWindowCacheKeys.clear();
    _embeddedWindowLoadingKeys.clear();
    _embeddedWindowPrefetchKeys.clear();
    selectedEmbeddedSubtitleOrdinal = null;
    selectedOriginalSubtitleOrdinal = null;
    selectedTranslationSubtitleOrdinal = null;
    _embeddedSelectionRevision++;
    await _disableNativeSubtitleTracks();
    _syncCurrentCue(force: true, clearLookup: true);
    final effectivelyBilingual = _isEffectivelyBilingual(_cues);
    lastNotice = effectivelyBilingual
        ? '已载入 ${_cues.length} 条双语字幕。'
        : '已载入 ${_cues.length} 条字幕；可继续自动翻译为双语。';
    notifyListeners();
    if (settings.autoPrepareSubtitles &&
        !effectivelyBilingual &&
        !processing.isRunning) {
      unawaited(translateCurrentSubtitles());
    }
  }

  Future<void> selectEmbeddedSubtitleTrack(
    int ordinal, {
    bool combineWithCurrent = false,
  }) {
    final tapped = _trackForOrdinal(ordinal);
    if (tapped?.isGenerated == true && !combineWithCurrent) {
      return selectEmbeddedSubtitlePair(translationOrdinal: ordinal);
    }
    if (combineWithCurrent) {
      final currentOriginal = selectedOriginalSubtitleTrack;
      final currentTranslation = selectedTranslationSubtitleTrack;
      if (currentOriginal != null &&
          currentTranslation == null &&
          currentOriginal.ordinal != ordinal) {
        return selectEmbeddedSubtitlePair(
          originalOrdinal: currentOriginal.ordinal,
          translationOrdinal: ordinal,
        );
      }
      if (currentTranslation != null &&
          currentOriginal == null &&
          currentTranslation.ordinal != ordinal) {
        return selectEmbeddedSubtitlePair(
          originalOrdinal: ordinal,
          translationOrdinal: currentTranslation.ordinal,
        );
      }
    }
    return selectEmbeddedSubtitlePair(originalOrdinal: ordinal);
  }

  /// Selects up to two text subtitle tracks and joins them on the video's
  /// timeline.  The first track is shown as the original line and the second
  /// as the translation line; either role may be left empty.
  Future<void> selectEmbeddedSubtitlePair({
    int? originalOrdinal,
    int? translationOrdinal,
  }) async {
    final path = mediaPath;
    final subtitleMediaPath = _activePlaybackUrl ?? path;
    if (path == null || subtitleMediaPath == null) return;
    final selectionRevision = ++_embeddedSelectionRevision;
    if (originalOrdinal != null && originalOrdinal == translationOrdinal) {
      translationOrdinal = null;
    }

    final originalTrack = _trackForOrdinal(originalOrdinal);
    final translationTrack = _trackForOrdinal(translationOrdinal);
    if (originalOrdinal != null && originalTrack == null ||
        translationOrdinal != null && translationTrack == null) {
      return;
    }
    if (originalTrack != null && !originalTrack.isTextBased) {
      if (translationTrack != null) {
        lastError = '图形字幕不能与另一条字幕合并；请选择文本字幕轨道。';
        notifyListeners();
        return;
      }
      clearMessages();
      _embeddedWindowedMode = false;
      subtitleLoading = true;
      notifyListeners();
      try {
        await _useNativeEmbeddedTrack(originalTrack);
      } finally {
        subtitleLoading = false;
        notifyListeners();
      }
      return;
    }
    if (translationTrack != null && !translationTrack.isTextBased) {
      lastError = '图形字幕不能作为译文轨道，请选择 ASS/SRT/MOV_TEXT 等文本字幕。';
      notifyListeners();
      return;
    }
    if (originalTrack == null && translationTrack == null) return;

    clearMessages();
    subtitleLoading = true;
    notifyListeners();
    final loadToken = _mediaLoadToken;
    try {
      // Switch the native renderer immediately, then upgrade to clickable
      // text after extraction.  Remote MKV subtitle extraction can take a
      // while, and leaving the default Arabic track visible during that wait
      // made a valid click look like a no-op.
      final previewOriginal = originalTrack ?? translationTrack;
      final previewTranslation = originalTrack == null
          ? null
          : translationTrack;
      await _setNativeSubtitlePair(
        originalTrack: previewOriginal,
        translationTrack: previewTranslation,
      );
      _embeddedSubtitleAlignmentOffset = null;
      _setCues(const []);
      _currentCueIndex = -1;
      selectedEmbeddedSubtitleOrdinal =
          originalTrack?.ordinal ?? translationTrack?.ordinal;
      selectedOriginalSubtitleOrdinal = originalTrack?.ordinal;
      selectedTranslationSubtitleOrdinal = translationTrack?.ordinal;
      _embeddedWindowedMode = true;
      _embeddedWindowCacheKeys.clear();
      _embeddedWindowLoadingKeys.clear();
      _embeddedWindowPrefetchKeys.clear();
      mediaMeta = '内嵌字幕 · 正在载入可导航文本';
      lastNotice = translationTrack == null
          ? '已切换到 ${previewOriginal?.label ?? '所选轨道'}，正在载入字幕导航…'
          : '已显示原文与译文，正在载入双语字幕导航…';
      notifyListeners();
      final (windowStart, windowEnd, windowBucket) = _embeddedWindowBounds(
        position,
      );
      final merged = await _extractEmbeddedWindowCues(
        mediaPath: subtitleMediaPath,
        original: originalTrack,
        translation: translationTrack,
        start: windowStart,
        end: windowEnd,
      );
      if (loadToken != _mediaLoadToken || mediaPath != path) return;
      if (selectionRevision != _embeddedSelectionRevision) return;
      if (merged.isEmpty) {
        await _useNativeEmbeddedPair(
          originalTrack: originalTrack ?? translationTrack,
          translationTrack: originalTrack == null ? null : translationTrack,
          extractionError: '当前时间附近的文本暂未提取，将随播放进度重试',
        );
      } else {
        _embeddedWindowCacheKeys.add(
          _embeddedWindowKey(
            bucket: windowBucket,
            original: originalTrack,
            translation: translationTrack,
          ),
        );
        await _useEmbeddedTextTracks(
          originalTrack: originalTrack,
          translationTrack: translationTrack,
          cues: merged,
        );
        unawaited(_ensureEmbeddedSubtitleWindow(position));
      }
    } on EmbeddedSubtitleException catch (error) {
      await _useNativeEmbeddedPair(
        originalTrack: originalTrack ?? translationTrack,
        translationTrack: originalTrack == null ? null : translationTrack,
        extractionError: error.message,
      );
    } finally {
      if (loadToken == _mediaLoadToken && mediaPath == path) {
        subtitleLoading = false;
        notifyListeners();
      }
    }
  }

  Future<void> _useEmbeddedTextTrack(
    EmbeddedSubtitleTrack track,
    List<SubtitleCue> cues, {
    bool automatic = false,
  }) async {
    await _useEmbeddedTextTracks(
      originalTrack: track,
      cues: cues,
      automatic: automatic,
    );
  }

  Future<void> _useEmbeddedTextTracks({
    required EmbeddedSubtitleTrack? originalTrack,
    EmbeddedSubtitleTrack? translationTrack,
    required List<SubtitleCue> cues,
    bool automatic = false,
  }) async {
    _setCues(cues);
    lastError = null;
    selectedEmbeddedSubtitleOrdinal =
        originalTrack?.ordinal ?? translationTrack?.ordinal;
    selectedOriginalSubtitleOrdinal = originalTrack?.ordinal;
    selectedTranslationSubtitleOrdinal = translationTrack?.ordinal;
    await _disableNativeSubtitleTracks();
    _syncCurrentCue(force: true, clearLookup: true);
    final labels = [
      if (originalTrack != null) '原文：${originalTrack.label}',
      if (translationTrack != null) '译文：${translationTrack.label}',
    ];
    final codecs = {
      if (originalTrack != null) originalTrack.codec.toUpperCase(),
      if (translationTrack != null) translationTrack.codec.toUpperCase(),
    }.join('+');
    mediaMeta = '内嵌 $codecs · ${embeddedSubtitleTracks.length} 条字幕轨';
    final bilingual =
        originalTrack != null &&
        translationTrack != null &&
        _isEffectivelyBilingual(_cues);
    lastNotice = bilingual
        ? '已匹配双语内嵌字幕：${labels.join('  ·  ')}（时间线已自动对齐）'
        : '${automatic ? '已自动匹配' : '已切换到'}内嵌字幕：'
              '${labels.join('  ·  ')}（${_cues.length} 条）';
    notifyListeners();
    if (settings.autoPrepareSubtitles &&
        !bilingual &&
        !processing.isRunning &&
        _cues.isNotEmpty) {
      unawaited(translateCurrentSubtitles());
    }
  }

  Future<void> _useNativeEmbeddedTrack(
    EmbeddedSubtitleTrack track, {
    String? extractionError,
  }) async {
    await _useNativeEmbeddedPair(
      originalTrack: track,
      extractionError: extractionError,
    );
    if (extractionError == null && !track.isTextBased) {
      lastNotice = '已启用内嵌图形字幕：${track.label}；该格式不支持点击查词与字幕导航。';
      notifyListeners();
    }
  }

  Future<void> _useNativeEmbeddedPair({
    required EmbeddedSubtitleTrack? originalTrack,
    EmbeddedSubtitleTrack? translationTrack,
    String? extractionError,
  }) async {
    if (originalTrack == null && translationTrack == null) return;
    lastError = null;
    final primary = originalTrack ?? translationTrack!;
    await _setNativeSubtitlePair(
      originalTrack: primary,
      translationTrack: originalTrack == null ? null : translationTrack,
    );
    _setCues(const []);
    _currentCueIndex = -1;
    selectedEmbeddedSubtitleOrdinal =
        originalTrack?.ordinal ?? translationTrack?.ordinal;
    selectedOriginalSubtitleOrdinal = originalTrack?.ordinal;
    selectedTranslationSubtitleOrdinal = translationTrack?.ordinal;
    mediaMeta =
        '内嵌 ${primary.codec.toUpperCase()} · '
        '${embeddedSubtitleTracks.length} 条字幕轨';
    final labels = [
      if (originalTrack != null) '原文：${originalTrack.label}',
      if (translationTrack != null) '译文：${translationTrack.label}',
    ];
    lastNotice = extractionError == null
        ? '已切换到 ${labels.join('  ·  ')}；正在准备字幕导航。'
        : '已显示 ${labels.join('  ·  ')}；可导航文本提取未完成：$extractionError';
    notifyListeners();
  }

  Future<void> _setNativeSubtitlePair({
    required EmbeddedSubtitleTrack? originalTrack,
    EmbeddedSubtitleTrack? translationTrack,
  }) async {
    final nativeTracks = player.state.tracks.subtitle;
    final primary = originalTrack ?? translationTrack;
    final nativePrimary = primary == null || primary.isGenerated
        ? null
        : _resolveNativeSubtitleTrack(nativeTracks, primary);
    if (primary?.isGenerated == true) {
      try {
        await player.setSubtitleTrack(SubtitleTrack.no());
      } catch (_) {
        // The generated track is rendered by the clickable text overlay.
      }
    } else if (nativePrimary != null) {
      try {
        await player.setSubtitleTrack(nativePrimary);
      } catch (error) {
        // A remote track can appear in ffprobe before mpv has finished
        // publishing its native track list.  Do not abort the selection: the
        // text extraction below can still provide a clickable overlay.
        lastError = '原生字幕轨道暂时无法切换：$error';
        try {
          await player.setSubtitleTrack(SubtitleTrack.no());
        } catch (_) {
          // The player may still be opening the network media.
        }
      }
    } else {
      // Never fall back to `auto` here: that would silently re-enable the
      // container default (Arabic in the affected The Boys file).
      try {
        await player.setSubtitleTrack(SubtitleTrack.no());
      } catch (_) {
        // Keep the selection state and let text extraction finish even if the
        // native player is not ready yet.
      }
      lastError = '无法映射所选内嵌字幕轨道，正在尝试提取文本字幕。';
    }

    final nativeSecondary =
        originalTrack != null &&
            translationTrack != null &&
            !originalTrack.isGenerated &&
            !translationTrack.isGenerated
        ? _resolveNativeSubtitleTrack(nativeTracks, translationTrack)
        : null;
    try {
      if (nativeSecondary != null && nativeSecondary.id != nativePrimary?.id) {
        await _sendNativeCommand(['set', 'secondary-sid', nativeSecondary.id]);
        await _sendNativeCommand(['set', 'secondary-sub-visibility', 'yes']);
      } else {
        await _sendNativeCommand(['set', 'secondary-sid', 'no']);
      }
    } catch (_) {
      // Some older mpv builds do not expose secondary-sid.  The primary track
      // remains selected and the merged text overlay will provide bilingual
      // output once extraction completes.
    }
  }

  Future<void> _sendNativeCommand(List<String> command) async {
    final nativePlatform = player.platform;
    if (nativePlatform == null) return;
    // media_kit exposes `command` on its native implementation, but not on
    // the abstract PlatformPlayer type.  The app only calls this path on the
    // Windows/Android native backends.
    await (nativePlatform as dynamic).command(command);
  }

  Future<void> _disableNativeSubtitleTracks() async {
    try {
      await player.setSubtitleTrack(SubtitleTrack.no());
    } catch (_) {
      // The text overlay remains usable while the native player finishes
      // opening a remote stream.
    }
    try {
      await _sendNativeCommand(['set', 'secondary-sid', 'no']);
    } catch (_) {
      // Secondary subtitles are optional on older mpv builds.
    }
  }

  SubtitleTrack? _resolveNativeSubtitleTrack(
    List<SubtitleTrack> nativeTracks,
    EmbeddedSubtitleTrack track,
  ) {
    final available = nativeTracks
        .where((item) => item.id != 'auto' && item.id != 'no')
        .toList(growable: false);
    if (available.isEmpty) return null;

    final nativeId = track.nativeTrackId;
    if (nativeId != null) {
      for (final candidate in available) {
        if (candidate.id == nativeId) return candidate;
      }
    }

    // A track obtained from ffprobe has no mpv id.  Match its metadata first,
    // then use subtitle-only order as a safe fallback.  This avoids the old
    // `nativeTracks[ordinal]` mapping, which selected `auto`/`no` or the first
    // default stream for every remote track.
    final language = _subtitleLanguageKey(track.language);
    final title = track.title?.trim().toLowerCase();
    final metadataMatches = available
        .where((candidate) {
          final sameLanguage =
              language.isEmpty ||
              _subtitleLanguageKey(candidate.language) == language;
          final sameTitle =
              title == null ||
              title.isEmpty ||
              candidate.title?.trim().toLowerCase() == title;
          return sameLanguage && sameTitle;
        })
        .toList(growable: false);
    if (metadataMatches.length == 1) return metadataMatches.first;
    if (track.ordinal >= 0 && track.ordinal < available.length) {
      return available[track.ordinal];
    }
    return null;
  }

  Future<List<SubtitleCue>> _prepareFullTranslationCues() async {
    final path = mediaPath;
    final sourcePath = _activePlaybackUrl ?? path;
    final originalTrack = _windowOriginalTrack();
    final translationTrack = _windowTranslationTrack();
    if (path == null || sourcePath == null) {
      return List<SubtitleCue>.from(_cues);
    }

    final tracks = [
      ?originalTrack,
      if (translationTrack != null && translationTrack != originalTrack)
        translationTrack,
    ];
    if (tracks.isEmpty) return List<SubtitleCue>.from(_cues);

    processing.update(
      stage: ProcessingStage.translating,
      progress: 0.04,
      detail: '正在提取所选字幕轨道的完整时间轴…',
      modelThought: '先完整读取时间码，确保生成的外挂译文与原字幕逐条对应。',
    );
    final extracted = await Future.wait([
      for (final track in tracks)
        track.isGenerated
            ? Future.value(List<SubtitleCue>.from(track.generatedCues))
            : _embeddedSubtitles.extract(
                mediaPath: sourcePath,
                track: track,
                headers: _activePlaybackHeaders,
              ),
    ]);
    final original = originalTrack == null || originalTrack.isGenerated
        ? const <SubtitleCue>[]
        : extracted[tracks.indexOf(originalTrack)];
    final translation = translationTrack == null
        ? const <SubtitleCue>[]
        : extracted[tracks.indexOf(translationTrack)];
    final merged = EmbeddedSubtitleAlignment.merge(
      original: original,
      translation: translation,
      offset: _embeddedSubtitleAlignmentOffset,
    );
    if (merged.isNotEmpty) {
      _setCues(merged);
      _syncCurrentCue(force: true, clearLookup: true);
    }
    return List<SubtitleCue>.from(_cues);
  }

  Future<String?> _writeGeneratedTranslationTrack(
    List<SubtitleCue> translationCues,
  ) async {
    final path = mediaPath;
    if (path == null || translationCues.isEmpty) return null;
    try {
      final isRemote = path.contains('://');
      final targetPath = isRemote
          ? '${(await getTemporaryDirectory()).path}${Platform.pathSeparator}'
                'yingyu-${path.hashCode.abs()}-${settings.targetLanguage}.srt'
          : '${path.replaceFirst(RegExp(r'\.[^.\\/]+$'), '')}'
                '.yingyu-${settings.targetLanguage}.srt';
      final file = await SubtitleWriter.writeSrt(
        path: targetPath,
        cues: translationCues,
      );
      return file.path;
    } on Object {
      // A remote stream may not have a writable local path.  The virtual track
      // remains selectable from memory, so a file write failure is non-fatal.
      return null;
    }
  }

  Future<EmbeddedSubtitleTrack?> _installGeneratedTranslationTrack(
    List<SubtitleCue> translated,
  ) async {
    final translationCues = [
      for (final cue in translated)
        if (cue.translation.trim().isNotEmpty)
          SubtitleCue(
            id: 'translation-${cue.id}',
            start: cue.start,
            end: cue.end,
            original: cue.translation.trim(),
            speaker: cue.speaker,
          ),
    ];
    if (translationCues.isEmpty) return null;
    final outputPath = await _writeGeneratedTranslationTrack(translationCues);
    final nextOrdinal = embeddedSubtitleTracks.isEmpty
        ? 0
        : embeddedSubtitleTracks
                  .map((track) => track.ordinal)
                  .reduce(math.max) +
              1;
    final generated = EmbeddedSubtitleTrack(
      ordinal: nextOrdinal,
      streamIndex: -1,
      codec: 'srt',
      language: settings.targetLanguage,
      title: '影语 ${localTranslationEnabled ? '本地' : '在线'}译文',
      isDefault: false,
      isForced: false,
      isGenerated: true,
      generatedCues: translationCues,
      externalPath: outputPath,
    );
    embeddedSubtitleTracks = [
      for (final track in embeddedSubtitleTracks)
        if (!track.isGenerated) track,
      generated,
    ];
    return generated;
  }

  void _activateGeneratedTranslationTrack(
    EmbeddedSubtitleTrack generated, {
    required int? originalOrdinal,
  }) {
    final original = _trackForOrdinal(originalOrdinal);
    final useOriginal = original != null && !original.isGenerated;
    selectedOriginalSubtitleOrdinal = useOriginal ? original.ordinal : null;
    selectedTranslationSubtitleOrdinal = generated.ordinal;
    selectedEmbeddedSubtitleOrdinal = useOriginal
        ? original.ordinal
        : generated.ordinal;
    _embeddedWindowedMode = false;
    _embeddedWindowCacheKeys.clear();
    _embeddedWindowLoadingKeys.clear();
    _embeddedWindowPrefetchKeys.clear();
    _embeddedSelectionRevision++;
    mediaMeta = '外挂 SRT · ${settings.targetLanguage} · 一一对应';
  }

  Future<void> translateCurrentSubtitles() async {
    if (processing.isRunning) return;
    final wasPlaying = isPlaying;
    if (wasPlaying) await player.pause();
    processing.reset();
    processing.update(
      stage: ProcessingStage.translating,
      progress: 0.02,
      detail: localTranslationEnabled ? '正在准备本地模型翻译全部字幕…' : '正在准备在线模型翻译全部字幕…',
      modelThought: '暂停播放，准备按原字幕时间码逐条生成对应译文。',
    );
    try {
      final originalOrdinal =
          selectedOriginalSubtitleOrdinal ??
          (selectedTranslationSubtitleOrdinal == null
              ? selectedEmbeddedSubtitleOrdinal
              : null);
      final sourceCues = await _prepareFullTranslationCues();
      if (sourceCues.isEmpty) {
        throw StateError('请先加载一份可解析的单语字幕。');
      }
      processing.update(
        stage: ProcessingStage.translating,
        progress: 0.1,
        detail: '已准备 ${sourceCues.length} 条字幕，开始逐条翻译…',
        totalUnits: sourceCues.length,
        completedUnits: sourceCues
            .where((cue) => cue.translation.trim().isNotEmpty)
            .length,
        currentOriginal: sourceCues.first.original,
        currentTranslation: '',
        modelThought: localTranslationEnabled
            ? '本地模型将结合前后字幕语境处理每一条句子。'
            : '在线模型将结合前后字幕语境处理每一条句子。',
      );
      final translated = localTranslationEnabled
          ? await _localTranslation.translateCues(
              cues: sourceCues,
              sourceLanguage: settings.sourceLanguage,
              targetLanguage: settings.targetLanguage,
              modelsDirectory: localModelDirectory,
              modelName: localModelName,
              onProgress: (progress) {
                final fraction = progress.total <= 0
                    ? 0.2
                    : 0.1 + 0.8 * progress.completed / progress.total;
                processing.update(
                  stage: ProcessingStage.translating,
                  progress: fraction,
                  detail: '本地模型翻译中 · ${progress.completed}/${progress.total} 条',
                  completedUnits: progress.completed,
                  totalUnits: progress.total,
                  currentOriginal: progress.original,
                  currentTranslation: progress.translation,
                  modelThought: progress.thought,
                );
              },
            )
          : await _translateOnlineWithProgress(sourceCues);
      final missing = translated
          .where(
            (cue) =>
                cue.original.trim().isNotEmpty &&
                cue.translation.trim().isEmpty,
          )
          .length;
      if (missing > 0) {
        throw StateError('模型未返回 $missing 条字幕译文，未生成不完整的外挂翻译轨。');
      }
      _setCues(translated);
      final generated = await _installGeneratedTranslationTrack(translated);
      await _disableNativeSubtitleTracks();
      _syncCurrentCue(force: true, clearLookup: true);
      if (generated != null) {
        _activateGeneratedTranslationTrack(
          generated,
          originalOrdinal: originalOrdinal,
        );
      }
      lastUsageCharge = localTranslationEnabled
          ? null
          : _pipeline.lastUsageCharge;
      processing.update(
        stage: ProcessingStage.completed,
        progress: 1,
        detail: '已生成 ${translated.length} 条双语字幕，并创建一一对应的外挂译文轨。',
        completedUnits: translated.length,
        totalUnits: translated.length,
        currentOriginal: translated.isEmpty ? '' : translated.last.original,
        currentTranslation: translated.isEmpty
            ? ''
            : translated.last.translation,
        modelThought: '时间码已保留，外挂译文轨现在可以和任意内嵌原文轨组合。',
      );
      if (localTranslationEnabled) {
        localTranslationReady = true;
        localModelRuntime = _localTranslation.runtime;
        lastNotice = generated?.externalPath == null
            ? '本地模型已翻译全部字幕并生成外挂译文轨，不需要登录且不扣除点数。'
            : '本地模型已翻译全部字幕并生成外挂译文轨：${generated!.externalPath}';
      } else {
        final charge = lastUsageCharge;
        final billing = charge == null
            ? '在线模型已翻译全部字幕并生成外挂译文轨。'
            : '翻译完成，扣除 ${charge.chargedCredits} 点，余额 ${charge.balanceCredits} 点。';
        lastNotice = generated?.externalPath == null
            ? billing
            : '$billing 文件：${generated!.externalPath}';
        unawaited(refreshBilling(silent: true));
      }
    } catch (error) {
      processing.fail(error.toString());
      lastError = error.toString();
    } finally {
      if (wasPlaying && hasMedia) await player.play();
      notifyListeners();
    }
  }

  Future<List<SubtitleCue>> _translateOnlineWithProgress(
    List<SubtitleCue> sourceCues,
  ) async {
    processing.update(
      stage: ProcessingStage.translating,
      progress: 0.16,
      detail: '在线模型正在翻译 ${sourceCues.length} 条字幕…',
      currentOriginal: sourceCues.first.original,
      currentTranslation: '',
      modelThought: '正在结合前后句判断语气、代词和专有名词；仅展示摘要状态。',
    );
    final translated = await _pipeline.translateStream(
      cues: sourceCues,
      sourceLanguage: settings.sourceLanguage,
      targetLanguage: settings.targetLanguage,
      onStatus: (message) {
        processing.update(
          stage: ProcessingStage.translating,
          progress: 0.16,
          detail: message,
          totalUnits: sourceCues.length,
          modelThought: '模型正在结合前后字幕语境生成译文。',
        );
      },
      onPartial: (batch, completed, total) {
        final current = batch.lastOrNull;
        final fraction = total <= 0
            ? 0.2
            : (0.16 + 0.74 * completed / total).clamp(0.16, 0.92);
        processing.update(
          stage: ProcessingStage.translating,
          progress: fraction,
          detail: '在线模型流式翻译中 · $completed/$total 条',
          completedUnits: completed,
          totalUnits: total,
          currentOriginal: current?.original ?? '',
          currentTranslation: current?.translation ?? '',
          modelThought: '已收到一批译文，继续结合前后字幕语境处理下一批。',
        );
      },
    );
    final last = translated.lastOrNull;
    processing.update(
      stage: ProcessingStage.translating,
      progress: 0.93,
      detail: '在线模型返回结果，正在逐条校验时间码…',
      completedUnits: translated.length,
      totalUnits: sourceCues.length,
      currentOriginal: last?.original ?? '',
      currentTranslation: last?.translation ?? '',
      modelThought: '正在检查每条字幕是否都有对应译文，避免生成错位外挂轨。',
    );
    return translated;
  }

  Future<void> generateSubtitles() async {
    final path = mediaPath;
    if (path == null) {
      lastError = '请先打开一个本地视频。';
      notifyListeners();
      return;
    }
    if (localTranslationEnabled) {
      lastError = '本地模型模式已禁用联网模型。无字幕视频的语音识别需要暂时关闭本地模式，或先载入单语字幕。';
      notifyListeners();
      return;
    }
    processing.reset();
    try {
      final generated = await _pipeline.processVideo(
        file: File(path),
        sourceLanguage: settings.sourceLanguage,
        targetLanguage: settings.targetLanguage,
        state: processing,
      );
      _setCues(generated);
      _embeddedWindowedMode = false;
      _embeddedWindowCacheKeys.clear();
      _embeddedWindowLoadingKeys.clear();
      _embeddedWindowPrefetchKeys.clear();
      selectedEmbeddedSubtitleOrdinal = null;
      selectedOriginalSubtitleOrdinal = null;
      selectedTranslationSubtitleOrdinal = null;
      _embeddedSelectionRevision++;
      await _disableNativeSubtitleTracks();
      _syncCurrentCue(force: true, clearLookup: true);
      lastNotice = 'SeedASR 2.0 已生成双语字幕。';
      unawaited(refreshBilling(silent: true));
    } catch (error) {
      processing.fail(error.toString());
      lastError = error.toString();
    }
    notifyListeners();
  }

  Future<void> applySettings({
    required String pipelineBaseUrl,
    required String sourceLanguage,
    required String targetLanguage,
    required bool autoPrepareSubtitles,
  }) async {
    settings
      ..pipelineBaseUrl = pipelineBaseUrl
      ..sourceLanguage = sourceLanguage
      ..targetLanguage = targetLanguage
      ..autoPrepareSubtitles = autoPrepareSubtitles;
    await settings.save();
    _pipeline.close();
    _pipeline = PipelineClient(baseUrl: settings.pipelineBaseUrl);
    _dictionary = DictionaryService(_pipeline);
    accountSession = null;
    accountError = null;
    billingOverview = null;
    billingError = null;
    lastNotice = '字幕服务设置已保存。';
    notifyListeners();
    if (settings.autoPrepareSubtitles && !processing.isRunning) {
      if (_cues.isEmpty &&
          mediaPath != null &&
          embeddedSubtitleTracks.isEmpty) {
        unawaited(generateSubtitles());
      } else if (_cues.any((cue) => !cue.isBilingual)) {
        unawaited(translateCurrentSubtitles());
      }
    }
  }

  Future<void> togglePlay() async {
    if (hasMedia) {
      await player.playOrPause();
      return;
    }
    isPlaying = !isPlaying;
    if (isPlaying) {
      _demoTicker ??= Timer.periodic(const Duration(milliseconds: 250), (_) {
        position += const Duration(milliseconds: 250);
        if (position >= duration) position = Duration.zero;
        _syncCurrentCue();
        notifyListeners();
      });
    } else {
      _demoTicker?.cancel();
      _demoTicker = null;
    }
    notifyListeners();
  }

  Future<void> seek(Duration target) async {
    final clamped = Duration(
      milliseconds: target.inMilliseconds.clamp(0, duration.inMilliseconds),
    );
    if (hasMedia) {
      _clearPendingResume();
      await player.seek(clamped);
    } else {
      position = clamped;
      _syncCurrentCue(force: true);
      notifyListeners();
    }
  }

  Future<void> seekRelative(Duration delta) => seek(position + delta);

  Future<void> seekCue(int index, {bool autoplay = true}) async {
    if (index < 0 || index >= _cues.length) return;
    _currentCueIndex = index;
    await seek(_cues[index].start);
    if (hasMedia && autoplay && !isPlaying) await player.play();
    notifyListeners();
  }

  Future<void> seekAdjacentCue(int delta) async {
    if (_cues.isEmpty) return;
    await seekCue((_currentCueIndex + delta).clamp(0, _cues.length - 1));
  }

  Future<bool> searchAndSeek(String query) async {
    final normalized = query.trim().toLowerCase();
    if (normalized.isEmpty) return false;
    final index = _cues.indexWhere(
      (cue) =>
          cue.original.toLowerCase().contains(normalized) ||
          cue.translation.toLowerCase().contains(normalized),
    );
    if (index < 0) {
      lastNotice = '没有找到包含“${query.trim()}”的字幕。';
      notifyListeners();
      return false;
    }
    await seekCue(index);
    return true;
  }

  Future<void> setRate(double value) async {
    playbackRate = value;
    if (hasMedia) await player.setRate(value);
    notifyListeners();
  }

  Future<void> setFrameInterpolationMode(FrameInterpolationMode mode) async {
    frameInterpolationMode = mode;
    settings.frameInterpolationMode = mode.name;
    unawaited(settings.save());
    notifyListeners();
    if (!hasMedia) return;
    try {
      await _applyFrameInterpolation(mode);
      lastNotice = mode == FrameInterpolationMode.off
          ? '视频插帧已关闭。'
          : '已启用${mode.label}插帧；高分辨率视频可能增加耗电与发热。';
    } catch (_) {
      frameInterpolationMode = FrameInterpolationMode.off;
      settings.frameInterpolationMode = FrameInterpolationMode.off.name;
      unawaited(settings.save());
      lastError = '当前设备无法启用视频插帧，已恢复原始帧率。';
    }
    notifyListeners();
  }

  Future<void> _restoreFrameInterpolation() async {
    try {
      await _applyFrameInterpolation(frameInterpolationMode);
    } catch (_) {
      frameInterpolationMode = FrameInterpolationMode.off;
      settings.frameInterpolationMode = FrameInterpolationMode.off.name;
      unawaited(settings.save());
    }
  }

  Future<void> _applyFrameInterpolation(FrameInterpolationMode mode) async {
    final nativePlayer = player.platform;
    if (nativePlayer is! NativePlayer) return;
    if (mode == FrameInterpolationMode.off) {
      await nativePlayer.setProperty('interpolation', 'no');
      await nativePlayer.setProperty('video-sync', 'audio');
      await nativePlayer.setProperty('interpolation-threshold', '0.01');
      return;
    }
    await nativePlayer.setProperty('video-sync', 'display-resample');
    await nativePlayer.setProperty('interpolation', 'yes');
    await nativePlayer.setProperty('interpolation-threshold', '-1');
    await nativePlayer.setProperty(
      'tscale',
      mode == FrameInterpolationMode.balanced ? 'oversample' : 'mitchell',
    );
  }

  Future<void> adjustVolume(double delta) async {
    volume = (volume + delta).clamp(0, 100);
    if (hasMedia) await player.setVolume(volume);
    notifyListeners();
  }

  void adjustVisualBrightness(double delta) {
    visualBrightness = (visualBrightness + delta).clamp(0.35, 1);
    notifyListeners();
  }

  void setSubtitleBottomOffset(double value) {
    subtitleBottomOffset = value.clamp(-160, 220);
    settings.subtitleBottomOffset = subtitleBottomOffset;
    unawaited(settings.save());
    notifyListeners();
  }

  void setSubtitleOriginalScale(double value) {
    subtitleOriginalScale = value.clamp(0.65, 1.75);
    settings.subtitleOriginalScale = subtitleOriginalScale;
    unawaited(settings.save());
    notifyListeners();
  }

  void setSubtitleTranslationScale(double value) {
    subtitleTranslationScale = value.clamp(0.65, 1.75);
    settings.subtitleTranslationScale = subtitleTranslationScale;
    unawaited(settings.save());
    notifyListeners();
  }

  void setSubtitleTranslationFirst(bool value) {
    subtitleTranslationFirst = value;
    settings.subtitleTranslationFirst = value;
    unawaited(settings.save());
    notifyListeners();
  }

  void setHideHearingImpairedSubtitles(bool value) {
    if (hideHearingImpairedSubtitles == value) return;
    hideHearingImpairedSubtitles = value;
    settings.hideHearingImpairedSubtitles = value;
    _refreshVisibleCues();
    _syncCurrentCue(force: true);
    unawaited(settings.save());
    notifyListeners();
  }

  void toggleDrawer() {
    drawerOpen = !drawerOpen;
    notifyListeners();
  }

  void togglePlaylist() {
    playlistOpen = !playlistOpen;
    notifyListeners();
  }

  void setDrawer(bool value) {
    drawerOpen = value;
    notifyListeners();
  }

  void toggleSentenceLoop() {
    sentenceLoop = !sentenceLoop;
    notifyListeners();
  }

  void toggleLock() {
    controlsLocked = !controlsLocked;
    if (controlsLocked) {
      drawerOpen = false;
      playlistOpen = false;
    }
    notifyListeners();
  }

  void setSubtitleMode(SubtitleDisplayMode mode) {
    subtitleMode = mode;
    notifyListeners();
  }

  void setOsdVisible(bool value) {
    if (controlsLocked && value) return;
    osdVisible = value;
    notifyListeners();
  }

  Future<void> toggleFullscreen() async {
    if (Platform.isWindows) {
      isFullscreen = !await windowManager.isFullScreen();
      await windowManager.setFullScreen(isFullscreen);
      notifyListeners();
      return;
    }
    isFullscreen = !isFullscreen;
    await SystemChrome.setEnabledSystemUIMode(
      isFullscreen ? SystemUiMode.immersiveSticky : SystemUiMode.edgeToEdge,
    );
    notifyListeners();
  }

  Future<void> selectWord(String word, [String? sentence]) async {
    final querySentence = sentence ?? currentCue?.original ?? '';
    final requestToken = ++_lookupToken;
    selectedWord = word;
    _selectedSentence = querySentence;
    selectedEntry = null;
    dictionaryError = null;
    dictionaryPreview = const {};
    dictionaryStatus = localTranslationEnabled ? '正在准备本地模型…' : '正在连接词典服务…';
    lookupLoading = true;
    notifyListeners();
    void updatePartial(Map<String, String> fields) {
      if (requestToken != _lookupToken) return;
      dictionaryPreview = Map.unmodifiable(fields);
      notifyListeners();
    }

    void updateStatus(String message) {
      if (requestToken != _lookupToken) return;
      dictionaryStatus = message;
      notifyListeners();
    }

    try {
      final entry = localTranslationEnabled
          ? await _localTranslation.lookupDictionary(
              word: word,
              sentence: querySentence,
              targetLanguage: settings.targetLanguage,
              modelsDirectory: localModelDirectory,
              modelName: localModelName,
              onPartial: updatePartial,
              onStatus: updateStatus,
            )
          : await _dictionary.lookup(
              word: word,
              sentence: querySentence,
              onPartial: updatePartial,
              onStatus: updateStatus,
            );
      if (requestToken != _lookupToken) return;
      selectedEntry = entry;
      if (!localTranslationEnabled && _pipeline.lastUsageCharge != null) {
        lastUsageCharge = _pipeline.lastUsageCharge;
        unawaited(refreshBilling(silent: true));
      }
    } catch (error) {
      if (requestToken != _lookupToken) return;
      dictionaryError = error.toString();
    } finally {
      if (requestToken == _lookupToken) {
        lookupLoading = false;
        dictionaryStatus = null;
        dictionaryPreview = const {};
        notifyListeners();
      }
    }
  }

  Future<void> retryWordLookup() async {
    final word = selectedWord;
    if (word == null || lookupLoading) return;
    await selectWord(word, _selectedSentence);
  }

  Future<void> refreshBilling({bool silent = false}) async {
    if (localTranslationEnabled) {
      billingOverview = null;
      billingError = null;
      accountSession = null;
      billingLoading = false;
      if (!silent) notifyListeners();
      return;
    }
    if (billingLoading) return;
    billingLoading = true;
    if (!silent) billingError = null;
    notifyListeners();
    try {
      billingOverview = await _pipeline.billingOverview();
      accountSession = billingOverview!.account;
      billingError = null;
    } catch (error) {
      if (!silent) billingError = error.toString();
    } finally {
      billingLoading = false;
      notifyListeners();
    }
  }

  Future<void> refreshAccount({bool silent = false}) async {
    if (localTranslationEnabled) {
      accountSession = null;
      accountError = null;
      accountLoading = false;
      if (!silent) notifyListeners();
      return;
    }
    if (accountLoading) return;
    accountLoading = true;
    if (!silent) accountError = null;
    notifyListeners();
    try {
      accountSession = await _pipeline.currentAccount();
      accountError = null;
    } catch (error) {
      if (!silent) accountError = error.toString();
    } finally {
      accountLoading = false;
      notifyListeners();
    }
  }

  Future<bool> loginAccount({
    required String username,
    required String password,
  }) async {
    if (localTranslationEnabled) {
      accountError = '本地模型模式无需登录；关闭本地模型后才能使用联网服务。';
      notifyListeners();
      return false;
    }
    if (accountLoading) return false;
    accountLoading = true;
    accountError = null;
    notifyListeners();
    try {
      accountSession = await _pipeline.loginAccount(
        username: username.trim(),
        password: password,
      );
      billingOverview = null;
      unawaited(refreshBilling(silent: true));
      if (Platform.isAndroid) unawaited(refreshCloudMedia());
      return true;
    } catch (error) {
      accountError = error.toString();
      return false;
    } finally {
      accountLoading = false;
      notifyListeners();
    }
  }

  Future<bool> registerAccount({
    required String username,
    required String email,
    required String verificationCode,
    required String password,
    String? displayName,
  }) async {
    if (localTranslationEnabled) {
      accountError = '本地模型模式无需注册；关闭本地模型后才能使用联网服务。';
      notifyListeners();
      return false;
    }
    if (accountLoading) return false;
    accountLoading = true;
    accountError = null;
    notifyListeners();
    try {
      accountSession = await _pipeline.registerAccount(
        username: username.trim(),
        email: email.trim(),
        verificationCode: verificationCode.trim(),
        password: password,
        displayName: displayName?.trim(),
      );
      billingOverview = null;
      unawaited(refreshBilling(silent: true));
      if (Platform.isAndroid) unawaited(refreshCloudMedia());
      return true;
    } catch (error) {
      accountError = error.toString();
      return false;
    } finally {
      accountLoading = false;
      notifyListeners();
    }
  }

  Future<int?> requestEmailVerification(String email) async {
    if (localTranslationEnabled) {
      accountError = '本地模型模式无需邮箱验证。';
      notifyListeners();
      return null;
    }
    if (emailCodeLoading || accountLoading) return null;
    emailCodeLoading = true;
    accountError = null;
    notifyListeners();
    try {
      return await _pipeline.requestEmailVerification(email.trim());
    } catch (error) {
      accountError = error.toString();
      return null;
    } finally {
      emailCodeLoading = false;
      notifyListeners();
    }
  }

  Future<void> logoutAccount() async {
    if (localTranslationEnabled) {
      accountSession = null;
      billingOverview = null;
      billingError = null;
      accountError = null;
      notifyListeners();
      return;
    }
    if (accountLoading) return;
    accountLoading = true;
    accountError = null;
    notifyListeners();
    try {
      await _pipeline.logoutAccount();
      accountSession = null;
      billingOverview = null;
      billingError = null;
    } catch (error) {
      accountError = error.toString();
    } finally {
      accountLoading = false;
      notifyListeners();
    }
  }

  Future<void> openCheckout(String packageId) async {
    if (localTranslationEnabled) {
      billingError = '本地模型模式不使用联网模型，也不需要充值。';
      notifyListeners();
      return;
    }
    if (!externalCheckoutAllowed) {
      billingError = '此 Android 发行版不允许外部数字内容结算。';
      notifyListeners();
      return;
    }
    billingLoading = true;
    billingError = null;
    notifyListeners();
    try {
      final url = await _pipeline.createCheckout(packageId);
      final opened = await launchUrl(url, mode: LaunchMode.externalApplication);
      if (!opened) throw PipelineException('无法打开系统支付页面。');
      lastNotice = '已在系统浏览器打开安全支付页；付款后请刷新额度。';
    } catch (error) {
      billingError = error.toString();
    } finally {
      billingLoading = false;
      notifyListeners();
    }
  }

  void closeDictionary() {
    _clearLookupSelection();
    notifyListeners();
  }

  void _clearLookupSelection() {
    _lookupToken++;
    selectedEntry = null;
    selectedWord = null;
    dictionaryError = null;
    dictionaryPreview = const {};
    dictionaryStatus = null;
    _selectedSentence = '';
    lookupLoading = false;
  }

  void toggleSavedWord() {
    final word = selectedEntry?.word.toLowerCase();
    if (word == null) return;
    if (!savedWords.add(word)) savedWords.remove(word);
    notifyListeners();
  }

  bool isSaved(String word) => savedWords.contains(word.toLowerCase());

  void clearMessages() {
    lastError = null;
    lastNotice = null;
    notifyListeners();
  }

  void reportPlayerActionError(Object error) {
    lastError = error.toString();
    notifyListeners();
  }

  bool _isEffectivelyBilingual(List<SubtitleCue> cues) {
    if (cues.isEmpty) return false;
    final bilingualCount = cues.where((cue) => cue.isBilingual).length;
    return bilingualCount == cues.length ||
        (bilingualCount >= 3 && bilingualCount / cues.length >= 0.15);
  }

  void _syncCurrentCue({bool force = false, bool clearLookup = false}) {
    if (_cues.isEmpty) {
      _currentCueIndex = -1;
      return;
    }
    final oldIndex = _currentCueIndex;
    var candidate = oldIndex;
    if (candidate >= 0 &&
        candidate < _cues.length &&
        _cues[candidate].contains(position)) {
      _handleLearningModes(candidate);
      return;
    }

    var low = 0;
    var high = _cues.length - 1;
    candidate = -1;
    while (low <= high) {
      final middle = (low + high) >> 1;
      final cue = _cues[middle];
      if (position < cue.start) {
        high = middle - 1;
      } else if (position >= cue.end) {
        low = middle + 1;
      } else {
        candidate = middle;
        break;
      }
    }

    if (candidate < 0) {
      candidate = high.clamp(0, _cues.length - 1);
    }
    _currentCueIndex = candidate;
    if (clearLookup && (force || oldIndex != candidate)) {
      _clearLookupSelection();
    }
    _handleLearningModes(candidate);
  }

  void _handleLearningModes(int index) {
    final cue = _cues[index];
    if (sentenceLoop &&
        isPlaying &&
        position >= cue.end - const Duration(milliseconds: 90)) {
      unawaited(seek(cue.start));
      return;
    }
  }

  @override
  void dispose() {
    _mediaLoadToken++;
    _coverLoadToken++;
    _demoTicker?.cancel();
    for (final subscription in _subscriptions) {
      unawaited(subscription.cancel());
    }
    processing.dispose();
    _pipeline.close();
    unawaited(_localTranslation.close());
    unawaited(_authenticatedMediaProxy.close());
    _onlineStreamClient.close();
    unawaited(player.dispose());
    super.dispose();
  }
}
