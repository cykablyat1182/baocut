import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../domain/models/billing.dart';
import 'learning_player_controller.dart';

Future<void> showAccountDialog(
  BuildContext context,
  LearningPlayerController controller,
) => showDialog<void>(
  context: context,
  builder: (_) => _AccountDialog(controller: controller),
);

class _AccountDialog extends StatefulWidget {
  const _AccountDialog({required this.controller});

  final LearningPlayerController controller;

  @override
  State<_AccountDialog> createState() => _AccountDialogState();
}

class _AccountDialogState extends State<_AccountDialog> {
  final _username = TextEditingController();
  final _email = TextEditingController();
  final _verificationCode = TextEditingController();
  final _displayName = TextEditingController();
  final _password = TextEditingController();
  final _passwordConfirmation = TextEditingController();
  bool _registering = false;
  bool _obscurePassword = true;
  int _codeCooldown = 0;
  Timer? _cooldownTimer;
  String? _localError;
  String? _localNotice;

  @override
  void initState() {
    super.initState();
    unawaited(widget.controller.refreshAccount(silent: true));
  }

  @override
  void dispose() {
    _cooldownTimer?.cancel();
    _username.dispose();
    _email.dispose();
    _verificationCode.dispose();
    _displayName.dispose();
    _password.dispose();
    _passwordConfirmation.dispose();
    super.dispose();
  }

  bool _validEmail(String value) =>
      RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(value.trim());

  void _startCooldown() {
    _cooldownTimer?.cancel();
    setState(() => _codeCooldown = 60);
    _cooldownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (_codeCooldown <= 1) {
        timer.cancel();
        setState(() => _codeCooldown = 0);
      } else {
        setState(() => _codeCooldown--);
      }
    });
  }

  Future<void> _requestCode() async {
    final email = _email.text.trim();
    setState(() {
      _localError = null;
      _localNotice = null;
    });
    if (!_validEmail(email)) {
      setState(() => _localError = '请输入有效的电子邮箱。');
      return;
    }
    final expiresIn = await widget.controller.requestEmailVerification(email);
    if (expiresIn != null && mounted) {
      _startCooldown();
      setState(() {
        _localNotice = '验证码已发送，有效期约 ${expiresIn ~/ 60} 分钟。';
      });
    }
  }

  Future<void> _submit() async {
    final username = _username.text.trim();
    final password = _password.text;
    setState(() {
      _localError = null;
      _localNotice = null;
    });
    if (username.length < 3) {
      setState(() => _localError = '用户名至少需要 3 个字符。');
      return;
    }
    if (_registering && !_validEmail(_email.text)) {
      setState(() => _localError = '请输入有效的电子邮箱。');
      return;
    }
    if (_registering && !RegExp(r'^\d{6}$').hasMatch(_verificationCode.text)) {
      setState(() => _localError = '请输入邮件中的 6 位验证码。');
      return;
    }
    if (password.length < 8) {
      setState(() => _localError = '密码至少需要 8 个字符。');
      return;
    }
    if (_registering && password != _passwordConfirmation.text) {
      setState(() => _localError = '两次输入的密码不一致。');
      return;
    }

    final success = _registering
        ? await widget.controller.registerAccount(
            username: username,
            email: _email.text,
            verificationCode: _verificationCode.text,
            password: password,
            displayName: _displayName.text,
          )
        : await widget.controller.loginAccount(
            username: username,
            password: password,
          );
    if (success && mounted) {
      _password.clear();
      _passwordConfirmation.clear();
      _verificationCode.clear();
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.controller,
      builder: (context, _) {
        final account = widget.controller.accountSession;
        final signedIn = account != null && !account.profile.isGuest;
        final compact = MediaQuery.sizeOf(context).width < 600;
        return AlertDialog(
          insetPadding: EdgeInsets.symmetric(
            horizontal: compact ? 12 : 40,
            vertical: 24,
          ),
          titlePadding: const EdgeInsets.fromLTRB(24, 22, 14, 0),
          title: Row(
            children: [
              const Icon(Icons.person_outline_rounded, color: AppColors.amber),
              const SizedBox(width: 11),
              Expanded(child: Text(signedIn ? '我的账户' : '账户登录')),
              IconButton(
                tooltip: '关闭',
                onPressed: () => Navigator.of(context).pop(),
                icon: const Icon(Icons.close_rounded),
              ),
            ],
          ),
          content: SizedBox(
            width: compact ? double.infinity : 520,
            child: widget.controller.accountLoading && account == null
                ? const Padding(
                    padding: EdgeInsets.symmetric(vertical: 72),
                    child: Center(child: CircularProgressIndicator()),
                  )
                : signedIn
                ? _SignedInAccount(
                    account: account,
                    controller: widget.controller,
                  )
                : _buildAuthForm(),
          ),
        );
      },
    );
  }

  Widget _buildAuthForm() {
    final error = _localError ?? widget.controller.accountError;
    final busy =
        widget.controller.accountLoading || widget.controller.emailCodeLoading;
    return SingleChildScrollView(
      child: AutofillGroup(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFF1B1E21),
                borderRadius: BorderRadius.circular(11),
                border: Border.all(color: AppColors.divider),
              ),
              child: Row(
                children: [
                  const Icon(Icons.dns_outlined, color: AppColors.textMuted),
                  const SizedBox(width: 11),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          '影语账户服务',
                          style: TextStyle(
                            color: AppColors.ivory,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          widget.controller.settings.pipelineBaseUrl,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: AppColors.textMuted,
                            fontSize: 11.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(
                  value: false,
                  icon: Icon(Icons.login_rounded),
                  label: Text('登录'),
                ),
                ButtonSegment(
                  value: true,
                  icon: Icon(Icons.person_add_alt_1_rounded),
                  label: Text('注册'),
                ),
              ],
              selected: {_registering},
              onSelectionChanged: busy
                  ? null
                  : (selection) => setState(() {
                      _registering = selection.first;
                      _localError = null;
                      _localNotice = null;
                    }),
            ),
            const SizedBox(height: 17),
            TextField(
              controller: _username,
              autofocus: true,
              textInputAction: TextInputAction.next,
              autofillHints: const [AutofillHints.username],
              decoration: const InputDecoration(
                labelText: '用户名',
                prefixIcon: Icon(Icons.alternate_email_rounded),
                border: OutlineInputBorder(),
              ),
            ),
            if (_registering) ...[
              const SizedBox(height: 13),
              TextField(
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                textInputAction: TextInputAction.next,
                autofillHints: const [AutofillHints.email],
                decoration: const InputDecoration(
                  labelText: '电子邮箱',
                  prefixIcon: Icon(Icons.mail_outline_rounded),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 13),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: TextField(
                      controller: _verificationCode,
                      keyboardType: TextInputType.number,
                      textInputAction: TextInputAction.next,
                      maxLength: 6,
                      decoration: const InputDecoration(
                        labelText: '邮箱验证码',
                        counterText: '',
                        prefixIcon: Icon(Icons.verified_user_outlined),
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  SizedBox(
                    height: 56,
                    child: OutlinedButton(
                      onPressed: busy || _codeCooldown > 0
                          ? null
                          : _requestCode,
                      child: widget.controller.emailCodeLoading
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : Text(
                              _codeCooldown > 0
                                  ? '${_codeCooldown}s 后重发'
                                  : '发送验证码',
                            ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 13),
              TextField(
                controller: _displayName,
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: '昵称（可选）',
                  prefixIcon: Icon(Icons.badge_outlined),
                  border: OutlineInputBorder(),
                ),
              ),
            ],
            const SizedBox(height: 13),
            TextField(
              controller: _password,
              obscureText: _obscurePassword,
              textInputAction: _registering
                  ? TextInputAction.next
                  : TextInputAction.done,
              autofillHints: [
                _registering
                    ? AutofillHints.newPassword
                    : AutofillHints.password,
              ],
              onSubmitted: _registering ? null : (_) => _submit(),
              decoration: InputDecoration(
                labelText: '密码',
                prefixIcon: const Icon(Icons.lock_outline_rounded),
                border: const OutlineInputBorder(),
                suffixIcon: IconButton(
                  tooltip: _obscurePassword ? '显示密码' : '隐藏密码',
                  onPressed: () =>
                      setState(() => _obscurePassword = !_obscurePassword),
                  icon: Icon(
                    _obscurePassword
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined,
                  ),
                ),
              ),
            ),
            if (_registering) ...[
              const SizedBox(height: 13),
              TextField(
                controller: _passwordConfirmation,
                obscureText: _obscurePassword,
                textInputAction: TextInputAction.done,
                autofillHints: const [AutofillHints.newPassword],
                onSubmitted: (_) => _submit(),
                decoration: const InputDecoration(
                  labelText: '确认密码',
                  prefixIcon: Icon(Icons.lock_reset_rounded),
                  border: OutlineInputBorder(),
                ),
              ),
            ],
            if (_localNotice != null) ...[
              const SizedBox(height: 12),
              _InlineMessage(
                icon: Icons.mark_email_read_outlined,
                message: _localNotice!,
                success: true,
              ),
            ],
            if (error != null && error.isNotEmpty) ...[
              const SizedBox(height: 12),
              _InlineMessage(
                icon: Icons.error_outline_rounded,
                message: error,
                danger: true,
              ),
            ],
            const SizedBox(height: 17),
            FilledButton.icon(
              onPressed: busy ? null : _submit,
              icon: widget.controller.accountLoading
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : Icon(
                      _registering
                          ? Icons.person_add_alt_1_rounded
                          : Icons.login_rounded,
                    ),
              label: Text(_registering ? '验证邮箱并注册' : '登录'),
            ),
            const SizedBox(height: 10),
            const Text(
              '客户端只能注册普通账户；后台管理员账户由独立管理端和服务端配置维护。',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppColors.textMuted,
                fontSize: 11,
                height: 1.4,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SignedInAccount extends StatelessWidget {
  const _SignedInAccount({required this.account, required this.controller});

  final BillingAccount account;
  final LearningPlayerController controller;

  @override
  Widget build(BuildContext context) {
    final profile = account.profile;
    return SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: const Color(0xFF1B1E21),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.divider),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 27,
                  backgroundColor: AppColors.amber.withValues(alpha: 0.16),
                  child: Text(
                    profile.displayName.characters.first.toUpperCase(),
                    style: const TextStyle(
                      color: AppColors.amber,
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        profile.displayName,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: AppColors.ivory,
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '@${profile.username ?? ''}',
                        style: const TextStyle(
                          color: AppColors.textMuted,
                          fontSize: 12,
                        ),
                      ),
                      if (profile.email != null) ...[
                        const SizedBox(height: 3),
                        Row(
                          children: [
                            Icon(
                              profile.emailVerified
                                  ? Icons.verified_rounded
                                  : Icons.warning_amber_rounded,
                              size: 14,
                              color: profile.emailVerified
                                  ? const Color(0xFF71C79A)
                                  : AppColors.textMuted,
                            ),
                            const SizedBox(width: 5),
                            Flexible(
                              child: Text(
                                profile.email!,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: AppColors.textMuted,
                                  fontSize: 11.5,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text(
                      '可用额度',
                      style: TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 11,
                      ),
                    ),
                    Text(
                      '${account.balanceCredits}',
                      style: const TextStyle(
                        color: AppColors.amber,
                        fontSize: 25,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          _InlineMessage(
            icon: Icons.security_rounded,
            message: '当前为普通用户账户；管理功能不包含在播放器客户端中。',
          ),
          if (controller.accountError != null) ...[
            const SizedBox(height: 10),
            _InlineMessage(
              icon: Icons.error_outline_rounded,
              message: controller.accountError!,
              danger: true,
            ),
          ],
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: controller.accountLoading
                ? null
                : controller.refreshAccount,
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('刷新账户'),
          ),
          const SizedBox(height: 10),
          TextButton.icon(
            onPressed: controller.accountLoading
                ? null
                : controller.logoutAccount,
            icon: const Icon(Icons.logout_rounded),
            label: const Text('退出登录'),
          ),
        ],
      ),
    );
  }
}

class _InlineMessage extends StatelessWidget {
  const _InlineMessage({
    required this.icon,
    required this.message,
    this.danger = false,
    this.success = false,
  });

  final IconData icon;
  final String message;
  final bool danger;
  final bool success;

  @override
  Widget build(BuildContext context) {
    final color = danger
        ? AppColors.danger
        : success
        ? const Color(0xFF71C79A)
        : AppColors.textMuted;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: color.withValues(alpha: 0.30)),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              message,
              style: TextStyle(color: color, fontSize: 11.5, height: 1.4),
            ),
          ),
        ],
      ),
    );
  }
}
