import 'dart:async';

import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../learning_player_controller.dart';
import 'native_icon_button.dart';

class PlaybackOsd extends StatelessWidget {
  const PlaybackOsd({
    super.key,
    required this.controller,
    required this.onSubtitleMenu,
    required this.onSourceMenu,
    required this.compact,
    required this.dense,
    required this.onInteraction,
  });

  final LearningPlayerController controller;
  final VoidCallback onSubtitleMenu;
  final VoidCallback onSourceMenu;
  final bool compact;
  final bool dense;
  final VoidCallback onInteraction;

  @override
  Widget build(BuildContext context) {
    final height = dense
        ? 104.0
        : compact
        ? 128.0
        : 142.0;
    return AnimatedPositioned(
      left: 0,
      right: 0,
      bottom: controller.osdVisible ? 0 : -height,
      height: height,
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOutCubic,
      child: IgnorePointer(
        ignoring: !controller.osdVisible,
        child: Container(
          padding: EdgeInsets.fromLTRB(
            dense
                ? 12
                : compact
                ? 18
                : 26,
            dense
                ? 7
                : compact
                ? 18
                : 22,
            dense
                ? 12
                : compact
                ? 18
                : 26,
            dense
                ? 4
                : compact
                ? 8
                : 12,
          ),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0x00000000), Color(0xB8000000), Color(0xF5000000)],
              stops: [0, 0.38, 1],
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              _ProgressRow(
                controller: controller,
                compact: compact,
                onInteraction: onInteraction,
              ),
              SizedBox(
                height: dense
                    ? 2
                    : compact
                    ? 5
                    : 8,
              ),
              _ControlsRow(
                controller: controller,
                compact: compact,
                onSubtitleMenu: onSubtitleMenu,
                onSourceMenu: onSourceMenu,
                onInteraction: onInteraction,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProgressRow extends StatelessWidget {
  const _ProgressRow({
    required this.controller,
    required this.compact,
    required this.onInteraction,
  });

  final LearningPlayerController controller;
  final bool compact;
  final VoidCallback onInteraction;

  @override
  Widget build(BuildContext context) {
    final timeStyle = TextStyle(
      color: AppColors.ivory,
      fontSize: compact ? 11.5 : 12.5,
      fontFeatures: const [FontFeature.tabularFigures()],
    );
    return Row(
      children: [
        Text(formatDuration(controller.position), style: timeStyle),
        const SizedBox(width: 12),
        Expanded(
          child: CueProgressBar(
            controller: controller,
            onInteraction: onInteraction,
          ),
        ),
        const SizedBox(width: 12),
        Text(formatDuration(controller.duration), style: timeStyle),
      ],
    );
  }
}

class CueProgressBar extends StatelessWidget {
  const CueProgressBar({
    super.key,
    required this.controller,
    required this.onInteraction,
  });

  final LearningPlayerController controller;
  final VoidCallback onInteraction;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      slider: true,
      label: '播放进度',
      value: '${(controller.progress * 100).round()}%',
      increasedValue:
          '${((controller.progress + 0.02).clamp(0, 1) * 100).round()}%',
      decreasedValue:
          '${((controller.progress - 0.02).clamp(0, 1) * 100).round()}%',
      onIncrease: () => controller.seekRelative(const Duration(seconds: 5)),
      onDecrease: () => controller.seekRelative(const Duration(seconds: -5)),
      child: SizedBox(
        height: 24,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final width = constraints.maxWidth;
            final activeWidth = width * controller.progress;

            void seekAt(double x) {
              onInteraction();
              if (controller.duration.inMilliseconds <= 0) return;
              final fraction = (x / width).clamp(0.0, 1.0);
              controller.seek(
                Duration(
                  milliseconds: (controller.duration.inMilliseconds * fraction)
                      .round(),
                ),
              );
            }

            return GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTapDown: (details) => seekAt(details.localPosition.dx),
              onHorizontalDragUpdate: (details) =>
                  seekAt(details.localPosition.dx),
              child: Stack(
                alignment: Alignment.centerLeft,
                children: [
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 11,
                    child: Container(
                      height: 2,
                      color: Colors.white.withValues(alpha: 0.35),
                    ),
                  ),
                  for (final cue in controller.cues)
                    if (controller.duration.inMilliseconds > 0)
                      Positioned(
                        left:
                            width *
                                (cue.start.inMilliseconds /
                                        controller.duration.inMilliseconds)
                                    .clamp(0, 1) -
                            0.5,
                        top: 8.5,
                        child: Container(
                          width: 1,
                          height: 7,
                          color: Colors.white.withValues(alpha: 0.74),
                        ),
                      ),
                  Positioned(
                    left: 0,
                    top: 10,
                    child: Container(
                      width: activeWidth,
                      height: 4,
                      decoration: const BoxDecoration(
                        color: AppColors.amber,
                        borderRadius: BorderRadius.horizontal(
                          right: Radius.circular(2),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: (activeWidth - 6).clamp(0, width - 12),
                    top: 6,
                    child: Container(
                      width: 12,
                      height: 12,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColors.amber,
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _ControlsRow extends StatelessWidget {
  const _ControlsRow({
    required this.controller,
    required this.compact,
    required this.onSubtitleMenu,
    required this.onSourceMenu,
    required this.onInteraction,
  });

  final LearningPlayerController controller;
  final bool compact;
  final VoidCallback onSubtitleMenu;
  final VoidCallback onSourceMenu;
  final VoidCallback onInteraction;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final showStatus = constraints.maxWidth >= 1000;
        final showVolumeSlider = constraints.maxWidth >= 860;
        final seriesPlaylist = controller.playlist.length > 1;

        return Row(
          children: [
            if (showStatus)
              SizedBox(
                width: 230,
                child: Row(
                  children: [
                    const Icon(
                      Icons.graphic_eq_rounded,
                      size: 15,
                      color: AppColors.amber,
                    ),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(
                        controller.subtitleStatusLabel,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: AppColors.textMuted,
                          fontSize: 11.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            Expanded(
              child: Row(
                mainAxisAlignment: showStatus
                    ? MainAxisAlignment.center
                    : MainAxisAlignment.start,
                children: [
                  NativeIconButton(
                    icon: Icons.skip_previous_rounded,
                    onPressed: seriesPlaylist
                        ? controller.hasPreviousPlaylistItem
                              ? () {
                                  onInteraction();
                                  controller.openAdjacentPlaylistItem(-1);
                                }
                              : null
                        : () {
                            onInteraction();
                            controller.seekAdjacentCue(-1);
                          },
                    tooltip: seriesPlaylist ? '上一集' : '上一句 (PageUp)',
                    size: compact ? 38 : 42,
                  ),
                  NativeIconButton(
                    icon: Icons.replay_5_rounded,
                    onPressed: () {
                      onInteraction();
                      controller.seekRelative(const Duration(seconds: -5));
                    },
                    tooltip: '后退 5 秒',
                    size: compact ? 38 : 42,
                  ),
                  _PrimaryPlayButton(
                    playing: controller.isPlaying,
                    buffering: controller.isBuffering,
                    compact: compact,
                    onPressed: () {
                      onInteraction();
                      controller.togglePlay();
                    },
                  ),
                  NativeIconButton(
                    icon: Icons.forward_5_rounded,
                    onPressed: () {
                      onInteraction();
                      controller.seekRelative(const Duration(seconds: 5));
                    },
                    tooltip: '前进 5 秒',
                    size: compact ? 38 : 42,
                  ),
                  NativeIconButton(
                    icon: Icons.skip_next_rounded,
                    onPressed: seriesPlaylist
                        ? controller.hasNextPlaylistItem
                              ? () {
                                  onInteraction();
                                  controller.openAdjacentPlaylistItem(1);
                                }
                              : null
                        : () {
                            onInteraction();
                            controller.seekAdjacentCue(1);
                          },
                    tooltip: seriesPlaylist ? '下一集' : '下一句 (PageDown)',
                    size: compact ? 38 : 42,
                  ),
                ],
              ),
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                NativeIconButton(
                  icon: controller.volume <= 0
                      ? Icons.volume_off_rounded
                      : controller.volume < 45
                      ? Icons.volume_down_rounded
                      : Icons.volume_up_rounded,
                  onPressed: () {
                    onInteraction();
                    controller.adjustVolume(controller.volume > 0 ? -100 : 70);
                  },
                  tooltip: '静音',
                  size: compact ? 38 : 42,
                ),
                if (showVolumeSlider)
                  SizedBox(
                    width: 76,
                    child: SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        trackHeight: 2,
                        thumbShape: const RoundSliderThumbShape(
                          enabledThumbRadius: 5,
                        ),
                        overlayShape: const RoundSliderOverlayShape(
                          overlayRadius: 12,
                        ),
                        activeTrackColor: AppColors.amber,
                        inactiveTrackColor: Colors.white24,
                        thumbColor: AppColors.amber,
                        overlayColor: AppColors.amber.withValues(alpha: 0.12),
                      ),
                      child: Slider(
                        value: controller.volume,
                        min: 0,
                        max: 100,
                        onChanged: (value) {
                          onInteraction();
                          controller.adjustVolume(value - controller.volume);
                        },
                      ),
                    ),
                  ),
                _RateMenu(controller: controller, onInteraction: onInteraction),
                if (controller.hasNetworkSourceAlternatives)
                  NativeIconButton(
                    icon: Icons.alt_route_rounded,
                    onPressed: () {
                      onInteraction();
                      onSourceMenu();
                    },
                    tooltip: '切换线路',
                    selected: true,
                    size: compact ? 38 : 42,
                  ),
                NativeIconButton(
                  icon: Icons.closed_caption_outlined,
                  onPressed: () {
                    onInteraction();
                    onSubtitleMenu();
                  },
                  tooltip: '字幕',
                  selected: controller.cues.isNotEmpty,
                  size: compact ? 38 : 42,
                ),
                NativeIconButton(
                  icon: controller.isFullscreen
                      ? Icons.fullscreen_exit_rounded
                      : Icons.fullscreen_rounded,
                  onPressed: () {
                    onInteraction();
                    controller.toggleFullscreen();
                  },
                  tooltip: '全屏 (F)',
                  size: compact ? 38 : 42,
                ),
              ],
            ),
          ],
        );
      },
    );
  }
}

class _PrimaryPlayButton extends StatefulWidget {
  const _PrimaryPlayButton({
    required this.playing,
    required this.buffering,
    required this.compact,
    required this.onPressed,
  });

  final bool playing;
  final bool buffering;
  final bool compact;
  final VoidCallback onPressed;

  @override
  State<_PrimaryPlayButton> createState() => _PrimaryPlayButtonState();
}

class _PrimaryPlayButtonState extends State<_PrimaryPlayButton> {
  static const _bufferingIndicatorDelay = Duration(milliseconds: 320);

  Timer? _bufferingDelay;
  bool _showBufferingIndicator = false;

  @override
  void initState() {
    super.initState();
    _trackBuffering(widget.buffering);
  }

  @override
  void didUpdateWidget(covariant _PrimaryPlayButton oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.buffering != widget.buffering) {
      _trackBuffering(widget.buffering);
    }
  }

  void _trackBuffering(bool buffering) {
    _bufferingDelay?.cancel();
    if (!buffering) {
      _showBufferingIndicator = false;
      return;
    }

    // Seeking between nearby subtitle cues can produce a very short native
    // buffering pulse. Delay the spinner so those routine seeks do not flash
    // a loader on every page turn; sustained network stalls remain visible.
    _bufferingDelay = Timer(_bufferingIndicatorDelay, () {
      if (!mounted || !widget.buffering || _showBufferingIndicator) return;
      setState(() => _showBufferingIndicator = true);
    });
  }

  @override
  void dispose() {
    _bufferingDelay?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = widget.compact ? 48.0 : 54.0;
    final showBuffering = widget.buffering && _showBufferingIndicator;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: widget.compact ? 5 : 9),
      child: SizedBox.square(
        dimension: size,
        child: IconButton(
          onPressed: widget.onPressed,
          style: ButtonStyle(
            foregroundColor: const WidgetStatePropertyAll(AppColors.ivory),
            backgroundColor: WidgetStateProperty.resolveWith((states) {
              return states.contains(WidgetState.hovered)
                  ? Colors.white.withValues(alpha: 0.14)
                  : Colors.black.withValues(alpha: 0.35);
            }),
            side: const WidgetStatePropertyAll(
              BorderSide(color: Color(0xB8FFFFFF), width: 1.2),
            ),
            shape: const WidgetStatePropertyAll(CircleBorder()),
          ),
          icon: showBuffering
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: AppColors.ivory,
                  ),
                )
              : Icon(
                  widget.playing
                      ? Icons.pause_rounded
                      : Icons.play_arrow_rounded,
                  size: widget.compact ? 30 : 34,
                ),
        ),
      ),
    );
  }
}

class _RateMenu extends StatelessWidget {
  const _RateMenu({required this.controller, required this.onInteraction});

  final LearningPlayerController controller;
  final VoidCallback onInteraction;

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<double>(
      tooltip: '播放速度',
      color: const Color(0xF21B1D1F),
      surfaceTintColor: Colors.transparent,
      initialValue: controller.playbackRate,
      onOpened: onInteraction,
      onSelected: (value) {
        onInteraction();
        controller.setRate(value);
      },
      itemBuilder: (context) => [
        for (final rate in LearningPlayerController.playbackRates)
          PopupMenuItem(
            value: rate,
            child: Row(
              children: [
                SizedBox(
                  width: 18,
                  child: controller.playbackRate == rate
                      ? const Icon(
                          Icons.check_rounded,
                          size: 17,
                          color: AppColors.amber,
                        )
                      : null,
                ),
                const SizedBox(width: 8),
                Text('${rate.toStringAsFixed(rate % 1 == 0 ? 0 : 2)}×'),
              ],
            ),
          ),
      ],
      child: ConstrainedBox(
        constraints: const BoxConstraints(minWidth: 48, minHeight: 40),
        child: Center(
          child: Text(
            '${controller.playbackRate.toStringAsFixed(controller.playbackRate % 1 == 0 ? 0 : 1)}×',
            style: const TextStyle(
              color: AppColors.text,
              fontSize: 12.5,
              fontWeight: FontWeight.w600,
              fontFeatures: [FontFeature.tabularFigures()],
            ),
          ),
        ),
      ),
    );
  }
}
