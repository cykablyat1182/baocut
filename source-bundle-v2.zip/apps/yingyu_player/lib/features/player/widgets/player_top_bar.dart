import 'dart:io';

import 'package:flutter/material.dart';
import 'package:window_manager/window_manager.dart';

import '../../../core/theme/app_theme.dart';
import '../learning_player_controller.dart';
import 'native_icon_button.dart';

class PlayerTopBar extends StatefulWidget {
  const PlayerTopBar({
    super.key,
    required this.controller,
    required this.onBack,
    required this.onLibrary,
    required this.onOpenVideo,
    required this.onSubtitleMenu,
    this.onAccount,
    required this.onSettings,
  });

  final LearningPlayerController controller;
  final VoidCallback onBack;
  final VoidCallback onLibrary;
  final VoidCallback onOpenVideo;
  final VoidCallback onSubtitleMenu;
  final VoidCallback? onAccount;
  final VoidCallback onSettings;

  @override
  State<PlayerTopBar> createState() => _PlayerTopBarState();
}

class _PlayerTopBarState extends State<PlayerTopBar> {
  bool _maximized = false;

  Future<void> _toggleMaximize() async {
    if (await windowManager.isMaximized()) {
      await windowManager.unmaximize();
      _maximized = false;
    } else {
      await windowManager.maximize();
      _maximized = true;
    }
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final controller = widget.controller;
    return AnimatedPositioned(
      left: 0,
      right: 0,
      top: controller.osdVisible ? 0 : -54,
      height: 50,
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOutCubic,
      child: IgnorePointer(
        ignoring: !controller.osdVisible,
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xD9000000), Color(0x00000000)],
            ),
          ),
          child: Row(
            children: [
              const SizedBox(width: 8),
              NativeIconButton(
                icon: Icons.arrow_back_rounded,
                onPressed: widget.onBack,
                tooltip: '返回上一页',
                size: 40,
                iconSize: 21,
              ),
              NativeIconButton(
                icon: Icons.home_outlined,
                onPressed: widget.onLibrary,
                tooltip: '回到影视主页',
                size: 40,
                iconSize: 21,
              ),
              NativeIconButton(
                icon: Icons.folder_open_outlined,
                onPressed: widget.onOpenVideo,
                tooltip: '打开视频 (Ctrl+O)',
                size: 40,
                iconSize: 21,
              ),
              const SizedBox(width: 4),
              Expanded(
                child: Platform.isWindows
                    ? DragToMoveArea(child: _MediaTitle(controller: controller))
                    : _MediaTitle(controller: controller),
              ),
              if (Platform.isAndroid || Platform.isIOS) ...[
                NativeIconButton(
                  icon: Icons.closed_caption_outlined,
                  onPressed: widget.onSubtitleMenu,
                  tooltip: '字幕',
                  size: 40,
                ),
                if (widget.onAccount != null)
                  NativeIconButton(
                    icon: Icons.person_outline_rounded,
                    onPressed: widget.onAccount,
                    tooltip: '账户',
                    size: 40,
                  ),
                NativeIconButton(
                  icon: Icons.settings_outlined,
                  onPressed: widget.onSettings,
                  tooltip: '设置',
                  size: 40,
                ),
                const SizedBox(width: 8),
              ] else ...[
                if (widget.onAccount != null)
                  NativeIconButton(
                    icon: Icons.person_outline_rounded,
                    onPressed: widget.onAccount,
                    tooltip: '账户',
                    size: 40,
                    iconSize: 20,
                  ),
                _WindowButton(
                  icon: Icons.remove_rounded,
                  tooltip: '最小化',
                  onPressed: windowManager.minimize,
                ),
                _WindowButton(
                  icon: _maximized
                      ? Icons.filter_none_rounded
                      : Icons.crop_square_rounded,
                  tooltip: _maximized ? '还原' : '最大化',
                  onPressed: _toggleMaximize,
                ),
                _WindowButton(
                  icon: Icons.close_rounded,
                  tooltip: '关闭',
                  danger: true,
                  onPressed: windowManager.close,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _MediaTitle extends StatelessWidget {
  const _MediaTitle({required this.controller});

  final LearningPlayerController controller;

  @override
  Widget build(BuildContext context) {
    return SizedBox.expand(
      child: Align(
        alignment: Alignment.centerLeft,
        child: Row(
          children: [
            Flexible(
              child: Text(
                controller.mediaTitle,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: AppColors.ivory,
                  fontSize: 13.5,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Container(width: 1, height: 13, color: AppColors.divider),
            const SizedBox(width: 10),
            Text(
              controller.mediaMeta,
              style: const TextStyle(
                color: AppColors.textMuted,
                fontSize: 11.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WindowButton extends StatefulWidget {
  const _WindowButton({
    required this.icon,
    required this.tooltip,
    required this.onPressed,
    this.danger = false,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback onPressed;
  final bool danger;

  @override
  State<_WindowButton> createState() => _WindowButtonState();
}

class _WindowButtonState extends State<_WindowButton> {
  bool _hovered = false;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: widget.tooltip,
      child: MouseRegion(
        onEnter: (_) => setState(() => _hovered = true),
        onExit: (_) => setState(() => _hovered = false),
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: widget.onPressed,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 90),
            width: 46,
            height: 50,
            color: _hovered
                ? widget.danger
                      ? const Color(0xFFE81123)
                      : Colors.white.withValues(alpha: 0.10)
                : Colors.transparent,
            alignment: Alignment.center,
            child: Icon(widget.icon, size: 17, color: AppColors.text),
          ),
        ),
      ),
    );
  }
}
