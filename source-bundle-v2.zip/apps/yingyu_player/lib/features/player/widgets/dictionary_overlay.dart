import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/dictionary_entry.dart';
import 'native_icon_button.dart';

class DictionaryOverlay extends StatelessWidget {
  const DictionaryOverlay({
    super.key,
    required this.entry,
    required this.word,
    required this.loading,
    this.partial = const {},
    this.status,
    required this.error,
    required this.saved,
    required this.onClose,
    required this.onRetry,
    required this.onToggleSaved,
    required this.compact,
  });

  final DictionaryEntry? entry;
  final String? word;
  final bool loading;
  final Map<String, String> partial;
  final String? status;
  final String? error;
  final bool saved;
  final VoidCallback onClose;
  final VoidCallback onRetry;
  final VoidCallback onToggleSaved;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    if (word == null) return const SizedBox.shrink();

    return Material(
      color: Colors.transparent,
      child: Container(
        width: compact ? 360 : 390,
        constraints: const BoxConstraints(maxHeight: 310),
        decoration: BoxDecoration(
          color: const Color(0xF2131517),
          borderRadius: BorderRadius.circular(11),
          border: Border.all(color: const Color(0x38FFFFFF)),
          boxShadow: const [
            BoxShadow(
              color: Color(0x88000000),
              blurRadius: 24,
              offset: Offset(0, 10),
            ),
          ],
        ),
        child: Padding(
          padding: EdgeInsets.fromLTRB(
            compact ? 20 : 22,
            compact ? 16 : 18,
            14,
            compact ? 17 : 20,
          ),
          child: loading
              ? _LoadingState(
                  word: word!,
                  partial: partial,
                  status: status,
                  onClose: onClose,
                )
              : error != null
              ? _ErrorState(
                  word: word!,
                  error: error!,
                  onClose: onClose,
                  onRetry: onRetry,
                )
              : entry == null
              ? _ErrorState(
                  word: word!,
                  error: '没有查到释义，请重试。',
                  onClose: onClose,
                  onRetry: onRetry,
                )
              : _EntryState(
                  entry: entry!,
                  saved: saved,
                  onClose: onClose,
                  onToggleSaved: onToggleSaved,
                  compact: compact,
                ),
        ),
      ),
    );
  }
}

class _LoadingState extends StatelessWidget {
  const _LoadingState({
    required this.word,
    required this.partial,
    required this.status,
    required this.onClose,
  });

  final String word;
  final Map<String, String> partial;
  final String? status;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    final phonetic = partial['phonetic']?.trim() ?? '';
    final partOfSpeech = partial['partOfSpeech']?.trim() ?? '';
    final definition = partial['definition']?.trim() ?? '';
    final example = partial['example']?.trim() ?? '';
    final exampleTranslation = partial['exampleTranslation']?.trim() ?? '';
    return ConstrainedBox(
      constraints: const BoxConstraints(maxHeight: 270),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    partial['word']?.trim().isNotEmpty == true
                        ? partial['word']!.trim()
                        : word,
                    style: const TextStyle(
                      color: AppColors.amber,
                      fontSize: 21,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: AppColors.amber,
                  ),
                ),
                const SizedBox(width: 4),
                NativeIconButton(
                  icon: Icons.close_rounded,
                  onPressed: onClose,
                  tooltip: '关闭',
                  size: 34,
                  iconSize: 18,
                ),
              ],
            ),
            if (phonetic.isNotEmpty || partOfSpeech.isNotEmpty) ...[
              const SizedBox(height: 5),
              Text(
                [
                  phonetic,
                  partOfSpeech,
                ].where((value) => value.isNotEmpty).join('  ·  '),
                style: const TextStyle(
                  color: AppColors.textMuted,
                  fontSize: 13,
                ),
              ),
            ],
            const SizedBox(height: 7),
            Text(
              definition.isNotEmpty ? definition : (status ?? '正在逐步生成释义…'),
              style: TextStyle(
                color: definition.isNotEmpty
                    ? AppColors.ivory
                    : AppColors.textMuted,
                fontSize: 14,
                height: 1.45,
              ),
            ),
            if (example.isNotEmpty) ...[
              const SizedBox(height: 10),
              const Divider(height: 1),
              const SizedBox(height: 9),
              Text(
                example,
                style: const TextStyle(
                  color: AppColors.text,
                  fontSize: 13,
                  height: 1.4,
                ),
              ),
            ],
            if (exampleTranslation.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(
                exampleTranslation,
                style: const TextStyle(
                  color: AppColors.textMuted,
                  fontSize: 12,
                  height: 1.4,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  const _ErrorState({
    required this.word,
    required this.error,
    required this.onClose,
    required this.onRetry,
  });

  final String word;
  final String error;
  final VoidCallback onClose;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.error_outline_rounded, color: AppColors.amber),
            const SizedBox(width: 9),
            Expanded(
              child: Text(
                word,
                style: const TextStyle(
                  color: AppColors.ivory,
                  fontSize: 19,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            NativeIconButton(
              icon: Icons.close_rounded,
              onPressed: onClose,
              tooltip: '关闭',
              size: 34,
              iconSize: 18,
            ),
          ],
        ),
        const SizedBox(height: 13),
        Text(
          error,
          style: const TextStyle(
            color: AppColors.textMuted,
            fontSize: 13,
            height: 1.45,
          ),
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: onRetry,
          icon: const Icon(Icons.refresh_rounded, size: 17),
          label: const Text('重新查询'),
        ),
      ],
    );
  }
}

class _EntryState extends StatelessWidget {
  const _EntryState({
    required this.entry,
    required this.saved,
    required this.onClose,
    required this.onToggleSaved,
    required this.compact,
  });

  final DictionaryEntry entry;
  final bool saved;
  final VoidCallback onClose;
  final VoidCallback onToggleSaved;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  entry.word,
                  style: TextStyle(
                    color: AppColors.amber,
                    fontFamily: AppTheme.subtitleFont,
                    fontSize: compact ? 25 : 28,
                    fontWeight: FontWeight.w700,
                    height: 1,
                  ),
                ),
              ),
              NativeIconButton(
                icon: saved ? Icons.star_rounded : Icons.star_border,
                onPressed: onToggleSaved,
                tooltip: saved ? '移出词汇本' : '加入词汇本',
                selected: saved,
                size: 36,
                iconSize: 21,
              ),
              NativeIconButton(
                icon: Icons.close_rounded,
                onPressed: onClose,
                tooltip: '关闭',
                size: 36,
                iconSize: 19,
              ),
            ],
          ),
          if (entry.phonetic.trim().isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(
              entry.phonetic,
              style: const TextStyle(
                color: AppColors.textMuted,
                fontSize: 15,
                height: 1.2,
              ),
            ),
          ],
          const SizedBox(height: 13),
          Text.rich(
            TextSpan(
              children: [
                if (entry.partOfSpeech.trim().isNotEmpty)
                  TextSpan(
                    text: '${entry.partOfSpeech}  ',
                    style: const TextStyle(
                      color: AppColors.textMuted,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                TextSpan(text: entry.definition),
              ],
            ),
            style: const TextStyle(
              color: AppColors.ivory,
              fontSize: 16,
              height: 1.35,
            ),
          ),
          if (entry.example.trim().isNotEmpty) ...[
            const SizedBox(height: 14),
            const Divider(height: 1),
            const SizedBox(height: 13),
            Text(
              entry.example,
              style: const TextStyle(
                color: AppColors.text,
                fontSize: 14,
                height: 1.4,
              ),
            ),
          ],
          if (entry.exampleTranslation.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(
              entry.exampleTranslation,
              style: const TextStyle(
                color: AppColors.textMuted,
                fontSize: 13,
                height: 1.35,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
