import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/subtitle_cue.dart';
import '../learning_player_controller.dart';
import 'subtitle_overlay.dart';

class SubtitlePager extends StatefulWidget {
  const SubtitlePager({
    super.key,
    required this.controller,
    required this.compact,
  });

  final LearningPlayerController controller;
  final bool compact;

  @override
  State<SubtitlePager> createState() => _SubtitlePagerState();
}

class _SubtitlePagerState extends State<SubtitlePager>
    with SingleTickerProviderStateMixin {
  late final AnimationController _settleController;
  Animation<double>? _settleAnimation;
  double _dragOffset = 0;
  double _cardWidth = 1;
  bool _dragging = false;
  double _chromeOpacity = 0;
  Timer? _chromeHideTimer;
  int _animationToken = 0;

  LearningPlayerController get controller => widget.controller;

  @override
  void initState() {
    super.initState();
    _settleController =
        AnimationController(
          vsync: this,
          duration: const Duration(milliseconds: 220),
        )..addListener(() {
          final animation = _settleAnimation;
          if (animation != null && mounted) {
            setState(() => _dragOffset = animation.value);
          }
        });
  }

  @override
  void dispose() {
    _chromeHideTimer?.cancel();
    _settleController.dispose();
    super.dispose();
  }

  void _showChrome() {
    _chromeHideTimer?.cancel();
    if (_chromeOpacity != 1) setState(() => _chromeOpacity = 1);
  }

  void _scheduleChromeHide() {
    _chromeHideTimer?.cancel();
    _chromeHideTimer = Timer(const Duration(milliseconds: 720), () {
      if (mounted && !_dragging) setState(() => _chromeOpacity = 0);
    });
  }

  void _handleDragStart(DragStartDetails details) {
    _animationToken++;
    _settleController.stop();
    _showChrome();
    setState(() => _dragging = true);
  }

  void _handleDragUpdate(DragUpdateDetails details) {
    var nextOffset = (_dragOffset + details.delta.dx).clamp(
      -_cardWidth,
      _cardWidth,
    );
    if (nextOffset < 0 && _nextCue == null) nextOffset *= 0.28;
    if (nextOffset > 0 && _previousCue == null) nextOffset *= 0.28;
    setState(() => _dragOffset = nextOffset);
  }

  void _handleDragEnd(DragEndDetails details) {
    final velocity = details.primaryVelocity ?? 0;
    final pageDelta = _dragOffset < 0 ? 1 : -1;
    final targetCue = pageDelta > 0 ? _nextCue : _previousCue;
    final movingTowardTarget = pageDelta > 0 ? velocity < -420 : velocity > 420;
    final crossesThreshold = _dragOffset.abs() >= _cardWidth * 0.18;
    setState(() => _dragging = false);
    if (targetCue != null && (movingTowardTarget || crossesThreshold)) {
      _animateTo(pageDelta > 0 ? -_cardWidth : _cardWidth, pageDelta);
    } else {
      _animateTo(0, null);
    }
  }

  void _handleDragCancel() {
    setState(() => _dragging = false);
    _animateTo(0, null);
  }

  void _animateTo(double target, int? pageDelta) {
    final token = ++_animationToken;
    _settleAnimation = Tween<double>(begin: _dragOffset, end: target).animate(
      CurvedAnimation(parent: _settleController, curve: Curves.easeOutCubic),
    );
    _settleController
      ..reset()
      ..forward().whenComplete(() {
        if (!mounted || token != _animationToken) return;
        setState(() {
          _dragOffset = 0;
          _settleAnimation = null;
        });
        if (pageDelta != null) {
          unawaited(controller.seekAdjacentCue(pageDelta));
        }
        _scheduleChromeHide();
      });
  }

  SubtitleCue? get _previousCue {
    final index = controller.currentCueIndex - 1;
    return index >= 0 && index < controller.cues.length
        ? controller.cues[index]
        : null;
  }

  SubtitleCue? get _nextCue {
    final index = controller.currentCueIndex + 1;
    return index >= 0 && index < controller.cues.length
        ? controller.cues[index]
        : null;
  }

  @override
  Widget build(BuildContext context) {
    final cue = controller.currentCue;
    if (cue == null) return const SizedBox.shrink();
    return LayoutBuilder(
      builder: (context, constraints) {
        final available = constraints.maxWidth.isFinite
            ? constraints.maxWidth
            : (widget.compact ? 780.0 : 980.0);
        _cardWidth = math.min(available, widget.compact ? 800 : 1020);
        final progress = (_dragOffset.abs() / _cardWidth).clamp(0.0, 1.0);
        return Semantics(
          container: true,
          label: '字幕卡片，手机左右滑动、电脑使用方向键切换句子',
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onHorizontalDragStart: _handleDragStart,
            onHorizontalDragUpdate: _handleDragUpdate,
            onHorizontalDragEnd: _handleDragEnd,
            onHorizontalDragCancel: _handleDragCancel,
            child: AnimatedSize(
              duration: const Duration(milliseconds: 180),
              curve: Curves.easeOutCubic,
              alignment: Alignment.center,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 280),
                width: _cardWidth,
                decoration: BoxDecoration(
                  color: const Color(0xB3090B0D).withValues(
                    alpha: _chromeOpacity * (0.56 + progress * 0.18),
                  ),
                  borderRadius: BorderRadius.circular(widget.compact ? 16 : 18),
                  border: Border.all(
                    color: (_dragging ? AppColors.amber : Colors.white)
                        .withValues(
                          alpha: _chromeOpacity * (_dragging ? 0.34 : 0.08),
                        ),
                  ),
                  boxShadow: _chromeOpacity == 0
                      ? const []
                      : [
                          BoxShadow(
                            color: const Color(
                              0x52000000,
                            ).withValues(alpha: 0.32 * _chromeOpacity),
                            blurRadius: 22,
                            offset: const Offset(0, 10),
                          ),
                        ],
                ),
                clipBehavior: Clip.antiAlias,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    IgnorePointer(
                      child: Opacity(
                        opacity: 0,
                        child: _CueBody(
                          cue: cue,
                          controller: controller,
                          compact: widget.compact,
                          interactive: false,
                        ),
                      ),
                    ),
                    if (_previousCue case final previous?)
                      Positioned.fill(
                        child: _SlidingCue(
                          cue: previous,
                          controller: controller,
                          compact: widget.compact,
                          translationX: _dragOffset - _cardWidth,
                          opacity: 0.58 + progress * 0.42,
                          interactive: false,
                        ),
                      ),
                    Positioned.fill(
                      child: _SlidingCue(
                        cue: cue,
                        controller: controller,
                        compact: widget.compact,
                        translationX: _dragOffset,
                        opacity: 1 - progress * 0.28,
                        interactive: true,
                      ),
                    ),
                    if (_nextCue case final next?)
                      Positioned.fill(
                        child: _SlidingCue(
                          cue: next,
                          controller: controller,
                          compact: widget.compact,
                          translationX: _dragOffset + _cardWidth,
                          opacity: 0.58 + progress * 0.42,
                          interactive: false,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _SlidingCue extends StatelessWidget {
  const _SlidingCue({
    required this.cue,
    required this.controller,
    required this.compact,
    required this.translationX,
    required this.opacity,
    required this.interactive,
  });

  final SubtitleCue cue;
  final LearningPlayerController controller;
  final bool compact;
  final double translationX;
  final double opacity;
  final bool interactive;

  @override
  Widget build(BuildContext context) {
    return Transform.translate(
      offset: Offset(translationX, 0),
      child: Opacity(
        opacity: opacity.clamp(0, 1),
        child: IgnorePointer(
          ignoring: !interactive,
          child: OverflowBox(
            alignment: Alignment.center,
            minHeight: 0,
            maxHeight: double.infinity,
            child: _CueBody(
              cue: cue,
              controller: controller,
              compact: compact,
              interactive: interactive,
            ),
          ),
        ),
      ),
    );
  }
}

class _CueBody extends StatelessWidget {
  const _CueBody({
    required this.cue,
    required this.controller,
    required this.compact,
    required this.interactive,
  });

  final SubtitleCue cue;
  final LearningPlayerController controller;
  final bool compact;
  final bool interactive;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(
        horizontal: compact ? 24 : 34,
        vertical: compact ? 12 : 16,
      ),
      child: Center(
        child: SubtitleOverlay(
          cue: cue,
          mode: controller.subtitleMode,
          selectedWord: interactive ? controller.selectedWord : null,
          onWordTap: controller.selectWord,
          compact: compact,
          originalScale: controller.subtitleOriginalScale,
          translationScale: controller.subtitleTranslationScale,
          translationFirst: controller.subtitleTranslationFirst,
        ),
      ),
    );
  }
}
