import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/subtitle_tokenizer.dart';
import '../../../domain/models/subtitle_cue.dart';

typedef SubtitleWordTap = void Function(String word, String sentence);

class SubtitleOverlay extends StatelessWidget {
  const SubtitleOverlay({
    super.key,
    required this.cue,
    required this.mode,
    required this.selectedWord,
    required this.onWordTap,
    required this.compact,
    this.originalScale = 1,
    this.translationScale = 1,
    this.translationFirst = false,
  });

  final SubtitleCue? cue;
  final SubtitleDisplayMode mode;
  final String? selectedWord;
  final SubtitleWordTap onWordTap;
  final bool compact;
  final double originalScale;
  final double translationScale;
  final bool translationFirst;

  @override
  Widget build(BuildContext context) {
    final current = cue;
    if (current == null) return const SizedBox.shrink();
    if (mode == SubtitleDisplayMode.off) return const SizedBox.shrink();

    final showOriginal = mode != SubtitleDisplayMode.translation;
    final showTranslation =
        mode != SubtitleDisplayMode.original &&
        current.translation.trim().isNotEmpty;

    final originalLine = _InteractiveSentence(
      text: current.original,
      selectedWord: selectedWord,
      onWordTap: onWordTap,
      fontSize: (compact ? 24 : 32) * originalScale,
      fontWeight: FontWeight.w600,
      color: AppColors.ivory,
    );
    final translationLine = _InteractiveSentence(
      text: current.translation,
      selectedWord: selectedWord,
      onWordTap: onWordTap,
      fontSize: (compact ? 18 : 23) * translationScale,
      fontWeight: FontWeight.w500,
      color: AppColors.amber,
    );
    final gap = SizedBox(height: compact ? 6 : 9);
    final lines = translationFirst
        ? <Widget>[
            if (showTranslation) translationLine,
            if (showOriginal && showTranslation) gap,
            if (showOriginal) originalLine,
          ]
        : <Widget>[
            if (showOriginal) originalLine,
            if (showOriginal && showTranslation) gap,
            if (showTranslation) translationLine,
          ];

    return ConstrainedBox(
      constraints: BoxConstraints(maxWidth: compact ? 760 : 980),
      child: Column(mainAxisSize: MainAxisSize.min, children: lines),
    );
  }
}

class _InteractiveSentence extends StatelessWidget {
  const _InteractiveSentence({
    required this.text,
    required this.selectedWord,
    required this.onWordTap,
    required this.fontSize,
    required this.fontWeight,
    required this.color,
  });

  final String text;
  final String? selectedWord;
  final SubtitleWordTap onWordTap;
  final double fontSize;
  final FontWeight fontWeight;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final displayText = normalizeSubtitleDisplaySpacing(text);
    final tokens = tokenizeSubtitle(displayText);
    final selected = normalizeSubtitleQuery(selectedWord ?? '');

    return Wrap(
      alignment: WrapAlignment.center,
      crossAxisAlignment: WrapCrossAlignment.center,
      children: [
        for (final token in tokens)
          if (token.queryable)
            _WordToken(
              text: token.text,
              selected:
                  selected.isNotEmpty &&
                  selected == normalizeSubtitleQuery(token.text),
              fontSize: fontSize,
              fontWeight: fontWeight,
              color: color,
              onTap: () => onWordTap(token.text, text),
            )
          else
            Text(
              token.text,
              style: _subtitleStyle(
                fontSize: fontSize,
                fontWeight: fontWeight,
                color: color,
              ),
            ),
      ],
    );
  }
}

class _WordToken extends StatefulWidget {
  const _WordToken({
    required this.text,
    required this.selected,
    required this.fontSize,
    required this.fontWeight,
    required this.color,
    required this.onTap,
  });

  final String text;
  final bool selected;
  final double fontSize;
  final FontWeight fontWeight;
  final Color color;
  final VoidCallback onTap;

  @override
  State<_WordToken> createState() => _WordTokenState();
}

class _WordTokenState extends State<_WordToken> {
  bool _hovered = false;

  @override
  Widget build(BuildContext context) {
    final active = widget.selected || _hovered;
    return Semantics(
      button: true,
      label: '查询 ${widget.text}',
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        onEnter: (_) => setState(() => _hovered = true),
        onExit: (_) => setState(() => _hovered = false),
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: widget.onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 1, vertical: 3),
            child: Text(
              widget.text,
              style:
                  _subtitleStyle(
                    fontSize: widget.fontSize,
                    fontWeight: widget.fontWeight,
                    color: widget.color,
                  ).copyWith(
                    color: active ? AppColors.ivory : widget.color,
                    decoration: active ? TextDecoration.underline : null,
                    decorationColor: AppColors.amber,
                    decorationThickness: 1.25,
                  ),
            ),
          ),
        ),
      ),
    );
  }
}

TextStyle _subtitleStyle({
  required double fontSize,
  required FontWeight fontWeight,
  required Color color,
}) => TextStyle(
  color: color,
  fontFamily: AppTheme.subtitleFont,
  fontSize: fontSize,
  fontWeight: fontWeight,
  height: 1.14,
  letterSpacing: 0.1,
  shadows: _subtitleShadows,
);

const _subtitleShadows = [
  Shadow(color: Color(0xF0000000), blurRadius: 8, offset: Offset(0, 2)),
  Shadow(color: Color(0xB0000000), blurRadius: 2, offset: Offset(0, 1)),
];
