import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../domain/models/subtitle_cue.dart';
import '../learning_player_controller.dart';
import 'native_icon_button.dart';

class SubtitleDrawer extends StatefulWidget {
  const SubtitleDrawer({
    super.key,
    required this.controller,
    required this.width,
    required this.top,
    required this.bottom,
    required this.dense,
    required this.onSearch,
  });

  final LearningPlayerController controller;
  final double width;
  final double top;
  final double bottom;
  final bool dense;
  final VoidCallback onSearch;

  @override
  State<SubtitleDrawer> createState() => _SubtitleDrawerState();
}

class _SubtitleDrawerState extends State<SubtitleDrawer> {
  final ScrollController _scrollController = ScrollController();
  final GlobalKey _activeCueKey = GlobalKey();
  bool _wasOpen = false;
  bool _awaitingInitialJump = false;
  bool _jumpScheduled = false;

  LearningPlayerController get controller => widget.controller;

  @override
  void initState() {
    super.initState();
    _wasOpen = controller.drawerOpen;
    _awaitingInitialJump = _wasOpen;
    controller.addListener(_handleControllerUpdate);
    if (_awaitingInitialJump) _scheduleJumpToCurrentCue();
  }

  @override
  void didUpdateWidget(covariant SubtitleDrawer oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != controller) {
      oldWidget.controller.removeListener(_handleControllerUpdate);
      controller.addListener(_handleControllerUpdate);
      _wasOpen = controller.drawerOpen;
      _awaitingInitialJump = _wasOpen;
    }
  }

  @override
  void dispose() {
    controller.removeListener(_handleControllerUpdate);
    _scrollController.dispose();
    super.dispose();
  }

  void _handleControllerUpdate() {
    final isOpen = controller.drawerOpen;
    if (isOpen && !_wasOpen) {
      _awaitingInitialJump = true;
    } else if (!isOpen) {
      _awaitingInitialJump = false;
    }
    _wasOpen = isOpen;
    if (isOpen && _awaitingInitialJump) _scheduleJumpToCurrentCue();
  }

  void _scheduleJumpToCurrentCue() {
    if (_jumpScheduled) return;
    _jumpScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _jumpScheduled = false;
      if (!mounted || !controller.drawerOpen || !_awaitingInitialJump) return;
      final index = controller.currentCueIndex;
      final count = controller.cues.length;
      if (index < 0 || count == 0 || !_scrollController.hasClients) return;

      final position = _scrollController.position;
      final ratio = count <= 1 ? 0.0 : index / (count - 1);
      final target = (position.maxScrollExtent * ratio).clamp(
        position.minScrollExtent,
        position.maxScrollExtent,
      );
      _scrollController.jumpTo(target);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || !controller.drawerOpen) return;
        final activeContext = _activeCueKey.currentContext;
        if (activeContext != null) {
          Scrollable.ensureVisible(
            activeContext,
            alignment: 0.42,
            duration: const Duration(milliseconds: 180),
            curve: Curves.easeOutCubic,
          );
        }
        _awaitingInitialJump = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedPositioned(
      duration: const Duration(milliseconds: 240),
      curve: Curves.easeOutCubic,
      right: controller.drawerOpen ? 52 : -(widget.width + 8),
      top: widget.top,
      bottom: widget.bottom,
      width: widget.width,
      child: Semantics(
        container: true,
        label: '字幕导航',
        child: Material(
          color: AppColors.overlay,
          elevation: 0,
          shape: const RoundedRectangleBorder(
            side: BorderSide(color: AppColors.divider),
          ),
          child: Column(
            children: [
              _DrawerHeader(
                controller: controller,
                onSearch: widget.onSearch,
                dense: widget.dense,
              ),
              const Divider(height: 1),
              Expanded(
                child: controller.cues.isEmpty
                    ? _EmptySubtitleState(loading: controller.subtitleLoading)
                    : ListView.separated(
                        controller: _scrollController,
                        padding: EdgeInsets.zero,
                        itemCount: controller.cues.length,
                        separatorBuilder: (_, _) =>
                            const Divider(height: 1, indent: 30),
                        itemBuilder: (context, index) {
                          final cue = controller.cues[index];
                          return _CueRow(
                            key: index == controller.currentCueIndex
                                ? _activeCueKey
                                : null,
                            cue: cue,
                            active: index == controller.currentCueIndex,
                            mode: controller.subtitleMode,
                            selectedWord: controller.selectedWord,
                            dense: widget.dense,
                            onTap: () => controller.seekCue(index),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DrawerHeader extends StatelessWidget {
  const _DrawerHeader({
    required this.controller,
    required this.onSearch,
    required this.dense,
  });

  final LearningPlayerController controller;
  final VoidCallback onSearch;
  final bool dense;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: dense ? 48 : 58,
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          dense ? 14 : 17,
          dense ? 3 : 7,
          dense ? 7 : 9,
          dense ? 3 : 7,
        ),
        child: Row(
          children: [
            const Expanded(
              child: Text(
                '字幕导航',
                style: TextStyle(
                  color: AppColors.ivory,
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.2,
                ),
              ),
            ),
            NativeIconButton(
              icon: Icons.search_rounded,
              onPressed: onSearch,
              tooltip: '搜索字幕',
              size: 38,
              iconSize: 20,
            ),
            const SizedBox(width: 4),
            _ModeControl(controller: controller),
          ],
        ),
      ),
    );
  }
}

class _ModeControl extends StatelessWidget {
  const _ModeControl({required this.controller});

  final LearningPlayerController controller;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 32,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.045),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.divider),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (final mode in SubtitleDisplayMode.values)
            InkWell(
              borderRadius: BorderRadius.circular(7),
              onTap: () => controller.setSubtitleMode(mode),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                alignment: Alignment.center,
                padding: const EdgeInsets.symmetric(horizontal: 9),
                decoration: BoxDecoration(
                  color: controller.subtitleMode == mode
                      ? AppColors.amber.withValues(alpha: 0.13)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(7),
                ),
                child: Text(
                  mode.label,
                  style: TextStyle(
                    color: controller.subtitleMode == mode
                        ? AppColors.amber
                        : AppColors.textMuted,
                    fontSize: 11.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _CueRow extends StatelessWidget {
  const _CueRow({
    super.key,
    required this.cue,
    required this.active,
    required this.mode,
    required this.selectedWord,
    required this.dense,
    required this.onTap,
  });

  final SubtitleCue cue;
  final bool active;
  final SubtitleDisplayMode mode;
  final String? selectedWord;
  final bool dense;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final showOriginal =
        mode != SubtitleDisplayMode.translation &&
        mode != SubtitleDisplayMode.off;
    final showTranslation =
        mode != SubtitleDisplayMode.original &&
        mode != SubtitleDisplayMode.off &&
        cue.translation.isNotEmpty;

    return Material(
      color: active ? AppColors.selected : Colors.transparent,
      child: InkWell(
        onTap: onTap,
        hoverColor: Colors.white.withValues(alpha: 0.04),
        focusColor: AppColors.focus.withValues(alpha: 0.1),
        child: IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 160),
                width: 4,
                color: active ? AppColors.amber : Colors.transparent,
              ),
              Expanded(
                child: Padding(
                  padding: EdgeInsets.fromLTRB(
                    dense ? 10 : 16,
                    dense ? 6 : 11,
                    dense ? 10 : 15,
                    dense ? 7 : 12,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: dense ? 43 : 52,
                        height: dense ? 39 : 47,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Positioned.fill(
                              child: Align(
                                alignment: Alignment.center,
                                child: Container(
                                  width: 1,
                                  color: active
                                      ? AppColors.amber.withValues(alpha: 0.68)
                                      : AppColors.divider,
                                ),
                              ),
                            ),
                            Positioned(
                              top: 0,
                              left: 0,
                              right: 0,
                              child: Text(
                                formatDuration(cue.start),
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: active
                                      ? AppColors.amber
                                      : AppColors.textMuted,
                                  fontSize: 10.5,
                                  fontFeatures: const [
                                    FontFeature.tabularFigures(),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              top: dense ? 17 : 21,
                              child: Container(
                                width: active ? 10 : 7,
                                height: active ? 10 : 7,
                                decoration: BoxDecoration(
                                  color: active
                                      ? AppColors.amber
                                      : const Color(0xFF6B7075),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: AppColors.overlay,
                                    width: 2,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: dense ? 5 : 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (showOriginal)
                              _HighlightedText(
                                text: cue.original,
                                selectedWord: active ? selectedWord : null,
                                color: active
                                    ? AppColors.ivory
                                    : AppColors.text,
                              ),
                            if (showOriginal && showTranslation)
                              SizedBox(height: dense ? 2 : 5),
                            if (showTranslation)
                              Text(
                                cue.translation,
                                maxLines: dense ? 1 : 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: active
                                      ? AppColors.text
                                      : AppColors.textMuted,
                                  fontSize: 12.5,
                                  height: 1.35,
                                ),
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HighlightedText extends StatelessWidget {
  const _HighlightedText({
    required this.text,
    required this.selectedWord,
    required this.color,
  });

  final String text;
  final String? selectedWord;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final word = selectedWord?.trim();
    if (word == null || word.isEmpty) {
      return Text(
        text,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(color: color, fontSize: 13.5, height: 1.35),
      );
    }
    final pattern = RegExp(RegExp.escape(word), caseSensitive: false);
    final match = pattern.firstMatch(text);
    if (match == null) {
      return Text(
        text,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(color: color, fontSize: 13.5, height: 1.35),
      );
    }
    return Text.rich(
      TextSpan(
        children: [
          TextSpan(text: text.substring(0, match.start)),
          TextSpan(
            text: text.substring(match.start, match.end),
            style: const TextStyle(
              color: AppColors.amber,
              fontWeight: FontWeight.w700,
            ),
          ),
          TextSpan(text: text.substring(match.end)),
        ],
      ),
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(color: color, fontSize: 13.5, height: 1.35),
    );
  }
}

class _EmptySubtitleState extends StatelessWidget {
  const _EmptySubtitleState({this.loading = false});

  final bool loading;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              loading
                  ? Icons.hourglass_top_rounded
                  : Icons.subtitles_off_outlined,
              color: AppColors.textMuted,
              size: 30,
            ),
            const SizedBox(height: 12),
            Text(
              loading ? '正在载入当前片段字幕' : '尚未加载字幕',
              style: const TextStyle(color: AppColors.text, fontSize: 14),
            ),
            const SizedBox(height: 5),
            Text(
              loading
                  ? '会先显示播放点附近，再随播放进度补全前后时间轴'
                  : '可载入字幕文件或使用 SeedASR 2.0 自动生成',
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: AppColors.textMuted,
                fontSize: 11.5,
                height: 1.4,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class LearningToolRail extends StatelessWidget {
  const LearningToolRail({
    super.key,
    required this.controller,
    required this.onSettings,
  });

  final LearningPlayerController controller;
  final VoidCallback onSettings;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 46,
      padding: const EdgeInsets.symmetric(vertical: 5),
      decoration: BoxDecoration(
        color: AppColors.overlaySoft,
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: AppColors.divider),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          NativeIconButton(
            icon: Icons.format_list_bulleted_rounded,
            onPressed: controller.toggleDrawer,
            tooltip: '字幕导航 (S)',
            selected: controller.drawerOpen,
            size: 44,
          ),
          NativeIconButton(
            icon: Icons.playlist_play_rounded,
            onPressed: controller.togglePlaylist,
            tooltip: '播放列表',
            selected: controller.playlistOpen,
            size: 44,
          ),
          NativeIconButton(
            icon: Icons.repeat_one_rounded,
            onPressed: controller.toggleSentenceLoop,
            tooltip: '循环当前字幕 (R)',
            selected: controller.sentenceLoop,
            size: 44,
          ),
          NativeIconButton(
            icon: Icons.settings_outlined,
            onPressed: onSettings,
            tooltip: '设置',
            size: 44,
          ),
        ],
      ),
    );
  }
}
