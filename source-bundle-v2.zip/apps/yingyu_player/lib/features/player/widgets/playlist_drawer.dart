import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../learning_player_controller.dart';
import 'native_icon_button.dart';

class PlaylistDrawer extends StatelessWidget {
  const PlaylistDrawer({
    super.key,
    required this.controller,
    required this.width,
    required this.top,
    required this.bottom,
    required this.dense,
    required this.onOpenFolder,
  });

  final LearningPlayerController controller;
  final double width;
  final double top;
  final double bottom;
  final bool dense;
  final VoidCallback onOpenFolder;

  @override
  Widget build(BuildContext context) {
    final onlineSeries = controller.playlist.any(
      (item) => item.isOnline && !item.isLive,
    );
    return AnimatedPositioned(
      duration: const Duration(milliseconds: 240),
      curve: Curves.easeOutCubic,
      left: controller.playlistOpen ? 0 : -(width + 8),
      top: top,
      bottom: bottom,
      width: width,
      child: Semantics(
        container: true,
        label: '播放列表',
        child: Material(
          color: AppColors.overlay,
          shape: const RoundedRectangleBorder(
            side: BorderSide(color: AppColors.divider),
          ),
          child: Column(
            children: [
              SizedBox(
                height: dense ? 48 : 58,
                child: Padding(
                  padding: EdgeInsets.fromLTRB(
                    dense ? 13 : 16,
                    dense ? 3 : 7,
                    8,
                    dense ? 3 : 7,
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text(
                              '播放列表',
                              style: TextStyle(
                                color: AppColors.ivory,
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            Text(
                              controller.playlist.isEmpty
                                  ? '导入文件夹后自动归类'
                                  : onlineSeries
                                  ? '${controller.playlist.length} 集 · 当前第 ${controller.currentPlaylistIndex + 1} 集'
                                  : '${controller.playlist.length} 个媒体文件',
                              style: const TextStyle(
                                color: AppColors.textMuted,
                                fontSize: 10.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (!onlineSeries)
                        NativeIconButton(
                          icon: Icons.create_new_folder_outlined,
                          onPressed: onOpenFolder,
                          tooltip: '导入影视文件夹',
                          size: 38,
                          iconSize: 20,
                        ),
                    ],
                  ),
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: controller.playlist.isEmpty
                    ? _EmptyPlaylist(dense: dense)
                    : ListView.separated(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        itemCount: controller.playlist.length,
                        separatorBuilder: (_, _) =>
                            const Divider(height: 1, indent: 16, endIndent: 12),
                        itemBuilder: (context, index) {
                          final item = controller.playlist[index];
                          final active =
                              index == controller.currentPlaylistIndex;
                          return Material(
                            color: active
                                ? AppColors.selected
                                : Colors.transparent,
                            child: InkWell(
                              onTap: active
                                  ? null
                                  : () => controller.openPlaylistItem(index),
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(
                                  14,
                                  11,
                                  12,
                                  11,
                                ),
                                child: Row(
                                  children: [
                                    SizedBox(
                                      width: 28,
                                      child: Text(
                                        '${index + 1}'.padLeft(2, '0'),
                                        style: TextStyle(
                                          color: active
                                              ? AppColors.amber
                                              : AppColors.textMuted,
                                          fontSize: 11,
                                          fontFeatures: const [
                                            FontFeature.tabularFigures(),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Icon(
                                      active
                                          ? Icons.play_arrow_rounded
                                          : Icons.movie_outlined,
                                      color: active
                                          ? AppColors.amber
                                          : AppColors.textMuted,
                                      size: 18,
                                    ),
                                    const SizedBox(width: 9),
                                    Expanded(
                                      child: Text(
                                        item.title,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: active
                                              ? AppColors.ivory
                                              : AppColors.text,
                                          fontSize: 12.5,
                                          height: 1.35,
                                          fontWeight: active
                                              ? FontWeight.w700
                                              : FontWeight.w500,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
              ),
              const Divider(height: 1),
              Padding(
                padding: EdgeInsets.fromLTRB(
                  dense ? 10 : 14,
                  dense ? 6 : 10,
                  dense ? 10 : 14,
                  dense ? 7 : 12,
                ),
                child: onlineSeries
                    ? Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: controller.hasPreviousPlaylistItem
                                  ? () =>
                                        controller.openAdjacentPlaylistItem(-1)
                                  : null,
                              icon: const Icon(
                                Icons.skip_previous_rounded,
                                size: 17,
                              ),
                              label: const Text('上一集'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: controller.hasNextPlaylistItem
                                  ? () => controller.openAdjacentPlaylistItem(1)
                                  : null,
                              icon: const Icon(
                                Icons.skip_next_rounded,
                                size: 17,
                              ),
                              label: const Text('下一集'),
                            ),
                          ),
                        ],
                      )
                    : Text(
                        '选择一个视频时会自动扫描并归纳同一文件夹内的媒体。',
                        maxLines: dense ? 1 : null,
                        overflow: dense ? TextOverflow.ellipsis : null,
                        style: const TextStyle(
                          color: AppColors.textMuted,
                          fontSize: 10.5,
                          height: 1.35,
                        ),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyPlaylist extends StatelessWidget {
  const _EmptyPlaylist({required this.dense});

  final bool dense;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(dense ? 8 : 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.video_library_outlined,
              color: AppColors.textMuted,
              size: dense ? 25 : 31,
            ),
            SizedBox(height: dense ? 6 : 12),
            const Text(
              '尚未导入文件夹',
              style: TextStyle(color: AppColors.text, fontSize: 14),
            ),
            SizedBox(height: dense ? 3 : 5),
            const Text(
              '打开单个视频也会自动读取同一文件夹。',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppColors.textMuted,
                fontSize: 11.5,
                height: 1.4,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
