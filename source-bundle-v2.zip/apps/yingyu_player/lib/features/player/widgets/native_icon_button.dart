import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';

class NativeIconButton extends StatelessWidget {
  const NativeIconButton({
    super.key,
    required this.icon,
    required this.onPressed,
    this.tooltip,
    this.selected = false,
    this.size = 42,
    this.iconSize = 21,
    this.color,
    this.semanticLabel,
  });

  final IconData icon;
  final VoidCallback? onPressed;
  final String? tooltip;
  final bool selected;
  final double size;
  final double iconSize;
  final Color? color;
  final String? semanticLabel;

  @override
  Widget build(BuildContext context) {
    final button = Semantics(
      button: true,
      label: semanticLabel ?? tooltip,
      selected: selected,
      child: SizedBox.square(
        dimension: size,
        child: IconButton(
          onPressed: onPressed,
          padding: EdgeInsets.zero,
          style: ButtonStyle(
            foregroundColor: WidgetStateProperty.resolveWith((states) {
              if (states.contains(WidgetState.disabled)) {
                return AppColors.textMuted.withValues(alpha: 0.35);
              }
              if (selected) return AppColors.amber;
              if (states.contains(WidgetState.hovered) ||
                  states.contains(WidgetState.focused)) {
                return AppColors.ivory;
              }
              return color ?? AppColors.text;
            }),
            backgroundColor: WidgetStateProperty.resolveWith((states) {
              if (selected) {
                return AppColors.amber.withValues(alpha: 0.12);
              }
              if (states.contains(WidgetState.hovered) ||
                  states.contains(WidgetState.focused)) {
                return Colors.white.withValues(alpha: 0.09);
              }
              return Colors.transparent;
            }),
            shape: WidgetStatePropertyAll(
              RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
                side: selected
                    ? const BorderSide(color: AppColors.amberMuted)
                    : BorderSide.none,
              ),
            ),
          ),
          icon: Icon(icon, size: iconSize),
        ),
      ),
    );

    if (tooltip == null) return button;
    return Tooltip(message: tooltip, child: button);
  }
}
