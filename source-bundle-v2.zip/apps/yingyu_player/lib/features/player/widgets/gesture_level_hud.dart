import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';

enum GestureLevelKind { brightness, volume }

class GestureLevelHud extends StatelessWidget {
  const GestureLevelHud({
    super.key,
    required this.kind,
    required this.value,
    required this.visible,
    required this.height,
  });

  final GestureLevelKind kind;
  final double value;
  final bool visible;
  final double height;

  @override
  Widget build(BuildContext context) {
    final normalized = value.clamp(0.0, 1.0).toDouble();
    final percentage = (normalized * 100).round();
    final brightness = kind == GestureLevelKind.brightness;
    final label = brightness ? '亮度' : '音量';
    final icon = brightness
        ? normalized < 0.42
              ? Icons.brightness_low_rounded
              : Icons.brightness_6_rounded
        : normalized <= 0
        ? Icons.volume_off_rounded
        : normalized < 0.45
        ? Icons.volume_down_rounded
        : Icons.volume_up_rounded;

    return SizedBox(
      key: ValueKey('gesture-level-hud-${kind.name}'),
      width: 72,
      height: height,
      child: IgnorePointer(
        child: AnimatedOpacity(
          opacity: visible ? 1 : 0,
          duration: const Duration(milliseconds: 170),
          curve: Curves.easeOut,
          child: AnimatedScale(
            scale: visible ? 1 : 0.92,
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOutBack,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: const Color(0xD916191D),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x44000000),
                    blurRadius: 24,
                    offset: Offset(0, 9),
                  ),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 11, 10, 10),
                child: Column(
                  children: [
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 140),
                      transitionBuilder: (child, animation) => ScaleTransition(
                        scale: animation,
                        child: FadeTransition(opacity: animation, child: child),
                      ),
                      child: Icon(
                        icon,
                        key: ValueKey(icon),
                        color: AppColors.ivory,
                        size: 21,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      label,
                      style: const TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Expanded(
                      child: LayoutBuilder(
                        builder: (context, constraints) => ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: Stack(
                            alignment: Alignment.bottomCenter,
                            children: [
                              const Positioned.fill(
                                child: ColoredBox(color: Color(0x42FFFFFF)),
                              ),
                              AnimatedContainer(
                                duration: const Duration(milliseconds: 95),
                                curve: Curves.easeOutCubic,
                                width: 8,
                                height: constraints.maxHeight * normalized,
                                decoration: BoxDecoration(
                                  color: AppColors.amber,
                                  borderRadius: BorderRadius.circular(6),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Color(0x66F2B84B),
                                      blurRadius: 8,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      height: 17,
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 110),
                        transitionBuilder: (child, animation) => FadeTransition(
                          opacity: animation,
                          child: SlideTransition(
                            position: Tween<Offset>(
                              begin: const Offset(0, 0.24),
                              end: Offset.zero,
                            ).animate(animation),
                            child: child,
                          ),
                        ),
                        child: Text(
                          '$percentage%',
                          key: ValueKey(percentage),
                          style: const TextStyle(
                            color: AppColors.ivory,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            fontFeatures: [FontFeature.tabularFigures()],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
