import 'dart:async';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../../core/theme/app_theme.dart';
import '../../data/online_movie_service.dart';
import '../../domain/models/cloud_media_source.dart';
import '../../domain/models/media_playlist_item.dart';
import '../../domain/models/online_movie.dart';
import '../player/learning_player_controller.dart';
import '../player/widgets/desktop_window_bar.dart';

class OnlineMovieScreen extends StatefulWidget {
  const OnlineMovieScreen({super.key, required this.controller});

  final LearningPlayerController controller;

  @override
  State<OnlineMovieScreen> createState() => _OnlineMovieScreenState();
}

class _OnlineMovieScreenState extends State<OnlineMovieScreen> {
  final http.Client _client = http.Client();
  final TextEditingController _searchController = TextEditingController();
  late final OnlineMovieService _service = OnlineMovieService(_client);

  OnlineMovieWarehouse _warehouse =
      OnlineMovieService.recommendedWarehouses.first;
  OnlineMovieProvider? _provider;
  OnlineMovieCategory? _category;
  List<OnlineMovieProvider> _providers = const [];
  List<OnlineMovieCategory> _categories = const [];
  List<OnlineMovieSummary> _movies = const [];
  int _page = 1;
  int _pageCount = 1;
  int _requestToken = 0;
  bool _discovering = false;
  bool _loading = false;
  bool _globalSearch = false;
  String? _error;
  String? _notice;

  @override
  void initState() {
    super.initState();
    unawaited(_selectWarehouse(_warehouse));
  }

  @override
  void dispose() {
    _requestToken++;
    _searchController.dispose();
    _client.close();
    super.dispose();
  }

  Future<void> _selectWarehouse(OnlineMovieWarehouse warehouse) async {
    final token = ++_requestToken;
    setState(() {
      _warehouse = warehouse;
      _provider = null;
      _category = null;
      _providers = const [];
      _categories = const [];
      _movies = const [];
      _discovering = true;
      _loading = false;
      _globalSearch = false;
      _error = null;
      _notice = null;
    });
    try {
      final discovery = await _service.discover(warehouse);
      if (!mounted || token != _requestToken) return;
      if (discovery.providers.isEmpty) {
        setState(() {
          _error = discovery.unsupportedSiteCount > 0
              ? '该仓只有自定义 CatVod / JS 线路，Windows 原生端不会执行第三方脚本或 JAR。'
              : '该配置当前没有可读取的 JSON CMS 在线影视线路。';
          _notice = _discoveryNotice(discovery);
        });
        return;
      }
      setState(() {
        _providers = discovery.providers;
        _notice = _discoveryNotice(discovery);
      });
      await _loadFirstAvailableProvider(discovery.providers, token);
    } on OnlineMovieException catch (error) {
      if (mounted && token == _requestToken) {
        setState(() => _error = error.message);
      }
    } finally {
      if (mounted && token == _requestToken) {
        setState(() => _discovering = false);
      }
    }
  }

  String _discoveryNotice(OnlineMovieDiscovery discovery) {
    final details = <String>[
      '${discovery.providers.length} 条可用 4K 线路',
      if (discovery.unsupportedSiteCount > 0)
        '${discovery.unsupportedSiteCount} 条第三方脚本线路已隔离',
      if (discovery.failedConfigCount > 0)
        '${discovery.failedConfigCount} 个子配置暂不可用',
    ];
    return details.join(' · ');
  }

  Future<void> _selectProvider(OnlineMovieProvider provider) async {
    final token = ++_requestToken;
    setState(() {
      _provider = provider;
      _category = null;
      _categories = const [];
      _movies = const [];
      _page = 1;
      _error = null;
    });
    await _loadCatalog(token: token);
  }

  Future<void> _loadFirstAvailableProvider(
    List<OnlineMovieProvider> providers,
    int token,
  ) async {
    setState(() => _loading = true);
    String? lastFailure;
    try {
      for (final provider in providers.take(12)) {
        try {
          final result = await _service.loadCatalog(provider);
          if (!mounted || token != _requestToken) return;
          if (result.items.isEmpty) continue;
          setState(() {
            _provider = provider;
            _movies = result.items;
            _categories = result.categories;
            _page = result.page;
            _pageCount = result.pageCount;
            _error = null;
          });
          return;
        } on OnlineMovieException catch (error) {
          lastFailure = error.message;
        }
      }
      if (mounted && token == _requestToken) {
        setState(() {
          _provider = providers.first;
          _error = lastFailure ?? '该影视仓的原生 CMS 线路当前均未返回内容。';
        });
      }
    } finally {
      if (mounted && token == _requestToken) setState(() => _loading = false);
    }
  }

  Future<void> _selectCategory(OnlineMovieCategory? category) async {
    final token = ++_requestToken;
    setState(() {
      _category = category;
      _page = 1;
      _error = null;
      _globalSearch = false;
    });
    await _loadCatalog(token: token);
  }

  Future<void> _search() async {
    final keyword = _searchController.text.trim();
    if (keyword.isEmpty && _provider == null) return;
    final token = ++_requestToken;
    setState(() {
      _category = null;
      _page = 1;
      _error = null;
      _globalSearch = keyword.isNotEmpty;
    });
    if (keyword.isEmpty) {
      await _loadCatalog(token: token);
      return;
    }
    setState(() => _loading = true);
    try {
      final result = await _service.searchAll(keyword);
      if (!mounted || token != _requestToken) return;
      setState(() {
        _movies = result.items;
        _categories = const [];
        _page = 1;
        _pageCount = 1;
        _notice =
            '已搜索 ${result.providerCount} 条线路，找到 ${result.items.length} 个结果'
            '${result.failedProviderCount > 0 ? ' · ${result.failedProviderCount} 条线路暂不可用' : ''}';
        if (result.items.isEmpty) _error = '所有可用线路都没有找到“$keyword”。';
      });
    } on OnlineMovieException catch (error) {
      if (mounted && token == _requestToken) {
        setState(() {
          _movies = const [];
          _error = error.message;
        });
      }
    } finally {
      if (mounted && token == _requestToken) setState(() => _loading = false);
    }
  }

  Future<void> _changePage(int page) async {
    if (_provider == null || page < 1 || page > _pageCount) return;
    final token = ++_requestToken;
    setState(() {
      _page = page;
      _error = null;
    });
    await _loadCatalog(token: token);
  }

  Future<void> _loadCatalog({required int token}) async {
    final provider = _provider;
    if (provider == null) return;
    setState(() {
      _loading = true;
      _globalSearch = false;
    });
    try {
      final result = await _service.loadCatalog(
        provider,
        page: _page,
        categoryId: _category?.id,
        keyword: _searchController.text,
      );
      if (!mounted || token != _requestToken) return;
      setState(() {
        _movies = result.items;
        if (result.categories.isNotEmpty) _categories = result.categories;
        _page = result.page;
        _pageCount = result.pageCount;
        if (result.items.isEmpty) _error = '该线路没有返回匹配的影视内容。';
      });
    } on OnlineMovieException catch (error) {
      if (mounted && token == _requestToken) {
        setState(() {
          _movies = const [];
          _error = error.message;
        });
      }
    } finally {
      if (mounted && token == _requestToken) setState(() => _loading = false);
    }
  }

  Future<void> _openMovie(OnlineMovieSummary movie) async {
    final detail = await showDialog<OnlineMovieDetail>(
      context: context,
      builder: (context) =>
          _MovieLoadingDialog(future: _service.loadDetail(movie), movie: movie),
    );
    if (detail == null || !mounted) return;
    final selection = await showModalBottomSheet<_EpisodeSelection>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF11171C),
      builder: (context) => _EpisodeSheet(detail: detail),
    );
    if (selection == null || !mounted) return;
    if (selection.episode.isCloudShare) {
      await _importCloudEpisode(detail, selection.episode);
      return;
    }
    final provider = movie.provider;
    final playlist = detail.episodes
        .where((episode) => episode.route == selection.episode.route)
        .map(
          (episode) =>
              episode.toPlaylistItem(movie: detail, provider: provider),
        )
        .toList(growable: false);
    final item = selection.episode.toPlaylistItem(
      movie: detail,
      provider: provider,
    );
    // Keep episode navigation on the selected route, but retain the matching
    // episode from every other route for Baohe/TVBox-style source switching
    // and automatic failover during direct network playback.
    final selectedRouteEpisodes = detail.episodes
        .where(
          (episode) =>
              episode.route == selection.episode.route && !episode.isCloudShare,
        )
        .toList(growable: false);
    final selectedEpisodeIndex = selectedRouteEpisodes.indexWhere(
      (episode) => episode.url == selection.episode.url,
    );
    final sourceItems = <MediaPlaylistItem>[];
    final seenRoutes = <String>{};
    for (final episode in detail.episodes) {
      if (episode.isCloudShare || !seenRoutes.add(episode.route)) continue;
      final routeEpisodes = detail.episodes
          .where(
            (candidate) =>
                candidate.route == episode.route && !candidate.isCloudShare,
          )
          .toList(growable: false);
      if (routeEpisodes.isEmpty) continue;
      final matching = routeEpisodes.where(
        (candidate) => candidate.name == selection.episode.name,
      );
      final sourceEpisode = matching.isNotEmpty
          ? matching.first
          : routeEpisodes[(selectedEpisodeIndex < 0 ? 0 : selectedEpisodeIndex)
                .clamp(0, routeEpisodes.length - 1)];
      sourceItems.add(
        sourceEpisode.toPlaylistItem(movie: detail, provider: provider),
      );
    }
    await widget.controller.openOnlineStream(
      item,
      relatedItems: playlist.isEmpty ? [item] : playlist,
      sourceItems: sourceItems.isEmpty ? [item] : sourceItems,
    );
  }

  Future<void> _importCloudEpisode(
    OnlineMovieDetail movie,
    OnlineMovieEpisode episode,
  ) async {
    if (episode.cloudProvider != '夸克') {
      await showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('${episode.cloudProvider}转存尚未配置'),
          content: const Text('当前版本先支持夸克分享链接自动转存，并通过夸克直链播放。'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('知道了'),
            ),
          ],
        ),
      );
      return;
    }
    final sources = widget.controller.cloudSources
        .where((source) => source.canImportQuarkShares)
        .toList(growable: false);
    if (sources.isEmpty) {
      await showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('需要夸克转存配置'),
          content: const Text('请返回主页进入“影视 → 网盘”，扫码连接夸克后再进行转存。'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('知道了'),
            ),
          ],
        ),
      );
      return;
    }
    CloudMediaSource? source = sources.first;
    if (sources.length > 1) {
      source = await showModalBottomSheet<CloudMediaSource>(
        context: context,
        backgroundColor: const Color(0xFF11171C),
        builder: (context) => SafeArea(
          child: ListView(
            shrinkWrap: true,
            children: [
              const ListTile(
                title: Text('选择转存目标'),
                subtitle: Text('转存完成后将通过夸克直链播放'),
              ),
              for (final value in sources)
                ListTile(
                  leading: const Icon(Icons.cloud_download_outlined),
                  title: Text(value.name),
                  subtitle: Text(value.rootPath),
                  onTap: () => Navigator.pop(context, value),
                ),
            ],
          ),
        ),
      );
      if (source == null || !mounted) return;
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('转存后播放'),
        content: Text(
          '将“${movie.name} · ${episode.name}”转存到夸克网盘“${source!.name}”，完成后自动获取 4K 直链并播放。',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('开始转存'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    final succeeded = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => _CloudTransferDialog(
        future: widget.controller.importQuarkShareAndPlay(
          source: source!,
          shareUrl: episode.url,
          titleHint: '${movie.name} ${episode.name}',
          autoPlay: false,
        ),
      ),
    );
    if (succeeded == true && mounted) {
      final candidates = widget.controller.lastImportedCloudItems;
      if (candidates.isNotEmpty) {
        final selected = candidates.length == 1
            ? candidates.first
            : await showModalBottomSheet<MediaPlaylistItem>(
                context: context,
                isScrollControlled: true,
                backgroundColor: const Color(0xFF11171C),
                builder: (context) =>
                    _TransferredEpisodeSheet(movie: movie, items: candidates),
              );
        if (selected != null && mounted) {
          await widget.controller.openOnlineStream(
            selected,
            relatedItems: candidates,
          );
        }
      }
    }
    if (succeeded != true && mounted) {
      final message = widget.controller.lastError ?? '转存或播放失败。';
      await showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('无法播放 4K 线路'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('关闭'),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final compact = size.width < 860;
    return Scaffold(
      backgroundColor: AppColors.canvas,
      body: SafeArea(
        child: Column(
          children: [
            const DesktopWindowBar(title: '影语 · 在线影视'),
            Expanded(
              child: Row(
                children: [
                  if (!compact)
                    _WarehouseRail(
                      selected: _warehouse,
                      loading: _discovering,
                      onSelected: _selectWarehouse,
                    ),
                  Expanded(
                    child: Column(
                      children: [
                        _OnlineMovieHeader(
                          compact: compact,
                          warehouse: _warehouse,
                          controller: _searchController,
                          loading: _discovering || _loading,
                          onBack: widget.controller.showMovieLibrary,
                          onSearch: _search,
                          onReload: () => _selectWarehouse(_warehouse),
                          onWarehouse: compact
                              ? () => _showWarehousePicker(context)
                              : null,
                        ),
                        if (_notice case final notice?)
                          _StatusStrip(message: notice),
                        if (_error case final error?)
                          _StatusStrip(message: error, error: true),
                        if (_providers.isNotEmpty)
                          _HorizontalChoices<OnlineMovieProvider>(
                            values: _providers,
                            selected: _provider,
                            label: (value) => value.name,
                            onSelected: _selectProvider,
                          ),
                        if (_categories.isNotEmpty && !_globalSearch)
                          _CategoryBar(
                            values: _categories,
                            selected: _category,
                            onSelected: _selectCategory,
                          ),
                        Expanded(child: _buildBody(compact)),
                        if (_movies.isNotEmpty && !_globalSearch)
                          _Pagination(
                            page: _page,
                            pageCount: _pageCount,
                            loading: _loading,
                            onPage: _changePage,
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBody(bool compact) {
    if ((_discovering || _loading) && _movies.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_movies.isEmpty) {
      return _OnlineMovieEmpty(
        warehouse: _warehouse,
        hasError: _error != null,
        onReload: () => _selectWarehouse(_warehouse),
      );
    }
    return GridView.builder(
      padding: EdgeInsets.fromLTRB(
        compact ? 14 : 24,
        16,
        compact ? 14 : 24,
        24,
      ),
      gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: compact ? 170 : 205,
        childAspectRatio: 0.64,
        crossAxisSpacing: 14,
        mainAxisSpacing: 18,
      ),
      itemCount: _movies.length,
      itemBuilder: (context, index) => _MovieCard(
        movie: _movies[index],
        onTap: () => _openMovie(_movies[index]),
      ),
    );
  }

  Future<void> _showWarehousePicker(BuildContext context) async {
    final selected = await showModalBottomSheet<OnlineMovieWarehouse>(
      context: context,
      backgroundColor: const Color(0xFF11171C),
      builder: (context) => SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(vertical: 12),
          children: [
            ListTile(
              title: Text(
                '选择影视仓',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: const Text('仅保留 4K 线路；玩偶合集已拆分为独立入口'),
            ),
            for (final warehouse in OnlineMovieService.recommendedWarehouses)
              ListTile(
                leading: Icon(
                  warehouse == _warehouse
                      ? Icons.radio_button_checked_rounded
                      : Icons.radio_button_off_rounded,
                  color: warehouse == _warehouse ? AppColors.amber : null,
                ),
                title: Text(warehouse.name),
                subtitle: Text(
                  warehouse.url,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                onTap: () => Navigator.pop(context, warehouse),
              ),
          ],
        ),
      ),
    );
    if (selected != null && mounted) await _selectWarehouse(selected);
  }
}

class _WarehouseRail extends StatelessWidget {
  const _WarehouseRail({
    required this.selected,
    required this.loading,
    required this.onSelected,
  });

  final OnlineMovieWarehouse selected;
  final bool loading;
  final ValueChanged<OnlineMovieWarehouse> onSelected;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 226,
      decoration: const BoxDecoration(
        color: Color(0xB3090D11),
        border: Border(right: BorderSide(color: AppColors.divider)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 20, 16, 8),
            child: Text(
              '影视仓',
              style: TextStyle(
                color: AppColors.ivory,
                fontSize: 18,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(20, 0, 16, 14),
            child: Text(
              '${OnlineMovieService.recommendedWarehouses.length} 个配置入口',
              style: TextStyle(color: AppColors.textMuted, fontSize: 11),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(10, 0, 10, 16),
              itemCount: OnlineMovieService.recommendedWarehouses.length,
              itemBuilder: (context, index) {
                final warehouse =
                    OnlineMovieService.recommendedWarehouses[index];
                final active = warehouse == selected;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 3),
                  child: Material(
                    color: active
                        ? AppColors.amber.withValues(alpha: 0.12)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(10),
                    child: ListTile(
                      dense: true,
                      enabled: !loading,
                      leading: Icon(
                        active
                            ? Icons.movie_filter_rounded
                            : Icons.video_library_outlined,
                        size: 19,
                        color: active ? AppColors.amber : AppColors.textMuted,
                      ),
                      title: Text(
                        warehouse.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: active ? AppColors.ivory : AppColors.textMuted,
                          fontSize: 12,
                          fontWeight: active
                              ? FontWeight.w700
                              : FontWeight.w500,
                        ),
                      ),
                      onTap: () => onSelected(warehouse),
                    ),
                  ),
                );
              },
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              '第三方配置随时可能失效。仅播放你有权访问的内容。',
              style: TextStyle(
                color: Color(0xFF69727A),
                fontSize: 10,
                height: 1.45,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _OnlineMovieHeader extends StatelessWidget {
  const _OnlineMovieHeader({
    required this.compact,
    required this.warehouse,
    required this.controller,
    required this.loading,
    required this.onBack,
    required this.onSearch,
    required this.onReload,
    required this.onWarehouse,
  });

  final bool compact;
  final OnlineMovieWarehouse warehouse;
  final TextEditingController controller;
  final bool loading;
  final VoidCallback onBack;
  final VoidCallback onSearch;
  final VoidCallback onReload;
  final VoidCallback? onWarehouse;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(compact ? 6 : 14, 10, compact ? 8 : 18, 10),
      decoration: const BoxDecoration(
        color: Color(0xE80C1115),
        border: Border(bottom: BorderSide(color: AppColors.divider)),
      ),
      child: Row(
        children: [
          IconButton(
            tooltip: '返回影视资料库',
            onPressed: onBack,
            icon: const Icon(Icons.arrow_back_rounded),
          ),
          if (onWarehouse != null)
            IconButton(
              tooltip: '选择影视仓',
              onPressed: onWarehouse,
              icon: const Icon(Icons.storage_rounded),
            ),
          if (!compact) ...[
            const SizedBox(width: 4),
            SizedBox(
              width: 180,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '在线影视',
                    style: TextStyle(
                      color: AppColors.ivory,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  Text(
                    warehouse.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
          ],
          const Spacer(),
          SizedBox(
            width: compact ? 190 : 300,
            height: 40,
            child: TextField(
              controller: controller,
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => onSearch(),
              decoration: InputDecoration(
                hintText: '搜索全部线路',
                prefixIcon: const Icon(Icons.search_rounded, size: 19),
                suffixIcon: IconButton(
                  tooltip: '搜索',
                  onPressed: loading ? null : onSearch,
                  icon: const Icon(Icons.arrow_forward_rounded, size: 18),
                ),
                contentPadding: EdgeInsets.zero,
              ),
            ),
          ),
          IconButton(
            tooltip: '刷新影视仓',
            onPressed: loading ? null : onReload,
            icon: loading
                ? const SizedBox.square(
                    dimension: 17,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
    );
  }
}

class _StatusStrip extends StatelessWidget {
  const _StatusStrip({required this.message, this.error = false});

  final String message;
  final bool error;

  @override
  Widget build(BuildContext context) {
    final color = error ? AppColors.danger : AppColors.success;
    return Container(
      width: double.infinity,
      color: color.withValues(alpha: 0.08),
      padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 7),
      child: Text(
        message,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(color: color, fontSize: 11.5),
      ),
    );
  }
}

class _HorizontalChoices<T> extends StatelessWidget {
  const _HorizontalChoices({
    required this.values,
    required this.selected,
    required this.label,
    required this.onSelected,
  });

  final List<T> values;
  final T? selected;
  final String Function(T value) label;
  final ValueChanged<T> onSelected;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 47,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 7),
        scrollDirection: Axis.horizontal,
        itemCount: values.length,
        separatorBuilder: (_, _) => const SizedBox(width: 7),
        itemBuilder: (context, index) {
          final value = values[index];
          return ChoiceChip(
            label: Text(label(value)),
            selected: value == selected,
            onSelected: (_) => onSelected(value),
          );
        },
      ),
    );
  }
}

class _CategoryBar extends StatelessWidget {
  const _CategoryBar({
    required this.values,
    required this.selected,
    required this.onSelected,
  });

  final List<OnlineMovieCategory> values;
  final OnlineMovieCategory? selected;
  final ValueChanged<OnlineMovieCategory?> onSelected;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 43,
      child: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
        scrollDirection: Axis.horizontal,
        children: [
          ChoiceChip(
            label: const Text('全部'),
            selected: selected == null,
            onSelected: (_) => onSelected(null),
          ),
          for (final category in values) ...[
            const SizedBox(width: 6),
            ChoiceChip(
              label: Text(category.name),
              selected: category.id == selected?.id,
              onSelected: (_) => onSelected(category),
            ),
          ],
        ],
      ),
    );
  }
}

class _MovieCard extends StatelessWidget {
  const _MovieCard({required this.movie, required this.onTap});

  final OnlineMovieSummary movie;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFF141A20),
      borderRadius: BorderRadius.circular(13),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  const ColoredBox(color: Color(0xFF1B242B)),
                  if (movie.coverUrl case final cover?)
                    Image.network(
                      cover,
                      fit: BoxFit.cover,
                      headers: const {'User-Agent': 'Mozilla/5.0'},
                      errorBuilder: (_, _, _) => const _PosterFallback(),
                    )
                  else
                    const _PosterFallback(),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, Color(0xD9070A0D)],
                        stops: [0.58, 1],
                      ),
                    ),
                  ),
                  if (movie.remarks case final remarks?)
                    Positioned(
                      right: 7,
                      bottom: 7,
                      child: Container(
                        constraints: const BoxConstraints(maxWidth: 120),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 7,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xD90A0E12),
                          borderRadius: BorderRadius.circular(7),
                        ),
                        child: Text(
                          remarks,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: AppColors.amber,
                            fontSize: 9.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 9, 10, 3),
              child: Text(
                movie.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: AppColors.ivory,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 0, 10, 9),
              child: Text(
                [movie.provider.name, movie.typeName, movie.year]
                    .whereType<String>()
                    .where((value) => value.isNotEmpty)
                    .join(' · '),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: AppColors.textMuted,
                  fontSize: 10,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PosterFallback extends StatelessWidget {
  const _PosterFallback();

  @override
  Widget build(BuildContext context) {
    return const DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF263842), Color(0xFF10171B)],
        ),
      ),
      child: Icon(Icons.movie_outlined, color: AppColors.textMuted, size: 42),
    );
  }
}

class _OnlineMovieEmpty extends StatelessWidget {
  const _OnlineMovieEmpty({
    required this.warehouse,
    required this.hasError,
    required this.onReload,
  });

  final OnlineMovieWarehouse warehouse;
  final bool hasError;
  final VoidCallback onReload;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 520),
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                hasError ? Icons.link_off_rounded : Icons.movie_filter_rounded,
                size: 52,
                color: hasError ? AppColors.danger : AppColors.amber,
              ),
              const SizedBox(height: 15),
              Text(
                hasError ? '${warehouse.name} 当前无法加载' : '选择一个影视仓开始浏览',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: AppColors.ivory,
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                '配置由第三方维护，可能失效、加密或依赖 Android CatVod。影语只连接可直接验证的 JSON CMS 线路。',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.textMuted, height: 1.5),
              ),
              const SizedBox(height: 18),
              OutlinedButton.icon(
                onPressed: onReload,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('重新检测'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Pagination extends StatelessWidget {
  const _Pagination({
    required this.page,
    required this.pageCount,
    required this.loading,
    required this.onPage,
  });

  final int page;
  final int pageCount;
  final bool loading;
  final ValueChanged<int> onPage;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 48,
      decoration: const BoxDecoration(
        color: Color(0xE80C1115),
        border: Border(top: BorderSide(color: AppColors.divider)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          IconButton(
            tooltip: '上一页',
            onPressed: loading || page <= 1 ? null : () => onPage(page - 1),
            icon: const Icon(Icons.chevron_left_rounded),
          ),
          Text(
            '$page / $pageCount',
            style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
          ),
          IconButton(
            tooltip: '下一页',
            onPressed: loading || page >= pageCount
                ? null
                : () => onPage(page + 1),
            icon: const Icon(Icons.chevron_right_rounded),
          ),
        ],
      ),
    );
  }
}

class _MovieLoadingDialog extends StatelessWidget {
  const _MovieLoadingDialog({required this.future, required this.movie});

  final Future<OnlineMovieDetail> future;
  final OnlineMovieSummary movie;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(movie.name),
      content: SizedBox(
        width: 420,
        child: FutureBuilder<OnlineMovieDetail>(
          future: future,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const SizedBox(
                height: 110,
                child: Center(child: CircularProgressIndicator()),
              );
            }
            if (snapshot.hasError) {
              return Text(
                snapshot.error.toString(),
                style: const TextStyle(color: AppColors.danger),
              );
            }
            final detail = snapshot.data!;
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (context.mounted) Navigator.pop(context, detail);
            });
            return const SizedBox(
              height: 60,
              child: Center(child: CircularProgressIndicator()),
            );
          },
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('取消'),
        ),
      ],
    );
  }
}

class _TransferredEpisodeSheet extends StatelessWidget {
  const _TransferredEpisodeSheet({required this.movie, required this.items});

  final OnlineMovieDetail movie;
  final List<MediaPlaylistItem> items;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: FractionallySizedBox(
        heightFactor: 0.72,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${movie.name} · 选择剧集',
                style: const TextStyle(
                  color: AppColors.ivory,
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 5),
              const Text(
                '已转存完成，选择后立即播放',
                style: TextStyle(color: AppColors.textMuted, fontSize: 12),
              ),
              const SizedBox(height: 14),
              Expanded(
                child: ListView.separated(
                  itemCount: items.length,
                  separatorBuilder: (_, _) => const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final item = items[index];
                    return ListTile(
                      leading: CircleAvatar(
                        radius: 15,
                        backgroundColor: AppColors.selected,
                        child: Text(
                          '${index + 1}',
                          style: const TextStyle(
                            color: AppColors.amber,
                            fontSize: 12,
                          ),
                        ),
                      ),
                      title: Text(
                        item.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      trailing: const Icon(Icons.play_arrow_rounded),
                      onTap: () => Navigator.pop(context, item),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CloudTransferDialog extends StatelessWidget {
  const _CloudTransferDialog({required this.future});

  final Future<bool> future;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('正在转存 4K 资源'),
      content: SizedBox(
        width: 390,
        height: 120,
        child: FutureBuilder<bool>(
          future: future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (context.mounted) {
                  Navigator.pop(context, snapshot.data == true);
                }
              });
            }
            return const Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 16),
                Text(
                  '正在请求夸克转存并获取播放直链…',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.textMuted),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _EpisodeSheet extends StatefulWidget {
  const _EpisodeSheet({required this.detail});

  final OnlineMovieDetail detail;

  @override
  State<_EpisodeSheet> createState() => _EpisodeSheetState();
}

class _EpisodeSheetState extends State<_EpisodeSheet> {
  late String _route = widget.detail.episodes.isEmpty
      ? ''
      : widget.detail.episodes.first.route;

  @override
  Widget build(BuildContext context) {
    final routes = {
      for (final episode in widget.detail.episodes) episode.route,
    };
    final episodes = widget.detail.episodes
        .where((episode) => episode.route == _route)
        .toList(growable: false);
    return SafeArea(
      child: FractionallySizedBox(
        heightFactor: 0.76,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.detail.name,
                          style: const TextStyle(
                            color: AppColors.ivory,
                            fontSize: 21,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        if (widget.detail.remarks case final remarks?)
                          Text(
                            remarks,
                            style: const TextStyle(
                              color: AppColors.amber,
                              fontSize: 11,
                            ),
                          ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close_rounded),
                  ),
                ],
              ),
              if (widget.detail.blurb case final blurb?) ...[
                const SizedBox(height: 8),
                Text(
                  blurb,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 12,
                    height: 1.45,
                  ),
                ),
              ],
              const SizedBox(height: 14),
              if (routes.length > 1)
                SizedBox(
                  height: 40,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      for (final route in routes) ...[
                        ChoiceChip(
                          label: Text(route),
                          selected: route == _route,
                          onSelected: (_) => setState(() => _route = route),
                        ),
                        const SizedBox(width: 7),
                      ],
                    ],
                  ),
                ),
              const SizedBox(height: 10),
              Expanded(
                child: episodes.isEmpty
                    ? const Center(
                        child: Text(
                          '该影视没有可直接播放的 HTTP 地址',
                          style: TextStyle(color: AppColors.textMuted),
                        ),
                      )
                    : GridView.builder(
                        gridDelegate:
                            const SliverGridDelegateWithMaxCrossAxisExtent(
                              maxCrossAxisExtent: 150,
                              mainAxisExtent: 44,
                              crossAxisSpacing: 9,
                              mainAxisSpacing: 9,
                            ),
                        itemCount: episodes.length,
                        itemBuilder: (context, index) => OutlinedButton(
                          onPressed: () => Navigator.pop(
                            context,
                            _EpisodeSelection(episodes[index]),
                          ),
                          child: Text(
                            episodes[index].isCloudShare
                                ? '${episodes[index].cloudProvider} · ${episodes[index].name}'
                                : episodes[index].name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EpisodeSelection {
  const _EpisodeSelection(this.episode);

  final OnlineMovieEpisode episode;
}
