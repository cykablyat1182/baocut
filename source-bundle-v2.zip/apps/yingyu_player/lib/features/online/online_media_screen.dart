import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../domain/models/media_playlist_item.dart';
import '../../domain/models/online_stream_source.dart';
import '../player/learning_player_controller.dart';
import '../player/widgets/desktop_window_bar.dart';

class OnlineMediaScreen extends StatefulWidget {
  const OnlineMediaScreen({super.key, required this.controller});

  final LearningPlayerController controller;

  @override
  State<OnlineMediaScreen> createState() => _OnlineMediaScreenState();
}

class _OnlineMediaScreenState extends State<OnlineMediaScreen> {
  String _query = '';
  String? _source;
  String? _group;

  LearningPlayerController get controller => widget.controller;

  Future<void> _play(MediaPlaylistItem item) async {
    await controller.openOnlineStream(item);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final size = MediaQuery.sizeOf(context);
        final compact = size.width < 820;
        final normalized = _query.trim().toLowerCase();
        final items = controller.onlineStreamItems
            .where((item) {
              if (_source != null && item.sourceName != _source) return false;
              if (_group != null && item.group != _group) return false;
              return normalized.isEmpty ||
                  item.title.toLowerCase().contains(normalized) ||
                  (item.group?.toLowerCase().contains(normalized) ?? false);
            })
            .toList(growable: false);
        final sources = {
          for (final item in controller.onlineStreamItems)
            if (item.sourceName?.isNotEmpty == true) item.sourceName!,
        }.toList()..sort();
        final groups = {
          for (final item in controller.onlineStreamItems)
            if ((_source == null || item.sourceName == _source) &&
                item.group?.isNotEmpty == true)
              item.group!,
        }.toList()..sort();

        return Scaffold(
          backgroundColor: AppColors.canvas,
          body: SafeArea(
            child: Column(
              children: [
                const DesktopWindowBar(title: '影语 · 在线'),
                _OnlineHeader(
                  compact: compact,
                  loading: controller.onlineStreamsLoading,
                  count: items.length,
                  onBack: controller.showMovieLibrary,
                  onRefresh: controller.refreshOnlineStreams,
                  onManage: () => _showSourceManager(context, controller),
                  onQueryChanged: (value) => setState(() => _query = value),
                ),
                if (controller.lastError != null)
                  _MessageBar(
                    message: controller.lastError!,
                    error: true,
                    onClose: controller.clearMessages,
                  )
                else if (controller.lastNotice != null)
                  _MessageBar(
                    message: controller.lastNotice!,
                    onClose: controller.clearMessages,
                  ),
                if (sources.isNotEmpty)
                  _FilterBar(
                    values: sources,
                    selected: _source,
                    allLabel: '全部线路',
                    onSelected: (value) => setState(() {
                      _source = value;
                      _group = null;
                    }),
                  ),
                if (groups.isNotEmpty)
                  _FilterBar(
                    values: groups,
                    selected: _group,
                    allLabel: '全部分组',
                    onSelected: (value) => setState(() => _group = value),
                  ),
                Expanded(
                  child:
                      controller.onlineStreamsLoading &&
                          controller.onlineStreamItems.isEmpty
                      ? const Center(child: CircularProgressIndicator())
                      : controller.onlineStreamItems.isEmpty
                      ? _EmptyOnline(
                          onManage: () =>
                              _showSourceManager(context, controller),
                          onInstall: controller.installRecommendedTvBoxSource,
                        )
                      : items.isEmpty
                      ? const Center(
                          child: Text(
                            '没有匹配的频道',
                            style: TextStyle(color: AppColors.textMuted),
                          ),
                        )
                      : GridView.builder(
                          padding: EdgeInsets.fromLTRB(
                            compact ? 14 : 28,
                            14,
                            compact ? 14 : 28,
                            28,
                          ),
                          gridDelegate:
                              SliverGridDelegateWithMaxCrossAxisExtent(
                                maxCrossAxisExtent: compact ? 180 : 220,
                                mainAxisExtent: compact ? 126 : 144,
                                crossAxisSpacing: 14,
                                mainAxisSpacing: 14,
                              ),
                          itemCount: items.length,
                          itemBuilder: (context, index) => _ChannelCard(
                            item: items[index],
                            onTap: () => _play(items[index]),
                          ),
                        ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _OnlineHeader extends StatelessWidget {
  const _OnlineHeader({
    required this.compact,
    required this.loading,
    required this.count,
    required this.onBack,
    required this.onRefresh,
    required this.onManage,
    required this.onQueryChanged,
  });

  final bool compact;
  final bool loading;
  final int count;
  final VoidCallback onBack;
  final VoidCallback onRefresh;
  final VoidCallback onManage;
  final ValueChanged<String> onQueryChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(compact ? 8 : 18, 12, compact ? 8 : 22, 12),
      decoration: const BoxDecoration(
        color: Color(0xE80C1115),
        border: Border(bottom: BorderSide(color: AppColors.divider)),
      ),
      child: Row(
        children: [
          IconButton(
            tooltip: '返回资料库',
            onPressed: onBack,
            icon: const Icon(Icons.arrow_back_rounded),
          ),
          const SizedBox(width: 4),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '在线',
                  style: TextStyle(
                    color: AppColors.ivory,
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  '$count 个频道 · TVBox / M3U / TXT',
                  style: const TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            width: compact ? 190 : 280,
            height: 40,
            child: TextField(
              onChanged: onQueryChanged,
              decoration: const InputDecoration(
                hintText: '搜索频道或分组',
                prefixIcon: Icon(Icons.search_rounded, size: 19),
                contentPadding: EdgeInsets.zero,
              ),
            ),
          ),
          IconButton(
            tooltip: '刷新在线源',
            onPressed: loading ? null : onRefresh,
            icon: loading
                ? const SizedBox.square(
                    dimension: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.refresh_rounded),
          ),
          IconButton(
            tooltip: '管理在线源',
            onPressed: onManage,
            icon: const Icon(Icons.tune_rounded),
          ),
        ],
      ),
    );
  }
}

class _FilterBar extends StatelessWidget {
  const _FilterBar({
    required this.values,
    required this.selected,
    required this.allLabel,
    required this.onSelected,
  });

  final List<String> values;
  final String? selected;
  final String allLabel;
  final ValueChanged<String?> onSelected;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 46,
      child: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 7),
        scrollDirection: Axis.horizontal,
        children: [
          ChoiceChip(
            label: Text(allLabel),
            selected: selected == null,
            onSelected: (_) => onSelected(null),
          ),
          for (final value in values) ...[
            const SizedBox(width: 7),
            ChoiceChip(
              label: Text(value),
              selected: selected == value,
              onSelected: (_) => onSelected(value),
            ),
          ],
        ],
      ),
    );
  }
}

class _ChannelCard extends StatelessWidget {
  const _ChannelCard({required this.item, required this.onTap});

  final MediaPlaylistItem item;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFF141A20),
      borderRadius: BorderRadius.circular(14),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Stack(
          fit: StackFit.expand,
          children: [
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF243744), Color(0xFF10171C)],
                ),
              ),
            ),
            if (item.remoteLogoUrl case final logo?)
              Padding(
                padding: const EdgeInsets.fromLTRB(28, 15, 28, 43),
                child: Image.network(
                  logo,
                  fit: BoxFit.contain,
                  errorBuilder: (_, _, _) => const Icon(
                    Icons.live_tv_rounded,
                    size: 38,
                    color: AppColors.textMuted,
                  ),
                ),
              )
            else
              const Padding(
                padding: EdgeInsets.only(bottom: 31),
                child: Icon(
                  Icons.live_tv_rounded,
                  size: 40,
                  color: AppColors.textMuted,
                ),
              ),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Color(0xF005080A)],
                  stops: [0.35, 1],
                ),
              ),
            ),
            Positioned(
              left: 11,
              right: 11,
              bottom: 10,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: AppColors.ivory,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  if (item.group?.isNotEmpty == true)
                    Text(
                      item.group!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 10,
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyOnline extends StatelessWidget {
  const _EmptyOnline({required this.onManage, required this.onInstall});

  final VoidCallback onManage;
  final VoidCallback onInstall;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 520),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.connected_tv_rounded,
                size: 54,
                color: AppColors.amber,
              ),
              const SizedBox(height: 16),
              const Text(
                '添加 TVBox、M3U 或 TXT 在线源',
                style: TextStyle(
                  color: AppColors.ivory,
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                '支持线路切换、频道分组、台标、EPG 地址和在线直播播放。请仅添加你有权使用的内容源。',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.textMuted, height: 1.5),
              ),
              const SizedBox(height: 20),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                alignment: WrapAlignment.center,
                children: [
                  FilledButton.icon(
                    onPressed: onInstall,
                    icon: const Icon(Icons.cloud_download_outlined),
                    label: const Text('载入当前 TVBox 配置'),
                  ),
                  OutlinedButton.icon(
                    onPressed: onManage,
                    icon: const Icon(Icons.add_link_rounded),
                    label: const Text('添加其他源'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MessageBar extends StatelessWidget {
  const _MessageBar({
    required this.message,
    required this.onClose,
    this.error = false,
  });

  final String message;
  final VoidCallback onClose;
  final bool error;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 10, 20, 0),
      padding: const EdgeInsets.fromLTRB(12, 6, 4, 6),
      decoration: BoxDecoration(
        color: (error ? AppColors.danger : AppColors.success).withValues(
          alpha: 0.1,
        ),
        borderRadius: BorderRadius.circular(9),
      ),
      child: Row(
        children: [
          Icon(
            error ? Icons.error_outline_rounded : Icons.info_outline_rounded,
            size: 18,
            color: error ? AppColors.danger : AppColors.success,
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(message, style: const TextStyle(fontSize: 12))),
          IconButton(
            onPressed: onClose,
            icon: const Icon(Icons.close_rounded, size: 17),
          ),
        ],
      ),
    );
  }
}

Future<void> _showSourceManager(
  BuildContext context,
  LearningPlayerController controller,
) async {
  final nameController = TextEditingController();
  final urlController = TextEditingController();
  await showDialog<void>(
    context: context,
    builder: (context) => StatefulBuilder(
      builder: (context, setDialogState) => AlertDialog(
        title: const Text('管理在线源'),
        content: SizedBox(
          width: 620,
          height: 430,
          child: Column(
            children: [
              Expanded(
                child: controller.onlineStreamSources.isEmpty
                    ? const Center(
                        child: Text(
                          '还没有在线源',
                          style: TextStyle(color: AppColors.textMuted),
                        ),
                      )
                    : ListView.separated(
                        itemCount: controller.onlineStreamSources.length,
                        separatorBuilder: (_, _) => const Divider(height: 1),
                        itemBuilder: (context, index) {
                          final source = controller.onlineStreamSources[index];
                          return _SourceRow(
                            source: source,
                            onDelete: () async {
                              await controller.removeOnlineStreamSource(source);
                              setDialogState(() {});
                            },
                          );
                        },
                      ),
              ),
              const Divider(),
              const SizedBox(height: 8),
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: '名称',
                  hintText: '例如：家庭 IPTV',
                ),
              ),
              const SizedBox(height: 9),
              TextField(
                controller: urlController,
                decoration: const InputDecoration(
                  labelText: 'TVBox / M3U / TXT 地址',
                  hintText: 'https://example.com/tvbox.json',
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await controller.installRecommendedTvBoxSource();
            },
            child: const Text('载入当前配置'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('关闭'),
          ),
          FilledButton(
            onPressed: () async {
              await controller.addOnlineStreamSource(
                name: nameController.text,
                url: urlController.text,
              );
              if (controller.lastError == null && context.mounted) {
                Navigator.pop(context);
              } else {
                setDialogState(() {});
              }
            },
            child: const Text('添加并检测'),
          ),
        ],
      ),
    ),
  );
  nameController.dispose();
  urlController.dispose();
}

class _SourceRow extends StatelessWidget {
  const _SourceRow({required this.source, required this.onDelete});

  final OnlineStreamSource source;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.rss_feed_rounded, color: AppColors.amber),
      title: Text(source.name),
      subtitle: Text(source.url, maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: IconButton(
        tooltip: '移除',
        onPressed: onDelete,
        icon: const Icon(Icons.delete_outline_rounded),
      ),
    );
  }
}
