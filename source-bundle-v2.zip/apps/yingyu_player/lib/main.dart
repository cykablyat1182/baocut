import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:media_kit/media_kit.dart';
import 'package:window_manager/window_manager.dart';

import 'core/theme/app_theme.dart';
import 'data/local_pipeline_service.dart';
import 'data/settings_store.dart';
import 'features/library/media_library_screen.dart';
import 'features/online/online_movie_screen.dart';
import 'features/player/learning_player_controller.dart';
import 'features/player/player_screen.dart';

Future<void> main(List<String> arguments) async {
  WidgetsFlutterBinding.ensureInitialized();
  MediaKit.ensureInitialized();

  if (Platform.isAndroid || Platform.isIOS) {
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  }

  if (Platform.isWindows) {
    await windowManager.ensureInitialized();
    const options = WindowOptions(
      size: Size(1440, 900),
      minimumSize: Size(960, 600),
      center: true,
      backgroundColor: AppColors.canvas,
      titleBarStyle: TitleBarStyle.hidden,
      windowButtonVisibility: false,
    );
    await windowManager.waitUntilReadyToShow(options, () async {
      await windowManager.show();
      await windowManager.focus();
    });
  }

  final settings = await SettingsStore.load();
  if (!settings.localTranslationEnabled) {
    unawaited(LocalPipelineService.ensureStarted(settings.pipelineBaseUrl));
  }
  final controller = LearningPlayerController(settings: settings);
  runApp(YingyuApp(controller: controller));
  unawaited(controller.initializeLibrary());
  unawaited(controller.initializeLocalTranslation());
  unawaited(controller.initializeCloudLibrary());
  if (Platform.isWindows && arguments.isNotEmpty) {
    final initialMedia = arguments.firstWhere(
      (argument) => !argument.startsWith('--'),
      orElse: () => '',
    );
    if (initialMedia.isNotEmpty && await File(initialMedia).exists()) {
      unawaited(controller.openVideo(initialMedia));
    }
  }
}

class YingyuApp extends StatefulWidget {
  const YingyuApp({super.key, required this.controller});

  final LearningPlayerController controller;

  @override
  State<YingyuApp> createState() => _YingyuAppState();
}

class _YingyuAppState extends State<YingyuApp> {
  late bool _playerOrientationActive;

  @override
  void initState() {
    super.initState();
    _playerOrientationActive = widget.controller.hasMedia;
    widget.controller.addListener(_handleControllerChange);
    if (Platform.isAndroid || Platform.isIOS) {
      unawaited(_applyMobilePresentation(_playerOrientationActive));
    }
  }

  void _handleControllerChange() {
    final playerActive = widget.controller.hasMedia;
    if ((!Platform.isAndroid && !Platform.isIOS) ||
        playerActive == _playerOrientationActive) {
      return;
    }
    _playerOrientationActive = playerActive;
    unawaited(_applyMobilePresentation(playerActive));
  }

  Future<void> _applyMobilePresentation(bool playerActive) async {
    await SystemChrome.setPreferredOrientations(
      playerActive
          ? const [
              DeviceOrientation.landscapeLeft,
              DeviceOrientation.landscapeRight,
            ]
          : const [
              DeviceOrientation.portraitUp,
              DeviceOrientation.portraitDown,
              DeviceOrientation.landscapeLeft,
              DeviceOrientation.landscapeRight,
            ],
    );
    await SystemChrome.setEnabledSystemUIMode(
      playerActive && Platform.isAndroid
          ? SystemUiMode.immersiveSticky
          : SystemUiMode.edgeToEdge,
    );
  }

  @override
  void dispose() {
    widget.controller.removeListener(_handleControllerChange);
    widget.controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '影语 YingYu',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark(),
      home: AnimatedBuilder(
        animation: widget.controller,
        builder: (context, _) {
          if (widget.controller.hasMedia) {
            return PlayerScreen(controller: widget.controller);
          }
          return switch (widget.controller.librarySurface) {
            LibrarySurface.movies => MediaLibraryScreen(
              controller: widget.controller,
            ),
            LibrarySurface.onlineMovies => OnlineMovieScreen(
              controller: widget.controller,
            ),
          };
        },
      ),
    );
  }
}
