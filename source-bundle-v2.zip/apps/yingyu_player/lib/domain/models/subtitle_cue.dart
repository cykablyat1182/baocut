class SubtitleCue {
  const SubtitleCue({
    required this.id,
    required this.start,
    required this.end,
    required this.original,
    this.translation = '',
    this.speaker,
  });

  final String id;
  final Duration start;
  final Duration end;
  final String original;
  final String translation;
  final String? speaker;

  Duration get duration => end - start;
  bool get isBilingual => translation.trim().isNotEmpty;

  bool contains(Duration position) {
    return position >= start && position < end;
  }

  SubtitleCue copyWith({
    String? id,
    Duration? start,
    Duration? end,
    String? original,
    String? translation,
    String? speaker,
  }) {
    return SubtitleCue(
      id: id ?? this.id,
      start: start ?? this.start,
      end: end ?? this.end,
      original: original ?? this.original,
      translation: translation ?? this.translation,
      speaker: speaker ?? this.speaker,
    );
  }

  Map<String, Object?> toJson() => {
    'id': id,
    'startMs': start.inMilliseconds,
    'endMs': end.inMilliseconds,
    'original': original,
    'translation': translation,
    'speaker': speaker,
  };

  factory SubtitleCue.fromJson(Map<String, Object?> json) {
    return SubtitleCue(
      id: json['id'] as String,
      start: Duration(milliseconds: (json['startMs'] as num).toInt()),
      end: Duration(milliseconds: (json['endMs'] as num).toInt()),
      original: json['original'] as String,
      translation: json['translation'] as String? ?? '',
      speaker: json['speaker'] as String?,
    );
  }
}

enum SubtitleDisplayMode {
  bilingual,
  original,
  translation,
  off;

  String get label => switch (this) {
    bilingual => '双语',
    original => '原文',
    translation => '译文',
    off => '关闭',
  };
}
