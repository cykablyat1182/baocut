import 'package:flutter/foundation.dart';

enum ProcessingStage {
  idle,
  uploading,
  extractingAudio,
  transcribing,
  translating,
  aligning,
  completed,
  failed;

  String get label => switch (this) {
    idle => '准备中',
    uploading => '上传媒体',
    extractingAudio => '提取音轨',
    transcribing => 'SeedASR 2.0 识别',
    translating => '翻译字幕',
    aligning => '字幕对齐',
    completed => '学习字幕已生成',
    failed => '处理失败',
  };
}

class ProcessingState extends ChangeNotifier {
  ProcessingStage stage = ProcessingStage.idle;
  double progress = 0;
  String detail = '';
  String? error;
  int completedUnits = 0;
  int totalUnits = 0;
  String currentOriginal = '';
  String currentTranslation = '';
  String modelThought = '';

  bool get isRunning =>
      stage != ProcessingStage.idle &&
      stage != ProcessingStage.completed &&
      stage != ProcessingStage.failed;

  void update({
    required ProcessingStage stage,
    required double progress,
    String detail = '',
    int? completedUnits,
    int? totalUnits,
    String? currentOriginal,
    String? currentTranslation,
    String? modelThought,
  }) {
    this.stage = stage;
    this.progress = progress.clamp(0, 1);
    this.detail = detail;
    error = null;
    if (completedUnits != null) this.completedUnits = completedUnits;
    if (totalUnits != null) this.totalUnits = totalUnits;
    if (currentOriginal != null) this.currentOriginal = currentOriginal;
    if (currentTranslation != null) {
      this.currentTranslation = currentTranslation;
    }
    if (modelThought != null) this.modelThought = modelThought;
    notifyListeners();
  }

  void fail(String message) {
    stage = ProcessingStage.failed;
    error = message;
    detail = message;
    notifyListeners();
  }

  void reset() {
    stage = ProcessingStage.idle;
    progress = 0;
    detail = '';
    error = null;
    completedUnits = 0;
    totalUnits = 0;
    currentOriginal = '';
    currentTranslation = '';
    modelThought = '';
    notifyListeners();
  }
}
