import 'media_playlist_item.dart';

class OnlineMovieWarehouse {
  const OnlineMovieWarehouse({
    required this.name,
    required this.url,
    this.fallbackUrls = const [],
    this.siteKey,
  });

  final String name;
  final String url;
  final List<String> fallbackUrls;

  /// Optional key used when a TVBox aggregate contains several independent
  /// 4K sites. Keeping the key on the warehouse lets the UI expose each site
  /// as its own route instead of presenting one opaque aggregate entry.
  final String? siteKey;

  List<String> get addresses => [url, ...fallbackUrls];
}

class OnlineMovieProvider {
  const OnlineMovieProvider({
    required this.key,
    required this.name,
    required this.api,
    required this.warehouseName,
    this.adapter = 'cms',
    this.fallbackApis = const [],
    this.playUrl = '',
  });

  final String key;
  final String name;
  final String api;
  final String warehouseName;
  final String adapter;
  final List<String> fallbackApis;

  /// Optional TVBox `playUrl` resolver prefix (for example `...?url=`).
  /// Native CMS routes without a resolver keep this empty and play directly.
  final String playUrl;

  List<String> get addresses => [api, ...fallbackApis];
}

class OnlineMovieCategory {
  const OnlineMovieCategory({required this.id, required this.name});

  final String id;
  final String name;
}

class OnlineMovieSummary {
  const OnlineMovieSummary({
    required this.id,
    required this.name,
    required this.provider,
    this.coverUrl,
    this.remarks,
    this.typeName,
    this.year,
  });

  final String id;
  final String name;
  final OnlineMovieProvider provider;
  final String? coverUrl;
  final String? remarks;
  final String? typeName;
  final String? year;
}

class OnlineMovieEpisode {
  const OnlineMovieEpisode({
    required this.name,
    required this.url,
    required this.route,
    this.httpHeaders = const {},
  });

  final String name;
  final String url;
  final String route;
  final Map<String, String> httpHeaders;

  bool get isCloudShare => switch (Uri.tryParse(url)?.host.toLowerCase()) {
    'pan.quark.cn' ||
    'drive.quark.cn' ||
    'drive-pc.quark.cn' ||
    'drive-h.quark.cn' ||
    'www.alipan.com' ||
    'www.aliyundrive.com' ||
    'www.115.com' ||
    '115.com' ||
    'www.123pan.com' ||
    'www.123684.com' ||
    'drive.uc.cn' ||
    'uc.cn' => true,
    _ => false,
  };

  String get cloudProvider => switch (Uri.tryParse(url)?.host.toLowerCase()) {
    'pan.quark.cn' ||
    'drive.quark.cn' ||
    'drive-pc.quark.cn' ||
    'drive-h.quark.cn' => '夸克',
    'www.alipan.com' || 'www.aliyundrive.com' => '阿里云盘',
    'www.115.com' || '115.com' => '115',
    'www.123pan.com' || 'www.123684.com' => '123 网盘',
    'drive.uc.cn' || 'uc.cn' => 'UC 网盘',
    _ => '网盘',
  };

  MediaPlaylistItem toPlaylistItem({
    required OnlineMovieDetail movie,
    required OnlineMovieProvider provider,
  }) {
    return MediaPlaylistItem(
      path: url,
      title: movie.episodes.length > 1 ? '${movie.name} · $name' : movie.name,
      remoteLogoUrl: movie.coverUrl,
      group: movie.name,
      sourceName: '${provider.warehouseName} · ${provider.name} · $route',
      httpHeaders: httpHeaders,
      isOnline: true,
    );
  }
}

class OnlineMovieDetail {
  const OnlineMovieDetail({
    required this.id,
    required this.name,
    required this.episodes,
    this.coverUrl,
    this.remarks,
    this.typeName,
    this.year,
    this.blurb,
  });

  final String id;
  final String name;
  final List<OnlineMovieEpisode> episodes;
  final String? coverUrl;
  final String? remarks;
  final String? typeName;
  final String? year;
  final String? blurb;
}

class OnlineMovieDiscovery {
  const OnlineMovieDiscovery({
    required this.providers,
    required this.configCount,
    required this.unsupportedSiteCount,
    required this.failedConfigCount,
  });

  final List<OnlineMovieProvider> providers;
  final int configCount;
  final int unsupportedSiteCount;
  final int failedConfigCount;
}

class OnlineMoviePage {
  const OnlineMoviePage({
    required this.items,
    required this.categories,
    required this.page,
    required this.pageCount,
  });

  final List<OnlineMovieSummary> items;
  final List<OnlineMovieCategory> categories;
  final int page;
  final int pageCount;
}

class OnlineMovieGlobalSearch {
  const OnlineMovieGlobalSearch({
    required this.items,
    required this.providerCount,
    required this.failedProviderCount,
  });

  final List<OnlineMovieSummary> items;
  final int providerCount;
  final int failedProviderCount;
}
