class MediaPlaylistItem {
  const MediaPlaylistItem({
    required this.path,
    required this.title,
    this.coverPath,
    this.remoteLogoUrl,
    this.group,
    this.sourceName,
    this.epgUrl,
    this.httpHeaders = const {},
    this.isOnline = false,
    this.isLive = false,
    this.cloudSourceId,
    this.remotePath,
    this.remoteSubtitlePaths = const [],
    this.remoteSubtitleUrls = const [],
  });

  final String path;
  final String title;
  final String? coverPath;
  final String? remoteLogoUrl;
  final String? group;
  final String? sourceName;
  final String? epgUrl;
  final Map<String, String> httpHeaders;
  final bool isOnline;
  final bool isLive;
  final String? cloudSourceId;
  final String? remotePath;
  final List<String> remoteSubtitlePaths;
  final List<String> remoteSubtitleUrls;

  /// A small, platform-neutral snapshot used for local history and favorites.
  /// Keeping the complete playback metadata means Android can reopen an online
  /// or cloud item after a restart instead of only showing a dead URL.
  Map<String, Object?> toJson() => {
    'path': path,
    'title': title,
    if (coverPath != null) 'coverPath': coverPath,
    if (remoteLogoUrl != null) 'remoteLogoUrl': remoteLogoUrl,
    if (group != null) 'group': group,
    if (sourceName != null) 'sourceName': sourceName,
    if (epgUrl != null) 'epgUrl': epgUrl,
    'httpHeaders': httpHeaders,
    'isOnline': isOnline,
    'isLive': isLive,
    if (cloudSourceId != null) 'cloudSourceId': cloudSourceId,
    if (remotePath != null) 'remotePath': remotePath,
    'remoteSubtitlePaths': remoteSubtitlePaths,
    'remoteSubtitleUrls': remoteSubtitleUrls,
  };

  static MediaPlaylistItem? fromJson(Object? value) {
    if (value is! Map) return null;
    final path = value['path'];
    final title = value['title'];
    if (path is! String || path.trim().isEmpty || title is! String) {
      return null;
    }
    final rawHeaders = value['httpHeaders'];
    final headers = <String, String>{};
    if (rawHeaders is Map) {
      for (final entry in rawHeaders.entries) {
        if (entry.key is String && entry.value is String) {
          headers[entry.key as String] = entry.value as String;
        }
      }
    }
    List<String> strings(Object? input) => input is List
        ? [
            for (final item in input)
              if (item is String) item,
          ]
        : const [];
    return MediaPlaylistItem(
      path: path,
      title: title,
      coverPath: value['coverPath'] is String
          ? value['coverPath'] as String
          : null,
      remoteLogoUrl: value['remoteLogoUrl'] is String
          ? value['remoteLogoUrl'] as String
          : null,
      group: value['group'] is String ? value['group'] as String : null,
      sourceName: value['sourceName'] is String
          ? value['sourceName'] as String
          : null,
      epgUrl: value['epgUrl'] is String ? value['epgUrl'] as String : null,
      httpHeaders: headers,
      isOnline: value['isOnline'] == true,
      isLive: value['isLive'] == true,
      cloudSourceId: value['cloudSourceId'] is String
          ? value['cloudSourceId'] as String
          : null,
      remotePath: value['remotePath'] is String
          ? value['remotePath'] as String
          : null,
      remoteSubtitlePaths: strings(value['remoteSubtitlePaths']),
      remoteSubtitleUrls: strings(value['remoteSubtitleUrls']),
    );
  }

  MediaPlaylistItem copyWith({
    String? coverPath,
    String? remoteLogoUrl,
    String? epgUrl,
    Map<String, String>? httpHeaders,
  }) {
    return MediaPlaylistItem(
      path: path,
      title: title,
      coverPath: coverPath ?? this.coverPath,
      remoteLogoUrl: remoteLogoUrl ?? this.remoteLogoUrl,
      group: group,
      sourceName: sourceName,
      epgUrl: epgUrl ?? this.epgUrl,
      httpHeaders: httpHeaders ?? this.httpHeaders,
      isOnline: isOnline,
      isLive: isLive,
      cloudSourceId: cloudSourceId,
      remotePath: remotePath,
      remoteSubtitlePaths: remoteSubtitlePaths,
      remoteSubtitleUrls: remoteSubtitleUrls,
    );
  }
}
