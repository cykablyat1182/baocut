class CloudMediaSource {
  const CloudMediaSource({
    required this.id,
    required this.name,
    required this.baseUrl,
    required this.apiToken,
    this.rootPath = '/',
    this.provider = 'openlist',
    this.transferCredential = '',
    this.transferFolderId = '0',
  });

  final String id;
  final String name;
  final String baseUrl;
  final String apiToken;
  final String rootPath;
  final String provider;
  final String transferCredential;
  final String transferFolderId;

  bool get isDirectQuark => provider == 'quark_direct';
  bool get isManagedOpenList => provider == 'managed_openlist';

  bool get canImportQuarkShares =>
      (provider == 'quark' || isDirectQuark) &&
      transferCredential.trim().isNotEmpty;

  String get providerLabel => switch (provider) {
    'quark' => '夸克网盘（OpenList）',
    'quark_direct' => '夸克网盘（扫码直连）',
    'managed_openlist' => '云端网盘',
    'aliyun' => '阿里云盘（OpenList）',
    'baidu' => '百度网盘（OpenList）',
    '115' => '115 网盘（OpenList）',
    'webdav' => 'WebDAV / OpenList',
    _ => 'OpenList 聚合网盘',
  };

  CloudMediaSource copyWith({
    String? transferCredential,
    String? transferFolderId,
  }) => CloudMediaSource(
    id: id,
    name: name,
    baseUrl: baseUrl,
    apiToken: apiToken,
    rootPath: rootPath,
    provider: provider,
    transferCredential: transferCredential ?? this.transferCredential,
    transferFolderId: transferFolderId ?? this.transferFolderId,
  );

  Map<String, Object> toJson() => {
    'id': id,
    'name': name,
    'base_url': baseUrl,
    'api_token': apiToken,
    'root_path': rootPath,
    'provider': provider,
    'transfer_credential': transferCredential,
    'transfer_folder_id': transferFolderId,
  };

  static CloudMediaSource? fromJson(Object? value) {
    if (value is! Map) return null;
    final id = value['id']?.toString().trim() ?? '';
    final name = value['name']?.toString().trim() ?? '';
    final baseUrl = value['base_url']?.toString().trim() ?? '';
    final apiToken = value['api_token']?.toString().trim() ?? '';
    final rootPath = value['root_path']?.toString().trim() ?? '/';
    if (id.isEmpty || name.isEmpty || baseUrl.isEmpty || apiToken.isEmpty) {
      return null;
    }
    return CloudMediaSource(
      id: id,
      name: name,
      baseUrl: baseUrl,
      apiToken: apiToken,
      rootPath: rootPath.isEmpty ? '/' : rootPath,
      provider: value['provider']?.toString().trim() ?? 'openlist',
      transferCredential: value['transfer_credential']?.toString().trim() ?? '',
      transferFolderId: value['transfer_folder_id']?.toString().trim() ?? '0',
    );
  }
}
