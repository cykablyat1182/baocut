class OnlineStreamSource {
  const OnlineStreamSource({required this.name, required this.url});

  final String name;
  final String url;

  Map<String, String> toJson() => {'name': name, 'url': url};

  static OnlineStreamSource? fromJson(Object? value) {
    if (value is! Map) return null;
    final name = value['name']?.toString().trim() ?? '';
    final url = value['url']?.toString().trim() ?? '';
    if (name.isEmpty || url.isEmpty) return null;
    return OnlineStreamSource(name: name, url: url);
  }
}
