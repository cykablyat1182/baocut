class DictionaryEntry {
  const DictionaryEntry({
    required this.word,
    required this.phonetic,
    required this.partOfSpeech,
    required this.definition,
    required this.example,
    this.exampleTranslation = '',
  });

  final String word;
  final String phonetic;
  final String partOfSpeech;
  final String definition;
  final String example;
  final String exampleTranslation;

  Map<String, Object?> toJson() => {
    'word': word,
    'phonetic': phonetic,
    'partOfSpeech': partOfSpeech,
    'definition': definition,
    'example': example,
    'exampleTranslation': exampleTranslation,
  };

  factory DictionaryEntry.fromJson(Map<String, Object?> json) {
    return DictionaryEntry(
      word: json['word'] as String? ?? '',
      phonetic: json['phonetic'] as String? ?? '',
      partOfSpeech: json['partOfSpeech'] as String? ?? '',
      definition: json['definition'] as String? ?? '',
      example: json['example'] as String? ?? '',
      exampleTranslation: json['exampleTranslation'] as String? ?? '',
    );
  }
}
