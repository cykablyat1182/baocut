class UsageCharge {
  const UsageCharge({
    required this.chargedCredits,
    required this.balanceCredits,
    required this.inputTokens,
    required this.outputTokens,
  });

  factory UsageCharge.fromJson(Map<String, Object?> json) => UsageCharge(
    chargedCredits: (json['chargedCredits'] as num?)?.toInt() ?? 0,
    balanceCredits: (json['balanceCredits'] as num?)?.toInt() ?? 0,
    inputTokens: (json['inputTokens'] as num?)?.toInt() ?? 0,
    outputTokens: (json['outputTokens'] as num?)?.toInt() ?? 0,
  );

  final int chargedCredits;
  final int balanceCredits;
  final int inputTokens;
  final int outputTokens;
}

class AccountProfile {
  const AccountProfile({
    required this.username,
    required this.email,
    required this.emailVerified,
    required this.displayName,
    required this.role,
    required this.isGuest,
    required this.disabled,
  });

  factory AccountProfile.fromJson(Map<String, Object?> json) => AccountProfile(
    username: json['username'] as String?,
    email: json['email'] as String?,
    emailVerified: json['emailVerified'] as bool? ?? false,
    displayName: json['displayName'] as String? ?? '访客账户',
    role: json['role'] as String? ?? 'user',
    isGuest: json['isGuest'] as bool? ?? true,
    disabled: json['disabled'] as bool? ?? false,
  );

  final String? username;
  final String? email;
  final bool emailVerified;
  final String displayName;
  final String role;
  final bool isGuest;
  final bool disabled;

  bool get isAdmin => role == 'admin';
}

class BillingPricing {
  const BillingPricing({
    required this.inputCreditsPerThousandTokens,
    required this.outputCreditsPerThousandTokens,
    required this.minimumChargeCredits,
    required this.minimumBalanceToStart,
  });

  factory BillingPricing.fromJson(Map<String, Object?> json) => BillingPricing(
    inputCreditsPerThousandTokens:
        (json['inputCreditsPerThousandTokens'] as num?)?.toDouble() ?? 0,
    outputCreditsPerThousandTokens:
        (json['outputCreditsPerThousandTokens'] as num?)?.toDouble() ?? 0,
    minimumChargeCredits: (json['minimumChargeCredits'] as num?)?.toInt() ?? 0,
    minimumBalanceToStart:
        (json['minimumBalanceToStart'] as num?)?.toInt() ?? 0,
  );

  final double inputCreditsPerThousandTokens;
  final double outputCreditsPerThousandTokens;
  final int minimumChargeCredits;
  final int minimumBalanceToStart;
}

class BillingTransaction {
  const BillingTransaction({
    required this.kind,
    required this.deltaCredits,
    required this.balanceAfter,
    required this.description,
    required this.createdAt,
  });

  factory BillingTransaction.fromJson(Map<String, Object?> json) =>
      BillingTransaction(
        kind: json['kind'] as String? ?? '',
        deltaCredits: (json['deltaCredits'] as num?)?.toInt() ?? 0,
        balanceAfter: (json['balanceAfter'] as num?)?.toInt() ?? 0,
        description: json['description'] as String? ?? '',
        createdAt:
            DateTime.tryParse(json['createdAt'] as String? ?? '') ??
            DateTime.fromMillisecondsSinceEpoch(0),
      );

  final String kind;
  final int deltaCredits;
  final int balanceAfter;
  final String description;
  final DateTime createdAt;
}

class BillingAccount {
  const BillingAccount({
    required this.accountId,
    required this.profile,
    required this.balanceCredits,
    required this.pricing,
    required this.transactions,
  });

  factory BillingAccount.fromJson(Map<String, Object?> json) {
    final rawPricing = json['pricing'];
    final rawProfile = json['profile'];
    return BillingAccount(
      accountId: json['accountId'] as String? ?? '',
      profile: AccountProfile.fromJson(
        rawProfile is Map
            ? rawProfile.map(
                (key, value) => MapEntry(key.toString(), value as Object?),
              )
            : const {},
      ),
      balanceCredits: (json['balanceCredits'] as num?)?.toInt() ?? 0,
      pricing: BillingPricing.fromJson(
        rawPricing is Map
            ? rawPricing.map(
                (key, value) => MapEntry(key.toString(), value as Object?),
              )
            : const {},
      ),
      transactions: [
        for (final item in json['transactions'] as List? ?? const [])
          if (item is Map)
            BillingTransaction.fromJson(
              item.map(
                (key, value) => MapEntry(key.toString(), value as Object?),
              ),
            ),
      ],
    );
  }

  final String accountId;
  final AccountProfile profile;
  final int balanceCredits;
  final BillingPricing pricing;
  final List<BillingTransaction> transactions;
}

class BillingPackage {
  const BillingPackage({
    required this.id,
    required this.name,
    required this.description,
    required this.credits,
    required this.formattedAmount,
  });

  factory BillingPackage.fromJson(Map<String, Object?> json) => BillingPackage(
    id: json['id'] as String? ?? '',
    name: json['name'] as String? ?? '',
    description: json['description'] as String? ?? '',
    credits: (json['credits'] as num?)?.toInt() ?? 0,
    formattedAmount: json['formattedAmount'] as String? ?? '',
  );

  final String id;
  final String name;
  final String description;
  final int credits;
  final String formattedAmount;
}

class BillingOverview {
  const BillingOverview({
    required this.account,
    required this.packages,
    required this.checkoutAvailable,
  });

  final BillingAccount account;
  final List<BillingPackage> packages;
  final bool checkoutAvailable;
}
