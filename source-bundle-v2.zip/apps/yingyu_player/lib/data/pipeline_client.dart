import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;
import 'package:uuid/uuid.dart';

import '../domain/models/billing.dart';
import '../domain/models/dictionary_entry.dart';
import '../domain/models/processing_state.dart';
import '../domain/models/subtitle_cue.dart';
import 'device_auth_store.dart';
import 'openlist_media_service.dart';

class PipelineException implements Exception {
  PipelineException(this.message);

  final String message;

  @override
  String toString() => message;
}

class PipelineClient {
  PipelineClient({
    required String baseUrl,
    http.Client? client,
    DeviceAuthStore? authStore,
  }) : _baseUri = Uri.parse(baseUrl.replaceAll(RegExp(r'/$'), '')),
       _client = client ?? http.Client(),
       _authStore = authStore ?? DeviceAuthStore();

  static const _chunkSize = 4 * 1024 * 1024;
  static const _uuid = Uuid();

  final Uri _baseUri;
  final http.Client _client;
  final DeviceAuthStore _authStore;
  Future<String>? _authenticationInFlight;

  UsageCharge? lastUsageCharge;

  Uri _uri(String path) => _baseUri.replace(
    path:
        '${_baseUri.path.endsWith('/') ? _baseUri.path.substring(0, _baseUri.path.length - 1) : _baseUri.path}$path',
  );

  Future<List<SubtitleCue>> processVideo({
    required File file,
    required String sourceLanguage,
    required String targetLanguage,
    required ProcessingState state,
  }) async {
    final length = await file.length();
    final upload = await _postJson('/api/uploads', {
      'fileName': file.uri.pathSegments.last,
      'size': length,
      'lastModifiedMs': (await file.lastModified()).millisecondsSinceEpoch,
    });
    final uploadId = upload['uploadId'] as String?;
    if (uploadId == null || uploadId.isEmpty) {
      throw PipelineException('服务器没有返回有效的上传任务。');
    }

    final receivedParts = {
      for (final item in (upload['receivedParts'] as List? ?? const []))
        (item as num).toInt(),
    };
    await _uploadChunks(
      file: file,
      uploadId: uploadId,
      length: length,
      receivedParts: receivedParts,
      state: state,
    );

    state.update(
      stage: ProcessingStage.extractingAudio,
      progress: 0.04,
      detail: '正在提取适合语音识别的单声道音轨',
    );
    final completed = await _postJson('/api/uploads/$uploadId/complete', {
      'sourceLanguage': sourceLanguage,
      'targetLanguage': targetLanguage,
    });
    final jobId = completed['jobId'] as String?;
    if (jobId == null || jobId.isEmpty) {
      throw PipelineException('服务器没有返回有效的处理任务。');
    }
    return _pollJob(jobId: jobId, state: state);
  }

  Future<List<SubtitleCue>> translate({
    required List<SubtitleCue> cues,
    required String sourceLanguage,
    required String targetLanguage,
  }) async {
    // Kept as a JSON compatibility call for older self-hosted services. New
    // player flows use [translateStream] so desktop, Android and Apple
    // clients all receive partial batches while the model is working.
    final response = await _postJson('/api/translate', {
      'sourceLanguage': sourceLanguage,
      'targetLanguage': targetLanguage,
      'cues': cues.map((cue) => cue.toJson()).toList(),
    });
    _captureUsageCharge(response);
    final rawCues = response['cues'] as List? ?? const [];
    return rawCues
        .whereType<Map>()
        .map(
          (item) => SubtitleCue.fromJson(
            item.map((key, value) => MapEntry(key.toString(), value)),
          ),
        )
        .toList();
  }

  /// Translates subtitles over SSE so the player can show each completed
  /// batch immediately. The final event still contains the complete, ordered
  /// track and its usage charge. A JSON endpoint fallback keeps older servers
  /// compatible while they are being upgraded.
  Future<List<SubtitleCue>> translateStream({
    required List<SubtitleCue> cues,
    required String sourceLanguage,
    required String targetLanguage,
    void Function(List<SubtitleCue> cues, int completed, int total)? onPartial,
    void Function(String message)? onStatus,
  }) async {
    final body = {
      'sourceLanguage': sourceLanguage,
      'targetLanguage': targetLanguage,
      'cues': cues.map((cue) => cue.toJson()).toList(),
    };
    final idempotencyKey = _uuid.v4();
    for (var attempt = 0; attempt < 2; attempt++) {
      final token = await _ensureAccessToken();
      final request = http.Request('POST', _uri('/api/translate/stream'))
        ..headers.addAll({
          'authorization': 'Bearer $token',
          'content-type': 'application/json',
          'accept': 'text/event-stream',
          'x-idempotency-key': idempotencyKey,
        })
        ..body = jsonEncode(body);
      late http.StreamedResponse response;
      try {
        response = await _client
            .send(request)
            .timeout(const Duration(minutes: 2));
      } on TimeoutException {
        throw PipelineException('字幕翻译流连接超时，请稍后重试。');
      } on SocketException {
        throw PipelineException(
          '无法连接字幕服务：${_serviceEndpointLabel()}。请检查服务地址或网络。',
        );
      } on http.ClientException {
        throw PipelineException(
          '无法连接字幕服务：${_serviceEndpointLabel()}。请检查服务地址或网络。',
        );
      }

      if (response.statusCode == 401 && attempt == 0) {
        if (await _authStore.isUserSession(_baseUri)) {
          final failed = http.Response.bytes(
            await response.stream.toBytes(),
            response.statusCode,
            headers: response.headers,
          );
          throw PipelineException(_messageFrom(failed));
        }
        await response.stream.drain<void>();
        await _authStore.clearAccessToken(_baseUri);
        continue;
      }

      if (response.statusCode == 404) {
        await response.stream.drain<void>();
        final fallback = await _postJson('/api/translate', body);
        _captureUsageCharge(fallback);
        final decoded = _decodeSubtitleCues(fallback['cues']);
        if (decoded.isNotEmpty) {
          onStatus?.call('翻译完成，正在校验时间码…');
          onPartial?.call(decoded, decoded.length, cues.length);
        }
        return decoded;
      }

      if (response.statusCode < 200 || response.statusCode >= 300) {
        final failed = http.Response.bytes(
          await response.stream.toBytes(),
          response.statusCode,
          headers: response.headers,
        );
        throw PipelineException(_messageFrom(failed));
      }

      List<SubtitleCue>? complete;
      Object? streamError;
      var eventName = 'message';
      final data = <String>[];
      void dispatchEvent() {
        if (data.isEmpty) {
          eventName = 'message';
          return;
        }
        final raw = data.join('\n');
        data.clear();
        final currentEvent = eventName;
        eventName = 'message';
        final decoded = jsonDecode(raw);
        if (decoded is! Map) return;
        final value = decoded.map(
          (key, value) => MapEntry(key.toString(), value as Object?),
        );
        switch (currentEvent) {
          case 'status':
            final message = value['message'];
            if (message is String) onStatus?.call(message);
          case 'partial':
            final batch = _decodeSubtitleCues(value['cues']);
            if (batch.isEmpty) return;
            onPartial?.call(
              batch,
              (value['completed'] as num?)?.toInt() ?? batch.length,
              (value['total'] as num?)?.toInt() ?? cues.length,
            );
          case 'complete':
            complete = _decodeSubtitleCues(value['cues']);
            final billing = value['billing'];
            if (billing is Map) {
              _captureUsageCharge({'billing': billing});
            }
          case 'error':
            streamError = value['error']?.toString() ?? '字幕翻译失败。';
          default:
            break;
        }
      }

      try {
        await for (final line
            in response.stream
                .transform(utf8.decoder)
                .transform(const LineSplitter())
                .timeout(const Duration(minutes: 2))) {
          if (line.isEmpty) {
            dispatchEvent();
          } else if (line.startsWith(':')) {
            continue;
          } else if (line.startsWith('event:')) {
            eventName = line.substring(6).trim();
          } else if (line.startsWith('data:')) {
            data.add(line.substring(5).trimLeft());
          }
          if (streamError != null) {
            throw PipelineException(streamError.toString());
          }
        }
        dispatchEvent();
      } on TimeoutException {
        throw PipelineException('字幕翻译流式响应超时，请重试。');
      } on FormatException {
        throw PipelineException('字幕翻译服务返回了无法识别的数据。');
      }
      if (streamError != null) {
        throw PipelineException(streamError.toString());
      }
      if (complete == null) {
        throw PipelineException('字幕翻译服务没有完成本次请求。');
      }
      return complete!;
    }
    throw PipelineException('设备账户认证失败。');
  }

  List<SubtitleCue> _decodeSubtitleCues(Object? raw) {
    if (raw is! List) return const [];
    return raw
        .whereType<Map>()
        .map(
          (item) => SubtitleCue.fromJson(
            item.map((key, value) => MapEntry(key.toString(), value)),
          ),
        )
        .toList();
  }

  Future<List<Map<String, Object?>>> managedMediaList(
    String path, {
    bool refresh = false,
  }) async {
    final response = await _postJson('/api/media/library/list', {
      'path': path,
      'refresh': refresh,
    });
    final entries = response['entries'];
    if (entries is! List) return const [];
    return [
      for (final entry in entries)
        if (entry is Map)
          entry.map((key, value) => MapEntry(key.toString(), value as Object?)),
    ];
  }

  Future<OpenListResolvedFile> managedMediaLink(
    String path, {
    String linkType = 'streaming',
  }) async {
    final response = await _postJson('/api/media/library/link', {
      'path': path,
      'type': linkType,
    });
    final url = response['url']?.toString().trim() ?? '';
    final uri = Uri.tryParse(url);
    if (uri == null ||
        !uri.hasAuthority ||
        (uri.scheme != 'http' && uri.scheme != 'https')) {
      throw PipelineException('媒体代理没有返回有效播放地址。');
    }
    final headers = <String, String>{};
    final rawHeaders = response['headers'];
    if (rawHeaders is Map) {
      for (final entry in rawHeaders.entries) {
        headers[entry.key.toString()] = entry.value.toString();
      }
    }
    return OpenListResolvedFile(url: uri.toString(), headers: headers);
  }

  Future<DictionaryEntry?> lookup({
    required String word,
    required String sentence,
  }) => lookupStream(word: word, sentence: sentence);

  Future<DictionaryEntry?> lookupStream({
    required String word,
    required String sentence,
    void Function(Map<String, String> fields)? onPartial,
    void Function(String message)? onStatus,
  }) async {
    final body = jsonEncode({
      'word': word,
      'sentence': sentence,
      'targetLanguage': 'zh-CN',
    });
    final idempotencyKey = _uuid.v4();
    for (var attempt = 0; attempt < 2; attempt++) {
      final token = await _ensureAccessToken();
      final request = http.Request('POST', _uri('/api/dictionary/stream'))
        ..headers.addAll({
          'authorization': 'Bearer $token',
          'content-type': 'application/json',
          'accept': 'text/event-stream',
          'x-idempotency-key': idempotencyKey,
        })
        ..body = body;
      late http.StreamedResponse response;
      try {
        response = await _client
            .send(request)
            .timeout(const Duration(minutes: 2));
      } on TimeoutException {
        throw PipelineException('词典服务连接超时，请稍后重试。');
      } on SocketException {
        throw PipelineException(
          '无法连接字幕服务：${_serviceEndpointLabel()}。请检查服务地址或网络。',
        );
      } on http.ClientException {
        throw PipelineException(
          '无法连接字幕服务：${_serviceEndpointLabel()}。请检查服务地址或网络。',
        );
      }

      if (response.statusCode == 401 && attempt == 0) {
        if (await _authStore.isUserSession(_baseUri)) {
          final failed = http.Response.bytes(
            await response.stream.toBytes(),
            response.statusCode,
            headers: response.headers,
          );
          throw PipelineException(_messageFrom(failed));
        }
        await response.stream.drain<void>();
        await _authStore.clearAccessToken(_baseUri);
        continue;
      }

      if (response.statusCode == 404) {
        await response.stream.drain<void>();
        final fallback = await _postJson('/api/dictionary', {
          'word': word,
          'sentence': sentence,
          'targetLanguage': 'zh-CN',
        });
        _captureUsageCharge(fallback);
        final entry = fallback['entry'];
        if (entry is! Map) return null;
        final decoded = DictionaryEntry.fromJson(
          entry.map((key, value) => MapEntry(key.toString(), value)),
        );
        onPartial?.call(
          decoded.toJson().map(
            (key, value) => MapEntry(key, value?.toString() ?? ''),
          ),
        );
        return decoded;
      }

      if (response.statusCode < 200 || response.statusCode >= 300) {
        final failed = http.Response.bytes(
          await response.stream.toBytes(),
          response.statusCode,
          headers: response.headers,
        );
        throw PipelineException(_messageFrom(failed));
      }

      DictionaryEntry? entry;
      Object? streamError;
      var eventName = 'message';
      final data = <String>[];
      void dispatchEvent() {
        if (data.isEmpty) {
          eventName = 'message';
          return;
        }
        final raw = data.join('\n');
        data.clear();
        final currentEvent = eventName;
        eventName = 'message';
        final decoded = jsonDecode(raw);
        if (decoded is! Map) return;
        final value = decoded.map(
          (key, value) => MapEntry(key.toString(), value as Object?),
        );
        switch (currentEvent) {
          case 'status':
            final message = value['message'];
            if (message is String) onStatus?.call(message);
          case 'partial':
            final fields = <String, String>{};
            for (final field
                in (value['fields'] is Map
                    ? (value['fields'] as Map).entries
                    : value.entries)) {
              if (field.key is String && field.value is String) {
                fields[field.key as String] = field.value as String;
              }
            }
            if (fields.isNotEmpty) onPartial?.call(fields);
          case 'complete':
            final rawEntry = value['entry'];
            if (rawEntry is! Map) {
              throw PipelineException('词典服务没有返回有效释义。');
            }
            final billing = value['billing'];
            if (billing is Map) {
              _captureUsageCharge({'billing': billing});
            }
            entry = DictionaryEntry.fromJson(
              rawEntry.map((key, value) => MapEntry(key.toString(), value)),
            );
          case 'error':
            streamError = value['error']?.toString() ?? '词典查询失败。';
          default:
            break;
        }
      }

      try {
        await for (final line
            in response.stream
                .transform(utf8.decoder)
                .transform(const LineSplitter())
                .timeout(const Duration(minutes: 2))) {
          if (line.isEmpty) {
            dispatchEvent();
          } else if (line.startsWith(':')) {
            continue;
          } else if (line.startsWith('event:')) {
            eventName = line.substring(6).trim();
          } else if (line.startsWith('data:')) {
            data.add(line.substring(5).trimLeft());
          }
          if (streamError != null) {
            throw PipelineException(streamError.toString());
          }
        }
        dispatchEvent();
      } on TimeoutException {
        throw PipelineException('词典流式响应超时，请重试。');
      } on FormatException {
        throw PipelineException('词典服务返回了无法识别的数据。');
      }
      if (streamError != null) {
        throw PipelineException(streamError.toString());
      }
      if (entry == null) throw PipelineException('词典服务没有完成本次查询。');
      return entry;
    }
    throw PipelineException('设备账户认证失败。');
  }

  Future<BillingAccount> registerAccount({
    required String username,
    required String email,
    required String verificationCode,
    required String password,
    String? displayName,
  }) async {
    final response = await _postPublicJson('/api/auth/register', {
      'username': username,
      'email': email,
      'verificationCode': verificationCode,
      'password': password,
      if (displayName != null && displayName.trim().isNotEmpty)
        'displayName': displayName.trim(),
    });
    return _adoptAccountSession(response);
  }

  Future<int> requestEmailVerification(String email) async {
    final response = await _postPublicJson('/api/auth/email/request-code', {
      'email': email.trim(),
    });
    return (response['expiresInSeconds'] as num?)?.toInt() ?? 600;
  }

  Future<BillingAccount> loginAccount({
    required String username,
    required String password,
  }) async {
    final response = await _postPublicJson('/api/auth/login', {
      'username': username,
      'password': password,
    });
    return _adoptAccountSession(response);
  }

  Future<BillingAccount> currentAccount() async {
    final response = await _getJson('/api/auth/me');
    return _parseAccount(response['account']);
  }

  Future<void> logoutAccount() async {
    final token = await _authStore.accessToken(_baseUri);
    try {
      if (token == null || token.isEmpty) return;
      final response = await _request(
        () => _client.post(
          _uri('/api/auth/logout'),
          headers: {
            'authorization': 'Bearer $token',
            'accept': 'application/json',
          },
        ),
        timeout: const Duration(seconds: 30),
      );
      if (response.statusCode != 204 && response.statusCode != 401) {
        _decodeResponse(response);
      }
    } finally {
      await _authStore.clearAccessToken(_baseUri);
    }
  }

  Future<BillingOverview> billingOverview() async {
    final responses = await Future.wait([
      _getJson('/api/billing/account'),
      _getJson('/api/billing/packages'),
    ]);
    final rawAccount = responses[0]['account'];
    if (rawAccount is! Map) {
      throw PipelineException('服务端没有返回有效的额度账户。');
    }
    final account = BillingAccount.fromJson(
      rawAccount.map(
        (key, value) => MapEntry(key.toString(), value as Object?),
      ),
    );
    final rawPackages = responses[1]['packages'] as List? ?? const [];
    final packages = [
      for (final item in rawPackages)
        if (item is Map)
          BillingPackage.fromJson(
            item.map(
              (key, value) => MapEntry(key.toString(), value as Object?),
            ),
          ),
    ];
    return BillingOverview(
      account: account,
      packages: packages,
      checkoutAvailable: responses[1]['checkoutAvailable'] == true,
    );
  }

  Future<Uri> createCheckout(String packageId) async {
    final response = await _postJson('/api/billing/checkout', {
      'packageId': packageId,
    });
    final rawUrl = response['checkoutUrl'] as String? ?? '';
    final url = Uri.tryParse(rawUrl);
    if (url == null || url.scheme != 'https') {
      throw PipelineException('服务端没有返回安全的支付地址。');
    }
    return url;
  }

  Future<void> _uploadChunks({
    required File file,
    required String uploadId,
    required int length,
    required Set<int> receivedParts,
    required ProcessingState state,
  }) async {
    final randomAccess = await file.open();
    try {
      final partCount = (length / _chunkSize).ceil();
      for (var partIndex = 0; partIndex < partCount; partIndex++) {
        final start = partIndex * _chunkSize;
        final end = (start + _chunkSize).clamp(0, length);
        if (receivedParts.contains(partIndex)) {
          state.update(
            stage: ProcessingStage.uploading,
            progress: end / length,
            detail: '恢复上传 ${_formatBytes(end)} / ${_formatBytes(length)}',
          );
          continue;
        }

        await randomAccess.setPosition(start);
        final bytes = await randomAccess.read(end - start);
        await _putChunk(
          uploadId: uploadId,
          partIndex: partIndex,
          bytes: bytes,
          start: start,
          end: end,
          total: length,
        );
        state.update(
          stage: ProcessingStage.uploading,
          progress: end / length,
          detail: '已上传 ${_formatBytes(end)} / ${_formatBytes(length)}',
        );
      }
    } finally {
      await randomAccess.close();
    }
  }

  Future<void> _putChunk({
    required String uploadId,
    required int partIndex,
    required Uint8List bytes,
    required int start,
    required int end,
    required int total,
  }) async {
    Object? lastError;
    for (var attempt = 1; attempt <= 3; attempt++) {
      try {
        final token = await _ensureAccessToken();
        final response = await _request(
          () => _client.put(
            _uri('/api/uploads/$uploadId/parts/$partIndex'),
            headers: {
              'authorization': 'Bearer $token',
              'content-type': 'application/octet-stream',
              'content-range': 'bytes $start-${end - 1}/$total',
              'x-chunk-sha256': sha256.convert(bytes).toString(),
              'x-idempotency-key': _uuid.v4(),
            },
            body: bytes,
          ),
          timeout: const Duration(minutes: 2),
        );
        if (response.statusCode >= 200 && response.statusCode < 300) return;
        if (response.statusCode == 401) {
          if (await _authStore.isUserSession(_baseUri)) {
            throw PipelineException(_messageFrom(response));
          }
          await _authStore.clearAccessToken(_baseUri);
        }
        lastError = _messageFrom(response);
      } catch (error) {
        lastError = error;
      }
      await Future<void>.delayed(Duration(seconds: attempt * attempt));
    }
    throw PipelineException('分片 ${partIndex + 1} 上传失败：$lastError');
  }

  Future<List<SubtitleCue>> _pollJob({
    required String jobId,
    required ProcessingState state,
  }) async {
    final deadline = DateTime.now().add(const Duration(hours: 2));
    while (DateTime.now().isBefore(deadline)) {
      final response = await _getJson('/api/jobs/$jobId');
      final status = response['status'] as String? ?? 'running';
      final stage = _stageFrom(response['stage'] as String?);
      final progress = (response['progress'] as num?)?.toDouble() ?? 0;
      final detail = response['detail'] as String? ?? stage.label;

      if (status == 'failed') {
        throw PipelineException(response['error'] as String? ?? '字幕处理失败。');
      }
      if (status == 'completed') {
        final rawCues = response['cues'] as List? ?? const [];
        final cues = rawCues
            .whereType<Map>()
            .map(
              (item) => SubtitleCue.fromJson(
                item.map((key, value) => MapEntry(key.toString(), value)),
              ),
            )
            .toList();
        state.update(
          stage: ProcessingStage.completed,
          progress: 1,
          detail: '已生成 ${cues.length} 条双语字幕',
        );
        return cues;
      }

      state.update(stage: stage, progress: progress, detail: detail);
      await Future<void>.delayed(const Duration(seconds: 3));
    }
    throw PipelineException('处理超时。任务仍可能在服务端继续运行。');
  }

  ProcessingStage _stageFrom(String? value) => switch (value) {
    'uploading' => ProcessingStage.uploading,
    'extracting_audio' => ProcessingStage.extractingAudio,
    'transcribing' => ProcessingStage.transcribing,
    'translating' => ProcessingStage.translating,
    'aligning' => ProcessingStage.aligning,
    'completed' => ProcessingStage.completed,
    'failed' => ProcessingStage.failed,
    _ => ProcessingStage.idle,
  };

  Future<Map<String, Object?>> _getJson(String path) async {
    return _getJsonUri(_uri(path));
  }

  Future<Map<String, Object?>> _getJsonUri(Uri uri) async {
    for (var attempt = 0; attempt < 2; attempt++) {
      final token = await _ensureAccessToken();
      final response = await _request(
        () => _client.get(
          uri,
          headers: {
            'authorization': 'Bearer $token',
            'accept': 'application/json',
          },
        ),
        timeout: const Duration(seconds: 30),
      );
      if (response.statusCode != 401 || attempt == 1) {
        return _decodeResponse(response);
      }
      if (await _authStore.isUserSession(_baseUri)) {
        return _decodeResponse(response);
      }
      await _authStore.clearAccessToken(_baseUri);
    }
    throw PipelineException('设备账户认证失败。');
  }

  Future<Map<String, Object?>> _postJson(
    String path,
    Map<String, Object?> body,
  ) async {
    for (var attempt = 0; attempt < 2; attempt++) {
      final token = await _ensureAccessToken();
      final response = await _request(
        () => _client.post(
          _uri(path),
          headers: {
            'authorization': 'Bearer $token',
            'content-type': 'application/json',
            'accept': 'application/json',
            'x-idempotency-key': _uuid.v4(),
          },
          body: jsonEncode(body),
        ),
        timeout: const Duration(minutes: 2),
      );
      if (response.statusCode != 401 || attempt == 1) {
        return _decodeResponse(response);
      }
      if (await _authStore.isUserSession(_baseUri)) {
        return _decodeResponse(response);
      }
      await _authStore.clearAccessToken(_baseUri);
    }
    throw PipelineException('设备账户认证失败。');
  }

  Future<Map<String, Object?>> _postPublicJson(
    String path,
    Map<String, Object?> body,
  ) async {
    final response = await _request(
      () => _client.post(
        _uri(path),
        headers: {
          'content-type': 'application/json',
          'accept': 'application/json',
        },
        body: jsonEncode(body),
      ),
      timeout: const Duration(seconds: 30),
    );
    return _decodeResponse(response);
  }

  Future<BillingAccount> _adoptAccountSession(
    Map<String, Object?> response,
  ) async {
    final token = response['accessToken'] as String? ?? '';
    if (token.length < 32) {
      throw PipelineException('服务端没有返回有效的登录凭据。');
    }
    final account = _parseAccount(response['account']);
    await _authStore.saveAccessToken(_baseUri, token);
    await _authStore.setUserSession(_baseUri, true);
    return account;
  }

  BillingAccount _parseAccount(Object? value) {
    if (value is! Map) {
      throw PipelineException('服务端没有返回有效的账户。');
    }
    return BillingAccount.fromJson(
      value.map((key, value) => MapEntry(key.toString(), value as Object?)),
    );
  }

  Future<String> _ensureAccessToken() async {
    final stored = await _authStore.accessToken(_baseUri);
    if (stored != null && stored.isNotEmpty) return stored;
    final existing = _authenticationInFlight;
    if (existing != null) return existing;

    final future = _registerDevice();
    _authenticationInFlight = future;
    try {
      return await future;
    } finally {
      if (identical(_authenticationInFlight, future)) {
        _authenticationInFlight = null;
      }
    }
  }

  Future<String> _registerDevice() async {
    final credentials = await _authStore.credentials();
    final response = await _request(
      () => _client.post(
        _uri('/api/auth/device'),
        headers: {
          'content-type': 'application/json',
          'accept': 'application/json',
        },
        body: jsonEncode({
          'installationId': credentials.installationId,
          'installationSecret': credentials.installationSecret,
        }),
      ),
      timeout: const Duration(seconds: 30),
    );
    final decoded = _decodeResponse(response);
    final token = decoded['accessToken'] as String? ?? '';
    if (token.length < 32) {
      throw PipelineException('服务端没有返回有效的设备凭据。');
    }
    await _authStore.saveAccessToken(_baseUri, token);
    await _authStore.setUserSession(_baseUri, false);
    return token;
  }

  void _captureUsageCharge(Map<String, Object?> response) {
    final raw = response['billing'];
    if (raw is Map) {
      lastUsageCharge = UsageCharge.fromJson(
        raw.map((key, value) => MapEntry(key.toString(), value as Object?)),
      );
    }
  }

  Future<http.Response> _request(
    Future<http.Response> Function() send, {
    required Duration timeout,
  }) async {
    try {
      return await send().timeout(timeout);
    } on TimeoutException {
      throw PipelineException(
        '字幕服务响应超时：${_serviceEndpointLabel()}。请检查服务是否运行或稍后重试。',
      );
    } on SocketException {
      throw PipelineException(
        '无法连接字幕服务：${_serviceEndpointLabel()}。请先启动本机字幕服务或检查服务器地址。',
      );
    } on http.ClientException {
      throw PipelineException(
        '无法连接字幕服务：${_serviceEndpointLabel()}。请先启动本机字幕服务或检查服务器地址。',
      );
    }
  }

  String _serviceEndpointLabel() {
    final port = _baseUri.hasPort ? ':${_baseUri.port}' : '';
    return '${_baseUri.scheme}://${_baseUri.host}$port';
  }

  Map<String, Object?> _decodeResponse(http.Response response) {
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw PipelineException(_messageFrom(response));
    }
    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    if (decoded is! Map) {
      throw PipelineException('服务端返回了无法识别的数据。');
    }
    return decoded.map(
      (key, value) => MapEntry(key.toString(), value as Object?),
    );
  }

  String _messageFrom(http.Response response) {
    try {
      final decoded = jsonDecode(utf8.decode(response.bodyBytes));
      if (decoded is Map && decoded['error'] is String) {
        return decoded['error'] as String;
      }
    } catch (_) {
      // Fall through to the HTTP status below.
    }
    return 'HTTP ${response.statusCode}';
  }

  String _formatBytes(int bytes) {
    if (bytes >= 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
    }
    if (bytes >= 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / 1024).toStringAsFixed(0)} KB';
  }

  void close() => _client.close();
}
