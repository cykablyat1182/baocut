import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import '../domain/models/subtitle_cue.dart';

/// Reads timed-text samples from an HTTP MP4 without downloading video data.
///
/// FFmpeg has to walk interleaved media packets for some cloud MP4 files even
/// when an input seek is supplied.  This reader downloads the MP4 `moov` box
/// once, uses its sample table as an index, and then requests only the tiny
/// `tx3g` packets which overlap the requested playback window.
class Mp4MovTextSubtitleReader {
  Mp4MovTextSubtitleReader(this._client);

  static const _probeBytes = 64;
  static const _maxTopLevelBoxes = 32;
  static const _maxMoovBytes = 64 * 1024 * 1024;
  static const _sampleWorkers = 8;
  static const _requestTimeout = Duration(seconds: 18);

  final http.Client _client;
  final Map<String, Future<_Mp4Index?>> _indexCache = {};

  /// Returns the timed-text tracks advertised by a range-readable HTTP MP4.
  ///
  /// Quark's mobile playback endpoint can keep an `.mkv` filename while
  /// serving an MP4 rendition.  Native track discovery and FFprobeKit are not
  /// reliable for that response on every Android build, so use the same MP4
  /// index that powers windowed subtitle reads as the primary probe.
  Future<List<Mp4MovTextTrackInfo>?> probeTracks({
    required Uri uri,
    Map<String, String> headers = const {},
  }) async {
    if (uri.scheme != 'http' && uri.scheme != 'https') return null;
    final index = await _getIndex(uri, headers);
    if (index == null) return null;
    return [
      for (final track in index.tracks)
        Mp4MovTextTrackInfo(
          streamIndex: track.globalOrdinal,
          subtitleOrdinal: track.subtitleOrdinal,
          language: track.language,
          codec: track.format == 'tx3g' ? 'mov_text' : track.format,
        ),
    ];
  }

  Future<List<SubtitleCue>?> readWindow({
    required Uri uri,
    required int streamIndex,
    required int subtitleOrdinal,
    required String? language,
    required Duration start,
    required Duration end,
    Map<String, String> headers = const {},
  }) async {
    if (uri.scheme != 'http' && uri.scheme != 'https') return null;
    final index = await _getIndex(uri, headers);
    if (index == null) return null;
    final track = index.selectTrack(
      streamIndex: streamIndex,
      subtitleOrdinal: subtitleOrdinal,
      language: language,
    );
    if (track == null || track.format != 'tx3g') return null;

    final startMicros = math.max(0, start.inMicroseconds);
    final endMicros = math.max(startMicros + 1, end.inMicroseconds);
    final selected = track.samples
        .where(
          (sample) =>
              sample.endMicros > startMicros && sample.startMicros < endMicros,
        )
        .toList(growable: false);
    if (selected.isEmpty) return const <SubtitleCue>[];

    final payloads = List<Uint8List?>.filled(selected.length, null);
    var next = 0;
    Future<void> worker() async {
      while (true) {
        final current = next++;
        if (current >= selected.length) return;
        final sample = selected[current];
        if (sample.size <= 0) continue;
        payloads[current] = await _readSample(index, uri, sample, headers);
      }
    }

    await Future.wait([
      for (var i = 0; i < math.min(_sampleWorkers, selected.length); i++)
        worker(),
    ]);

    final cues = <SubtitleCue>[];
    for (var i = 0; i < selected.length; i++) {
      final payload = payloads[i];
      if (payload == null) continue;
      final text = decodeMovTextSample(payload);
      if (text.isEmpty) continue;
      final sample = selected[i];
      cues.add(
        SubtitleCue(
          id: 'mp4-${track.trackId}-${sample.index}',
          start: Duration(microseconds: sample.startMicros),
          end: Duration(
            microseconds: math.max(sample.startMicros + 1, sample.endMicros),
          ),
          original: text,
        ),
      );
    }
    return cues;
  }

  static String decodeMovTextSample(Uint8List payload) {
    if (payload.length < 2) return '';
    final declaredLength = ByteData.sublistView(payload).getUint16(0);
    final textLength = math.min(declaredLength, payload.length - 2);
    if (textLength <= 0) return '';
    final bytes = Uint8List.sublistView(payload, 2, 2 + textLength);
    String value;
    if (bytes.length >= 2 && bytes[0] == 0xfe && bytes[1] == 0xff) {
      final units = <int>[];
      final data = ByteData.sublistView(bytes, 2);
      for (var offset = 0; offset + 1 < data.lengthInBytes; offset += 2) {
        units.add(data.getUint16(offset));
      }
      value = String.fromCharCodes(units);
    } else if (bytes.length >= 2 && bytes[0] == 0xff && bytes[1] == 0xfe) {
      final units = <int>[];
      final data = ByteData.sublistView(bytes, 2);
      for (var offset = 0; offset + 1 < data.lengthInBytes; offset += 2) {
        units.add(data.getUint16(offset, Endian.little));
      }
      value = String.fromCharCodes(units);
    } else {
      value = utf8.decode(bytes, allowMalformed: true);
    }
    return value
        .replaceAll('\u0000', '')
        .replaceAll('\r\n', '\n')
        .replaceAll('\r', '\n')
        .trim();
  }

  Future<_Mp4Index?> _getIndex(Uri uri, Map<String, String> headers) async {
    final key = uri.toString();
    final cached = _indexCache[key];
    if (cached != null) return cached;
    while (_indexCache.length >= 3) {
      _indexCache.remove(_indexCache.keys.first);
    }
    final loading = _loadIndex(uri, headers);
    _indexCache[key] = loading;
    try {
      return await loading;
    } catch (_) {
      if (identical(_indexCache[key], loading)) _indexCache.remove(key);
      rethrow;
    }
  }

  Future<_Mp4Index?> _loadIndex(Uri uri, Map<String, String> headers) async {
    final first = await _fetchRange(uri, 0, _probeBytes - 1, headers);
    if (first.bytes.length < 8) return null;

    var offset = 0;
    for (var count = 0; count < _maxTopLevelBoxes; count++) {
      final headerBytes = offset + 16 <= first.bytes.length
          ? Uint8List.sublistView(first.bytes, offset, offset + 16)
          : (await _fetchRange(uri, offset, offset + 15, headers)).bytes;
      final header = _readRemoteBoxHeader(headerBytes, absoluteOffset: offset);
      if (header == null || header.size <= 0) return null;
      if (header.type == 'moov') {
        if (header.size > _maxMoovBytes) {
          throw const Mp4SubtitleReadException('视频字幕索引过大，无法快速载入。');
        }
        final response = await _fetchRange(
          uri,
          offset,
          offset + header.size - 1,
          headers,
        );
        if (response.bytes.length < header.size) {
          throw const Mp4SubtitleReadException('视频字幕索引读取不完整。');
        }
        return _Mp4Index.parse(response.bytes, uri.toString());
      }
      if (header.size < header.headerSize) return null;
      offset += header.size;
      final totalLength = first.totalLength;
      if (totalLength != null && offset >= totalLength) return null;
    }
    return null;
  }

  _RemoteBoxHeader? _readRemoteBoxHeader(
    Uint8List bytes, {
    required int absoluteOffset,
  }) {
    if (bytes.length < 8) return null;
    final data = ByteData.sublistView(bytes);
    var size = data.getUint32(0);
    var headerSize = 8;
    if (size == 1) {
      if (bytes.length < 16) return null;
      size = data.getUint64(8);
      headerSize = 16;
    }
    return _RemoteBoxHeader(
      offset: absoluteOffset,
      size: size,
      type: ascii.decode(bytes.sublist(4, 8), allowInvalid: true),
      headerSize: headerSize,
    );
  }

  Future<Uint8List?> _readSample(
    _Mp4Index index,
    Uri uri,
    _Mp4Sample sample,
    Map<String, String> headers,
  ) async {
    final cacheKey = '${sample.offset}:${sample.size}';
    final cached = index.sampleLoads[cacheKey];
    if (cached != null) return await cached;
    final loading = () async {
      for (var attempt = 0; attempt < 2; attempt++) {
        try {
          final response = await _fetchRange(
            uri,
            sample.offset,
            sample.offset + sample.size - 1,
            headers,
          );
          if (response.bytes.length >= sample.size) {
            return Uint8List.sublistView(response.bytes, 0, sample.size);
          }
        } on Object {
          if (attempt == 1) return null;
        }
      }
      return null;
    }();
    index.sampleLoads[cacheKey] = loading;
    if (index.sampleLoads.length > 4000) {
      index.sampleLoads.remove(index.sampleLoads.keys.first);
    }
    final result = await loading;
    if (result == null && identical(index.sampleLoads[cacheKey], loading)) {
      index.sampleLoads.remove(cacheKey);
    }
    return result;
  }

  Future<_RangeResponse> _fetchRange(
    Uri uri,
    int start,
    int end,
    Map<String, String> headers,
  ) async {
    if (start < 0 || end < start) {
      throw const Mp4SubtitleReadException('字幕字节范围无效。');
    }
    final request = http.Request('GET', uri)
      ..headers.addAll(headers)
      ..headers['Range'] = 'bytes=$start-$end';
    final streamed = await _client.send(request).timeout(_requestTimeout);
    final expectedLength = end - start + 1;
    if (streamed.statusCode != 206) {
      final safeWholeResponse =
          streamed.statusCode == 200 &&
          start == 0 &&
          streamed.contentLength != null &&
          streamed.contentLength! <= expectedLength;
      if (!safeWholeResponse) {
        final subscription = streamed.stream.listen((_) {});
        await subscription.cancel();
        throw Mp4SubtitleReadException(
          '服务器不支持字幕所需的分段读取（HTTP ${streamed.statusCode}）。',
        );
      }
    }
    final bytes = await streamed.stream.toBytes().timeout(_requestTimeout);
    final totalLength =
        _parseTotalLength(streamed.headers['content-range']) ??
        (streamed.statusCode == 200 ? streamed.contentLength : null);
    return _RangeResponse(bytes, totalLength);
  }

  int? _parseTotalLength(String? contentRange) {
    if (contentRange == null) return null;
    final match = RegExp(r'/([0-9]+)$').firstMatch(contentRange.trim());
    return match == null ? null : int.tryParse(match.group(1)!);
  }
}

class Mp4MovTextTrackInfo {
  const Mp4MovTextTrackInfo({
    required this.streamIndex,
    required this.subtitleOrdinal,
    required this.language,
    required this.codec,
  });

  final int streamIndex;
  final int subtitleOrdinal;
  final String? language;
  final String codec;
}

class Mp4SubtitleReadException implements Exception {
  const Mp4SubtitleReadException(this.message);

  final String message;

  @override
  String toString() => message;
}

class _RangeResponse {
  const _RangeResponse(this.bytes, this.totalLength);

  final Uint8List bytes;
  final int? totalLength;
}

class _RemoteBoxHeader {
  const _RemoteBoxHeader({
    required this.offset,
    required this.size,
    required this.type,
    required this.headerSize,
  });

  final int offset;
  final int size;
  final String type;
  final int headerSize;
}

class _Mp4Index {
  _Mp4Index({required this.sourceKey, required this.tracks});

  final String sourceKey;
  final List<_Mp4Track> tracks;
  final Map<String, Future<Uint8List?>> sampleLoads = {};

  factory _Mp4Index.parse(Uint8List bytes, String sourceKey) {
    final parser = _Mp4BoxParser(bytes);
    final root = parser.boxAt(0, bytes.length);
    if (root == null || root.type != 'moov') {
      throw const Mp4SubtitleReadException('网络视频不是可分段读取的 MP4。');
    }
    final movieHeader = parser.firstChild(root, 'mvhd');
    final movieTimescale = movieHeader == null
        ? 0
        : parser.readTimescale(movieHeader);
    final tracks = <_Mp4Track>[];
    var globalOrdinal = 0;
    var subtitleOrdinal = 0;
    for (final trackBox
        in parser.children(root).where((box) => box.type == 'trak')) {
      final parsed = parser.readTrack(
        trackBox,
        globalOrdinal: globalOrdinal,
        subtitleOrdinal: subtitleOrdinal,
        movieTimescale: movieTimescale,
      );
      if (parsed != null) {
        tracks.add(parsed);
        subtitleOrdinal++;
      }
      globalOrdinal++;
    }
    return _Mp4Index(sourceKey: sourceKey, tracks: tracks);
  }

  _Mp4Track? selectTrack({
    required int streamIndex,
    required int subtitleOrdinal,
    required String? language,
  }) {
    if (streamIndex >= 0) {
      for (final track in tracks) {
        if (track.globalOrdinal == streamIndex) return track;
      }
    }
    for (final track in tracks) {
      if (track.subtitleOrdinal == subtitleOrdinal) return track;
    }
    final languageKey = _languageKey(language);
    if (languageKey.isNotEmpty) {
      final matches = tracks
          .where((track) => _languageKey(track.language) == languageKey)
          .toList(growable: false);
      if (matches.length == 1) return matches.first;
    }
    return null;
  }

  static String _languageKey(String? value) {
    final normalized = value?.trim().toLowerCase().replaceAll('_', '-');
    if (normalized == null || normalized.isEmpty) return '';
    return switch (normalized) {
      'eng' || 'en' => 'en',
      'chi' || 'zho' || 'zh' || 'cht' => 'zh',
      'jpn' || 'ja' => 'ja',
      _ => normalized.split('-').first,
    };
  }
}

class _Mp4Track {
  const _Mp4Track({
    required this.trackId,
    required this.globalOrdinal,
    required this.subtitleOrdinal,
    required this.language,
    required this.format,
    required this.samples,
  });

  final int trackId;
  final int globalOrdinal;
  final int subtitleOrdinal;
  final String? language;
  final String format;
  final List<_Mp4Sample> samples;
}

class _Mp4Sample {
  const _Mp4Sample({
    required this.index,
    required this.offset,
    required this.size,
    required this.startMicros,
    required this.endMicros,
  });

  final int index;
  final int offset;
  final int size;
  final int startMicros;
  final int endMicros;
}

class _Mp4BoxParser {
  _Mp4BoxParser(this.bytes) : data = ByteData.sublistView(bytes);

  final Uint8List bytes;
  final ByteData data;

  _Mp4Box? boxAt(int offset, int limit) {
    if (offset < 0 || offset + 8 > limit || limit > bytes.length) return null;
    var size = data.getUint32(offset);
    var headerSize = 8;
    if (size == 1) {
      if (offset + 16 > limit) return null;
      size = data.getUint64(offset + 8);
      headerSize = 16;
    } else if (size == 0) {
      size = limit - offset;
    }
    if (size < headerSize || offset + size > limit) return null;
    return _Mp4Box(
      offset: offset,
      size: size,
      type: ascii.decode(
        bytes.sublist(offset + 4, offset + 8),
        allowInvalid: true,
      ),
      headerSize: headerSize,
    );
  }

  Iterable<_Mp4Box> children(_Mp4Box parent) sync* {
    var offset = parent.payloadStart;
    final limit = parent.offset + parent.size;
    while (offset + 8 <= limit) {
      final child = boxAt(offset, limit);
      if (child == null) return;
      yield child;
      offset += child.size;
    }
  }

  _Mp4Box? firstChild(_Mp4Box parent, String type) {
    for (final child in children(parent)) {
      if (child.type == type) return child;
    }
    return null;
  }

  _Mp4Box? findPath(_Mp4Box parent, List<String> path) {
    var current = parent;
    for (final type in path) {
      final child = firstChild(current, type);
      if (child == null) return null;
      current = child;
    }
    return current;
  }

  int readTimescale(_Mp4Box header) {
    final payload = header.payloadStart;
    if (!_contains(header, payload, 4)) return 0;
    final version = data.getUint8(payload);
    final offset = payload + (version == 1 ? 20 : 12);
    return _contains(header, offset, 4) ? data.getUint32(offset) : 0;
  }

  _Mp4Track? readTrack(
    _Mp4Box trackBox, {
    required int globalOrdinal,
    required int subtitleOrdinal,
    required int movieTimescale,
  }) {
    final mediaHeader = findPath(trackBox, const ['mdia', 'mdhd']);
    final handler = findPath(trackBox, const ['mdia', 'hdlr']);
    final sampleTable = findPath(trackBox, const ['mdia', 'minf', 'stbl']);
    if (mediaHeader == null || handler == null || sampleTable == null) {
      return null;
    }
    final handlerOffset = handler.payloadStart + 8;
    if (!_contains(handler, handlerOffset, 4)) return null;
    final handlerType = ascii.decode(
      bytes.sublist(handlerOffset, handlerOffset + 4),
      allowInvalid: true,
    );
    if (handlerType != 'sbtl' &&
        handlerType != 'text' &&
        handlerType != 'subt') {
      return null;
    }

    final timescale = readTimescale(mediaHeader);
    if (timescale <= 0) return null;
    final sampleDescription = firstChild(sampleTable, 'stsd');
    final timeToSample = firstChild(sampleTable, 'stts');
    final sampleSize = firstChild(sampleTable, 'stsz');
    final sampleToChunk = firstChild(sampleTable, 'stsc');
    final chunkOffset =
        firstChild(sampleTable, 'stco') ?? firstChild(sampleTable, 'co64');
    if (sampleDescription == null ||
        timeToSample == null ||
        sampleSize == null ||
        sampleToChunk == null ||
        chunkOffset == null) {
      return null;
    }

    final formatOffset = sampleDescription.payloadStart + 12;
    if (!_contains(sampleDescription, formatOffset, 4)) return null;
    final format = ascii.decode(
      bytes.sublist(formatOffset, formatOffset + 4),
      allowInvalid: true,
    );
    if (format != 'tx3g') return null;

    final sizes = _readSampleSizes(sampleSize);
    final durations = _readTimeEntries(timeToSample, signedValues: false);
    if (sizes.isEmpty || durations.isEmpty) return null;
    final sampleCount = math.min(sizes.length, durations.length);
    final composition = firstChild(sampleTable, 'ctts');
    final compositionOffsets = composition == null
        ? const <int>[]
        : _readTimeEntries(
            composition,
            signedValues: data.getUint8(composition.payloadStart) == 1,
          );
    final offsets = _readSampleOffsets(sampleToChunk, chunkOffset, sizes);
    if (offsets.length < sampleCount) return null;

    final editOffsetSeconds = _readEditOffsetSeconds(
      trackBox,
      movieTimescale: movieTimescale,
      trackTimescale: timescale,
    );
    final samples = <_Mp4Sample>[];
    var decodeTime = 0;
    for (var index = 0; index < sampleCount; index++) {
      final duration = durations[index];
      final compositionOffset = index < compositionOffsets.length
          ? compositionOffsets[index]
          : 0;
      final startSeconds =
          (decodeTime + compositionOffset) / timescale + editOffsetSeconds;
      final endSeconds = startSeconds + duration / timescale;
      samples.add(
        _Mp4Sample(
          index: index,
          offset: offsets[index],
          size: sizes[index],
          startMicros: (startSeconds * Duration.microsecondsPerSecond).round(),
          endMicros: (endSeconds * Duration.microsecondsPerSecond).round(),
        ),
      );
      decodeTime += duration;
    }

    final trackHeader = firstChild(trackBox, 'tkhd');
    final trackId = trackHeader == null
        ? globalOrdinal + 1
        : _readTrackId(trackHeader, globalOrdinal + 1);
    return _Mp4Track(
      trackId: trackId,
      globalOrdinal: globalOrdinal,
      subtitleOrdinal: subtitleOrdinal,
      language: _readLanguage(mediaHeader),
      format: format,
      samples: samples,
    );
  }

  int _readTrackId(_Mp4Box box, int fallback) {
    final payload = box.payloadStart;
    if (!_contains(box, payload, 1)) return fallback;
    final version = data.getUint8(payload);
    final offset = payload + (version == 1 ? 20 : 12);
    return _contains(box, offset, 4) ? data.getUint32(offset) : fallback;
  }

  String? _readLanguage(_Mp4Box box) {
    final payload = box.payloadStart;
    if (!_contains(box, payload, 1)) return null;
    final version = data.getUint8(payload);
    final offset = payload + (version == 1 ? 32 : 20);
    if (!_contains(box, offset, 2)) return null;
    final packed = data.getUint16(offset);
    if (packed == 0) return null;
    final value = String.fromCharCodes([
      ((packed >> 10) & 0x1f) + 0x60,
      ((packed >> 5) & 0x1f) + 0x60,
      (packed & 0x1f) + 0x60,
    ]);
    return value == '```' ? null : value;
  }

  List<int> _readSampleSizes(_Mp4Box box) {
    final payload = box.payloadStart;
    if (!_contains(box, payload + 4, 8)) return const [];
    final constantSize = data.getUint32(payload + 4);
    final count = data.getUint32(payload + 8);
    if (count > 1000000) return const [];
    if (constantSize != 0) return List<int>.filled(count, constantSize);
    if (!_contains(box, payload + 12, count * 4)) return const [];
    return [
      for (var index = 0; index < count; index++)
        data.getUint32(payload + 12 + index * 4),
    ];
  }

  List<int> _readTimeEntries(_Mp4Box box, {required bool signedValues}) {
    final payload = box.payloadStart;
    if (!_contains(box, payload + 4, 4)) return const [];
    final entryCount = data.getUint32(payload + 4);
    if (entryCount > 1000000 || !_contains(box, payload + 8, entryCount * 8)) {
      return const [];
    }
    final values = <int>[];
    for (var entry = 0; entry < entryCount; entry++) {
      final offset = payload + 8 + entry * 8;
      final count = data.getUint32(offset);
      final value = signedValues
          ? data.getInt32(offset + 4)
          : data.getUint32(offset + 4);
      if (count > 1000000 || values.length + count > 1000000) {
        return const [];
      }
      values.addAll(List<int>.filled(count, value));
    }
    return values;
  }

  List<int> _readSampleOffsets(
    _Mp4Box sampleToChunk,
    _Mp4Box chunkOffset,
    List<int> sampleSizes,
  ) {
    final stscPayload = sampleToChunk.payloadStart;
    if (!_contains(sampleToChunk, stscPayload + 4, 4)) return const [];
    final stscCount = data.getUint32(stscPayload + 4);
    if (stscCount == 0 ||
        stscCount > 1000000 ||
        !_contains(sampleToChunk, stscPayload + 8, stscCount * 12)) {
      return const [];
    }
    final entries = <_SampleToChunkEntry>[];
    for (var index = 0; index < stscCount; index++) {
      final offset = stscPayload + 8 + index * 12;
      entries.add(
        _SampleToChunkEntry(
          firstChunk: data.getUint32(offset),
          samplesPerChunk: data.getUint32(offset + 4),
        ),
      );
    }

    final chunkPayload = chunkOffset.payloadStart;
    if (!_contains(chunkOffset, chunkPayload + 4, 4)) return const [];
    final chunkCount = data.getUint32(chunkPayload + 4);
    final wide = chunkOffset.type == 'co64';
    final width = wide ? 8 : 4;
    if (chunkCount > 1000000 ||
        !_contains(chunkOffset, chunkPayload + 8, chunkCount * width)) {
      return const [];
    }
    final chunks = [
      for (var index = 0; index < chunkCount; index++)
        wide
            ? data.getUint64(chunkPayload + 8 + index * width)
            : data.getUint32(chunkPayload + 8 + index * width),
    ];

    final offsets = <int>[];
    var sampleIndex = 0;
    var entryIndex = 0;
    for (var chunkIndex = 1; chunkIndex <= chunks.length; chunkIndex++) {
      while (entryIndex + 1 < entries.length &&
          chunkIndex >= entries[entryIndex + 1].firstChunk) {
        entryIndex++;
      }
      var offset = chunks[chunkIndex - 1];
      final samplesInChunk = entries[entryIndex].samplesPerChunk;
      for (
        var index = 0;
        index < samplesInChunk && sampleIndex < sampleSizes.length;
        index++
      ) {
        offsets.add(offset);
        offset += sampleSizes[sampleIndex];
        sampleIndex++;
      }
      if (sampleIndex >= sampleSizes.length) break;
    }
    return offsets;
  }

  double _readEditOffsetSeconds(
    _Mp4Box trackBox, {
    required int movieTimescale,
    required int trackTimescale,
  }) {
    if (movieTimescale <= 0 || trackTimescale <= 0) return 0;
    final edit = findPath(trackBox, const ['edts', 'elst']);
    if (edit == null) return 0;
    final payload = edit.payloadStart;
    if (!_contains(edit, payload, 8)) return 0;
    final version = data.getUint8(payload);
    final entryCount = data.getUint32(payload + 4);
    var offset = payload + 8;
    var presentationSeconds = 0.0;
    for (var index = 0; index < entryCount; index++) {
      final width = version == 1 ? 20 : 12;
      if (!_contains(edit, offset, width)) return 0;
      final segmentDuration = version == 1
          ? data.getUint64(offset)
          : data.getUint32(offset);
      final mediaTime = version == 1
          ? data.getInt64(offset + 8)
          : data.getInt32(offset + 4);
      if (mediaTime == -1) {
        presentationSeconds += segmentDuration / movieTimescale;
      } else {
        return presentationSeconds - mediaTime / trackTimescale;
      }
      offset += width;
    }
    return 0;
  }

  bool _contains(_Mp4Box box, int offset, int length) {
    return offset >= box.payloadStart &&
        length >= 0 &&
        offset + length <= box.offset + box.size;
  }
}

class _Mp4Box {
  const _Mp4Box({
    required this.offset,
    required this.size,
    required this.type,
    required this.headerSize,
  });

  final int offset;
  final int size;
  final String type;
  final int headerSize;

  int get payloadStart => offset + headerSize;
}

class _SampleToChunkEntry {
  const _SampleToChunkEntry({
    required this.firstChunk,
    required this.samplesPerChunk,
  });

  final int firstChunk;
  final int samplesPerChunk;
}
