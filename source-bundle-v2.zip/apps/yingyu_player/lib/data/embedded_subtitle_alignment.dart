import '../domain/models/subtitle_cue.dart';

/// Pairs two text subtitle tracks by their timestamps.
///
/// Subtitle streams in the same video normally share a timeline, but some
/// containers have a small constant offset between language tracks.  A
/// robust offset cluster is estimated first, then cues are paired in
/// monotonic order by overlap or a very small boundary gap.  This keeps the
/// result usable for clicking, seeking, and the bilingual overlay instead of
/// relying on stream order.
class EmbeddedSubtitleAlignment {
  const EmbeddedSubtitleAlignment._();

  // A candidate without any timeline overlap is only accepted when it is very
  // close.  A loose multi-second fallback is what previously let a Chinese
  // cue from the following sentence attach to the current English cue.
  static const _maxMatchDistance = Duration(milliseconds: 900);
  static const _maxOffset = Duration(seconds: 12);
  static const _offsetBucketWidth = 250;
  static const _skipPenalty = -20.0;

  static List<SubtitleCue> merge({
    required List<SubtitleCue> original,
    required List<SubtitleCue> translation,
    Duration? offset,
  }) {
    if (original.isEmpty) {
      return [
        for (final cue in translation)
          cue.copyWith(
            id: 'translation-${cue.id}',
            original: '',
            translation: cue.original,
          ),
      ];
    }
    if (translation.isEmpty) return List<SubtitleCue>.from(original);

    final primary = List<SubtitleCue>.from(original)
      ..sort((a, b) => a.start.compareTo(b.start));
    final secondary = List<SubtitleCue>.from(translation)
      ..sort((a, b) => a.start.compareTo(b.start));
    final effectiveOffset =
        offset ?? estimateOffset(original: primary, translation: secondary);
    final pairs = _align(primary, secondary, effectiveOffset);
    final translationByOriginal = <int, int>{
      for (final pair in pairs) pair.$1: pair.$2,
    };
    final merged = <SubtitleCue>[];

    for (var index = 0; index < primary.length; index++) {
      final cue = primary[index];
      final matchIndex = translationByOriginal[index];
      if (matchIndex == null) {
        merged.add(cue);
        continue;
      }
      final candidate = secondary[matchIndex];
      final alignedStart = candidate.start - effectiveOffset;
      final alignedEnd = candidate.end - effectiveOffset;
      final start = cue.start <= alignedStart ? cue.start : alignedStart;
      final end = cue.end >= alignedEnd ? cue.end : alignedEnd;
      merged.add(
        SubtitleCue(
          id: cue.id,
          start: start,
          end: end,
          original: cue.original,
          translation: candidate.original,
          speaker: cue.speaker,
        ),
      );
    }
    return merged;
  }

  /// Estimates the constant timestamp difference between two subtitle
  /// streams.  It is public so a remote/windowed player can calculate this
  /// once and reuse it for later windows instead of allowing the pairing to
  /// jump as each small range is fetched.
  static Duration estimateOffset({
    required List<SubtitleCue> original,
    required List<SubtitleCue> translation,
  }) {
    final primary = List<SubtitleCue>.from(original)
      ..sort((a, b) => a.start.compareTo(b.start));
    final secondary = List<SubtitleCue>.from(translation)
      ..sort((a, b) => a.start.compareTo(b.start));
    final estimated = _estimateOffset(primary, secondary);
    return _preferHigherOverlapOffset(primary, secondary, estimated);
  }

  /// Finds a monotonic one-to-one alignment.  The previous greedy matcher
  /// searched the entire translation list for every original cue, so a later
  /// translation could be consumed by an earlier cue and shift the rest of
  /// the window.  Dynamic programming lets us skip unmatched cues while
  /// keeping both subtitle streams in order.
  static List<(int, int)> _align(
    List<SubtitleCue> primary,
    List<SubtitleCue> secondary,
    Duration offset,
  ) {
    final scores = List.generate(
      primary.length + 1,
      (_) => List<double>.filled(secondary.length + 1, double.negativeInfinity),
    );
    final actions = List.generate(
      primary.length + 1,
      (_) => List<_AlignmentAction?>.filled(secondary.length + 1, null),
    );
    scores[0][0] = 0;

    void update(int row, int column, double value, _AlignmentAction action) {
      if (value > scores[row][column]) {
        scores[row][column] = value;
        actions[row][column] = action;
      }
    }

    for (var row = 0; row <= primary.length; row++) {
      for (var column = 0; column <= secondary.length; column++) {
        final current = scores[row][column];
        if (current == double.negativeInfinity) continue;
        if (row < primary.length) {
          update(
            row + 1,
            column,
            current + _skipPenalty,
            _AlignmentAction.skipOriginal,
          );
        }
        if (column < secondary.length) {
          update(
            row,
            column + 1,
            current + _skipPenalty,
            _AlignmentAction.skipTranslation,
          );
        }
        if (row < primary.length && column < secondary.length) {
          final pairScore = _pairScore(primary[row], secondary[column], offset);
          if (pairScore != null) {
            update(
              row + 1,
              column + 1,
              current + pairScore,
              _AlignmentAction.pair,
            );
          }
        }
      }
    }

    final pairs = <(int, int)>[];
    var row = primary.length;
    var column = secondary.length;
    while (row > 0 || column > 0) {
      final action = actions[row][column];
      switch (action) {
        case _AlignmentAction.pair:
          pairs.add((row - 1, column - 1));
          row--;
          column--;
        case _AlignmentAction.skipOriginal:
          row--;
        case _AlignmentAction.skipTranslation:
          column--;
        case null:
          // The first cell is the only reachable cell without an action.
          row = 0;
          column = 0;
      }
    }
    return pairs.reversed.toList(growable: false);
  }

  static double? _pairScore(
    SubtitleCue source,
    SubtitleCue candidate,
    Duration offset,
  ) {
    final adjustedStart = candidate.start - offset;
    final adjustedEnd = candidate.end - offset;
    final overlap = _overlap(
      source.start,
      source.end,
      adjustedStart,
      adjustedEnd,
    );
    final distance = (source.start - adjustedStart).abs();
    if (overlap == Duration.zero && distance > _maxMatchDistance) {
      return null;
    }
    // Overlap dominates; start distance only breaks ties.  A small positive
    // score for adjacent cues is useful when one track has split a sentence
    // at a slightly different boundary, but it cannot win once the gap is
    // close to a second.
    if (overlap == Duration.zero) {
      return 1000 - distance.inMilliseconds.toDouble();
    }
    return (100000 + overlap.inMilliseconds * 10 - distance.inMilliseconds)
        .toDouble();
  }

  static Duration _estimateOffset(
    List<SubtitleCue> primary,
    List<SubtitleCue> secondary,
  ) {
    final deltas = <int>[];
    final sampleCount = primary.length < 180 ? primary.length : 180;
    for (var index = 0; index < sampleCount; index++) {
      final cue = primary[index];
      SubtitleCue? nearest;
      var nearestDistance = _maxOffset.inMilliseconds + 1;
      for (final candidate in secondary) {
        final distance = (candidate.start - cue.start).abs().inMilliseconds;
        if (distance < nearestDistance) {
          nearestDistance = distance;
          nearest = candidate;
        }
      }
      if (nearest != null && nearestDistance <= _maxOffset.inMilliseconds) {
        deltas.add((nearest.start - cue.start).inMilliseconds);
      }
    }
    if (deltas.isEmpty) return Duration.zero;
    // A nearest-start median is easily pulled by a handful of missing or
    // differently segmented cues.  Pick the densest 250 ms bucket first, then
    // take the median inside that cluster to reject those outliers.
    final buckets = <int, int>{};
    for (final delta in deltas) {
      final bucket = (delta / _offsetBucketWidth).round();
      buckets[bucket] = (buckets[bucket] ?? 0) + 1;
    }
    var bestBucket = 0;
    var bestCount = -1;
    for (final entry in buckets.entries) {
      if (entry.value > bestCount ||
          entry.value == bestCount && entry.key.abs() < bestBucket.abs()) {
        bestBucket = entry.key;
        bestCount = entry.value;
      }
    }
    final center = bestBucket * _offsetBucketWidth;
    final cluster =
        deltas
            .where((delta) => (delta - center).abs() <= _offsetBucketWidth)
            .toList()
          ..sort();
    final sortedDeltas = List<int>.from(deltas)..sort();
    final values = cluster.isEmpty ? sortedDeltas : cluster;
    final value = values[values.length ~/ 2];
    return Duration(
      milliseconds: value.clamp(
        -_maxOffset.inMilliseconds,
        _maxOffset.inMilliseconds,
      ),
    );
  }

  static Duration _preferHigherOverlapOffset(
    List<SubtitleCue> primary,
    List<SubtitleCue> secondary,
    Duration estimated,
  ) {
    if (estimated == Duration.zero) return estimated;
    final baseline = _overlapScore(primary, secondary, Duration.zero);
    final shifted = _overlapScore(primary, secondary, estimated);
    // An estimated offset can be produced by a different nearby sentence in
    // a sparse window.  Only apply it when it creates strictly more temporal
    // overlap than the original movie timeline; ties stay at zero to avoid a
    // visible jump between adjacent windows.
    return shifted > baseline ? estimated : Duration.zero;
  }

  static int _overlapScore(
    List<SubtitleCue> primary,
    List<SubtitleCue> secondary,
    Duration offset,
  ) {
    var score = 0;
    for (final source in primary) {
      var best = 0;
      for (final candidate in secondary) {
        final overlap = _overlap(
          source.start,
          source.end,
          candidate.start - offset,
          candidate.end - offset,
        );
        if (overlap.inMilliseconds > best) {
          best = overlap.inMilliseconds;
        }
      }
      score += best;
    }
    return score;
  }

  static Duration _overlap(
    Duration firstStart,
    Duration firstEnd,
    Duration secondStart,
    Duration secondEnd,
  ) {
    final start = firstStart >= secondStart ? firstStart : secondStart;
    final end = firstEnd <= secondEnd ? firstEnd : secondEnd;
    return end > start ? end - start : Duration.zero;
  }
}

enum _AlignmentAction { skipOriginal, skipTranslation, pair }
