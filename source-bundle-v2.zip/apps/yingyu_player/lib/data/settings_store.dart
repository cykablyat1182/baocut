import 'dart:convert';
import 'dart:io';

import 'package:shared_preferences/shared_preferences.dart';

import '../domain/models/media_playlist_item.dart';

class SettingsStore {
  SettingsStore._({
    required this.pipelineBaseUrl,
    required this.sourceLanguage,
    required this.targetLanguage,
    required this.autoPrepareSubtitles,
    required this.subtitleBottomOffset,
    required this.subtitleOriginalScale,
    required this.subtitleTranslationScale,
    required this.subtitleTranslationFirst,
    required this.hideHearingImpairedSubtitles,
    required this.frameInterpolationMode,
    required this.localTranslationEnabled,
    required this.localModelDirectory,
    required this.localModelName,
    required this.libraryFolders,
    required this.onlineStreamSources,
    required this.recentMediaPaths,
    required this.playbackPositionsMs,
    required this.playbackDurationsMs,
    required this.favoriteMediaPaths,
    required this.mediaHistory,
  });

  static const _pipelineKey = 'pipeline_base_url';
  static const _sourceLanguageKey = 'source_language';
  static const _targetLanguageKey = 'target_language';
  static const _autoPrepareSubtitlesKey = 'auto_prepare_subtitles';
  static const _subtitleBottomOffsetKey = 'subtitle_bottom_offset';
  static const _subtitleOriginalScaleKey = 'subtitle_original_scale';
  static const _subtitleTranslationScaleKey = 'subtitle_translation_scale';
  static const _subtitleTranslationFirstKey = 'subtitle_translation_first';
  static const _hideHearingImpairedSubtitlesKey =
      'hide_hearing_impaired_subtitles';
  static const _frameInterpolationModeKey = 'frame_interpolation_mode';
  static const _localTranslationEnabledKey = 'local_translation_enabled';
  static const _localModelDirectoryKey = 'local_model_directory';
  static const _localModelNameKey = 'local_model_name';
  static const _libraryFoldersKey = 'library_folders';
  static const _onlineStreamSourcesKey = 'online_stream_sources';
  static const _recentMediaPathsKey = 'recent_media_paths';
  static const _playbackPositionsKey = 'playback_positions_ms';
  static const _playbackDurationsKey = 'playback_durations_ms';
  static const _favoriteMediaPathsKey = 'favorite_media_paths';
  static const _mediaHistoryKey = 'media_history_v1';

  String pipelineBaseUrl;
  String sourceLanguage;
  String targetLanguage;
  bool autoPrepareSubtitles;
  double subtitleBottomOffset;
  double subtitleOriginalScale;
  double subtitleTranslationScale;
  bool subtitleTranslationFirst;
  bool hideHearingImpairedSubtitles;
  String frameInterpolationMode;
  bool localTranslationEnabled;
  String localModelDirectory;
  String localModelName;
  List<String> libraryFolders;
  List<String> onlineStreamSources;
  List<String> recentMediaPaths;
  Map<String, int> playbackPositionsMs;
  Map<String, int> playbackDurationsMs;
  List<String> favoriteMediaPaths;

  /// Serialized metadata for recent/favorite items.  Paths alone are enough
  /// for local files, but not for cloud and online items whose catalog entry
  /// is rebuilt asynchronously after an Android restart.
  Map<String, Map<String, Object?>> mediaHistory;
  Future<void> _saveQueue = Future<void>.value();

  static Future<SettingsStore> load() async {
    final preferences = await SharedPreferences.getInstance();
    final compiledUrl = const String.fromEnvironment('PIPELINE_API_URL');
    final defaultUrl = compiledUrl.isNotEmpty
        ? compiledUrl
        : (Platform.isAndroid || Platform.isIOS)
        ? 'http://117.72.29.101'
        : 'http://127.0.0.1:8787';

    final savedPipelineUrl = preferences.getString(_pipelineKey)?.trim();
    // Older Android builds shipped with emulator/loopback defaults.  Keep a
    // physical device pointed at the shared service after an upgrade instead
    // of silently leaving account, billing and translation requests offline.
    final pipelineUrl =
        savedPipelineUrl == null ||
            ((Platform.isAndroid || Platform.isIOS) &&
                (savedPipelineUrl == 'http://10.0.2.2:8787' ||
                    savedPipelineUrl == 'http://127.0.0.1:8787' ||
                    savedPipelineUrl == 'http://localhost:8787' ||
                    savedPipelineUrl == 'http://117.72.29.101:8787'))
        ? defaultUrl
        : savedPipelineUrl;

    return SettingsStore._(
      pipelineBaseUrl: pipelineUrl,
      sourceLanguage: preferences.getString(_sourceLanguageKey) ?? 'en-US',
      targetLanguage: preferences.getString(_targetLanguageKey) ?? 'zh-CN',
      autoPrepareSubtitles:
          preferences.getBool(_autoPrepareSubtitlesKey) ?? true,
      subtitleBottomOffset:
          (preferences.getDouble(_subtitleBottomOffsetKey) ?? 0)
              .clamp(-160, 220)
              .toDouble(),
      subtitleOriginalScale:
          (preferences.getDouble(_subtitleOriginalScaleKey) ?? 1)
              .clamp(0.65, 1.75)
              .toDouble(),
      subtitleTranslationScale:
          (preferences.getDouble(_subtitleTranslationScaleKey) ?? 1)
              .clamp(0.65, 1.75)
              .toDouble(),
      subtitleTranslationFirst:
          preferences.getBool(_subtitleTranslationFirstKey) ?? false,
      hideHearingImpairedSubtitles:
          preferences.getBool(_hideHearingImpairedSubtitlesKey) ?? false,
      frameInterpolationMode:
          preferences.getString(_frameInterpolationModeKey) ?? 'off',
      localTranslationEnabled:
          preferences.getBool(_localTranslationEnabledKey) ?? false,
      localModelDirectory:
          preferences.getString(_localModelDirectoryKey)?.trim() ??
          (Platform.isWindows ? r'D:\AI\Ollama\models' : ''),
      localModelName: preferences.getString(_localModelNameKey)?.trim() ?? '',
      libraryFolders: _uniqueNonEmpty(
        preferences.getStringList(_libraryFoldersKey) ?? const [],
      ),
      onlineStreamSources: _uniqueNonEmpty(
        preferences.getStringList(_onlineStreamSourcesKey) ?? const [],
      ),
      recentMediaPaths: _uniqueNonEmpty(
        preferences.getStringList(_recentMediaPathsKey) ?? const [],
      ),
      playbackPositionsMs: _readIntMap(
        preferences.getString(_playbackPositionsKey),
      ),
      playbackDurationsMs: _readIntMap(
        preferences.getString(_playbackDurationsKey),
      ),
      favoriteMediaPaths: _uniqueNonEmpty(
        preferences.getStringList(_favoriteMediaPathsKey) ?? const [],
      ),
      mediaHistory: _readMediaHistory(preferences.getString(_mediaHistoryKey)),
    );
  }

  Future<void> save() {
    _saveQueue = _saveQueue.then(
      (_) => _write(),
      onError: (Object _, StackTrace _) => _write(),
    );
    return _saveQueue;
  }

  Future<void> _write() async {
    final preferences = await SharedPreferences.getInstance();
    await Future.wait([
      preferences.setString(
        _pipelineKey,
        pipelineBaseUrl.trim().replaceAll(RegExp(r'/$'), ''),
      ),
      preferences.setString(_sourceLanguageKey, sourceLanguage),
      preferences.setString(_targetLanguageKey, targetLanguage),
      preferences.setBool(_autoPrepareSubtitlesKey, autoPrepareSubtitles),
      preferences.setDouble(_subtitleBottomOffsetKey, subtitleBottomOffset),
      preferences.setDouble(_subtitleOriginalScaleKey, subtitleOriginalScale),
      preferences.setDouble(
        _subtitleTranslationScaleKey,
        subtitleTranslationScale,
      ),
      preferences.setBool(
        _subtitleTranslationFirstKey,
        subtitleTranslationFirst,
      ),
      preferences.setBool(
        _hideHearingImpairedSubtitlesKey,
        hideHearingImpairedSubtitles,
      ),
      preferences.setString(_frameInterpolationModeKey, frameInterpolationMode),
      preferences.setBool(_localTranslationEnabledKey, localTranslationEnabled),
      preferences.setString(
        _localModelDirectoryKey,
        localModelDirectory.trim(),
      ),
      preferences.setString(_localModelNameKey, localModelName.trim()),
      preferences.setStringList(_libraryFoldersKey, libraryFolders),
      preferences.setStringList(_onlineStreamSourcesKey, onlineStreamSources),
      preferences.setStringList(_recentMediaPathsKey, recentMediaPaths),
      preferences.setString(
        _playbackPositionsKey,
        jsonEncode(playbackPositionsMs),
      ),
      preferences.setString(
        _playbackDurationsKey,
        jsonEncode(playbackDurationsMs),
      ),
      preferences.setStringList(_favoriteMediaPathsKey, favoriteMediaPaths),
      preferences.setString(_mediaHistoryKey, jsonEncode(mediaHistory)),
    ]);
  }

  static List<String> _uniqueNonEmpty(List<String> values) {
    final seen = <String>{};
    return [
      for (final value in values)
        if (value.trim().isNotEmpty && seen.add(value.trim())) value.trim(),
    ];
  }

  static Map<String, int> _readIntMap(String? source) {
    if (source == null || source.isEmpty) return {};
    try {
      final decoded = jsonDecode(source);
      if (decoded is! Map<String, dynamic>) return {};
      return {
        for (final entry in decoded.entries)
          if (entry.value is num)
            entry.key: (entry.value as num).toInt().clamp(0, 1 << 53),
      };
    } on FormatException {
      return {};
    }
  }

  static Map<String, Map<String, Object?>> _readMediaHistory(String? source) {
    if (source == null || source.isEmpty) return {};
    try {
      final decoded = jsonDecode(source);
      if (decoded is! Map) return {};
      final result = <String, Map<String, Object?>>{};
      for (final entry in decoded.entries) {
        if (entry.key is! String || entry.value is! Map) continue;
        final item = MediaPlaylistItem.fromJson(entry.value);
        if (item != null) result[entry.key as String] = item.toJson();
      }
      return result;
    } on FormatException {
      return {};
    }
  }
}
