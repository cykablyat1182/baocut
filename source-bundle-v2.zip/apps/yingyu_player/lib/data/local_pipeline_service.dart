import 'dart:async';
import 'dart:io';

import 'package:http/http.dart' as http;

/// Starts the bundled development pipeline when the Windows player is run
/// directly from this source checkout. Production builds can omit Node.js and
/// simply continue using the configured remote pipeline URL.
class LocalPipelineService {
  LocalPipelineService._();

  static Future<void>? _startupInFlight;

  static Future<void> ensureStarted(String baseUrl) {
    final existing = _startupInFlight;
    if (existing != null) return existing;
    final future = _ensureStarted(baseUrl);
    _startupInFlight = future;
    return future.whenComplete(() {
      if (identical(_startupInFlight, future)) {
        _startupInFlight = null;
      }
    });
  }

  static Future<void> _ensureStarted(String baseUrl) async {
    if (!Platform.isWindows) return;
    final uri = Uri.tryParse(baseUrl);
    if (uri == null ||
        !const {'127.0.0.1', 'localhost', '::1'}.contains(uri.host)) {
      return;
    }
    if (await _isHealthy(uri)) return;

    final directory = _findServiceDirectory();
    if (directory == null) return;
    final serverFile = File(
      '$directory${Platform.pathSeparator}dist${Platform.pathSeparator}server.js',
    );
    if (!serverFile.existsSync()) return;

    try {
      await Process.start(
        'node',
        const ['dist/server.js'],
        workingDirectory: directory,
        environment: _serviceEnvironment(),
        mode: ProcessStartMode.detached,
      );
      await _waitForHealth(uri);
    } on Object {
      // The client still reports a useful endpoint-specific error if Node is
      // unavailable or the local service cannot be started.
    }
  }

  static Future<bool> _isHealthy(Uri baseUri) async {
    try {
      final response = await http
          .get(_healthUri(baseUri))
          .timeout(const Duration(milliseconds: 700));
      return response.statusCode == 200;
    } on Object {
      return false;
    }
  }

  static Future<void> _waitForHealth(Uri baseUri) async {
    final deadline = DateTime.now().add(const Duration(seconds: 6));
    while (DateTime.now().isBefore(deadline)) {
      if (await _isHealthy(baseUri)) return;
      await Future<void>.delayed(const Duration(milliseconds: 250));
    }
  }

  static Uri _healthUri(Uri baseUri) {
    final path = baseUri.path.endsWith('/')
        ? baseUri.path.substring(0, baseUri.path.length - 1)
        : baseUri.path;
    return baseUri.replace(path: '$path/health');
  }

  static Map<String, String> _serviceEnvironment() {
    final environment = Map<String, String>.from(Platform.environment);
    // The desktop shell may have old ARK/model variables from a previous
    // session. Remove them so dotenv can load the server-side .env selected for
    // this local pipeline (including a provider change such as DeepSeek).
    for (final key in const [
      'MODEL_CONFIG_PATH',
      'ARK_API_KEY',
      'ARK_MODEL',
      'ARK_BASE_URL',
    ]) {
      environment.remove(key);
    }
    environment['YINGYU_LOCAL_PIPELINE'] = '1';
    environment['YINGYU_LOCAL_ENV_FILE'] = '.env.local';
    return environment;
  }

  static String? _findServiceDirectory() {
    final configured = Platform.environment['YINGYU_MEDIA_PIPELINE_DIR'];
    final roots = <String>[
      if (configured != null && configured.trim().isNotEmpty) configured.trim(),
      Directory.current.path,
      File(Platform.resolvedExecutable).parent.path,
    ];
    final seen = <String>{};
    for (final root in roots) {
      var current = Directory(root);
      for (var depth = 0; depth < 14; depth++) {
        if (!seen.add(current.path.toLowerCase())) break;
        final candidate = Directory(
          '${current.path}${Platform.pathSeparator}services${Platform.pathSeparator}media_pipeline',
        );
        if (File(
          '${candidate.path}${Platform.pathSeparator}dist${Platform.pathSeparator}server.js',
        ).existsSync()) {
          return candidate.path;
        }
        final parent = current.parent;
        if (parent.path == current.path) break;
        current = parent;
      }
    }
    return null;
  }
}
