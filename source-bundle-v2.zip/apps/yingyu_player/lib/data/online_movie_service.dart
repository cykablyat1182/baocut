import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../domain/models/online_movie.dart';

class OnlineMovieService {
  OnlineMovieService(this._client);

  final http.Client _client;
  final Map<String, Future<_FetchedConfig>> _configCache = {};

  // The public qist aggregate contains many script/JAR providers.  The
  // native player intentionally exposes only its direct 4K routes.  Each
  // entry carries the aggregate site's key, so the former “4K 聚合” is split
  // into independent, selectable warehouses and a broken route cannot hide
  // the other ones.
  static const _qistUrl = 'https://qist.wyfc.qzz.io/jsm.json';
  static const _qistFallbackUrls = <String>[
    'https://fastly.jsdelivr.net/gh/qist/tvbox@master/jsm.json',
    'https://raw.githubusercontent.com/qist/tvbox/master/jsm.json',
  ];
  static const recommendedWarehouses = <OnlineMovieWarehouse>[
    OnlineMovieWarehouse(
      name: '玩偶 4K',
      url: _qistUrl,
      fallbackUrls: _qistFallbackUrls,
      siteKey: '玩偶',
    ),
    OnlineMovieWarehouse(
      name: '快映 4K',
      url: _qistUrl,
      fallbackUrls: _qistFallbackUrls,
      siteKey: '快映',
    ),
    OnlineMovieWarehouse(
      name: '木偶 4K',
      url: _qistUrl,
      fallbackUrls: _qistFallbackUrls,
      siteKey: '木偶',
    ),
    OnlineMovieWarehouse(
      name: '蜡笔 4K',
      url: _qistUrl,
      fallbackUrls: _qistFallbackUrls,
      siteKey: '蜡笔',
    ),
    OnlineMovieWarehouse(
      name: '闪电 4K',
      url: _qistUrl,
      fallbackUrls: _qistFallbackUrls,
      siteKey: '闪电',
    ),
    OnlineMovieWarehouse(
      name: '至臻 4K',
      url: _qistUrl,
      fallbackUrls: _qistFallbackUrls,
      siteKey: '至臻',
    ),
    OnlineMovieWarehouse(
      name: '多多 4K',
      url: _qistUrl,
      fallbackUrls: _qistFallbackUrls,
      siteKey: '多多',
    ),
    OnlineMovieWarehouse(
      name: '欧哥 4K',
      url: _qistUrl,
      fallbackUrls: _qistFallbackUrls,
      siteKey: '欧哥',
    ),
    OnlineMovieWarehouse(
      name: '二小 4K',
      url: _qistUrl,
      fallbackUrls: _qistFallbackUrls,
      siteKey: '二小',
    ),
    OnlineMovieWarehouse(
      name: '虎斑 4K',
      url: _qistUrl,
      fallbackUrls: _qistFallbackUrls,
      siteKey: '虎斑',
    ),
  ];

  // Searching all routes should use the same independent 4K entries shown
  // in the picker; this keeps a result's provider and route identity intact.
  static const _globalSearchWarehouses = recommendedWarehouses;

  Future<OnlineMovieDiscovery> discover(OnlineMovieWarehouse warehouse) async {
    OnlineMovieException? lastError;
    OnlineMovieDiscovery? lastEmpty;
    for (final address in warehouse.addresses) {
      try {
        final result = await _discoverAddress(warehouse, address);
        if (result.providers.isNotEmpty) return result;
        lastEmpty = result;
      } on OnlineMovieException catch (error) {
        lastError = error;
      }
    }
    if (lastEmpty != null) return lastEmpty;
    throw lastError ?? const OnlineMovieException('影视仓及其备用地址均无法连接。');
  }

  Future<OnlineMovieGlobalSearch> searchAll(String keyword) async {
    final normalized = keyword.trim();
    if (normalized.isEmpty) {
      throw const OnlineMovieException('请输入要搜索的影视名称。');
    }

    final discoveries = await Future.wait(
      _globalSearchWarehouses.map((warehouse) async {
        try {
          return await discover(warehouse);
        } on OnlineMovieException {
          return null;
        }
      }),
    );
    final providers = _dedupeProviders([
      for (final discovery in discoveries)
        if (discovery != null) ...discovery.providers,
    ]);
    if (providers.isEmpty) {
      throw const OnlineMovieException('当前没有可用于全线路搜索的影视源。');
    }

    final searchedProviders = providers.take(48).toList(growable: false);
    final results = await Future.wait(
      searchedProviders.map((provider) async {
        try {
          return await loadCatalog(provider, keyword: normalized);
        } on OnlineMovieException {
          return null;
        }
      }),
    );
    final items = <OnlineMovieSummary>[];
    var failed = 0;
    for (final result in results) {
      if (result == null) {
        failed++;
      } else {
        items.addAll(result.items);
      }
    }

    final seen = <String>{};
    final unique = [
      for (final item in items)
        if (seen.add(
          '${item.provider.api.toLowerCase()}|${item.id.toLowerCase()}',
        ))
          item,
    ];
    unique.sort((first, second) {
      final firstScore = _searchScore(first.name, normalized);
      final secondScore = _searchScore(second.name, normalized);
      final score = firstScore.compareTo(secondScore);
      if (score != 0) return score;
      final title = first.name.compareTo(second.name);
      if (title != 0) return title;
      return first.provider.name.compareTo(second.provider.name);
    });
    return OnlineMovieGlobalSearch(
      items: unique.take(320).toList(growable: false),
      providerCount: searchedProviders.length,
      failedProviderCount: failed,
    );
  }

  Future<OnlineMovieDiscovery> _discoverAddress(
    OnlineMovieWarehouse warehouse,
    String address,
  ) async {
    final root = await _fetchConfig(address);
    final nested = _warehouseEntries(root.map, root.uri);
    if (nested.isEmpty) {
      final result = _providersFromConfig(
        root.map,
        warehouse.name,
        root.uri,
        siteKey: warehouse.siteKey,
      );
      return OnlineMovieDiscovery(
        providers: result.providers,
        configCount: 1,
        unsupportedSiteCount: result.unsupported,
        failedConfigCount: 0,
      );
    }

    final providers = <OnlineMovieProvider>[];
    var unsupported = 0;
    var failed = 0;
    var attempted = 0;
    const maxNestedConfigs = 24;
    final entries = nested.take(maxNestedConfigs).toList(growable: false);
    const batchSize = 6;
    for (var start = 0; start < entries.length; start += batchSize) {
      final end = (start + batchSize).clamp(0, entries.length);
      final batch = entries.sublist(start, end);
      attempted += batch.length;
      final results = await Future.wait(
        batch.map((entry) async {
          try {
            final config = await _fetchConfig(entry.url);
            return _providersFromConfig(
              config.map,
              '${warehouse.name} · ${entry.name}',
              config.uri,
              siteKey: warehouse.siteKey,
            );
          } on OnlineMovieException {
            return null;
          }
        }),
      );
      for (final result in results) {
        if (result == null) {
          failed++;
          continue;
        }
        providers.addAll(result.providers);
        unsupported += result.unsupported;
      }
      if (providers.length >= 12) break;
    }
    return OnlineMovieDiscovery(
      providers: _dedupeProviders(providers),
      configCount: attempted,
      unsupportedSiteCount: unsupported,
      failedConfigCount: failed,
    );
  }

  Future<OnlineMoviePage> loadCatalog(
    OnlineMovieProvider provider, {
    int page = 1,
    String? categoryId,
    String? keyword,
  }) async {
    if (provider.adapter == 'wogg' || provider.adapter == 'panweb') {
      return _loadPanCatalog(
        provider,
        page: page,
        categoryId: categoryId,
        keyword: keyword,
      );
    }
    final uri = _apiUri(
      provider.api,
      action: 'detail',
      page: page,
      categoryId: categoryId,
      keyword: keyword,
    );
    final response = await _get(uri);
    final decoded = _decodeApi(response.bodyBytes);
    final list = decoded['list'];
    final items = <OnlineMovieSummary>[];
    if (list is List) {
      for (final value in list.whereType<Map>()) {
        final id = _text(value['vod_id']);
        final name = _text(value['vod_name']);
        if (id.isEmpty || name.isEmpty) continue;
        items.add(
          OnlineMovieSummary(
            id: id,
            name: name,
            provider: provider,
            coverUrl: _httpUrl(value['vod_pic']),
            remarks: _nullableText(value['vod_remarks']),
            typeName: _nullableText(value['type_name']),
            year: _nullableText(value['vod_year']),
          ),
        );
      }
    }
    return OnlineMoviePage(
      items: items,
      categories: _parseCategories(decoded['class']),
      page: _int(decoded['page'], fallback: page).clamp(1, 1 << 30),
      pageCount: _int(decoded['pagecount'], fallback: 1).clamp(1, 1 << 30),
    );
  }

  Future<OnlineMovieDetail> loadDetail(OnlineMovieSummary movie) async {
    if (movie.provider.adapter == 'wogg' ||
        movie.provider.adapter == 'panweb') {
      return _loadPanDetail(movie);
    }
    final uri = _apiUri(movie.provider.api, action: 'detail', ids: movie.id);
    final response = await _get(uri);
    final decoded = _decodeApi(response.bodyBytes);
    final list = decoded['list'];
    final value = list is List && list.isNotEmpty && list.first is Map
        ? list.first as Map
        : const <String, dynamic>{};
    final episodes = _parseEpisodes(
      _text(value['vod_play_from']),
      _text(value['vod_play_url']),
      playUrlPrefix: movie.provider.playUrl,
    );
    return OnlineMovieDetail(
      id: movie.id,
      name: _nullableText(value['vod_name']) ?? movie.name,
      coverUrl: _httpUrl(value['vod_pic']) ?? movie.coverUrl,
      remarks: _nullableText(value['vod_remarks']) ?? movie.remarks,
      typeName: _nullableText(value['type_name']) ?? movie.typeName,
      year: _nullableText(value['vod_year']) ?? movie.year,
      blurb: _cleanHtml(
        _nullableText(value['vod_content']) ??
            _nullableText(value['vod_blurb']),
      ),
      episodes: episodes,
    );
  }

  Future<_FetchedConfig> _fetchConfig(String address) {
    final key = address.trim();
    final cached = _configCache[key];
    if (cached != null) return cached;
    final future = _fetchConfigUncached(address);
    _configCache[key] = future;
    return future.then(
      (value) {
        return value;
      },
      onError: (Object error, StackTrace stackTrace) {
        _configCache.remove(key);
        Error.throwWithStackTrace(error, stackTrace);
      },
    );
  }

  Future<_FetchedConfig> _fetchConfigUncached(String address) async {
    final uri = Uri.tryParse(address);
    if (uri == null || !uri.hasScheme || !uri.hasAuthority) {
      throw const OnlineMovieException('配置地址无效。');
    }
    final response = await _get(uri);
    final contentType = response.headers['content-type']?.toLowerCase() ?? '';
    if (contentType.startsWith('image/') &&
        !contentType.contains('webp') &&
        !contentType.contains('json')) {
      throw const OnlineMovieException('该配置经过图片或加密封装，当前无法安全解析。');
    }
    final text = _decodeText(response.bodyBytes);
    final map = _decodeConfig(text);
    return _FetchedConfig(uri: response.request?.url ?? uri, map: map);
  }

  Future<http.Response> _get(
    Uri uri, {
    Map<String, String> headers = const {},
  }) async {
    try {
      final response = await _client
          .get(
            uri,
            headers: {
              'Accept': 'application/json,text/plain,*/*',
              'User-Agent': 'YingYu/1.10 TVBox-compatible client',
              ...headers,
            },
          )
          .timeout(const Duration(seconds: 16));
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw OnlineMovieException('请求失败（HTTP ${response.statusCode}）。');
      }
      return response;
    } on OnlineMovieException {
      rethrow;
    } on TimeoutException {
      throw const OnlineMovieException('连接影视仓超时，已自动尝试备用地址。');
    } catch (error) {
      throw OnlineMovieException('无法连接该影视仓：$error');
    }
  }

  static Map<String, dynamic> _decodeConfig(String source) {
    final normalized = source
        .replaceFirst('\uFEFF', '')
        .split(RegExp(r'\r?\n'))
        .where((line) => !line.trimLeft().startsWith('//'))
        .join('\n')
        .trim();
    final start = normalized.indexOf('{');
    final end = normalized.lastIndexOf('}');
    if (start < 0 || end <= start) {
      throw const OnlineMovieException('返回内容不是可识别的 TVBox 配置。');
    }
    try {
      final decoded = jsonDecode(normalized.substring(start, end + 1));
      if (decoded is Map<String, dynamic>) return decoded;
      if (decoded is Map) return Map<String, dynamic>.from(decoded);
      throw const FormatException();
    } on FormatException {
      throw const OnlineMovieException('TVBox 配置格式不兼容或已加密。');
    }
  }

  static Map<String, dynamic> _decodeApi(List<int> bytes) {
    final text = _decodeText(bytes).replaceFirst('\uFEFF', '').trim();
    try {
      final decoded = jsonDecode(text);
      if (decoded is Map<String, dynamic>) return decoded;
      if (decoded is Map) return Map<String, dynamic>.from(decoded);
    } on FormatException {
      // XML CMS endpoints are deliberately rejected instead of being guessed.
    }
    throw const OnlineMovieException('该线路没有返回兼容的 JSON CMS 数据。');
  }

  static List<_WarehouseEntry> _warehouseEntries(
    Map<String, dynamic> config,
    Uri baseUri,
  ) {
    final values = config['urls'];
    if (values is! List) return const [];
    return [
      for (final entry in values.whereType<Map>())
        if (_text(entry['url']).isNotEmpty)
          _WarehouseEntry(
            name: _nullableText(entry['name']) ?? '未命名配置',
            url: baseUri.resolve(_text(entry['url'])).toString(),
          ),
    ];
  }

  static _ProviderResult _providersFromConfig(
    Map<String, dynamic> config,
    String warehouseName,
    Uri baseUri, {
    String? siteKey,
  }) {
    final values = config['sites'];
    if (values is! List) return const _ProviderResult([], 0);
    final providers = <OnlineMovieProvider>[];
    var unsupported = 0;
    final normalizedSiteKey = siteKey?.trim().toLowerCase();
    final allSites = values.whereType<Map>().toList(growable: false);
    final selectedSites = normalizedSiteKey == null || normalizedSiteKey.isEmpty
        ? allSites
        : allSites
              .where(
                (site) =>
                    _text(site['key']).trim().toLowerCase() ==
                    normalizedSiteKey,
              )
              .toList(growable: false);
    // A one-site config is already a split route and may not declare a
    // TVBox key (this is common in mirrors and in user-provided test configs).
    // Accept it as-is while keeping multi-site aggregates strictly filtered.
    final sites = selectedSites.isNotEmpty || allSites.length > 1
        ? selectedSites
        : allSites;
    for (final site in sites) {
      final type = _int(site['type'], fallback: -1);
      final api = _text(site['api']);
      final adapter = _panAdapter(type, api);
      if (adapter != null) {
        final origins = _panOrigins(site['ext']);
        if (origins.isEmpty) {
          unsupported++;
          continue;
        }
        providers.add(
          OnlineMovieProvider(
            key: _nullableText(site['key']) ?? origins.first,
            name: _nullableText(site['name']) ?? '4K 网盘线路',
            api: origins.first,
            fallbackApis: origins.skip(1).toList(growable: false),
            warehouseName: warehouseName,
            adapter: adapter,
          ),
        );
        continue;
      }
      if (type != 1 || api.isEmpty) {
        unsupported++;
        continue;
      }
      final resolved = baseUri.resolve(api);
      if (resolved.scheme != 'http' && resolved.scheme != 'https') {
        unsupported++;
        continue;
      }
      providers.add(
        OnlineMovieProvider(
          key: _nullableText(site['key']) ?? resolved.toString(),
          name: _nullableText(site['name']) ?? '在线线路',
          api: resolved.toString(),
          warehouseName: warehouseName,
          playUrl: _firstText([
            site['playUrl'],
            site['playurl'],
            site['play_url'],
          ]),
        ),
      );
    }
    return _ProviderResult(_dedupeProviders(providers), unsupported);
  }

  static List<OnlineMovieProvider> _dedupeProviders(
    List<OnlineMovieProvider> providers,
  ) {
    final seen = <String>{};
    return [
      for (final provider in providers)
        if (seen.add('${provider.adapter}|${provider.api.toLowerCase()}'))
          provider,
    ];
  }

  Future<OnlineMoviePage> _loadPanCatalog(
    OnlineMovieProvider provider, {
    required int page,
    String? categoryId,
    String? keyword,
  }) async {
    http.Response? response;
    Uri? responseUri;
    OnlineMovieException? lastError;
    for (final address in provider.addresses) {
      final base = Uri.tryParse(address);
      if (base == null || !base.hasAuthority) continue;
      final normalizedKeyword = keyword?.trim() ?? '';
      final path = normalizedKeyword.isNotEmpty
          ? provider.adapter == 'wogg'
                ? '/vodsearch/${Uri.encodeComponent(normalizedKeyword)}----------$page---.html'
                : '/index.php/vod/search/page/$page/wd/${Uri.encodeComponent(normalizedKeyword)}.html'
          : provider.adapter == 'wogg'
          ? '/vodshow/${categoryId ?? '1'}--------$page---.html'
          : '/index.php/vod/show/id/${categoryId ?? '1'}/page/$page.html';
      try {
        final requestedUri = base.resolve(path);
        response = await _get(requestedUri, headers: _panRequestHeaders);
        responseUri = response.request?.url ?? requestedUri;
        final source = utf8.decode(response.bodyBytes, allowMalformed: true);
        final title = _tagText(source, 'title');
        if (title != 'Just a moment...') break;
        response = null;
        responseUri = null;
        lastError = const OnlineMovieException('4K 站点正在进行人机验证。');
      } on OnlineMovieException catch (error) {
        lastError = error;
      }
    }
    if (response == null) {
      throw lastError ?? const OnlineMovieException('4K 线路的备用地址均无法连接。');
    }
    final source = utf8.decode(response.bodyBytes, allowMalformed: true);
    final cards = _panCards(source);
    final items = <OnlineMovieSummary>[];
    final seen = <String>{};
    for (final card in cards) {
      final href = card.href;
      final name = card.name;
      if (href.isEmpty || name.isEmpty) continue;
      final detailUrl = responseUri!.resolve(href).toString();
      if (!seen.add(detailUrl)) continue;
      final cover = card.cover;
      final remarks = card.remarks;
      items.add(
        OnlineMovieSummary(
          id: detailUrl,
          name: name,
          provider: provider,
          coverUrl: cover.trim().isEmpty
              ? null
              : responseUri.resolve(cover.trim()).toString(),
          remarks: remarks?.isEmpty == true ? null : remarks,
          typeName: '4K 网盘',
        ),
      );
    }
    final pageNumbers =
        RegExp(
              "<a\\b[^>]*class=[\"'][^\"']*(?:page|mac_pages)[^\"']*[\"'][^>]*>([\\s\\S]*?)</a>",
              caseSensitive: false,
            )
            .allMatches(source)
            .map((match) => int.tryParse(_stripHtml(match.group(1) ?? '')))
            .whereType<int>();
    final discoveredPageCount = pageNumbers.fold<int>(
      page,
      (a, b) => a > b ? a : b,
    );
    return OnlineMoviePage(
      items: items,
      categories: const [
        OnlineMovieCategory(id: '1', name: '电影'),
        OnlineMovieCategory(id: '2', name: '剧集'),
        OnlineMovieCategory(id: '44', name: '臻彩视界'),
        OnlineMovieCategory(id: '3', name: '动漫'),
        OnlineMovieCategory(id: '4', name: '综艺'),
        OnlineMovieCategory(id: '6', name: '短剧'),
      ],
      page: page,
      pageCount: discoveredPageCount,
    );
  }

  Future<OnlineMovieDetail> _loadPanDetail(OnlineMovieSummary movie) async {
    final uri = Uri.tryParse(movie.id);
    if (uri == null) throw const OnlineMovieException('4K 影视详情地址无效。');
    final response = await _get(uri, headers: _panRequestHeaders);
    final source = utf8.decode(response.bodyBytes, allowMalformed: true);
    final episodes = <OnlineMovieEpisode>[];
    for (final row in _classSegments(source, 'module-row-title')) {
      final label = _tagText(row, 'h4') ?? '';
      final content = _tagText(row, 'p') ?? _stripHtml(row);
      final urls = RegExp("https?://[^\\s<>\"']+", caseSensitive: false)
          .allMatches(content)
          .map((match) => match.group(0)!)
          .map((url) => url.replaceAll(RegExp(r'[\)\]\}\u3002，,;]+$'), ''));
      for (final url in urls) {
        final uri = Uri.tryParse(url);
        if (uri == null || !uri.hasAuthority) continue;
        final host = uri.host.toLowerCase();
        final route = switch (host) {
          'pan.quark.cn' => '夸克网盘',
          'www.alipan.com' || 'www.aliyundrive.com' => '阿里云盘',
          'www.115.com' || '115.com' => '115 网盘',
          'drive.uc.cn' => 'UC 网盘',
          _ => '4K 网盘',
        };
        episodes.add(
          OnlineMovieEpisode(
            name: label.isEmpty ? route : label,
            url: url,
            route: route,
          ),
        );
      }
    }
    return OnlineMovieDetail(
      id: movie.id,
      name: movie.name,
      coverUrl: movie.coverUrl,
      remarks: movie.remarks,
      typeName: movie.typeName,
      year: movie.year,
      blurb: _metaContent(source, 'description'),
      episodes: episodes,
    );
  }

  static String? _panAdapter(int type, String api) {
    if (type != 3) return null;
    final normalized = api.trim().toLowerCase();
    if (normalized == 'csp_wogg' || normalized == 'csp_wo4k') return 'wogg';
    if (normalized == 'csp_panwebshare') return 'panweb';
    return null;
  }

  static const _panRequestHeaders = <String, String>{
    'Accept': 'text/html,application/xhtml+xml,*/*',
    'User-Agent':
        'Mozilla/5.0 (iPhone; CPU iPhone OS 18_2 like Mac OS X) AppleWebKit/604.1.14 (KHTML, like Gecko)',
  };

  static List<String> _panOrigins(Object? ext) {
    final values = <Object?>[];
    if (ext is Map) {
      final sites = ext['site'];
      if (sites is List) {
        values.addAll(sites);
      } else {
        values.add(sites);
      }
    } else {
      values.add(ext);
    }
    final seen = <String>{};
    return [
      for (final value in values)
        if (value != null)
          for (final token in value.toString().split(RegExp(r'[|,]')))
            if (Uri.tryParse(token.trim()) case final uri?)
              if ((uri.scheme == 'http' || uri.scheme == 'https') &&
                  uri.hasAuthority &&
                  seen.add(uri.toString().replaceAll(RegExp(r'/$'), '')))
                uri.toString().replaceAll(RegExp(r'/$'), ''),
    ];
  }

  static List<_PanCard> _panCards(String source) {
    final cards = <_PanCard>[];
    final seen = <String>{};
    for (final segment in _classSegments(source, 'module-search-item')) {
      final card = _panCard(segment);
      if (card != null && seen.add(card.href)) cards.add(card);
    }
    for (final segment in _classSegments(source, 'module-item')) {
      final card = _panCard(segment);
      if (card != null && seen.add(card.href)) cards.add(card);
    }
    return cards;
  }

  static _PanCard? _panCard(String segment) {
    final imageTag = RegExp(
      r'<img\b[^>]*>',
      caseSensitive: false,
    ).firstMatch(segment)?.group(0);
    final serialAnchor = RegExp(
      "<a\\b[^>]*class=[\"'][^\"']*video-serial[^\"']*[\"'][^>]*>[\\s\\S]*?</a>",
      caseSensitive: false,
    ).firstMatch(segment)?.group(0);
    final anchor =
        serialAnchor ??
        RegExp(
          "<a\\b[^>]*href=[\"'][^\"']+[\"'][^>]*>[\\s\\S]*?</a>",
          caseSensitive: false,
        ).firstMatch(segment)?.group(0);
    final href = _attribute(anchor, 'href') ?? '';
    final name =
        _attribute(imageTag, 'alt') ??
        _attribute(anchor, 'title') ??
        (anchor == null ? '' : _stripHtml(anchor));
    if (href.trim().isEmpty || name.trim().isEmpty) return null;
    return _PanCard(
      href: _decodeHtml(href.trim()),
      name: _decodeHtml(name.trim()),
      cover: _decodeHtml(
        _attribute(imageTag, 'data-src') ?? _attribute(imageTag, 'src') ?? '',
      ),
      remarks: serialAnchor == null ? null : _stripHtml(serialAnchor),
    );
  }

  static List<String> _classSegments(String source, String className) {
    final matches = RegExp(
      "<(?:div|li)\\b[^>]*class=[\"'][^\"']*${RegExp.escape(className)}[^\"']*[\"'][^>]*>",
      caseSensitive: false,
    ).allMatches(source).toList();
    return [
      for (var index = 0; index < matches.length; index++)
        source.substring(
          matches[index].end,
          index + 1 < matches.length ? matches[index + 1].start : source.length,
        ),
    ];
  }

  static String? _tagText(String source, String tag) {
    final match = RegExp(
      '<${RegExp.escape(tag)}\\b[^>]*>([\\s\\S]*?)</${RegExp.escape(tag)}>',
      caseSensitive: false,
    ).firstMatch(source);
    return match == null ? null : _stripHtml(match.group(1) ?? '');
  }

  static String? _metaContent(String source, String name) {
    for (final match in RegExp(
      r'<meta\b[^>]*>',
      caseSensitive: false,
    ).allMatches(source)) {
      final tag = match.group(0);
      if ((_attribute(tag, 'name') ?? '').toLowerCase() == name.toLowerCase()) {
        final content = _attribute(tag, 'content')?.trim();
        if (content?.isNotEmpty == true) return _decodeHtml(content!);
      }
    }
    return null;
  }

  static String? _attribute(String? tag, String name) {
    if (tag == null) return null;
    final match = RegExp(
      "${RegExp.escape(name)}\\s*=\\s*([\"'])([\\s\\S]*?)\\1",
      caseSensitive: false,
    ).firstMatch(tag);
    return match?.group(2);
  }

  static String _stripHtml(String value) => _decodeHtml(
    value
        .replaceAll(RegExp(r'<[^>]+>'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim(),
  );

  static String _decodeHtml(String value) => value
      .replaceAll('&nbsp;', ' ')
      .replaceAll('&amp;', '&')
      .replaceAll('&quot;', '"')
      .replaceAll('&#39;', "'")
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>');

  static int _searchScore(String title, String keyword) {
    final normalizedTitle = title.toLowerCase().replaceAll(' ', '');
    final normalizedKeyword = keyword.toLowerCase().replaceAll(' ', '');
    if (normalizedTitle == normalizedKeyword) return 0;
    if (normalizedTitle.startsWith(normalizedKeyword)) return 1;
    if (normalizedTitle.contains(normalizedKeyword)) return 2;
    return 3;
  }

  static Uri _apiUri(
    String address, {
    required String action,
    int? page,
    String? categoryId,
    String? keyword,
    String? ids,
  }) {
    final base = Uri.parse(address);
    final query = Map<String, String>.from(base.queryParameters)
      ..removeWhere(
        (key, _) =>
            const {'ac', 'action', 'pg', 't', 'wd', 'ids'}.contains(key),
      )
      ..['ac'] = action;
    if (page != null) query['pg'] = '$page';
    if (categoryId?.trim().isNotEmpty == true) query['t'] = categoryId!.trim();
    if (keyword?.trim().isNotEmpty == true) query['wd'] = keyword!.trim();
    if (ids?.trim().isNotEmpty == true) query['ids'] = ids!.trim();
    return base.replace(queryParameters: query);
  }

  static List<OnlineMovieCategory> _parseCategories(Object? value) {
    if (value is! List) return const [];
    return [
      for (final item in value.whereType<Map>())
        if (_text(item['type_id']).isNotEmpty &&
            _text(item['type_name']).isNotEmpty)
          OnlineMovieCategory(
            id: _text(item['type_id']),
            name: _text(item['type_name']),
          ),
    ];
  }

  static List<OnlineMovieEpisode> _parseEpisodes(
    String playFrom,
    String playUrl, {
    String playUrlPrefix = '',
  }) {
    final routeNames = playFrom.split(r'$$$');
    final routeValues = playUrl.split(r'$$$');
    final output = <OnlineMovieEpisode>[];
    for (var routeIndex = 0; routeIndex < routeValues.length; routeIndex++) {
      final route =
          routeIndex < routeNames.length &&
              routeNames[routeIndex].trim().isNotEmpty
          ? routeNames[routeIndex].trim()
          : '线路 ${routeIndex + 1}';
      for (final token in routeValues[routeIndex].split('#')) {
        final separator = token.indexOf(r'$');
        final rawName = separator > 0 ? token.substring(0, separator) : '';
        final rawAddress = separator > 0
            ? token.substring(separator + 1)
            : token;
        final parts = rawAddress.split('|');
        final rawUrl = _normalizePlayableAddress(parts.first.trim());
        final url = _applyPlayUrl(rawUrl, playUrlPrefix);
        final uri = Uri.tryParse(url);
        if (uri == null || !_isPlayableUrl(uri)) {
          continue;
        }
        final headers = <String, String>{};
        for (final part in parts.skip(1)) {
          final equals = part.indexOf('=');
          if (equals <= 0) continue;
          final key = Uri.decodeComponent(part.substring(0, equals).trim());
          final value = Uri.decodeComponent(part.substring(equals + 1).trim());
          if (key.isNotEmpty && value.isNotEmpty) headers[key] = value;
        }
        output.add(
          OnlineMovieEpisode(
            name: rawName.trim().isEmpty ? '播放' : rawName.trim(),
            url: url,
            route: route,
            httpHeaders: headers,
          ),
        );
      }
    }
    return output;
  }

  /// Only HTTP(S) media is accepted by the movie catalogue.  Live protocols
  /// (RTMP/RTSP) belong to the removed live-stream feature and must not leak
  /// into the 4K movie player, even when an upstream TVBox config contains
  /// them alongside its catalogue routes.
  static bool _isPlayableUrl(Uri uri) =>
      uri.hasAuthority &&
      const {'http', 'https'}.contains(uri.scheme.toLowerCase());

  static String _normalizePlayableAddress(String value) {
    var normalized = _decodeHtml(value.trim()).replaceAll(r'\/', '/');
    if (!normalized.contains('://') &&
        normalized.toLowerCase().contains('%3a%2f%2f')) {
      normalized = Uri.decodeComponent(normalized);
    }
    if (normalized.contains('://')) return normalized;
    final lower = normalized.toLowerCase();
    if (lower.startsWith('pan.quark.cn/') ||
        lower.startsWith('drive.quark.cn/') ||
        lower.startsWith('drive-pc.quark.cn/') ||
        lower.startsWith('drive-h.quark.cn/')) {
      return 'https://$normalized';
    }
    return normalized;
  }

  static String _applyPlayUrl(String url, String prefix) {
    final resolver = prefix.trim();
    if (resolver.isEmpty ||
        _looksLikeDirectMediaAddress(url) ||
        _isCloudShareAddress(url)) {
      // A number of TVBox configs keep a resolver in `playUrl` even for
      // routes that already return a native HLS/MP4 address.  Sending those
      // direct addresses through the resolver turns them into an HTML player
      // page, which libmpv correctly rejects as an unknown media format.
      // Cloud-share links must also remain untouched so the UI can hand them
      // to the transfer/OpenList flow instead of trying to play the share
      // page as a video.
      return url;
    }
    if (resolver.contains('{url}')) {
      return resolver.replaceAll('{url}', url);
    }
    // TVBox's `playUrl` is a resolver prefix and is intentionally joined
    // without URL encoding; many legacy resolvers expect the original URL.
    return '$resolver$url';
  }

  static bool _isCloudShareAddress(String value) {
    final uri = Uri.tryParse(value.trim());
    if (uri == null) return false;
    final host = uri.host.toLowerCase();
    return host == 'pan.quark.cn' ||
        host == 'drive.quark.cn' ||
        host == 'drive-pc.quark.cn' ||
        host == 'drive-h.quark.cn' ||
        host == 'www.alipan.com' ||
        host == 'www.aliyundrive.com' ||
        host == '115.com' ||
        host == 'www.115.com' ||
        host == 'www.123pan.com' ||
        host == 'www.123684.com' ||
        host == 'drive.uc.cn' ||
        host == 'uc.cn';
  }

  static bool _looksLikeDirectMediaAddress(String value) {
    final normalized = value.trim().toLowerCase();
    if (normalized.startsWith('rtmp://') ||
        normalized.startsWith('rtmps://') ||
        normalized.startsWith('rtsp://')) {
      return true;
    }
    final uri = Uri.tryParse(normalized);
    if (uri == null) return false;
    final address = '${uri.path}?${uri.query}';
    return const [
      '.m3u8',
      '.m3u',
      '.mp4',
      '.mkv',
      '.webm',
      '.mov',
      '.flv',
      '.ts',
      '.mpd',
      '.avi',
      '.wmv',
      '.rmvb',
    ].any(address.contains);
  }

  static String _decodeText(List<int> bytes) {
    try {
      return utf8.decode(bytes);
    } on FormatException {
      return latin1.decode(bytes);
    }
  }

  static String _text(Object? value) => value?.toString().trim() ?? '';

  static String _firstText(Iterable<Object?> values) {
    for (final value in values) {
      final text = _text(value);
      if (text.isNotEmpty) return text;
    }
    return '';
  }

  static String? _nullableText(Object? value) {
    final text = _text(value);
    return text.isEmpty ? null : text;
  }

  static String? _httpUrl(Object? value) {
    final text = _text(value);
    final uri = Uri.tryParse(text);
    return uri != null && (uri.scheme == 'http' || uri.scheme == 'https')
        ? text
        : null;
  }

  static int _int(Object? value, {required int fallback}) {
    return value is num
        ? value.toInt()
        : int.tryParse(_text(value)) ?? fallback;
  }

  static String? _cleanHtml(String? value) {
    if (value == null) return null;
    final cleaned = value
        .replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n')
        .replaceAll(RegExp(r'<[^>]+>'), '')
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&amp;', '&')
        .trim();
    return cleaned.isEmpty ? null : cleaned;
  }
}

class OnlineMovieException implements Exception {
  const OnlineMovieException(this.message);

  final String message;

  @override
  String toString() => message;
}

class _FetchedConfig {
  const _FetchedConfig({required this.uri, required this.map});

  final Uri uri;
  final Map<String, dynamic> map;
}

class _WarehouseEntry {
  const _WarehouseEntry({required this.name, required this.url});

  final String name;
  final String url;
}

class _ProviderResult {
  const _ProviderResult(this.providers, this.unsupported);

  final List<OnlineMovieProvider> providers;
  final int unsupported;
}

class _PanCard {
  const _PanCard({
    required this.href,
    required this.name,
    required this.cover,
    required this.remarks,
  });

  final String href;
  final String name;
  final String cover;
  final String? remarks;
}
