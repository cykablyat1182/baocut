import '../domain/models/media_playlist_item.dart';
import 'openlist_media_service.dart';
import 'pipeline_client.dart';

/// Account-authenticated OpenList catalog hosted behind the YingYu service.
///
/// The client only sees a logical media library. OpenList administrator
/// credentials and the physical mount path remain on the server.
class ManagedOpenListMediaService {
  const ManagedOpenListMediaService(this._pipeline);

  static const sourceId = 'managed-openlist';

  final PipelineClient Function() _pipeline;

  static const _videoExtensions = {
    'mkv',
    'mp4',
    'avi',
    'mov',
    'webm',
    'm4v',
    'ts',
    'mts',
    'm2ts',
    'mpeg',
    'mpg',
    'wmv',
    'flv',
    'vob',
    'rmvb',
  };
  static const _subtitleExtensions = {'srt', 'vtt', 'ass', 'ssa'};

  Future<List<MediaPlaylistItem>> load({
    int maxDepth = 8,
    int maxFiles = 1200,
    bool refresh = false,
  }) async {
    final files = <_ManagedFile>[];
    await _walk('/', 0, maxDepth, maxFiles, files, refresh);
    final subtitles = <String, List<String>>{};
    for (final file in files.where(
      (item) => _subtitleExtensions.contains(_extension(item.path)),
    )) {
      subtitles.putIfAbsent(_stem(file.path), () => []).add(file.path);
    }
    return [
      for (final file in files)
        if (_videoExtensions.contains(_extension(file.path)))
          MediaPlaylistItem(
            path: Uri(
              scheme: 'managed',
              host: sourceId,
              path: file.path,
            ).toString(),
            title: file.name,
            group: _parentLabel(file.path),
            sourceName: '云端网盘',
            isOnline: true,
            isLive: false,
            cloudSourceId: sourceId,
            remotePath: file.path,
            remoteSubtitlePaths: _matchingSubtitles(file.path, subtitles),
          ),
    ];
  }

  Future<OpenListResolvedFile> resolve(
    String path, {
    String linkType = 'streaming',
  }) => _pipeline().managedMediaLink(path, linkType: linkType);

  Future<void> _walk(
    String path,
    int depth,
    int maxDepth,
    int maxFiles,
    List<_ManagedFile> output,
    bool refresh,
  ) async {
    if (depth > maxDepth || output.length >= maxFiles) return;
    final entries = await _pipeline().managedMediaList(path, refresh: refresh);
    final children = <String>[];
    for (final entry in entries) {
      if (output.length >= maxFiles) break;
      final name = entry['name']?.toString().trim() ?? '';
      if (name.isEmpty || name.contains('/')) continue;
      final childPath = path == '/' ? '/$name' : '$path/$name';
      if (entry['isDirectory'] == true) {
        children.add(childPath);
      } else if (_videoExtensions.contains(_extension(childPath)) ||
          _subtitleExtensions.contains(_extension(childPath))) {
        output.add(_ManagedFile(name: name, path: childPath));
      }
    }
    await Future.wait(
      children.map(
        (child) => _walk(child, depth + 1, maxDepth, maxFiles, output, refresh),
      ),
    );
  }

  static List<String> _matchingSubtitles(
    String videoPath,
    Map<String, List<String>> subtitles,
  ) {
    final stem = _stem(videoPath);
    final exact = subtitles[stem];
    if (exact != null && exact.isNotEmpty) return List.from(exact);
    return [
      for (final entry in subtitles.entries)
        if (entry.key.startsWith('$stem.') ||
            entry.key.startsWith('${stem}_') ||
            entry.key.startsWith('$stem-'))
          ...entry.value,
    ];
  }

  static String _extension(String path) {
    final dot = path.lastIndexOf('.');
    return dot < 0 ? '' : path.substring(dot + 1).toLowerCase();
  }

  static String _stem(String path) =>
      path.replaceFirst(RegExp(r'\.[^.\/]+$'), '').toLowerCase();

  static String _parentLabel(String path) {
    final parts = path.split('/').where((part) => part.isNotEmpty).toList();
    return parts.length > 1 ? parts[parts.length - 2] : '网盘影视';
  }
}

class _ManagedFile {
  const _ManagedFile({required this.name, required this.path});

  final String name;
  final String path;
}
