import 'dart:io';

import '../domain/models/subtitle_cue.dart';

/// Writes the generated translation as a normal, one-cue-per-entry SRT file.
/// The player also keeps the parsed cues in memory so remote streams can use
/// the same track picker even when their media URL is not writable.
class SubtitleWriter {
  const SubtitleWriter._();

  static Future<File> writeSrt({
    required String path,
    required Iterable<SubtitleCue> cues,
  }) async {
    final output = File(path);
    await output.parent.create(recursive: true);
    final buffer = StringBuffer();
    var index = 0;
    for (final cue in cues) {
      final text = cue.original.trim();
      if (text.isEmpty) continue;
      index++;
      buffer
        ..writeln(index)
        ..writeln('${_timestamp(cue.start)} --> ${_timestamp(cue.end)}')
        ..writeln(text)
        ..writeln();
    }
    await output.writeAsString(buffer.toString(), flush: true);
    return output;
  }

  static String _timestamp(Duration value) {
    final milliseconds = value.inMilliseconds.clamp(0, 24 * 60 * 60 * 1000);
    final hours = milliseconds ~/ Duration.millisecondsPerHour;
    final minutes =
        (milliseconds % Duration.millisecondsPerHour) ~/
        Duration.millisecondsPerMinute;
    final seconds =
        (milliseconds % Duration.millisecondsPerMinute) ~/
        Duration.millisecondsPerSecond;
    final millis = milliseconds % Duration.millisecondsPerSecond;
    return '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')},${millis.toString().padLeft(3, '0')}';
  }
}
