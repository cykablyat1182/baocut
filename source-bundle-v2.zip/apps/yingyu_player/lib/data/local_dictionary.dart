import '../domain/models/dictionary_entry.dart';

const localDictionary = <String, DictionaryEntry>{
  'weather': DictionaryEntry(
    word: 'weather',
    phonetic: '/ˈweðər/',
    partOfSpeech: 'n.',
    definition: '天气；气象',
    example: 'The weather in London changes quickly.',
    exampleTranslation: '伦敦的天气变化很快。',
  ),
  'suppose': DictionaryEntry(
    word: 'suppose',
    phonetic: '/səˈpoʊz/',
    partOfSpeech: 'v.',
    definition: '认为；推断；假设',
    example: 'I suppose we could wait until morning.',
    exampleTranslation: '我想我们可以等到早上。',
  ),
  'depends': DictionaryEntry(
    word: 'depend',
    phonetic: '/dɪˈpend/',
    partOfSpeech: 'v.',
    definition: '取决于；依靠',
    example: 'It depends on what you need.',
    exampleTranslation: '这取决于你需要什么。',
  ),
  'london': DictionaryEntry(
    word: 'London',
    phonetic: '/ˈlʌndən/',
    partOfSpeech: 'n.',
    definition: '伦敦（英国首都）',
    example: 'London is quieter after the rain.',
    exampleTranslation: '雨后的伦敦更安静。',
  ),
  'changing': DictionaryEntry(
    word: 'change',
    phonetic: '/tʃeɪndʒ/',
    partOfSpeech: 'v.',
    definition: '改变；变化',
    example: 'The light keeps changing.',
    exampleTranslation: '光线一直在变化。',
  ),
  'interesting': DictionaryEntry(
    word: 'interesting',
    phonetic: '/ˈɪntrəstɪŋ/',
    partOfSpeech: 'adj.',
    definition: '有趣的；引人入胜的',
    example: 'That is what makes the city interesting.',
    exampleTranslation: '正因如此，这座城市才有趣。',
  ),
};
