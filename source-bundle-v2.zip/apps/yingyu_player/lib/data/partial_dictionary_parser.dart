/// Extracts complete or in-progress string fields from a streamed JSON object.
///
/// The provider emits one JSON string a token at a time. This small scanner
/// exposes readable fields such as `definition` before the whole object has
/// arrived, while respecting escaped quotes and Unicode escapes.
Map<String, String> parsePartialDictionaryFields(String source) {
  const fields = [
    'word',
    'phonetic',
    'partOfSpeech',
    'definition',
    'example',
    'exampleTranslation',
  ];
  final result = <String, String>{};
  for (final field in fields) {
    final marker = RegExp('"$field"\\s*:\\s*"').firstMatch(source);
    if (marker == null) continue;
    final start = marker.end;
    var end = source.length;
    var escaped = false;
    for (var index = start; index < source.length; index++) {
      final character = source[index];
      if (escaped) {
        escaped = false;
        continue;
      }
      if (character == '\\') {
        escaped = true;
      } else if (character == '"') {
        end = index;
        break;
      }
    }
    final value = _decodeJsonStringPrefix(source.substring(start, end));
    if (value.isNotEmpty) result[field] = value;
  }
  return result;
}

String _decodeJsonStringPrefix(String source) {
  final result = StringBuffer();
  for (var index = 0; index < source.length; index++) {
    final character = source[index];
    if (character != '\\') {
      result.write(character);
      continue;
    }
    if (index + 1 >= source.length) break;
    final escape = source[++index];
    switch (escape) {
      case '"':
        result.write('"');
      case '\\':
        result.write('\\');
      case '/':
        result.write('/');
      case 'b':
        result.write('\b');
      case 'f':
        result.write('\f');
      case 'n':
        result.write('\n');
      case 'r':
        result.write('\r');
      case 't':
        result.write('\t');
      case 'u':
        if (index + 4 >= source.length) return result.toString();
        final code = int.tryParse(
          source.substring(index + 1, index + 5),
          radix: 16,
        );
        if (code == null) return result.toString();
        result.writeCharCode(code);
        index += 4;
      default:
        result.write(escape);
    }
  }
  return result.toString();
}
