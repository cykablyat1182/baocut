import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:ffmpeg_kit_flutter_new_min/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new_min/return_code.dart';
import 'package:path_provider/path_provider.dart';

class MediaCoverService {
  final Map<String, Future<String?>> _pending = {};
  final Map<String, Future<List<File>>> _directoryImages = {};

  void invalidateDirectoryIndex() => _directoryImages.clear();

  Future<String?> resolve(String mediaPath) {
    return _pending.putIfAbsent(mediaPath, () async {
      try {
        return await _resolve(mediaPath);
      } finally {
        _pending.remove(mediaPath);
      }
    });
  }

  Future<String?> _resolve(String mediaPath) async {
    final media = File(mediaPath);
    if (!await media.exists()) return null;

    final sidecar = await _findSidecar(media);
    if (sidecar != null) return sidecar.path;

    try {
      final stat = await media.stat();
      final support = await getApplicationSupportDirectory();
      final cache = Directory(
        '${support.path}${Platform.pathSeparator}media-covers',
      );
      await cache.create(recursive: true);
      final normalized = Platform.isWindows
          ? media.path.toLowerCase()
          : media.path;
      final fingerprint = sha256
          .convert(
            utf8.encode(
              '$normalized|${stat.size}|${stat.modified.millisecondsSinceEpoch}',
            ),
          )
          .toString();
      final output = File(
        '${cache.path}${Platform.pathSeparator}$fingerprint.jpg',
      );
      if (await _isUsable(output)) return output.path;

      if (await _extractFrame(media.path, output.path, seekSeconds: 8) ||
          await _extractFrame(media.path, output.path, seekSeconds: 0)) {
        return await _isUsable(output) ? output.path : null;
      }
      if (await output.exists()) await output.delete();
    } catch (_) {
      return null;
    }
    return null;
  }

  Future<File?> _findSidecar(File media) async {
    final separator = Platform.pathSeparator;
    final fileName = media.uri.pathSegments.last;
    final dot = fileName.lastIndexOf('.');
    final mediaStem = (dot > 0 ? fileName.substring(0, dot) : fileName)
        .toLowerCase();
    final parentPath = media.parent.path;
    final images = await _directoryImages.putIfAbsent(parentPath, () async {
      try {
        return [
          await for (final entity in media.parent.list(followLinks: false))
            if (entity is File && _isImagePath(entity.path)) entity,
        ];
      } on FileSystemException {
        return const <File>[];
      }
    });
    if (images.isEmpty) return null;

    File? best;
    var bestScore = 0;
    for (final image in images) {
      final imageName = image.path.split(separator).last.toLowerCase();
      final imageDot = imageName.lastIndexOf('.');
      final imageStem = imageDot > 0
          ? imageName.substring(0, imageDot)
          : imageName;
      final score = _sidecarScore(mediaStem, imageStem);
      if (score > bestScore) {
        best = image;
        bestScore = score;
      }
    }
    return best;
  }

  static int _sidecarScore(String mediaStem, String imageStem) {
    if (imageStem == mediaStem) return 100;
    if (imageStem == '$mediaStem-poster' ||
        imageStem == '${mediaStem}_poster' ||
        imageStem == '$mediaStem.poster' ||
        imageStem == '$mediaStem-cover' ||
        imageStem == '${mediaStem}_cover' ||
        imageStem == '$mediaStem.cover') {
      return 95;
    }
    if (imageStem.startsWith(mediaStem) &&
        const ['poster', 'cover', 'thumb'].any(imageStem.contains)) {
      return 90;
    }
    return switch (imageStem) {
      'poster' => 50,
      'folder' => 45,
      'cover' => 40,
      'thumbnail' || 'thumb' => 35,
      'fanart' => 30,
      _ => 0,
    };
  }

  static bool _isImagePath(String path) {
    final dot = path.lastIndexOf('.');
    if (dot < 0) return false;
    return const {
      'jpg',
      'jpeg',
      'png',
      'webp',
      'bmp',
    }.contains(path.substring(dot + 1).toLowerCase());
  }

  static Future<bool> _isUsable(File file) async {
    if (!await file.exists()) return false;
    return await file.length() > 512;
  }

  static Future<bool> _extractFrame(
    String mediaPath,
    String outputPath, {
    required int seekSeconds,
  }) async {
    final session = await FFmpegKit.executeWithArguments([
      '-nostdin',
      '-y',
      '-v',
      'error',
      '-ss',
      seekSeconds.toString(),
      '-i',
      mediaPath,
      '-map',
      '0:v:0?',
      '-frames:v',
      '1',
      '-vf',
      'scale=720:-2:force_original_aspect_ratio=decrease',
      '-q:v',
      '4',
      '-an',
      '-sn',
      outputPath,
    ]);
    return ReturnCode.isSuccess(await session.getReturnCode());
  }
}
