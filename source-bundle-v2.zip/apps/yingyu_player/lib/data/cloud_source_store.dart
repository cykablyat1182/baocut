import 'dart:convert';

import 'package:flutter/services.dart';

import '../domain/models/cloud_media_source.dart';
import 'device_auth_store.dart';

class CloudSourceStore {
  CloudSourceStore({SystemCredentialStore? secureStorage})
    : _secureStorage = secureStorage ?? const SystemCredentialStore();

  static const _storageKey = 'cloud_media_sources_v1';
  final SystemCredentialStore _secureStorage;

  Future<List<CloudMediaSource>> read() async {
    try {
      final encoded = await _secureStorage.read(key: _storageKey);
      // Callers add/remove sources after loading. Always return a growable
      // list; returning `const []` here makes the first connection fail with
      // "Cannot remove from an unmodifiable list" when duplicate cleanup runs.
      if (encoded == null || encoded.isEmpty) return <CloudMediaSource>[];
      final decoded = jsonDecode(encoded);
      if (decoded is! List) return <CloudMediaSource>[];
      return <CloudMediaSource>[
        for (final value in decoded) ?CloudMediaSource.fromJson(value),
      ];
    } on Object {
      return <CloudMediaSource>[];
    }
  }

  Future<void> write(List<CloudMediaSource> sources) async {
    try {
      await _secureStorage.write(
        key: _storageKey,
        value: jsonEncode([for (final source in sources) source.toJson()]),
      );
    } on PlatformException catch (error) {
      throw CloudSourceStoreException(
        '系统凭据存储不可用，网盘令牌没有保存：${error.message ?? error.code}',
      );
    }
  }
}

class CloudSourceStoreException implements Exception {
  const CloudSourceStoreException(this.message);
  final String message;
}
