import 'dart:io';

import 'package:flutter/services.dart';

class AndroidStorageAccess {
  const AndroidStorageAccess();

  static const _channel = MethodChannel('yingyu/storage_access');

  Future<bool> hasAccess() async {
    if (!Platform.isAndroid) return true;
    return await _channel.invokeMethod<bool>('hasAccess') ?? false;
  }

  Future<bool> requestAccess() async {
    if (!Platform.isAndroid) return true;
    return await _channel.invokeMethod<bool>('requestAccess') ?? false;
  }

  Future<String?> pickMediaFile() async {
    if (!Platform.isAndroid) return null;
    return _channel.invokeMethod<String>('pickMediaFile');
  }
}
