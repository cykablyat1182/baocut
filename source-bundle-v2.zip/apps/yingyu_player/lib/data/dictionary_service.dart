import '../domain/models/dictionary_entry.dart';
import 'local_dictionary.dart';
import 'pipeline_client.dart';
import 'subtitle_tokenizer.dart';

class DictionaryService {
  DictionaryService(this._pipeline);

  final PipelineClient _pipeline;
  final Map<String, DictionaryEntry> _cache = {...localDictionary};

  Future<DictionaryEntry> lookup({
    required String word,
    required String sentence,
    void Function(Map<String, String> fields)? onPartial,
    void Function(String message)? onStatus,
  }) async {
    final normalized = normalizeSubtitleQuery(word);
    if (normalized.isEmpty) {
      throw PipelineException('请选择字幕中的单词或短语。');
    }

    final cached = _cache[normalized];
    if (cached != null) {
      onPartial?.call(
        cached.toJson().map(
          (key, value) => MapEntry(key, value?.toString() ?? ''),
        ),
      );
      return cached;
    }

    final online = await _pipeline.lookupStream(
      word: normalized,
      sentence: sentence.trim(),
      onPartial: onPartial,
      onStatus: onStatus,
    );
    if (online == null || online.definition.trim().isEmpty) {
      throw PipelineException('词典服务没有返回有效释义，请重试。');
    }
    _cache[normalized] = online;
    return online;
  }
}
