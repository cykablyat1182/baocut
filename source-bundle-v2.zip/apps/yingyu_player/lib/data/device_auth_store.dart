import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

class DeviceCredentials {
  const DeviceCredentials({
    required this.installationId,
    required this.installationSecret,
  });

  final String installationId;
  final String installationSecret;
}

class DeviceAuthStore {
  DeviceAuthStore({SystemCredentialStore? secureStorage})
    : _secureStorage = secureStorage ?? const SystemCredentialStore();

  static const _installationIdKey = 'device_installation_id';
  static const _installationSecretKey = 'device_installation_secret';
  static const _uuid = Uuid();

  final SystemCredentialStore _secureStorage;

  String _randomSecret() {
    final random = Random.secure();
    final bytes = List<int>.generate(32, (_) => random.nextInt(256));
    return base64UrlEncode(bytes).replaceAll('=', '');
  }

  String _tokenKey(Uri baseUri) {
    final service = baseUri.replace(
      path: baseUri.path.replaceAll(RegExp(r'/$'), ''),
    );
    final digest = sha256.convert(utf8.encode(service.toString())).toString();
    return 'service_access_token_$digest';
  }

  String _userSessionKey(Uri baseUri) => '${_tokenKey(baseUri)}_is_user';

  Future<DeviceCredentials> credentials() async {
    final preferences = await SharedPreferences.getInstance();
    var installationId = preferences.getString(_installationIdKey);
    if (installationId == null || installationId.length < 16) {
      installationId = _uuid.v4();
      await preferences.setString(_installationIdKey, installationId);
    }

    var installationSecret = await _secureStorage.read(
      key: _installationSecretKey,
    );
    if (installationSecret == null || installationSecret.length < 32) {
      installationSecret = _randomSecret();
      await _secureStorage.write(
        key: _installationSecretKey,
        value: installationSecret,
      );
    }
    return DeviceCredentials(
      installationId: installationId,
      installationSecret: installationSecret,
    );
  }

  Future<String?> accessToken(Uri baseUri) =>
      _secureStorage.read(key: _tokenKey(baseUri));

  Future<void> saveAccessToken(Uri baseUri, String token) =>
      _secureStorage.write(key: _tokenKey(baseUri), value: token);

  Future<bool> isUserSession(Uri baseUri) async {
    final preferences = await SharedPreferences.getInstance();
    return preferences.getBool(_userSessionKey(baseUri)) ?? false;
  }

  Future<void> setUserSession(Uri baseUri, bool value) async {
    final preferences = await SharedPreferences.getInstance();
    await preferences.setBool(_userSessionKey(baseUri), value);
  }

  Future<void> clearAccessToken(Uri baseUri) async {
    await _secureStorage.delete(key: _tokenKey(baseUri));
    await setUserSession(baseUri, false);
  }
}

class SystemCredentialStore {
  const SystemCredentialStore();

  static const _channel = MethodChannel('yingyu/secure_credentials');

  Future<String?> read({required String key}) =>
      _channel.invokeMethod<String>('read', {'key': key});

  Future<void> write({required String key, required String? value}) async {
    if (value == null) {
      await delete(key: key);
      return;
    }
    await _channel.invokeMethod<void>('write', {'key': key, 'value': value});
  }

  Future<void> delete({required String key}) =>
      _channel.invokeMethod<void>('delete', {'key': key});
}
