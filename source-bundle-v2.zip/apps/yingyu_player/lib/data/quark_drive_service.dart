import 'dart:convert';

import 'package:http/http.dart' as http;

import '../domain/models/cloud_media_source.dart';
import '../domain/models/media_playlist_item.dart';
import 'openlist_media_service.dart';

/// Direct Quark Cloud Drive access used by the Android client.
///
/// The mobile app deliberately talks to Quark with the cookie obtained from
/// the QR login.  No OpenList URL, admin token, or intermediate server is
/// needed.  The API returns short-lived download URLs, so links are resolved
/// immediately before playback or download.
class QuarkDriveService {
  QuarkDriveService(this._client);

  static const directBaseUrl = 'https://drive-pc.quark.cn/1/clouddrive';
  static const _baseUrls = [
    directBaseUrl,
    'https://drive.quark.cn/1/clouddrive',
    'https://drive-m.quark.cn/1/clouddrive',
  ];

  static const _videoExtensions = {
    'mkv',
    'mp4',
    'avi',
    'mov',
    'webm',
    'm4v',
    'ts',
    'mts',
    'm2ts',
    'mpeg',
    'mpg',
    'wmv',
    'flv',
    'vob',
    'rmvb',
  };
  static const _subtitleExtensions = {'srt', 'vtt', 'ass', 'ssa'};

  final http.Client _client;
  final Map<String, _QuarkCookieSession> _cookieSessions = {};

  Future<List<MediaPlaylistItem>> load(
    CloudMediaSource source, {
    int maxDepth = 8,
    int maxFiles = 1200,
  }) async {
    await _refreshSessionCookie(source);
    final files = <_QuarkFile>[];
    final rootFid = _rootFid(source.rootPath);
    await _walk(source, rootFid, '', 0, maxDepth, maxFiles, files);

    final subtitles = <String, List<_QuarkFile>>{};
    for (final file in files.where(
      (file) => _subtitleExtensions.contains(_extension(file.name)),
    )) {
      subtitles.putIfAbsent(_subtitleKey(file), () => []).add(file);
    }

    return [
      for (final file in files)
        if (_videoExtensions.contains(_extension(file.name)))
          MediaPlaylistItem(
            path: _identity(source.id, file.fid),
            title: file.name,
            group: file.parentPath.isEmpty
                ? '夸克网盘'
                : file.parentPath.split('/').last,
            sourceName: source.name,
            isOnline: true,
            isLive: false,
            cloudSourceId: source.id,
            // Direct Quark endpoints address files by fid, not by a path.
            remotePath: file.fid,
            remoteSubtitlePaths: [
              for (final subtitle
                  in subtitles[_subtitleKey(file)] ?? const <_QuarkFile>[])
                subtitle.fid,
            ],
          ),
    ];
  }

  Future<QuarkDriveResolvedFile> resolve(
    CloudMediaSource source,
    String fid, {
    String linkType = 'streaming',
  }) async {
    // Quark rotates __puus independently from the long-lived login cookies.
    // Refresh it immediately before asking for a short-lived CDN URL.
    await _refreshSessionCookie(source);
    final data = await _request(
      source,
      'POST',
      '/file/download',
      body: {
        'fids': [fid],
      },
    );
    final list = data is List ? data : const <Object?>[];
    final file = list.whereType<Map>().firstOrNull;
    if (file == null) {
      throw const QuarkDriveException('夸克没有返回该文件的播放地址。');
    }
    final url = [file['download_url'], file['preview_url'], file['url']]
        .map((value) => value?.toString().trim() ?? '')
        .map(Uri.tryParse)
        .whereType<Uri>()
        .where(
          (uri) =>
              uri.hasAuthority &&
              (uri.scheme == 'http' || uri.scheme == 'https'),
        )
        .firstOrNull;
    if (url == null) {
      throw const QuarkDriveException('夸克返回的播放地址无效或已过期。');
    }
    // Quark's signed OSS URL is not completely bearer-only.  The download
    // endpoint validates the Quark session cookie again when the media bytes
    // are requested.  Desktop browsers hide this detail because they send
    // their cookie jar automatically; media_kit on Android does not.
    return QuarkDriveResolvedFile(
      url: url.toString(),
      headers: _streamHeaders(_downloadCookie(source)),
    );
  }

  /// Returns the latest cookie jar, including a rotated `__puus`, so callers
  /// can persist it between app launches.
  String currentCookie(CloudMediaSource source) =>
      _serializeCookies(_cookiesFor(source));

  /// Replaces a runtime cookie jar after a new QR login.
  void resetSession(CloudMediaSource source) {
    final seed = _normalizeCookie(source.transferCredential);
    _cookieSessions[source.id] = _QuarkCookieSession(
      seed: seed,
      cookies: _parseCookies(seed),
    );
  }

  Future<void> _refreshSessionCookie(CloudMediaSource source) async {
    await _request(source, 'GET', '/config');
  }

  Future<void> _walk(
    CloudMediaSource source,
    String parentFid,
    String parentPath,
    int depth,
    int maxDepth,
    int maxFiles,
    List<_QuarkFile> output,
  ) async {
    if (depth > maxDepth || output.length >= maxFiles) return;
    final data = await _request(
      source,
      'GET',
      '/file/sort',
      query: {
        'pdir_fid': parentFid,
        '_page': '1',
        '_size': '100',
        '_fetch_total': '1',
        '_fetch_sub_dirs': '0',
        '_sort': 'file_type:asc,updated_at:desc',
      },
    );
    final entries = _listEntries(data);
    final childDirectories = <({String fid, String path})>[];
    for (final raw in entries) {
      if (output.length >= maxFiles) break;
      final fid = raw['fid']?.toString().trim() ?? '';
      final name = raw['file_name']?.toString().trim() ?? '';
      if (fid.isEmpty || name.isEmpty) continue;
      final isDirectory =
          raw['dir'] == true ||
          raw['dir']?.toString() == '1' ||
          (raw['file_type']?.toString() == '0' &&
              raw['category']?.toString() == '0');
      final childPath = parentPath.isEmpty ? name : '$parentPath/$name';
      if (isDirectory) {
        childDirectories.add((fid: fid, path: childPath));
      } else if (_videoExtensions.contains(_extension(name)) ||
          _subtitleExtensions.contains(_extension(name))) {
        output.add(_QuarkFile(fid: fid, name: name, parentPath: parentPath));
      }
    }
    await Future.wait(
      childDirectories.map(
        (directory) => _walk(
          source,
          directory.fid,
          directory.path,
          depth + 1,
          maxDepth,
          maxFiles,
          output,
        ),
      ),
    );
  }

  Future<Object?> _request(
    CloudMediaSource source,
    String method,
    String path, {
    Map<String, String> query = const {},
    Map<String, Object?> body = const {},
  }) async {
    final cookie = currentCookie(source);
    if (cookie.isEmpty) {
      throw const QuarkDriveException('请先扫码登录夸克网盘。');
    }
    QuarkDriveException? lastError;
    for (final base in _baseUrls) {
      final now = DateTime.now().millisecondsSinceEpoch;
      final uri = Uri.parse('$base$path').replace(
        queryParameters: {
          'pr': 'ucpro',
          'fr': 'pc',
          'uc_param_str': '',
          '__dt': '${now % 10000}',
          '__t': '$now',
          ...query,
        },
      );
      try {
        final request = http.Request(method, uri)
          ..headers.addAll(_headers(cookie));
        if (method == 'POST') request.body = jsonEncode(body);
        final response = await _client
            .send(request)
            .timeout(const Duration(seconds: 25));
        _mergeSetCookie(source, response.headers['set-cookie']);
        final text = await response.stream.bytesToString();
        final decoded = jsonDecode(text);
        if (decoded is! Map) {
          lastError = QuarkDriveException(
            '夸克返回格式无效（HTTP ${response.statusCode}）。',
          );
          continue;
        }
        final code = _number(decoded['code']);
        if (response.statusCode >= 200 &&
            response.statusCode < 300 &&
            (code == 0 || code == 200)) {
          return decoded['data'];
        }
        final message = decoded['message']?.toString().trim();
        lastError = QuarkDriveException(
          message?.isNotEmpty == true
              ? message!
              : '夸克接口请求失败（HTTP ${response.statusCode}）。',
        );
        if (response.statusCode < 500 && response.statusCode != 404) {
          break;
        }
      } on QuarkDriveException {
        rethrow;
      } on FormatException {
        lastError = const QuarkDriveException('夸克返回格式无效。');
      } on Object catch (error) {
        lastError = QuarkDriveException('无法连接夸克网盘：$error');
      }
    }
    throw lastError ?? const QuarkDriveException('夸克接口请求失败。');
  }

  Map<String, String> _headers(String cookie) => {
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json',
    'Cookie': _normalizeCookie(cookie),
    'Origin': 'https://pan.quark.cn',
    'Referer': 'https://pan.quark.cn/',
    'User-Agent': 'quark-cloud-drive/2.5.56',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
  };

  static Map<String, String> _streamHeaders(String cookie) => {
    'Accept': '*/*',
    'Cookie': _normalizeCookie(cookie),
    'Origin': 'https://pan.quark.cn',
    'Referer': 'https://pan.quark.cn/',
    'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/128.0.0.0 Safari/537.36',
  };

  static String _normalizeCookie(String value) {
    var cookie = value.trim();
    if (cookie.toLowerCase().startsWith('cookie:')) {
      cookie = cookie.substring('cookie:'.length).trim();
    }
    return cookie;
  }

  Map<String, String> _cookiesFor(CloudMediaSource source) {
    final seed = _normalizeCookie(source.transferCredential);
    final current = _cookieSessions[source.id];
    if (current == null || current.seed != seed) {
      final replacement = _QuarkCookieSession(
        seed: seed,
        cookies: _parseCookies(seed),
      );
      _cookieSessions[source.id] = replacement;
      return replacement.cookies;
    }
    return current.cookies;
  }

  String _downloadCookie(CloudMediaSource source) {
    final cookies = _cookiesFor(source);
    final puus = cookies['__puus']?.trim();
    // The CDN validates the freshly rotated drive-pc cookie. Sending only
    // this cookie also avoids an older same-name cookie from another Quark
    // domain winning during header parsing.
    if (puus?.isNotEmpty == true) return '__puus=$puus';
    return _serializeCookies(cookies);
  }

  void _mergeSetCookie(CloudMediaSource source, String? header) {
    if (header == null || header.trim().isEmpty) return;
    final cookies = _cookiesFor(source);
    for (final match in RegExp(
      r'(?:^|,\s*)([^=;,\s]+)=([^;]*)',
    ).allMatches(header)) {
      final name = match.group(1)?.trim() ?? '';
      final value = match.group(2)?.trim() ?? '';
      if (name.isEmpty) continue;
      if (value.isEmpty) {
        cookies.remove(name);
      } else {
        cookies[name] = value;
      }
    }
  }

  static Map<String, String> _parseCookies(String value) {
    final output = <String, String>{};
    for (final part in _normalizeCookie(value).split(';')) {
      final separator = part.indexOf('=');
      if (separator <= 0) continue;
      final name = part.substring(0, separator).trim();
      final cookieValue = part.substring(separator + 1).trim();
      if (name.isNotEmpty && cookieValue.isNotEmpty) {
        output[name] = cookieValue;
      }
    }
    return output;
  }

  static String _serializeCookies(Map<String, String> cookies) => cookies
      .entries
      .where((entry) => entry.key.isNotEmpty && entry.value.isNotEmpty)
      .map((entry) => '${entry.key}=${entry.value}')
      .join('; ');

  static List<Map<String, dynamic>> _listEntries(Object? data) {
    if (data is! Map) return const [];
    final rawList = data['list'];
    if (rawList is! List) return const [];
    final output = <Map<String, dynamic>>[];
    for (final value in rawList) {
      if (value is Map && value['files'] is List) {
        for (final child in value['files'] as List) {
          if (child is Map) output.add(child.cast<String, dynamic>());
        }
      } else if (value is Map) {
        output.add(value.cast<String, dynamic>());
      }
    }
    return output;
  }

  static String _rootFid(String value) {
    final normalized = value.trim();
    return normalized.isEmpty || normalized == '/' ? '0' : normalized;
  }

  static String _extension(String path) {
    final dot = path.lastIndexOf('.');
    return dot < 0 ? '' : path.substring(dot + 1).toLowerCase();
  }

  static String _subtitleKey(_QuarkFile file) {
    final stem = file.name
        .replaceFirst(RegExp(r'\.[^.\\/]+$'), '')
        .toLowerCase();
    return '${file.parentPath.toLowerCase()}|$stem';
  }

  static String _identity(String sourceId, String fid) =>
      Uri(scheme: 'quark', host: sourceId, path: '/$fid').toString();

  static int _number(Object? value) => value is num
      ? value.toInt()
      : int.tryParse(value?.toString() ?? '') ?? -1;
}

class QuarkDriveResolvedFile extends OpenListResolvedFile {
  const QuarkDriveResolvedFile({required super.url, required super.headers});
}

class QuarkDriveException implements Exception {
  const QuarkDriveException(this.message);

  final String message;

  @override
  String toString() => message;
}

class _QuarkFile {
  const _QuarkFile({
    required this.fid,
    required this.name,
    required this.parentPath,
  });

  final String fid;
  final String name;
  final String parentPath;
}

class _QuarkCookieSession {
  const _QuarkCookieSession({required this.seed, required this.cookies});

  final String seed;
  final Map<String, String> cookies;
}
