import 'dart:convert';

import 'package:http/http.dart' as http;

import '../domain/models/cloud_media_source.dart';
import '../domain/models/media_playlist_item.dart';

class OpenListResolvedFile {
  const OpenListResolvedFile({required this.url, required this.headers});
  final String url;
  final Map<String, String> headers;
}

class OpenListMediaService {
  const OpenListMediaService(this._client);

  final http.Client _client;

  static const _videoExtensions = {
    'mkv',
    'mp4',
    'avi',
    'mov',
    'webm',
    'm4v',
    'ts',
    'mts',
    'm2ts',
    'mpeg',
    'mpg',
    'wmv',
    'flv',
    'vob',
    'rmvb',
  };
  static const _subtitleExtensions = {'srt', 'vtt', 'ass', 'ssa'};

  Future<List<MediaPlaylistItem>> load(
    CloudMediaSource source, {
    int maxDepth = 5,
    int maxFiles = 800,
  }) async {
    final discovered = <_CloudFile>[];
    await _walk(
      source,
      _normalizePath(source.rootPath),
      0,
      maxDepth,
      maxFiles,
      discovered,
    );
    final subtitles = <String, List<String>>{};
    for (final file in discovered.where(
      (file) => _subtitleExtensions.contains(_extension(file.path)),
    )) {
      subtitles.putIfAbsent(_baseName(file.path), () => []).add(file.path);
    }
    return [
      for (final file in discovered)
        if (_videoExtensions.contains(_extension(file.path)))
          MediaPlaylistItem(
            path: _identity(source.id, file.path),
            title: file.name,
            group: _parentLabel(file.path),
            sourceName: source.name,
            isOnline: true,
            isLive: false,
            cloudSourceId: source.id,
            remotePath: file.path,
            remoteSubtitlePaths: _matchingSubtitlePaths(file.path, subtitles),
          ),
    ];
  }

  Future<OpenListResolvedFile> resolve(
    CloudMediaSource source,
    String path, {
    String linkType = 'streaming',
  }) async {
    Map<String, dynamic> data;
    try {
      // fs/link returns a fresh, signed and range-capable URL. fs/get's
      // raw_url may be an unsigned /p/ proxy path (expire missing) when web
      // proxying is enabled, which makes remote playback fail or stall.
      data = await _post(source, '/api/fs/link', {
        'path': path,
        'password': '',
        'type': linkType,
      });
    } on OpenListException {
      // Keep compatibility with older OpenList releases without fs/link.
      data = await _post(source, '/api/fs/get', {'path': path});
    }
    final rawUrlValues =
        [
          data['url'],
          data['raw_url'],
          data['download_url'],
          data['proxy_url'],
        ].map((value) => value?.toString().trim() ?? '').where((value) {
          final uri = Uri.tryParse(value);
          return uri != null &&
              (uri.scheme == 'http' || uri.scheme == 'https') &&
              uri.host.isNotEmpty;
        });
    final rawUrlValue = rawUrlValues.firstOrNull ?? '';
    if (rawUrlValue.isEmpty) {
      final fallback = '${source.baseUrl.replaceAll(RegExp(r'/$'), '')}/d$path';
      final fallbackUri = Uri.tryParse(fallback);
      if (fallbackUri != null && fallbackUri.hasAuthority) {
        return OpenListResolvedFile(
          url: fallbackUri.toString(),
          headers: {'Authorization': source.apiToken},
        );
      }
      throw const OpenListException('网盘没有返回可播放或下载的直链。');
    }
    final rawUri = Uri.parse(rawUrlValue);
    final rawUrl = rawUri.hasScheme
        ? rawUri.toString()
        : Uri.parse(
            '${source.baseUrl.replaceAll(RegExp(r'/$'), '')}/',
          ).resolveUri(rawUri).toString();
    final headers = <String, String>{};
    final rawHeaders = data['header'] ?? data['headers'];
    if (rawHeaders is Map) {
      for (final entry in rawHeaders.entries) {
        headers[entry.key.toString()] = entry.value.toString();
      }
    }
    return OpenListResolvedFile(url: rawUrl, headers: headers);
  }

  Future<void> _walk(
    CloudMediaSource source,
    String path,
    int depth,
    int maxDepth,
    int maxFiles,
    List<_CloudFile> output,
  ) async {
    if (depth > maxDepth || output.length >= maxFiles) return;
    final data = await _post(source, '/api/fs/list', {
      'path': path,
      'password': '',
      'page': 1,
      'per_page': 0,
      'refresh': false,
    });
    final content = data['content'];
    if (content is! List) return;
    final childDirectories = <String>[];
    for (final raw in content) {
      if (raw is! Map || output.length >= maxFiles) break;
      final name = raw['name']?.toString() ?? '';
      if (name.isEmpty) continue;
      final childPath = _join(path, name);
      final isDirectory = raw['is_dir'] == true || raw['type'] == 1;
      if (isDirectory) {
        childDirectories.add(childPath);
      } else if (_isScannableSubtitleOrVideo(childPath)) {
        // Do not let unrelated APKs, archives, photos, and backups consume
        // the scan budget before the actual movies and sidecar subtitles.
        output.add(_CloudFile(name: name, path: childPath));
      }
    }
    // Sibling folders are independent OpenList requests. Fetch them together
    // so a large cloud library does not feel like a serial directory crawl.
    await Future.wait(
      childDirectories.map(
        (childPath) =>
            _walk(source, childPath, depth + 1, maxDepth, maxFiles, output),
      ),
    );
  }

  bool _isScannableSubtitleOrVideo(String path) {
    final extension = _extension(path);
    return _videoExtensions.contains(extension) ||
        _subtitleExtensions.contains(extension);
  }

  List<String> _matchingSubtitlePaths(
    String videoPath,
    Map<String, List<String>> subtitles,
  ) {
    final stem = _baseName(videoPath);
    final exact = subtitles[stem];
    if (exact != null && exact.isNotEmpty) return List<String>.from(exact);

    // Common releases append a language/track suffix to the sidecar name,
    // e.g. `Movie.en.ass` or `Movie.zh-CN.srt`.
    final matches = <String>[];
    for (final entry in subtitles.entries) {
      if (entry.key.startsWith('$stem.') ||
          entry.key.startsWith('${stem}_') ||
          entry.key.startsWith('$stem-')) {
        matches.addAll(entry.value);
      }
    }
    return matches;
  }

  Future<Map<String, dynamic>> _post(
    CloudMediaSource source,
    String endpoint,
    Map<String, Object> body,
  ) async {
    final base = source.baseUrl.trim().replaceAll(RegExp(r'/$'), '');
    final response = await _client
        .post(
          Uri.parse('$base$endpoint'),
          headers: {
            'Authorization': source.apiToken,
            'Content-Type': 'application/json',
          },
          body: jsonEncode(body),
        )
        .timeout(const Duration(seconds: 18));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw OpenListException('OpenList 请求失败（HTTP ${response.statusCode}）。');
    }
    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    if (decoded is! Map) throw const OpenListException('OpenList 返回格式无效。');
    final code = decoded['code'];
    if (code is num && code != 200) {
      throw OpenListException(
        decoded['message']?.toString() ?? 'OpenList 请求失败。',
      );
    }
    final data = decoded['data'];
    if (data is! Map) throw const OpenListException('OpenList 没有返回数据。');
    return data.cast<String, dynamic>();
  }

  static String _normalizePath(String value) {
    var path = value.trim().replaceAll('\\', '/');
    if (path.isEmpty) return '/';
    if (!path.startsWith('/')) path = '/$path';
    return path.length > 1 ? path.replaceAll(RegExp(r'/+$'), '') : path;
  }

  static String _join(String parent, String name) =>
      parent == '/' ? '/$name' : '$parent/$name';

  static String _extension(String path) {
    final dot = path.lastIndexOf('.');
    return dot < 0 ? '' : path.substring(dot + 1).toLowerCase();
  }

  static String _baseName(String path) =>
      path.replaceFirst(RegExp(r'\.[^.\/]+$'), '').toLowerCase();

  static String _parentLabel(String path) {
    final parts = path.split('/').where((part) => part.isNotEmpty).toList();
    return parts.length > 1 ? parts[parts.length - 2] : '网盘影视';
  }

  static String _identity(String sourceId, String path) =>
      Uri(scheme: 'openlist', host: sourceId, path: path).toString();
}

class _CloudFile {
  const _CloudFile({required this.name, required this.path});
  final String name;
  final String path;
}

class OpenListException implements Exception {
  const OpenListException(this.message);
  final String message;
}
