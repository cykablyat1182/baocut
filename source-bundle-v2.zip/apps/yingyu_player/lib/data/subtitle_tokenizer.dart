class SubtitleToken {
  const SubtitleToken(this.text, {required this.queryable});

  final String text;
  final bool queryable;
}

// Covers the writing systems most commonly encountered in imported subtitles.
// CJK runs are kept together because selecting a phrase is more useful than
// querying an isolated character when no language-specific segmenter exists.
final RegExp _subtitleTokenPattern = RegExp(
  r"[A-Za-z\u00C0-\u024F]+(?:['’\-][A-Za-z\u00C0-\u024F]+)*"
  r'|[\u3040-\u30FF\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]+'
  r'|[\uAC00-\uD7AF]+'
  r'|[\u0370-\u052F]+'
  r'|[\u0590-\u08FF]+'
  r'|[\u0900-\u097F]+'
  r"|[^A-Za-z\u00C0-\u024F\u3040-\u30FF\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF\uAC00-\uD7AF\u0370-\u052F\u0590-\u08FF\u0900-\u097F]+",
  unicode: true,
);

final RegExp _queryablePattern = RegExp(
  r'^[A-Za-z\u00C0-\u024F\u3040-\u30FF\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF\uAC00-\uD7AF\u0370-\u052F\u0590-\u08FF\u0900-\u097F]',
  unicode: true,
);

List<SubtitleToken> tokenizeSubtitle(String text) => [
  for (final match in _subtitleTokenPattern.allMatches(text))
    SubtitleToken(
      match.group(0)!,
      queryable: _queryablePattern.hasMatch(match.group(0)!),
    ),
];

/// Normalizes accidental whitespace in subtitle text without flattening
/// intentional line breaks. Embedded subtitle tracks can contain repeated
/// spaces, tabs, and Unicode spacing characters that otherwise appear as
/// visibly inconsistent gaps between words.
String normalizeSubtitleDisplaySpacing(String text) {
  final lines = text
      .replaceAll('\r\n', '\n')
      .replaceAll('\r', '\n')
      .split('\n');
  return lines
      .map((line) => line.replaceAll(RegExp(r'\s+'), ' ').trim())
      .join('\n')
      .trim();
}

String normalizeSubtitleQuery(String value) =>
    value.trim().toLowerCase().replaceAll('’', "'");
