import 'dart:convert';
import 'dart:typed_data';

import '../domain/models/subtitle_cue.dart';

class SubtitleParser {
  const SubtitleParser();

  List<SubtitleCue> parseBytes(Uint8List bytes, {required String fileName}) {
    final text = _decode(bytes);
    final extension = fileName.split('.').last.toLowerCase();
    return switch (extension) {
      'vtt' => parseVtt(text),
      'ass' || 'ssa' => parseAss(text),
      _ => parseSrt(text),
    };
  }

  List<SubtitleCue> parseSrt(String input) {
    final normalized = _normalize(input);
    final blocks = normalized.split(RegExp(r'\n\s*\n'));
    final cues = <SubtitleCue>[];

    for (final block in blocks) {
      final lines = block
          .split('\n')
          .map((line) => line.trimRight())
          .where((line) => line.trim().isNotEmpty)
          .toList();
      if (lines.isEmpty) continue;

      final timeLineIndex = lines.indexWhere((line) => line.contains('-->'));
      if (timeLineIndex < 0) continue;
      final times = _parseTimeRange(lines[timeLineIndex]);
      if (times == null) continue;

      final textLines = lines.skip(timeLineIndex + 1).toList();
      final content = _finalizeContent(_classifyLines(textLines));
      if (content.$1.isEmpty && content.$2.isEmpty) continue;

      cues.add(
        SubtitleCue(
          id: _cueId(cues.length, times.$1),
          start: times.$1,
          end: times.$2,
          original: content.$1,
          translation: content.$2,
        ),
      );
    }
    return _sanitize(cues);
  }

  List<SubtitleCue> parseVtt(String input) {
    final normalized = _normalize(
      input,
    ).replaceFirst(RegExp(r'^WEBVTT[^\n]*\n+'), '');
    return parseSrt(normalized);
  }

  List<SubtitleCue> parseAss(String input) {
    final cues = <SubtitleCue>[];
    for (final rawLine in _normalize(input).split('\n')) {
      if (!rawLine.startsWith('Dialogue:')) continue;
      final payload = rawLine.substring('Dialogue:'.length).trimLeft();
      final fields = payload.split(',');
      if (fields.length < 10) continue;

      final start = _parseAssTime(fields[1]);
      final end = _parseAssTime(fields[2]);
      if (start == null || end == null || end <= start) continue;

      final style = fields[3];
      final text = fields
          .sublist(9)
          .join(',')
          .replaceAll(RegExp(r'\{[^}]*\}'), '')
          .replaceAll(r'\N', '\n')
          .replaceAll(r'\n', '\n');
      final content = _classifyLines(
        text.split('\n'),
        languageHint: _languageHintFromStyle(style),
      );
      cues.add(
        SubtitleCue(
          id: _cueId(cues.length, start),
          start: start,
          end: end,
          original: content.$1,
          translation: content.$2,
        ),
      );
    }
    return _sanitize(cues);
  }

  String _decode(Uint8List bytes) {
    if (bytes.length >= 2) {
      if (bytes[0] == 0xFF && bytes[1] == 0xFE) {
        return _decodeUtf16(bytes.sublist(2), littleEndian: true);
      }
      if (bytes[0] == 0xFE && bytes[1] == 0xFF) {
        return _decodeUtf16(bytes.sublist(2), littleEndian: false);
      }
    }
    final offset =
        bytes.length >= 3 &&
            bytes[0] == 0xEF &&
            bytes[1] == 0xBB &&
            bytes[2] == 0xBF
        ? 3
        : 0;
    return utf8.decode(bytes.sublist(offset), allowMalformed: true);
  }

  String _decodeUtf16(Uint8List bytes, {required bool littleEndian}) {
    final codeUnits = <int>[];
    for (var index = 0; index + 1 < bytes.length; index += 2) {
      final first = bytes[index];
      final second = bytes[index + 1];
      codeUnits.add(
        littleEndian ? first | (second << 8) : (first << 8) | second,
      );
    }
    return String.fromCharCodes(codeUnits);
  }

  String _normalize(String text) {
    return text
        .replaceAll('\r\n', '\n')
        .replaceAll('\r', '\n')
        .replaceAll('\uFEFF', '')
        .trim();
  }

  (Duration, Duration)? _parseTimeRange(String line) {
    final parts = line.split('-->');
    if (parts.length != 2) return null;
    final start = _parseTimestamp(parts.first.trim());
    final endToken = parts.last.trim().split(RegExp(r'\s+')).first;
    final end = _parseTimestamp(endToken);
    if (start == null || end == null || end <= start) return null;
    return (start, end);
  }

  Duration? _parseTimestamp(String value) {
    final normalized = value.replaceAll(',', '.');
    final match = RegExp(
      r'^(?:(\d{1,2}):)?(\d{1,2}):(\d{1,2})(?:\.(\d{1,3}))?$',
    ).firstMatch(normalized);
    if (match == null) return null;

    final hours = int.tryParse(match.group(1) ?? '0') ?? 0;
    final minutes = int.tryParse(match.group(2) ?? '0') ?? 0;
    final seconds = int.tryParse(match.group(3) ?? '0') ?? 0;
    final fraction = match.group(4) ?? '0';
    final milliseconds = int.parse(fraction.padRight(3, '0').substring(0, 3));
    return Duration(
      hours: hours,
      minutes: minutes,
      seconds: seconds,
      milliseconds: milliseconds,
    );
  }

  Duration? _parseAssTime(String value) {
    final match = RegExp(
      // FFmpeg can emit a cue that started just before an input-side `-ss`
      // as `0:00:-00.50`; accept both that form and a leading minus sign so
      // windowed extraction can keep the cue active at the window boundary.
      r'^(-?)(\d+):(\d{1,2}):(-?\d{1,2})[.](\d{1,2})$',
    ).firstMatch(value.trim());
    if (match == null) return null;
    final rawSeconds = int.parse(match.group(4)!);
    final sign = match.group(1) == '-' || match.group(4)!.startsWith('-')
        ? -1
        : 1;
    final totalMilliseconds =
        (int.parse(match.group(2)!) * Duration.millisecondsPerHour) +
        (int.parse(match.group(3)!) * Duration.millisecondsPerMinute) +
        (rawSeconds.abs() * Duration.millisecondsPerSecond) +
        (int.parse(match.group(5)!) * 10);
    return Duration(milliseconds: sign * totalMilliseconds);
  }

  (String, String) _classifyLines(
    Iterable<String> rawLines, {
    _SubtitleLanguageHint? languageHint,
  }) {
    final original = <String>[];
    final translation = <String>[];

    for (final raw in rawLines) {
      final line = raw
          .replaceAll(RegExp(r'<[^>]+>'), '')
          .replaceAll(RegExp(r'\s+'), ' ')
          .trim();
      if (line.isEmpty) continue;
      if (languageHint == _SubtitleLanguageHint.original) {
        original.add(line);
      } else if (languageHint == _SubtitleLanguageHint.translation) {
        translation.add(line);
      } else if (_containsJapaneseKana(line)) {
        original.add(line);
      } else if (_containsCjk(line)) {
        translation.add(line);
      } else {
        original.add(line);
      }
    }

    return (original.join(' '), translation.join(' '));
  }

  (String, String) _finalizeContent((String, String) content) {
    final original = content.$1.trim();
    final translation = content.$2.trim();
    if (original.isEmpty && translation.isNotEmpty) {
      return (translation, '');
    }
    if (original == translation) return (original, '');
    return (original, translation);
  }

  _SubtitleLanguageHint? _languageHintFromStyle(String style) {
    final normalized = style.trim().toLowerCase();
    if (RegExp(
      r'(^|[\s_-])(jp|jpn|ja|japanese)(?=$|[\s_-])',
    ).hasMatch(normalized)) {
      return _SubtitleLanguageHint.original;
    }
    if (RegExp(
      r'(^|[\s_-])(cn|chs|cht|zh|zho|chi|gb|big5|sc|tc)(?=$|[\s_-])',
    ).hasMatch(normalized)) {
      return _SubtitleLanguageHint.translation;
    }
    return null;
  }

  bool _containsCjk(String value) {
    return RegExp(r'[\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]').hasMatch(value);
  }

  bool _containsJapaneseKana(String value) {
    return RegExp(r'[\u3040-\u30FF]').hasMatch(value);
  }

  List<SubtitleCue> _sanitize(List<SubtitleCue> cues) {
    cues.sort((a, b) {
      final byStart = a.start.compareTo(b.start);
      return byStart != 0 ? byStart : a.end.compareTo(b.end);
    });
    final merged = <SubtitleCue>[];
    for (final cue in cues) {
      if (cue.end <= cue.start) continue;
      if (merged.isNotEmpty &&
          merged.last.start == cue.start &&
          merged.last.end == cue.end) {
        final previous = merged.removeLast();
        merged.add(
          previous.copyWith(
            original: _joinUnique(previous.original, cue.original),
            translation: _joinUnique(previous.translation, cue.translation),
          ),
        );
      } else {
        merged.add(cue);
      }
    }

    final result = <SubtitleCue>[];
    for (var index = 0; index < merged.length; index++) {
      final cue = merged[index];
      final content = _finalizeContent((cue.original, cue.translation));
      if (content.$1.isEmpty && content.$2.isEmpty) continue;
      result.add(
        cue.copyWith(
          id: _cueId(index, cue.start),
          original: content.$1,
          translation: content.$2,
        ),
      );
    }
    return result;
  }

  String _joinUnique(String first, String second) {
    final values = <String>[];
    for (final value in [first.trim(), second.trim()]) {
      if (value.isNotEmpty && !values.contains(value)) values.add(value);
    }
    return values.join(' ');
  }

  String _cueId(int index, Duration start) =>
      'cue-${index + 1}-${start.inMilliseconds}';
}

/// Removes hearing-impaired/SDH cues while keeping spoken dialogue intact.
///
/// SDH markers are deliberately matched conservatively: a normal sentence
/// such as "I hear music" is retained, while bracketed sound descriptions,
/// music symbols, and standalone audio annotations are hidden.
class SubtitleCueFilter {
  const SubtitleCueFilter._();

  static List<SubtitleCue> withoutHearingImpaired(Iterable<SubtitleCue> cues) {
    final filtered = <SubtitleCue>[];
    for (final cue in cues) {
      // A parenthesized caption can have a plain-text translation paired with
      // it. Treat the bilingual pair as one SDH event so the translation is
      // not left behind as an orphaned subtitle.
      if (_isEntirelyParenthesized(cue.original) ||
          _isEntirelyParenthesized(cue.translation)) {
        continue;
      }
      final original = cleanText(cue.original);
      final translation = cleanText(cue.translation);
      if (original.isEmpty && translation.isEmpty) continue;
      filtered.add(cue.copyWith(original: original, translation: translation));
    }
    return coalesceNearDuplicates(filtered);
  }

  /// Collapses a repeated original that is emitted twice by some muxes when
  /// only one of the events has a translated line.  We only join adjacent
  /// cues with the same normalized original and compatible translations; a
  /// repeated sentence later in the episode remains a separate cue.
  static List<SubtitleCue> coalesceNearDuplicates(
    Iterable<SubtitleCue> cues, {
    Duration maxGap = const Duration(milliseconds: 1500),
  }) {
    final sorted = List<SubtitleCue>.from(cues)
      ..sort((first, second) {
        final byStart = first.start.compareTo(second.start);
        return byStart != 0 ? byStart : first.end.compareTo(second.end);
      });
    final result = <SubtitleCue>[];
    for (final cue in sorted) {
      if (result.isEmpty) {
        result.add(cue);
        continue;
      }
      final previous = result.last;
      final sameOriginal = _sameOrNestedOriginal(
        previous.original,
        cue.original,
      );
      final nextStartLimit = previous.end + maxGap;
      final near = cue.start <= nextStartLimit;
      final previousTranslation = previous.translation.trim();
      final cueTranslation = cue.translation.trim();
      final compatibleTranslation =
          previousTranslation.isEmpty ||
          cueTranslation.isEmpty ||
          _normalizeForDuplicate(previousTranslation) ==
              _normalizeForDuplicate(cueTranslation);
      if (!sameOriginal || !near || !compatibleTranslation) {
        result.add(cue);
        continue;
      }

      final original = previous.original.length >= cue.original.length
          ? previous.original
          : cue.original;
      final translation = previousTranslation.isNotEmpty
          ? previous.translation
          : cue.translation;
      result[result.length - 1] = previous.copyWith(
        start: previous.start <= cue.start ? previous.start : cue.start,
        end: previous.end >= cue.end ? previous.end : cue.end,
        original: original,
        translation: translation,
      );
    }
    return result;
  }

  static String _normalizeForDuplicate(String value) {
    return value
        .trim()
        .toLowerCase()
        .replaceFirst(RegExp(r'^[\-–—•·]+\s*'), '')
        .replaceAll(RegExp(r'\s+'), ' ');
  }

  static bool _sameOrNestedOriginal(String first, String second) {
    final normalizedFirst = _normalizeForDuplicate(first);
    final normalizedSecond = _normalizeForDuplicate(second);
    if (normalizedFirst == normalizedSecond) return true;
    final shorterText = normalizedFirst.length <= normalizedSecond.length
        ? normalizedFirst
        : normalizedSecond;
    final longerText = normalizedFirst.length > normalizedSecond.length
        ? normalizedFirst
        : normalizedSecond;
    if (shorterText.length >= 8 && longerText.contains(shorterText)) {
      return true;
    }

    final firstLines = _duplicateLines(first);
    final secondLines = _duplicateLines(second);
    if (firstLines.isEmpty || secondLines.isEmpty) return false;
    if (firstLines.length == secondLines.length) {
      return firstLines.join(' ') == secondLines.join(' ');
    }
    final longer = firstLines.length > secondLines.length
        ? firstLines
        : secondLines;
    final shorter = firstLines.length > secondLines.length
        ? secondLines
        : firstLines;
    return shorter.every(longer.contains);
  }

  static List<String> _duplicateLines(String value) {
    return value
        .replaceAll('\r\n', '\n')
        .replaceAll('\r', '\n')
        .split('\n')
        .map(_normalizeForDuplicate)
        .where((line) => line.isNotEmpty)
        .toList();
  }

  static String cleanText(String text) {
    final lines = text
        .replaceAll('\r\n', '\n')
        .replaceAll('\r', '\n')
        .split('\n')
        .map(_removeHearingImpairedFragments)
        .map((line) => line.trim())
        .where((line) => line.isNotEmpty && !_isHearingImpairedLine(line))
        .toList();
    return lines.join('\n');
  }

  static String _removeHearingImpairedFragments(String value) {
    // When the user enables the SDH filter, a subtitle line wholly enclosed
    // by parentheses is an accessibility annotation even if its wording is
    // unfamiliar (for example, a character/track-specific sound description).
    // Check the complete line here so ordinary inline parentheses in dialogue
    // such as "I think (maybe) we should go" are left untouched.
    if (_isParenthesizedLine(value.trim())) return '';

    final pattern = RegExp(
      r'(?:\([^()\n]+\)|\[[^\[\]\n]+\]|\{[^{}\n]+\}|'
      r'（[^（）\n]+）|【[^【】\n]+】|〈[^〈〉\n]+〉)',
    );
    final cleaned = value
        .replaceAllMapped(pattern, (match) {
          final fragment = match.group(0)!;
          return _isHearingImpairedLine(fragment) ? '' : fragment;
        })
        .replaceAll(RegExp(r'\s+'), ' ')
        .replaceFirst(RegExp(r'^\s*[-–—]\s+(?=[-–—])'), '');
    return RegExp(r'^\s*[-–—•·]+\s*$').hasMatch(cleaned) ? '' : cleaned;
  }

  static bool _isEntirelyParenthesized(String value) {
    final lines = value
        .replaceAll('\r\n', '\n')
        .replaceAll('\r', '\n')
        .split('\n')
        .map((line) => line.trim())
        .where((line) => line.isNotEmpty)
        .toList();
    return lines.isNotEmpty && lines.every(_isParenthesizedLine);
  }

  static bool _isParenthesizedLine(String value) {
    if (value.length < 2) return false;
    final pair = switch ((value[0], value[value.length - 1])) {
      ('(', ')') => ('(', ')'),
      ('（', '）') => ('（', '）'),
      _ => null,
    };
    if (pair == null) return false;

    var depth = 0;
    for (var index = 0; index < value.length; index++) {
      final character = value[index];
      if (character == pair.$1) {
        depth++;
      } else if (character == pair.$2) {
        depth--;
        if (depth < 0 || (depth == 0 && index != value.length - 1)) {
          return false;
        }
      }
    }
    return depth == 0;
  }

  static bool _isHearingImpairedLine(String value) {
    var candidate = value.trim();
    if (candidate.isEmpty) return true;
    candidate = candidate.replaceFirst(RegExp(r'^[•·]\s*'), '');
    if (candidate.contains('♪') || candidate.contains('♫')) return true;

    final normalized = candidate
        .toLowerCase()
        .replaceAll(RegExp(r'[_–—-]+'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    final wrapped = RegExp(
      r'^(?:\([^()]+\)|\[[^\[\]]+\]|\{[^{}]+\}|（[^（）]+）|【[^【】]+】|〈[^〈〉]+〉)$',
    ).hasMatch(candidate);
    final marker = RegExp(
      r'\b(?:indistinct|inaudible|unintelligible|muffled|chatter|'
      r'laugh(?:s|ter|ing)?|chuckle(?:s|ing)?|giggle(?:s|ing)?|'
      r'sigh(?:s|ing)?|cry(?:ing)?|sob(?:s|bing)?|whisper(?:s|ing)?|'
      r'scream(?:s|ing)?|shout(?:s|ing)?|yell(?:s|ing)?|'
      r'applause|cheer(?:s|ing)?|crowd|noise|static|'
      r'footsteps?|breathing|heartbeat|heart beating|'
      r'door(?:bell)?|phone ringing|ring(?:s|ing)?|alarm|'
      r'beep(?:s|ing)?|buzz(?:es|ing)?|thunder|wind|'
      r'music|sing(?:s|ing)?|song|siren|wail(?:s|ing)?|'
      r'horn|honk(?:s|ing)?|grunt(?:s|ing)?|groan(?:s|ing)?|'
      r'growl(?:s|ing)?|roar(?:s|ing)?|gasp(?:s|ing)?|pant(?:s|ing)?|'
      r'cough(?:s|ing)?|sneez(?:es|ing)?|sniff(?:s|ing)?|snort(?:s|ing)?|'
      r'moan(?:s|ing)?|whimper(?:s|ing)?|bark(?:s|ing)?|'
      r'engine|motor|traffic|radio|television|tv|over tv|on tv)\b',
    ).hasMatch(normalized);
    final cjkMarker = RegExp(
      r'(?:音乐|背景音乐|歌声|掌声|笑声|笑|哭声|哭泣|抽泣|'
      r'叹气|叹息|耳语|低语|尖叫|喊叫|欢呼|人群|喧哗|喧闹|'
      r'嘈杂|杂音|静电|脚步声|呼吸声|心跳|门铃|电话铃|铃声|'
      r'警报|哔声|蜂鸣|雷声|风声|电视声|雨声|敲门声|关门声|'
      r'警笛|汽笛|喇叭|鸣笛|呻吟|咕哝|喘息|咳嗽|喷嚏|抽鼻子|'
      r'引擎|发动机|车流|收音机|电视机|电视|音楽|笑い声|拍手|'
      r'足音|ため息|叫び声|喧騒|風音|ドアベル)',
    ).hasMatch(candidate);
    if (wrapped && (marker || cjkMarker)) return true;

    return RegExp(
      r'^(?:music|singing|applause|laugh(?:ter|ing)?|'
      r'inaudible|indistinct chatter|static|sound of .+|'
      r'音乐|背景音乐|歌声|掌声|笑声|哭声|抽泣|叹气|耳语|'
      r'喧哗|喧闹|嘈杂|杂音|静电|脚步声|呼吸声|心跳|门铃|'
      r'电话铃|铃声|警报|哔声|蜂鸣|雷声|风声|电视声|雨声|'
      r'音楽|笑い声|拍手|足音|ため息|叫び声|喧騒|ドアベル|'
      r'警笛|汽笛|喇叭|鸣笛|呻吟|咕哝|喘息|咳嗽|喷嚏|抽鼻子|'
      r'引擎|发动机|车流|收音机|电视机|电视)$',
    ).hasMatch(normalized);
  }
}

enum _SubtitleLanguageHint { original, translation }
