import 'dart:async';
import 'dart:collection';
import 'dart:io';
import 'dart:math';

/// Loopback streaming bridge for native players that do not reliably forward
/// authentication headers to cloud-drive download URLs on Android.
///
/// The bridge is bound to 127.0.0.1 only.  A random route token maps a local
/// media URL to one Quark signed URL and its required request headers.  Range
/// requests are forwarded so seeking does not turn into a full-file download.
class AuthenticatedMediaProxy {
  AuthenticatedMediaProxy({bool Function(Uri)? remoteValidator})
    : _remoteValidator = remoteValidator ?? _isQuarkRemote,
      _client = (HttpClient()
        ..autoUncompress = false
        ..connectionTimeout = const Duration(seconds: 20));

  final HttpClient _client;
  final bool Function(Uri) _remoteValidator;
  final LinkedHashMap<String, _ProxyTarget> _targets = LinkedHashMap();
  final Random _random = Random.secure();

  HttpServer? _server;
  StreamSubscription<HttpRequest>? _subscription;
  int _sequence = 0;

  Future<Uri> register({
    required Uri remoteUrl,
    required Map<String, String> headers,
    required String fileName,
  }) async {
    if (!_remoteValidator(remoteUrl)) {
      throw const AuthenticatedMediaProxyException('夸克播放地址无效。');
    }
    await _validateTarget(remoteUrl, headers);
    await _ensureStarted();
    final token = _newToken();
    _targets[token] = _ProxyTarget(
      remoteUrl: remoteUrl,
      headers: Map.unmodifiable(headers),
    );
    while (_targets.length > 8) {
      _targets.remove(_targets.keys.first);
    }
    final safeName = fileName.trim().isEmpty ? 'video.mkv' : fileName.trim();
    return Uri(
      scheme: 'http',
      host: InternetAddress.loopbackIPv4.address,
      port: _server!.port,
      pathSegments: ['media', token, safeName],
    );
  }

  Future<void> _ensureStarted() async {
    if (_server != null) return;
    final server = await HttpServer.bind(
      InternetAddress.loopbackIPv4,
      0,
      shared: false,
    );
    _server = server;
    _subscription = server.listen(_handleRequest);
  }

  Future<void> _validateTarget(
    Uri remoteUrl,
    Map<String, String> headers,
  ) async {
    HttpClientResponse? upstream;
    StreamSubscription<List<int>>? bodySubscription;
    try {
      upstream = await _openUpstream(
        method: 'GET',
        url: remoteUrl,
        headers: headers,
        range: 'bytes=0-1',
        ifRange: null,
      );
      if (upstream.statusCode != HttpStatus.ok &&
          upstream.statusCode != HttpStatus.partialContent) {
        throw AuthenticatedMediaProxyException(
          '夸克视频地址校验失败（HTTP ${upstream.statusCode}），请重新扫码后同步网盘。',
          statusCode: upstream.statusCode,
        );
      }
      bodySubscription = upstream.listen((_) {});
      await bodySubscription.cancel();
    } on AuthenticatedMediaProxyException {
      rethrow;
    } on Object catch (error) {
      throw AuthenticatedMediaProxyException('无法读取夸克视频数据：$error');
    } finally {
      await bodySubscription?.cancel();
    }
  }

  Future<void> _handleRequest(HttpRequest request) async {
    final response = request.response..bufferOutput = false;
    try {
      if (request.method != 'GET' && request.method != 'HEAD') {
        response.statusCode = HttpStatus.methodNotAllowed;
        await response.close();
        return;
      }
      final segments = request.uri.pathSegments;
      if (segments.length < 3 || segments.first != 'media') {
        response.statusCode = HttpStatus.notFound;
        await response.close();
        return;
      }
      final target = _targets[segments[1]];
      if (target == null) {
        response.statusCode = HttpStatus.notFound;
        await response.close();
        return;
      }
      final range = request.headers.value(HttpHeaders.rangeHeader);
      final ifRange = request.headers.value(HttpHeaders.ifRangeHeader);
      final upstream = await _openUpstream(
        method: request.method,
        url: target.remoteUrl,
        headers: target.headers,
        range: range,
        ifRange: ifRange,
      );
      response.statusCode = upstream.statusCode;
      _copyResponseHeaders(upstream.headers, response.headers);
      if (request.method == 'HEAD') {
        await upstream.drain<void>();
      } else {
        await response.addStream(upstream);
      }
      await response.close();
    } on Object {
      try {
        response.statusCode = HttpStatus.badGateway;
      } on StateError {
        // The upstream may have failed after response headers were committed.
      }
      try {
        await response.close();
      } on Object {
        // The native player may already have closed the loopback socket.
      }
    }
  }

  Future<HttpClientResponse> _openUpstream({
    required String method,
    required Uri url,
    required Map<String, String> headers,
    String? range,
    String? ifRange,
    int redirects = 0,
  }) async {
    if (!_remoteValidator(url)) {
      throw const AuthenticatedMediaProxyException('夸克播放地址跳转无效。');
    }
    final request = await _client.openUrl(method, url)
      ..followRedirects = false;
    headers.forEach(request.headers.set);
    request.headers.set(HttpHeaders.acceptEncodingHeader, 'identity');
    if (range?.isNotEmpty == true) {
      request.headers.set(HttpHeaders.rangeHeader, range!);
    }
    if (ifRange?.isNotEmpty == true) {
      request.headers.set(HttpHeaders.ifRangeHeader, ifRange!);
    }
    final response = await request.close();
    if (response.isRedirect && redirects < 6) {
      final location = response.headers.value(HttpHeaders.locationHeader);
      if (location != null && location.isNotEmpty) {
        final redirected = url.resolve(location);
        await response.drain<void>();
        return _openUpstream(
          method: method,
          url: redirected,
          headers: headers,
          range: range,
          ifRange: ifRange,
          redirects: redirects + 1,
        );
      }
    }
    return response;
  }

  static void _copyResponseHeaders(
    HttpHeaders source,
    HttpHeaders destination,
  ) {
    final forwarded = <String>{
      HttpHeaders.acceptRangesHeader,
      HttpHeaders.cacheControlHeader,
      'content-disposition',
      HttpHeaders.contentLengthHeader,
      HttpHeaders.contentRangeHeader,
      HttpHeaders.contentTypeHeader,
      HttpHeaders.etagHeader,
      HttpHeaders.expiresHeader,
      HttpHeaders.lastModifiedHeader,
    };
    for (final name in forwarded) {
      final values = source[name];
      if (values != null && values.isNotEmpty) {
        destination.set(name, values);
      }
    }
  }

  static bool _isQuarkRemote(Uri uri) {
    final host = uri.host.toLowerCase();
    return uri.scheme == 'https' &&
        uri.hasAuthority &&
        (host == 'quark.cn' || host.endsWith('.quark.cn'));
  }

  String _newToken() {
    final randomPart = List.generate(
      4,
      (_) => _random.nextInt(0x100000000).toRadixString(16).padLeft(8, '0'),
    ).join();
    return '${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}-'
        '${_sequence++}-$randomPart';
  }

  Future<void> close() async {
    _targets.clear();
    await _subscription?.cancel();
    _subscription = null;
    await _server?.close(force: true);
    _server = null;
    _client.close(force: true);
  }
}

class AuthenticatedMediaProxyException implements Exception {
  const AuthenticatedMediaProxyException(this.message, {this.statusCode});

  final String message;
  final int? statusCode;

  @override
  String toString() => message;
}

class _ProxyTarget {
  const _ProxyTarget({required this.remoteUrl, required this.headers});

  final Uri remoteUrl;
  final Map<String, String> headers;
}
