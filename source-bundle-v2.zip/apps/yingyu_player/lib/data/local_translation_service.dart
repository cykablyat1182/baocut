import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import '../domain/models/dictionary_entry.dart';
import '../domain/models/subtitle_cue.dart';
import 'partial_dictionary_parser.dart';

class LocalTranslationException implements Exception {
  LocalTranslationException(this.message);

  final String message;

  @override
  String toString() => message;
}

class LocalModelInfo {
  const LocalModelInfo({required this.name, this.sizeBytes});

  final String name;
  final int? sizeBytes;

  String get sizeLabel {
    final size = sizeBytes;
    if (size == null || size <= 0) return '';
    if (size >= 1024 * 1024 * 1024) {
      return '${(size / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
    }
    if (size >= 1024 * 1024) {
      return '${(size / (1024 * 1024)).toStringAsFixed(0)} MB';
    }
    return '${(size / 1024).toStringAsFixed(0)} KB';
  }
}

class LocalModelRuntime {
  const LocalModelRuntime({
    required this.name,
    required this.sizeBytes,
    required this.sizeVramBytes,
  });

  final String name;
  final int sizeBytes;
  final int sizeVramBytes;

  bool get usesGpu => sizeVramBytes > 0;

  String get deviceLabel {
    if (!usesGpu) return 'CPU';
    if (sizeVramBytes >= 1024 * 1024 * 1024) {
      return '显存 ${(sizeVramBytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
    }
    return '显存 ${(sizeVramBytes / (1024 * 1024)).toStringAsFixed(0)} MB';
  }
}

class SubtitleTranslationProgress {
  const SubtitleTranslationProgress({
    required this.completed,
    required this.total,
    required this.original,
    required this.translation,
    required this.thought,
  });

  final int completed;
  final int total;
  final String original;
  final String translation;

  /// A short, user-facing model status summary.  This is deliberately not a
  /// hidden chain-of-thought dump; it explains the current translation pass.
  final String thought;
}

/// A small Ollama client used only for the optional local translation mode.
///
/// The app talks to Ollama on loopback and never sends subtitles to the
/// network in this mode.  If Ollama is not already running, the bundled/local
/// executable is started with the configured model directory as
/// `OLLAMA_MODELS`.  `keep_alive: 0` is used when the feature is disabled so
/// the selected model is released from VRAM/RAM.
class LocalTranslationService {
  LocalTranslationService({http.Client? client})
    : _client = client ?? http.Client();

  static const defaultBaseUrl = 'http://127.0.0.1:11434';
  static const _batchSize = 18;
  static const _contextSize = 3;

  final http.Client _client;
  final Uri _baseUri = Uri.parse(defaultBaseUrl);
  Process? _serverProcess;
  String? _loadedModel;
  String? _loadedModelsDirectory;
  LocalModelRuntime? _runtime;
  bool _closed = false;

  String? get loadedModel => _loadedModel;
  LocalModelRuntime? get runtime => _runtime;

  Future<List<LocalModelInfo>> listModels({
    required String modelsDirectory,
  }) async {
    _ensureSupported();
    final directory = _normalizeDirectory(modelsDirectory);
    if (!await Directory(directory).exists()) {
      throw LocalTranslationException('本地模型目录不存在：$directory');
    }
    final models = await _fetchModels(directory, startServerIfNeeded: true);
    return models;
  }

  Future<LocalModelInfo> ensureReady({
    required String modelsDirectory,
    String? modelName,
  }) async {
    _ensureSupported();
    final directory = _normalizeDirectory(modelsDirectory);
    if (!await Directory(directory).exists()) {
      throw LocalTranslationException('本地模型目录不存在：$directory');
    }
    final models = await _fetchModels(directory, startServerIfNeeded: true);
    if (models.isEmpty) {
      throw LocalTranslationException(
        '没有在 $directory 找到 Ollama 模型。请先用 Ollama 导入或创建模型。',
      );
    }
    final requested = modelName?.trim() ?? '';
    final selected = models.firstWhere(
      (model) => model.name == requested,
      orElse: () => models.firstWhere(
        (model) => requested.isEmpty || model.name.startsWith('$requested:'),
        orElse: () => models.first,
      ),
    );
    if (_loadedModel == selected.name && _loadedModelsDirectory == directory) {
      final runtime = await _readRuntime(selected.name);
      if (runtime != null && runtime.usesGpu) {
        _runtime = runtime;
        return selected;
      }
      // keep_alive may have expired, or Ollama may have dropped the runner.
      // Clear the cache so the normal warm-up path can restore it and verify
      // the new runner's actual VRAM allocation.
      _loadedModel = null;
      _loadedModelsDirectory = null;
      _runtime = null;
      if (runtime != null) await _unloadModelByName(selected.name);
    }
    if (_loadedModel != null) await _unloadLoadedModel();
    await _unloadOtherModels(selected.name);
    await _warmModel(selected.name);
    final runtime = await _readRuntime(selected.name);
    if (runtime == null) {
      await _unloadModelByName(selected.name);
      throw LocalTranslationException(
        '无法确认本地模型的显存占用，已停止启用本地模式。请升级 Ollama 后重试。',
      );
    }
    if (!runtime.usesGpu) {
      await _unloadModelByName(selected.name);
      throw LocalTranslationException(
        '本地模型没有加载到显存，已停止启用本地模式。请检查 GPU 驱动、显存容量和 Ollama GPU 设置。',
      );
    }
    _loadedModel = selected.name;
    _loadedModelsDirectory = directory;
    _runtime = runtime;
    return selected;
  }

  Future<DictionaryEntry> lookupDictionary({
    required String word,
    required String sentence,
    required String targetLanguage,
    required String modelsDirectory,
    String? modelName,
    void Function(Map<String, String> fields)? onPartial,
    void Function(String message)? onStatus,
  }) async {
    final query = word.trim();
    if (query.isEmpty) {
      throw LocalTranslationException('请选择字幕中的单词或短语。');
    }
    onStatus?.call('正在准备本地模型…');
    final selected = await ensureReady(
      modelsDirectory: modelsDirectory,
      modelName: modelName,
    );
    final prompt =
        '''
请解释影视字幕中的单词或短语 "$query"，目标语言为 $targetLanguage。
结合完整句子判断此处词义，不要只给词典直译。完整句子：${sentence.trim()}
只返回合法 JSON，不要返回 Markdown 或思考过程：
{"word":"原词","phonetic":"音标","partOfSpeech":"词性","definition":"简明释义","example":"英文例句","exampleTranslation":"例句译文"}
''';
    onStatus?.call('本地模型已就绪，正在生成释义…');
    final request = http.Request('POST', _uri('/api/chat'))
      ..headers.addAll(const {
        'content-type': 'application/json',
        'accept': 'application/x-ndjson',
      })
      ..body = jsonEncode({
        'model': selected.name,
        'stream': true,
        'format': 'json',
        'keep_alive': '10m',
        'options': {
          'temperature': 0.1,
          'num_predict': 1024,
          'num_gpu': 999,
          'main_gpu': 0,
        },
        'messages': [
          {'role': 'system', 'content': '你是影视英语学习词典。必须只返回指定 JSON。'},
          {'role': 'user', 'content': prompt},
        ],
      });
    http.StreamedResponse response;
    try {
      response = await _client
          .send(request)
          .timeout(const Duration(minutes: 2));
    } on TimeoutException {
      throw LocalTranslationException('本地词典连接超时，请检查 Ollama 是否运行。');
    } on SocketException catch (error) {
      throw LocalTranslationException('无法连接本地 Ollama：${error.message}');
    } on http.ClientException catch (error) {
      throw LocalTranslationException('无法连接本地 Ollama：${error.message}');
    }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      final failed = http.Response.bytes(
        await response.stream.toBytes(),
        response.statusCode,
        headers: response.headers,
      );
      var message = 'HTTP ${failed.statusCode}';
      try {
        final decoded = jsonDecode(utf8.decode(failed.bodyBytes));
        if (decoded is Map && decoded['error'] is String) {
          message = decoded['error'] as String;
        }
      } catch (_) {
        // Use the HTTP status for non-JSON errors.
      }
      throw LocalTranslationException('Ollama：$message');
    }
    final content = StringBuffer();
    try {
      await for (final line
          in response.stream
              .transform(utf8.decoder)
              .transform(const LineSplitter())
              .timeout(const Duration(minutes: 2))) {
        if (line.trim().isEmpty) continue;
        final chunk = jsonDecode(line);
        if (chunk is! Map) continue;
        final error = chunk['error'];
        if (error is String && error.isNotEmpty) {
          throw LocalTranslationException('Ollama：$error');
        }
        final message = chunk['message'];
        final delta = message is Map ? message['content'] : null;
        if (delta is! String || delta.isEmpty) continue;
        content.write(delta);
        final fields = parsePartialDictionaryFields(content.toString());
        if (fields.isNotEmpty) onPartial?.call(fields);
      }
    } on TimeoutException {
      throw LocalTranslationException('本地词典流式响应超时，请重试。');
    } on FormatException {
      throw LocalTranslationException('Ollama 返回了无法识别的数据。');
    }
    final rawContent = content.toString();
    if (rawContent.isEmpty) {
      throw LocalTranslationException('Ollama 没有返回文本内容。');
    }
    final parsed = _parseObject(rawContent);
    final entry = DictionaryEntry.fromJson({
      'word': parsed['word'] as String? ?? query,
      'phonetic': parsed['phonetic'] as String? ?? '',
      'partOfSpeech': parsed['partOfSpeech'] as String? ?? '',
      'definition': parsed['definition'] as String? ?? '',
      'example': parsed['example'] as String? ?? sentence.trim(),
      'exampleTranslation': parsed['exampleTranslation'] as String? ?? '',
    });
    if (entry.definition.trim().isEmpty) {
      throw LocalTranslationException('本地模型没有返回有效释义。');
    }
    return entry;
  }

  Future<List<SubtitleCue>> translateCues({
    required List<SubtitleCue> cues,
    required String sourceLanguage,
    required String targetLanguage,
    required String modelsDirectory,
    String? modelName,
    void Function(SubtitleTranslationProgress progress)? onProgress,
  }) async {
    if (cues.isEmpty) return const [];
    final selected = await ensureReady(
      modelsDirectory: modelsDirectory,
      modelName: modelName,
    );
    final pending = [
      for (final cue in cues)
        if (cue.original.trim().isNotEmpty && !cue.isBilingual) cue,
    ];
    if (pending.isEmpty) return List<SubtitleCue>.from(cues);

    final translations = <String, String>{};
    var completed = cues
        .where((cue) => cue.translation.trim().isNotEmpty)
        .length;
    onProgress?.call(
      SubtitleTranslationProgress(
        completed: completed,
        total: cues.length,
        original: pending.first.original,
        translation: '',
        thought: '正在读取字幕上下文，判断语气、代词和专有名词…',
      ),
    );
    for (var offset = 0; offset < pending.length; offset += _batchSize) {
      final batch = pending
          .skip(offset)
          .take(_batchSize)
          .toList(growable: false);
      final firstIndex = cues.indexWhere((cue) => cue.id == batch.first.id);
      final lastIndex = cues.indexWhere((cue) => cue.id == batch.last.id);
      final previous = firstIndex <= 0
          ? const <SubtitleCue>[]
          : cues
                .sublist(
                  (firstIndex - _contextSize).clamp(0, firstIndex),
                  firstIndex,
                )
                .toList(growable: false);
      final next = lastIndex < 0 || lastIndex + 1 >= cues.length
          ? const <SubtitleCue>[]
          : cues
                .sublist(
                  lastIndex + 1,
                  (lastIndex + 1 + _contextSize).clamp(0, cues.length),
                )
                .toList(growable: false);

      final prompt = _translationPrompt(
        batch: batch,
        previous: previous,
        next: next,
        sourceLanguage: sourceLanguage,
        targetLanguage: targetLanguage,
      );
      final body = await _postJson('/api/chat', {
        'model': selected.name,
        'stream': false,
        'format': 'json',
        'keep_alive': '10m',
        'options': {
          'temperature': 0.15,
          'num_predict': 4096,
          'num_gpu': 999,
          'main_gpu': 0,
        },
        'messages': [
          {
            'role': 'system',
            'content': '你是影视字幕翻译器。只翻译目标字幕，不翻译上下文。必须返回合法 JSON。',
          },
          {'role': 'user', 'content': prompt},
        ],
      });
      final content = _responseContent(body);
      final parsed = _parseTranslations(content, batch);
      if (parsed.isEmpty) {
        throw LocalTranslationException('本地模型 ${selected.name} 没有返回可识别的字幕翻译。');
      }
      translations.addAll(parsed);
      for (final cue in batch) {
        final translation = parsed[cue.id];
        if (translation == null || translation.trim().isEmpty) continue;
        completed++;
        onProgress?.call(
          SubtitleTranslationProgress(
            completed: completed,
            total: cues.length,
            original: cue.original,
            translation: translation,
            thought: '已结合前后句校对语义，正在统一人名、时态和标点…',
          ),
        );
      }
    }

    final missing = pending.where((cue) {
      final value = translations[cue.id];
      return value == null || value.trim().isEmpty;
    }).length;
    if (missing > 0) {
      throw LocalTranslationException('本地模型未返回 $missing 条字幕译文，未生成不完整的外挂翻译轨。');
    }

    return [
      for (final cue in cues)
        cue.copyWith(translation: translations[cue.id] ?? cue.translation),
    ];
  }

  Future<void> unload() async {
    if (_loadedModel == null) return;
    await _unloadLoadedModel();
  }

  Future<void> close() async {
    if (_closed) return;
    _closed = true;
    try {
      await unload();
    } finally {
      _client.close();
    }
  }

  Future<List<LocalModelInfo>> _fetchModels(
    String modelsDirectory, {
    required bool startServerIfNeeded,
  }) async {
    Map<String, Object?>? body;
    try {
      body = await _getJson('/api/tags');
    } on LocalTranslationException {
      if (!startServerIfNeeded) rethrow;
      await _startServer(modelsDirectory);
      try {
        body = await _waitForTags();
      } catch (_) {
        // Allow a later toggle/refresh to retry after a failed launch.
        _serverProcess = null;
        rethrow;
      }
    }
    final raw = body['models'];
    if (raw is! List) return const [];
    final models = <LocalModelInfo>[];
    for (final item in raw) {
      if (item is! Map) continue;
      final name = item['name'] as String? ?? item['model'] as String? ?? '';
      if (name.trim().isEmpty) continue;
      final rawSize = item['size'];
      models.add(
        LocalModelInfo(
          name: name.trim(),
          sizeBytes: rawSize is num ? rawSize.toInt() : null,
        ),
      );
    }
    models.sort((a, b) => a.name.compareTo(b.name));
    return models;
  }

  Future<void> _startServer(String modelsDirectory) async {
    if (_serverProcess != null) return;
    final executable = await _findOllamaExecutable();
    final environment = <String, String>{
      ...Platform.environment,
      'OLLAMA_MODELS': modelsDirectory,
      'OLLAMA_HOST': '127.0.0.1:11434',
      // Prefer GPU offload and keep only one loaded model for this player.
      // Ollama still honors available VRAM and reports the actual amount via
      // /api/ps; activation is rejected when it reports CPU-only loading.
      'OLLAMA_GPU_LAYERS': '999',
      'OLLAMA_NUM_GPU': '999',
      'OLLAMA_MAX_LOADED_MODELS': '1',
      'OLLAMA_NUM_PARALLEL': '1',
      'OLLAMA_KEEP_ALIVE': '10m',
    };
    try {
      _serverProcess = await Process.start(
        executable,
        const ['serve'],
        mode: ProcessStartMode.detached,
        environment: environment,
      );
    } on ProcessException catch (error) {
      throw LocalTranslationException('无法启动 Ollama：${error.message}');
    }
  }

  Future<Map<String, Object?>> _waitForTags() async {
    Object? lastError;
    for (var attempt = 0; attempt < 36; attempt++) {
      try {
        return await _getJson('/api/tags', timeout: const Duration(seconds: 2));
      } catch (error) {
        lastError = error;
        await Future<void>.delayed(const Duration(milliseconds: 500));
      }
    }
    throw LocalTranslationException('Ollama 服务启动超时：$lastError');
  }

  Future<void> _warmModel(String model) async {
    await _postJson('/api/generate', {
      'model': model,
      'prompt': '只回复 OK。',
      'stream': false,
      'keep_alive': '10m',
      'options': {
        'temperature': 0,
        'num_predict': 1,
        'num_gpu': 999,
        'main_gpu': 0,
      },
    });
  }

  Future<void> _unloadLoadedModel() async {
    final model = _loadedModel;
    if (model == null) return;
    try {
      await _unloadModelByName(model);
    } finally {
      _loadedModel = null;
      _loadedModelsDirectory = null;
      _runtime = null;
    }
  }

  Future<void> _unloadModelByName(String model) async {
    await _postJson('/api/generate', {
      'model': model,
      'prompt': '',
      'stream': false,
      'keep_alive': 0,
    });
  }

  Future<void> _unloadOtherModels(String keepModel) async {
    try {
      final body = await _getJson('/api/ps');
      final raw = body['models'];
      if (raw is! List) return;
      for (final item in raw) {
        if (item is! Map) continue;
        final name = item['name'] as String? ?? item['model'] as String? ?? '';
        if (name.trim().isEmpty || name.trim() == keepModel) continue;
        try {
          await _unloadModelByName(name.trim());
        } catch (_) {
          // A stale runner should not prevent the selected model from loading.
        }
      }
    } catch (_) {
      // Older Ollama builds may not expose /api/ps.
    }
  }

  Future<LocalModelRuntime?> _readRuntime(String model) async {
    try {
      final body = await _getJson('/api/ps');
      final raw = body['models'];
      if (raw is! List) return null;
      for (final item in raw) {
        if (item is! Map) continue;
        final name = item['name'] as String? ?? item['model'] as String? ?? '';
        if (name.trim() != model) continue;
        final size = item['size'];
        final sizeVram = item['size_vram'];
        return LocalModelRuntime(
          name: model,
          sizeBytes: size is num ? size.toInt() : 0,
          sizeVramBytes: sizeVram is num ? sizeVram.toInt() : 0,
        );
      }
    } catch (_) {
      // The model is still usable on Ollama versions without /api/ps.
    }
    return null;
  }

  Future<String> _findOllamaExecutable() async {
    final configured = Platform.environment['OLLAMA_EXECUTABLE']?.trim();
    final candidates = <String>[
      if (configured != null && configured.isNotEmpty) configured,
      r'D:\AI\Ollama\ollama-new\ollama.exe',
      r'D:\AI\Ollama\ollama.exe',
      if (Platform.environment['LOCALAPPDATA'] case final localAppData?)
        '$localAppData\\Programs\\Ollama\\ollama.exe',
      if (Platform.environment['ProgramFiles'] case final programFiles?)
        '$programFiles\\Ollama\\ollama.exe',
    ];
    for (final candidate in candidates) {
      if (await File(candidate).exists()) return candidate;
    }
    try {
      final result = await Process.run('where.exe', const ['ollama']);
      final path = result.stdout
          .toString()
          .split(RegExp(r'[\r\n]+'))
          .firstWhere((value) => value.trim().isNotEmpty, orElse: () => '');
      if (path.trim().isNotEmpty) return path.trim();
    } catch (_) {
      // The executable may still be in a non-standard installation path.
    }
    throw LocalTranslationException(
      '没有找到 Ollama。请确认 ollama.exe 位于 D:\\AI\\Ollama\\ollama-new 或已加入 PATH。',
    );
  }

  String _translationPrompt({
    required List<SubtitleCue> batch,
    required List<SubtitleCue> previous,
    required List<SubtitleCue> next,
    required String sourceLanguage,
    required String targetLanguage,
  }) {
    String encode(Iterable<SubtitleCue> values) => jsonEncode([
      for (final cue in values)
        {
          'id': cue.id,
          'text': cue.original,
          if (cue.translation.trim().isNotEmpty) 'translation': cue.translation,
        },
    ]);
    return '''
将影视字幕从 $sourceLanguage 翻译成 $targetLanguage。
上下文只用于理解代词、省略主语、时态、俚语、人物和专有名词，禁止把上下文条目写入结果。
保持每个目标条目的 id，不合并、不拆分、不添加解释；翻译要自然、简洁，保留语气和标点。
只返回如下 JSON 结构：{"translations":[{"id":"目标id","translation":"译文"}]}。

前文（只读）：${encode(previous)}
目标字幕（必须全部翻译）：${encode(batch)}
后文（只读）：${encode(next)}
''';
  }

  String _responseContent(Map<String, Object?> body) {
    final message = body['message'];
    if (message is Map && message['content'] is String) {
      return message['content'] as String;
    }
    if (body['response'] is String) return body['response'] as String;
    throw LocalTranslationException('Ollama 没有返回文本内容。');
  }

  Map<String, String> _parseTranslations(
    String content,
    List<SubtitleCue> batch,
  ) {
    final text = content.trim();
    if (text.isEmpty) return const {};
    dynamic decoded;
    try {
      decoded = jsonDecode(_extractJson(text));
    } catch (_) {
      return const {};
    }
    dynamic raw = decoded;
    if (decoded is Map) {
      raw =
          decoded['translations'] ??
          decoded['items'] ??
          decoded['cues'] ??
          decoded['results'];
      if (raw == null) {
        final keyed = <String, String>{};
        for (final cue in batch) {
          final value = decoded[cue.id];
          if (value is String && value.trim().isNotEmpty) {
            keyed[cue.id] = value.trim();
          }
        }
        return keyed;
      }
    }
    if (raw is! List) return const {};
    final result = <String, String>{};
    for (var index = 0; index < raw.length; index++) {
      final item = raw[index];
      if (item is String && index < batch.length && item.trim().isNotEmpty) {
        result[batch[index].id] = item.trim();
        continue;
      }
      if (item is! Map) continue;
      final id =
          item['id'] as String? ??
          (index < batch.length ? batch[index].id : null);
      final translation =
          item['translation'] as String? ??
          item['text'] as String? ??
          item['target'] as String?;
      if (id != null && translation != null && translation.trim().isNotEmpty) {
        final known = batch.any((cue) => cue.id == id);
        if (known) result[id] = translation.trim();
      }
    }
    return result;
  }

  Map<String, Object?> _parseObject(String content) {
    final decoded = jsonDecode(_extractJson(content));
    if (decoded is! Map) {
      throw LocalTranslationException('本地模型返回的词典格式无效。');
    }
    return decoded.map(
      (key, value) => MapEntry(key.toString(), value as Object?),
    );
  }

  String _extractJson(String value) {
    final withoutFence = value
        .replaceFirst(RegExp(r'^```(?:json)?\s*', caseSensitive: false), '')
        .replaceFirst(RegExp(r'\s*```$'), '')
        .trim();
    final objectStart = withoutFence.indexOf('{');
    final objectEnd = withoutFence.lastIndexOf('}');
    if (objectStart >= 0 && objectEnd > objectStart) {
      return withoutFence.substring(objectStart, objectEnd + 1);
    }
    final arrayStart = withoutFence.indexOf('[');
    final arrayEnd = withoutFence.lastIndexOf(']');
    if (arrayStart >= 0 && arrayEnd > arrayStart) {
      return withoutFence.substring(arrayStart, arrayEnd + 1);
    }
    return withoutFence;
  }

  Future<Map<String, Object?>> _getJson(
    String path, {
    Duration timeout = const Duration(seconds: 5),
  }) async {
    final response = await _request(
      () => _client.get(
        _uri(path),
        headers: const {'accept': 'application/json'},
      ),
      timeout: timeout,
    );
    return _decode(response);
  }

  Future<Map<String, Object?>> _postJson(
    String path,
    Map<String, Object?> body, {
    Duration timeout = const Duration(minutes: 15),
  }) async {
    final response = await _request(
      () => _client.post(
        _uri(path),
        headers: const {
          'content-type': 'application/json',
          'accept': 'application/json',
        },
        body: jsonEncode(body),
      ),
      timeout: timeout,
    );
    return _decode(response);
  }

  Future<http.Response> _request(
    Future<http.Response> Function() send, {
    required Duration timeout,
  }) async {
    try {
      return await send().timeout(timeout);
    } on TimeoutException {
      throw LocalTranslationException('Ollama 响应超时，请检查本地模型是否正在加载。');
    } on SocketException catch (error) {
      throw LocalTranslationException('无法连接本地 Ollama：${error.message}');
    } on http.ClientException catch (error) {
      throw LocalTranslationException('无法连接本地 Ollama：${error.message}');
    }
  }

  Map<String, Object?> _decode(http.Response response) {
    if (response.statusCode < 200 || response.statusCode >= 300) {
      var message = 'HTTP ${response.statusCode}';
      try {
        final value = jsonDecode(utf8.decode(response.bodyBytes));
        if (value is Map && value['error'] is String) {
          message = value['error'] as String;
        }
      } catch (_) {
        // Keep the HTTP status for non-JSON errors.
      }
      throw LocalTranslationException('Ollama：$message');
    }
    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    if (decoded is! Map) {
      throw LocalTranslationException('Ollama 返回了无法识别的数据。');
    }
    return decoded.map(
      (key, value) => MapEntry(key.toString(), value as Object?),
    );
  }

  Uri _uri(String path) => _baseUri.replace(path: path);

  String _normalizeDirectory(String value) =>
      value.trim().replaceAll(RegExp(r'[\\/]+$'), '');

  void _ensureSupported() {
    if (!Platform.isWindows) {
      throw LocalTranslationException('本地 Ollama 翻译目前仅支持 Windows 端。');
    }
    if (_closed) throw LocalTranslationException('本地模型服务已经关闭。');
  }
}
