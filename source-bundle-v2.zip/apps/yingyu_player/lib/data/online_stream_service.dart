import 'dart:convert';

import 'package:http/http.dart' as http;

import '../domain/models/media_playlist_item.dart';
import '../domain/models/online_stream_source.dart';

class OnlineStreamService {
  const OnlineStreamService(this._client);

  final http.Client _client;

  Future<List<MediaPlaylistItem>> load(OnlineStreamSource source) async {
    final uri = Uri.tryParse(source.url);
    if (uri == null || !uri.hasScheme || !uri.host.isNotEmpty) {
      throw const OnlineStreamException('请输入有效的 http 或 https 播放列表地址。');
    }
    if (uri.scheme != 'http' && uri.scheme != 'https') {
      throw const OnlineStreamException('在线源配置地址仅支持 http 或 https。');
    }
    try {
      final response = await _client
          .get(uri, headers: const {'Accept': 'text/plain,*/*'})
          .timeout(const Duration(seconds: 15));
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw OnlineStreamException('读取在线源失败（HTTP ${response.statusCode}）。');
      }
      final body = _decode(response.bodyBytes);
      final items = _looksLikeTvBoxConfig(body)
          ? await _loadTvBoxConfig(source, uri, body)
          : parse(source, body);
      if (items.isEmpty) {
        throw const OnlineStreamException('未在配置中识别到可播放的直播地址。');
      }
      return items;
    } on OnlineStreamException {
      rethrow;
    } catch (error) {
      throw OnlineStreamException('无法连接在线源，请检查地址或网络：$error');
    }
  }

  Future<List<MediaPlaylistItem>> _loadTvBoxConfig(
    OnlineStreamSource source,
    Uri configUri,
    String body,
  ) async {
    final decoded = jsonDecode(_stripJsonComments(body));
    if (decoded is! Map<String, dynamic>) return const [];
    final lives = decoded['lives'];
    if (lives is! List) return const [];
    final tasks = <Future<List<MediaPlaylistItem>>>[];
    for (final entry in lives.whereType<Map>()) {
      final name = entry['name']?.toString().trim() ?? '';
      final value = entry['url'];
      final urls = value is List ? value : [value];
      for (final candidate in urls) {
        final address = candidate?.toString().trim() ?? '';
        if (address.isEmpty) continue;
        final liveUri = configUri.resolve(address);
        if (liveUri.scheme != 'http' && liveUri.scheme != 'https') continue;
        tasks.add(_loadTvBoxLive(source, entry, name, liveUri));
      }
    }
    final results = await Future.wait(tasks);
    return [for (final group in results) ...group];
  }

  Future<List<MediaPlaylistItem>> _loadTvBoxLive(
    OnlineStreamSource configSource,
    Map<dynamic, dynamic> entry,
    String name,
    Uri liveUri,
  ) async {
    final userAgent = entry['ua']?.toString().trim();
    final headers = {
      if (userAgent?.isNotEmpty == true) 'User-Agent': userAgent!,
    };
    // Some TVBox files put a single HLS/MP4 address directly in `lives.url`
    // instead of pointing to a text playlist. Fetching that binary as UTF-8
    // produces an empty channel list, so keep the native media URL intact.
    if (_looksLikeDirectMediaAddress(liveUri)) {
      final logoTemplate = entry['logo']?.toString().trim();
      final epgTemplate = entry['epg']?.toString().trim();
      return [
        MediaPlaylistItem(
          path: liveUri.toString(),
          title: name.isEmpty ? configSource.name : name,
          sourceName: configSource.name,
          remoteLogoUrl: _template(logoTemplate, name),
          epgUrl: _template(epgTemplate, name),
          httpHeaders: headers,
          isOnline: true,
          isLive: true,
        ),
      ];
    }
    try {
      final response = await _client
          .get(liveUri, headers: {'Accept': 'text/plain,*/*', ...headers})
          .timeout(const Duration(seconds: 12));
      if (response.statusCode < 200 || response.statusCode >= 300) {
        return const [];
      }
      final liveSource = OnlineStreamSource(
        name: name.isEmpty ? configSource.name : '${configSource.name} · $name',
        url: liveUri.toString(),
      );
      final logoTemplate = entry['logo']?.toString().trim();
      final epgTemplate = entry['epg']?.toString().trim();
      return parse(liveSource, _decode(response.bodyBytes))
          .map(
            (item) => item.copyWith(
              remoteLogoUrl:
                  item.remoteLogoUrl ?? _template(logoTemplate, item.title),
              epgUrl: _template(epgTemplate, item.title),
              httpHeaders: headers,
            ),
          )
          .toList(growable: false);
    } catch (_) {
      // A TVBox warehouse commonly contains a mix of stale and live lists.
      return const [];
    }
  }

  static List<MediaPlaylistItem> parse(OnlineStreamSource source, String text) {
    final lines = const LineSplitter()
        .convert(text.replaceFirst('\uFEFF', ''))
        .map((line) => line.trim())
        .where((line) => line.isNotEmpty)
        .toList(growable: false);
    final output = <MediaPlaylistItem>[];
    String? pendingTitle;
    String? pendingLogo;
    String? pendingGroup;
    String? textGroup;

    for (final line in lines) {
      if (line.startsWith('#EXTINF')) {
        pendingTitle = _attribute(line, 'tvg-name') ?? _title(line);
        pendingLogo = _attribute(line, 'tvg-logo');
        pendingGroup = _attribute(line, 'group-title');
        continue;
      }
      if (line.startsWith('#')) continue;
      if (line.endsWith(',#genre#')) {
        textGroup = line.substring(0, line.length - ',#genre#'.length).trim();
        continue;
      }
      if (_isStreamUrl(line)) {
        output.add(
          MediaPlaylistItem(
            path: line,
            title: pendingTitle?.trim().isNotEmpty == true
                ? pendingTitle!.trim()
                : '直播频道 ${output.length + 1}',
            remoteLogoUrl: pendingLogo,
            group: pendingGroup ?? textGroup,
            sourceName: source.name,
            isOnline: true,
            isLive: true,
          ),
        );
        pendingTitle = null;
        pendingLogo = null;
        pendingGroup = null;
        continue;
      }
      final separator = line.indexOf(',');
      if (separator > 0) {
        final title = line.substring(0, separator).trim();
        final address = line.substring(separator + 1).trim();
        if (_isStreamUrl(address)) {
          output.add(
            MediaPlaylistItem(
              path: address,
              title: title.isEmpty ? '直播频道 ${output.length + 1}' : title,
              group: textGroup,
              sourceName: source.name,
              isOnline: true,
              isLive: true,
            ),
          );
        }
      }
    }
    return output;
  }

  static bool _looksLikeTvBoxConfig(String text) {
    final normalized = _stripJsonComments(text).trimLeft();
    if (!normalized.startsWith('{')) return false;
    try {
      final decoded = jsonDecode(normalized);
      return decoded is Map &&
          (decoded.containsKey('sites') || decoded.containsKey('lives'));
    } on FormatException {
      return false;
    }
  }

  static String _stripJsonComments(String source) {
    return source
        .split(RegExp(r'\r?\n'))
        .where((line) => !line.trimLeft().startsWith('//'))
        .join('\n');
  }

  static String? _template(String? template, String channelName) {
    if (template == null || template.isEmpty) return null;
    final encoded = Uri.encodeComponent(channelName);
    return template
        .replaceAll('{name}', encoded)
        .replaceAll('{date}', _dateStamp());
  }

  static String _dateStamp() {
    final now = DateTime.now();
    return '${now.year.toString().padLeft(4, '0')}'
        '${now.month.toString().padLeft(2, '0')}'
        '${now.day.toString().padLeft(2, '0')}';
  }

  static bool _isStreamUrl(String value) {
    final uri = Uri.tryParse(value);
    return uri != null &&
        const {
          'http',
          'https',
          'rtmp',
          'rtmps',
          'rtsp',
        }.contains(uri.scheme.toLowerCase());
  }

  static bool _looksLikeDirectMediaAddress(Uri uri) {
    if (const {'rtmp', 'rtmps', 'rtsp'}.contains(uri.scheme.toLowerCase())) {
      return true;
    }
    final address = '${uri.path}?${uri.query}'.toLowerCase();
    return const [
      '.m3u8',
      '.mp4',
      '.flv',
      '.ts',
      '.mpd',
      '.webm',
      '.mov',
    ].any(address.contains);
  }

  static String? _attribute(String line, String key) {
    final match = RegExp(
      '$key="([^"]*)"',
      caseSensitive: false,
    ).firstMatch(line);
    return match?.group(1)?.trim();
  }

  static String? _title(String line) {
    final comma = line.indexOf(',');
    return comma < 0 ? null : line.substring(comma + 1).trim();
  }

  static String _decode(List<int> bytes) {
    try {
      return utf8.decode(bytes);
    } on FormatException {
      return latin1.decode(bytes);
    }
  }
}

class OnlineStreamException implements Exception {
  const OnlineStreamException(this.message);

  final String message;

  @override
  String toString() => message;
}
