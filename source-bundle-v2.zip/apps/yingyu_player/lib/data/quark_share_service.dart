import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:uuid/uuid.dart';

import '../domain/models/cloud_media_source.dart';

class QuarkShareImportResult {
  const QuarkShareImportResult({
    required this.savedFileIds,
    required this.sharedNames,
  });

  final List<String> savedFileIds;
  final List<String> sharedNames;
}

enum QuarkQrLoginStatus { waiting, success, expired, failed }

class QuarkQrLoginSession {
  QuarkQrLoginSession({
    required this.token,
    required this.requestId,
    required this.qrUrl,
    required Map<String, String> cookies,
  }) : cookies = Map<String, String>.from(cookies);

  final String token;
  final String requestId;
  final String qrUrl;
  final Map<String, String> cookies;
}

class QuarkQrLoginResult {
  const QuarkQrLoginResult({
    required this.status,
    this.cookie = '',
    this.message = '',
  });

  final QuarkQrLoginStatus status;
  final String cookie;
  final String message;
}

class QuarkShareService {
  const QuarkShareService(this._client);

  final http.Client _client;

  static const _baseUrls = [
    'https://drive-pc.quark.cn/1/clouddrive',
    'https://drive.quark.cn/1/clouddrive',
    'https://drive-h.quark.cn/1/clouddrive',
  ];
  static const _qrClientId = '532';
  static const _qrApiBase = 'https://uop.quark.cn/cas/ajax';

  Future<QuarkQrLoginSession> startQrLogin() async {
    final requestId = const Uuid().v4();
    final cookies = <String, String>{};
    final uri = Uri.parse('$_qrApiBase/getTokenForQrcodeLogin').replace(
      queryParameters: {
        'client_id': _qrClientId,
        'v': '1.2',
        'request_id': requestId,
      },
    );
    final response = await _qrGet(uri, cookies);
    final decoded = _decodeQrResponse(response);
    if (_integer(decoded['status']) != 2000000) {
      throw QuarkShareException(
        decoded['message']?.toString() ?? '无法创建夸克扫码登录。',
      );
    }
    final token =
        _map(_map(decoded['data'])['members'])['token']?.toString().trim() ??
        '';
    if (token.isEmpty) throw const QuarkShareException('夸克没有返回登录二维码。');
    final qrUrl = Uri.parse('https://su.quark.cn/4_eMHBJ').replace(
      queryParameters: {
        'token': token,
        'client_id': _qrClientId,
        'ssb': 'weblogin',
        'uc_param_str': '',
        'uc_biz_str':
            'S:custom|OPT:SAREA@0|OPT:IMMERSIVE@1|OPT:BACK_BTN_STYLE@0',
      },
    );
    return QuarkQrLoginSession(
      token: token,
      requestId: requestId,
      qrUrl: qrUrl.toString(),
      cookies: cookies,
    );
  }

  Future<QuarkQrLoginResult> pollQrLogin(QuarkQrLoginSession session) async {
    // Quark treats request_id as a per-request nonce. Reusing the token
    // request's UUID makes the QR request expire as soon as polling starts.
    final pollRequestId = const Uuid().v4();
    final uri = Uri.parse('$_qrApiBase/getServiceTicketByQrcodeToken').replace(
      queryParameters: {
        'client_id': _qrClientId,
        'v': '1.2',
        'request_id': pollRequestId,
        'token': session.token,
      },
    );
    final response = await _qrGet(uri, session.cookies);
    final decoded = _decodeQrResponse(response);
    final status = _integer(decoded['status']);
    if (status == 50004001) {
      return const QuarkQrLoginResult(status: QuarkQrLoginStatus.waiting);
    }
    if (status == 50004002 || status == 50004004) {
      return QuarkQrLoginResult(
        status: QuarkQrLoginStatus.expired,
        message: decoded['message']?.toString() ?? '二维码已过期，请刷新。',
      );
    }
    if (status != 2000000) {
      return QuarkQrLoginResult(
        status: QuarkQrLoginStatus.failed,
        message: decoded['message']?.toString() ?? '夸克扫码登录失败。',
      );
    }
    final ticket =
        _map(
          _map(decoded['data'])['members'],
        )['service_ticket']?.toString().trim() ??
        '';
    if (ticket.isEmpty) {
      return const QuarkQrLoginResult(
        status: QuarkQrLoginStatus.failed,
        message: '夸克没有返回登录凭据。',
      );
    }
    final accountUri = Uri.parse(
      'https://pan.quark.cn/account/info',
    ).replace(queryParameters: {'st': ticket, 'lw': 'scan'});
    await _qrGet(accountUri, session.cookies);
    final cookie = session.cookies.entries
        .map((entry) => '${entry.key}=${entry.value}')
        .join('; ');
    if (!session.cookies.containsKey('__kps') &&
        !session.cookies.containsKey('__pus')) {
      return const QuarkQrLoginResult(
        status: QuarkQrLoginStatus.failed,
        message: '扫码成功，但没有取得夸克网盘登录凭据，请重新扫码。',
      );
    }
    return QuarkQrLoginResult(
      status: QuarkQrLoginStatus.success,
      cookie: cookie,
    );
  }

  Future<http.Response> _qrGet(
    Uri initialUri,
    Map<String, String> cookies,
  ) async {
    var uri = initialUri;
    for (var redirects = 0; redirects < 6; redirects++) {
      if (!uri.host.endsWith('quark.cn')) {
        throw const QuarkShareException('夸克登录跳转到了不受信任的地址。');
      }
      final request = http.Request('GET', uri)
        ..followRedirects = false
        ..headers.addAll({
          'Accept': 'application/json, text/plain, */*',
          'Referer': 'https://pan.quark.cn/',
          'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128 Safari/537.36',
          if (cookies.isNotEmpty)
            'Cookie': cookies.entries
                .map((entry) => '${entry.key}=${entry.value}')
                .join('; '),
        });
      try {
        final streamed = await _client
            .send(request)
            .timeout(const Duration(seconds: 20));
        final response = await http.Response.fromStream(streamed);
        _mergeSetCookies(response.headers['set-cookie'], cookies);
        if (response.isRedirect) {
          final location = response.headers['location'];
          if (location == null || location.isEmpty) {
            throw const QuarkShareException('夸克登录跳转地址无效。');
          }
          uri = uri.resolve(location);
          continue;
        }
        if (response.statusCode < 200 || response.statusCode >= 300) {
          throw QuarkShareException('夸克登录接口请求失败（HTTP ${response.statusCode}）。');
        }
        return response;
      } on QuarkShareException {
        rethrow;
      } on Object catch (error) {
        throw QuarkShareException('无法连接夸克登录服务：$error');
      }
    }
    throw const QuarkShareException('夸克登录跳转次数过多。');
  }

  static void _mergeSetCookies(String? header, Map<String, String> cookies) {
    if (header == null || header.isEmpty) return;
    final matches = RegExp(r'(?:^|,\s*)([^=;,\s]+)=([^;]*)').allMatches(header);
    for (final match in matches) {
      final name = match.group(1)?.trim() ?? '';
      final value = match.group(2)?.trim() ?? '';
      if (name.isEmpty) continue;
      if (value.isEmpty) {
        cookies.remove(name);
      } else {
        cookies[name] = value;
      }
    }
  }

  static Map<String, dynamic> _decodeQrResponse(http.Response response) {
    try {
      final decoded = jsonDecode(utf8.decode(response.bodyBytes));
      if (decoded is Map) return _map(decoded);
    } on FormatException {
      // Converted to a user-facing error below.
    }
    throw const QuarkShareException('夸克登录返回格式无效。');
  }

  Future<QuarkShareImportResult> importShare(
    CloudMediaSource source,
    String shareUrl,
  ) async {
    if (!source.canImportQuarkShares) {
      throw const QuarkShareException('请先在夸克网盘配置中填写转存 Cookie。');
    }
    final share = _parseShare(shareUrl);
    final token = await _request(
      source,
      'POST',
      '/share/sharepage/token',
      body: {
        'pwd_id': share.id,
        'passcode': share.passcode,
        'support_visit_limit_private_share': true,
      },
    );
    final stoken = _map(token['data'])['stoken']?.toString() ?? '';
    if (stoken.isEmpty) throw const QuarkShareException('夸克分享链接已失效或需要提取码。');

    final entries = await _collectShareFiles(
      source: source,
      shareId: share.id,
      stoken: stoken,
      parentFid: '0',
    );
    final files = entries.where((entry) => !entry.isDirectory).toList();
    if (files.isEmpty) throw const QuarkShareException('该分享中没有可转存的文件。');

    // A season is commonly shared as one directory. Saving that directory as
    // a single task can report success while Quark is still copying only part
    // of its children. Save the discovered leaves in bounded batches instead,
    // which makes every episode independently verifiable and playable.
    final preferred = files.where((entry) => _isMediaFile(entry.name)).toList();
    final selected = preferred.isEmpty ? files : preferred;
    if (selected.length > 1000) {
      throw const QuarkShareException('该分享文件过多，请选择较小的影视目录。');
    }
    final savedFileIds = <String>[];
    final byParent = <String, List<_QuarkSharedEntry>>{};
    for (final entry in selected) {
      byParent.putIfAbsent(entry.parentFid, () => []).add(entry);
    }
    for (final group in byParent.entries) {
      for (var start = 0; start < group.value.length; start += 50) {
        final end = start + 50 < group.value.length
            ? start + 50
            : group.value.length;
        savedFileIds.addAll(
          await _saveSharedBatch(
            source: source,
            shareId: share.id,
            stoken: stoken,
            parentFid: group.key,
            entries: group.value.sublist(start, end),
          ),
        );
      }
    }
    return QuarkShareImportResult(
      savedFileIds: savedFileIds,
      sharedNames: selected.map((entry) => entry.name).toList(growable: false),
    );
  }

  Future<List<_QuarkSharedEntry>> _collectShareFiles({
    required CloudMediaSource source,
    required String shareId,
    required String stoken,
    required String parentFid,
    int depth = 0,
  }) async {
    if (depth > 10) return const [];
    final output = <_QuarkSharedEntry>[];
    for (var page = 1; page <= 20; page++) {
      final detail = await _request(
        source,
        'GET',
        '/share/sharepage/detail',
        query: {
          'pwd_id': shareId,
          'stoken': stoken,
          'pdir_fid': parentFid,
          'force': '0',
          '_page': '$page',
          '_size': '100',
          '_fetch_total': '1',
          '_sort': 'file_type:asc,updated_at:desc',
          'ver': '2',
          'fetch_share_full_path': '0',
        },
      );
      final rawList = _map(detail['data'])['list'];
      final pageFiles = rawList is List
          ? rawList.whereType<Map>().toList()
          : const <Map>[];
      for (final raw in pageFiles) {
        final fid = raw['fid']?.toString().trim() ?? '';
        final token = raw['share_fid_token']?.toString().trim() ?? '';
        final name = raw['file_name']?.toString().trim() ?? '';
        if (fid.isEmpty || name.isEmpty) continue;
        final isDirectory =
            raw['dir'] == true ||
            raw['dir']?.toString() == '1' ||
            (raw['file_type']?.toString() == '0' &&
                raw['category']?.toString() == '0');
        if (!isDirectory && token.isEmpty) continue;
        output.add(
          _QuarkSharedEntry(
            fid: fid,
            token: token,
            name: name,
            parentFid: parentFid,
            isDirectory: isDirectory,
          ),
        );
      }
      if (pageFiles.length < 100) break;
    }
    final directories = output
        .where((entry) => entry.isDirectory)
        .toList(growable: false);
    for (final directory in directories) {
      output.addAll(
        await _collectShareFiles(
          source: source,
          shareId: shareId,
          stoken: stoken,
          parentFid: directory.fid,
          depth: depth + 1,
        ),
      );
    }
    return output;
  }

  Future<List<String>> _saveSharedBatch({
    required CloudMediaSource source,
    required String shareId,
    required String stoken,
    required String parentFid,
    required List<_QuarkSharedEntry> entries,
  }) async {
    final saved = await _request(
      source,
      'POST',
      '/share/sharepage/save',
      body: {
        'fid_list': entries.map((entry) => entry.fid).toList(),
        'fid_token_list': entries.map((entry) => entry.token).toList(),
        'to_pdir_fid': source.transferFolderId.trim().isEmpty
            ? '0'
            : source.transferFolderId.trim(),
        'pwd_id': shareId,
        'stoken': stoken,
        'pdir_fid': parentFid,
        'pdir_save_all': false,
        'exclude_fids': const <String>[],
        'scene': 'link',
      },
    );
    final taskId = _map(saved['data'])['task_id']?.toString() ?? '';
    if (taskId.isEmpty) throw const QuarkShareException('夸克没有创建转存任务。');
    for (var retry = 0; retry < 20; retry++) {
      if (retry > 0) {
        await Future<void>.delayed(const Duration(milliseconds: 700));
      }
      final task = await _request(
        source,
        'GET',
        '/task',
        query: {'task_id': taskId, 'retry_index': '$retry'},
      );
      final data = _map(task['data']);
      final status = _integer(data['status']);
      if (status == 2) {
        final savedIds = _map(data['save_as'])['save_as_top_fids'];
        return savedIds is List
            ? savedIds.map((value) => value.toString()).toList()
            : const [];
      }
      if (status < 0 || status == 3 || status == 4) {
        throw QuarkShareException(data['message']?.toString() ?? '夸克转存任务失败。');
      }
    }
    throw const QuarkShareException('夸克转存超时，请稍后同步网盘。');
  }

  static bool _isMediaFile(String name) {
    final dot = name.lastIndexOf('.');
    if (dot < 0) return false;
    return const {
      'mkv',
      'mp4',
      'avi',
      'mov',
      'webm',
      'm4v',
      'ts',
      'mts',
      'm2ts',
      'srt',
      'vtt',
      'ass',
      'ssa',
    }.contains(name.substring(dot + 1).toLowerCase());
  }

  Future<Map<String, dynamic>> _request(
    CloudMediaSource source,
    String method,
    String path, {
    Map<String, String> query = const {},
    Map<String, Object>? body,
  }) async {
    final headers = {
      'Accept': 'application/json, text/plain, */*',
      'Content-Type': 'application/json',
      'Cookie': _normalizeCookie(source.transferCredential),
      'Origin': 'https://pan.quark.cn',
      'Referer': 'https://pan.quark.cn/',
      'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128.0.0.0 Safari/537.36',
      'Sec-Fetch-Site': 'same-site',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Dest': 'empty',
      'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    };
    try {
      QuarkShareException? lastError;
      for (final base in _baseUrls) {
        final now = DateTime.now().millisecondsSinceEpoch;
        final uri = Uri.parse('$base$path').replace(
          queryParameters: {
            'pr': 'ucpro',
            'fr': 'pc',
            'uc_param_str': '',
            '__dt': '${now % 10000}',
            '__t': '$now',
            ...query,
          },
        );
        final response =
            await (method == 'POST'
                    ? _client.post(
                        uri,
                        headers: headers,
                        body: jsonEncode(body ?? {}),
                      )
                    : _client.get(uri, headers: headers))
                .timeout(const Duration(seconds: 20));
        Map<String, dynamic>? result;
        try {
          final decoded = jsonDecode(utf8.decode(response.bodyBytes));
          if (decoded is Map) result = decoded.cast<String, dynamic>();
        } on FormatException {
          result = null;
        }
        if (result == null) {
          lastError = QuarkShareException(
            '夸克返回格式无效（HTTP ${response.statusCode}）。',
          );
        } else {
          final code = _integer(result['code']);
          final status = _integer(result['status']);
          if (response.statusCode >= 200 &&
              response.statusCode < 300 &&
              code == 0 &&
              (status == 0 || status == 200)) {
            return result;
          }
          final message = result['message']?.toString().trim();
          lastError = QuarkShareException(
            _quarkApiError(response.statusCode, code, message),
          );
          if (const {41004, 41008, 41010, 41011}.contains(code)) {
            throw lastError;
          }
          final retryableHttp = const {
            404,
            405,
            502,
            503,
            504,
          }.contains(response.statusCode);
          if (!retryableHttp) throw lastError;
        }
      }
      throw lastError ?? const QuarkShareException('夸克接口请求失败。');
    } on QuarkShareException {
      rethrow;
    } on Object catch (error) {
      throw QuarkShareException('无法连接夸克网盘：$error');
    }
  }

  static _QuarkShare _parseShare(String value) {
    final uri = Uri.tryParse(value.trim());
    if (uri == null ||
        !const {
          'pan.quark.cn',
          'drive.quark.cn',
          'drive-pc.quark.cn',
          'drive-h.quark.cn',
        }.contains(uri.host.toLowerCase())) {
      throw const QuarkShareException('当前只支持转存夸克分享链接。');
    }
    final segments = uri.pathSegments;
    final marker = segments.indexOf('s');
    final id = marker >= 0 && marker + 1 < segments.length
        ? segments[marker + 1].trim()
        : '';
    if (id.isEmpty) throw const QuarkShareException('夸克分享链接格式无效。');
    final fragmentPasscode = RegExp(
      r'(?:^|[?&#])(?:pwd|passcode)=([^&#]+)',
      caseSensitive: false,
    ).firstMatch(uri.fragment)?.group(1);
    final queryPasscode = uri.queryParameters['pwd']?.trim();
    final passcode = queryPasscode?.isNotEmpty == true
        ? queryPasscode!
        : uri.queryParameters['passcode']?.trim() ??
              (fragmentPasscode == null
                  ? ''
                  : Uri.decodeComponent(fragmentPasscode).trim());
    return _QuarkShare(id, passcode);
  }

  static String _quarkApiError(int httpStatus, int code, String? message) {
    final normalized = message?.trim() ?? '';
    if (code == 41004 || code == 41010 || code == 41011) {
      return '夸克分享不存在、已失效或已被取消（code $code）。';
    }
    if (code == 41008) {
      return '该夸克分享需要提取码，请在链接中附带 ?pwd=提取码。';
    }
    if (httpStatus == 401 || httpStatus == 403) {
      return '夸克登录凭据已失效，请重新扫码登录。';
    }
    if (normalized.isNotEmpty) {
      return '$normalized（HTTP $httpStatus，code $code）';
    }
    return '夸克接口请求失败（HTTP $httpStatus，code $code）。';
  }

  static String _normalizeCookie(String value) {
    var cookie = value.trim();
    if (cookie.toLowerCase().startsWith('cookie:')) {
      cookie = cookie.substring('cookie:'.length).trim();
    }
    return cookie;
  }

  static Map<String, dynamic> _map(Object? value) => value is Map
      ? value.map((key, value) => MapEntry(key.toString(), value))
      : const {};

  static int _integer(Object? value) =>
      value is num ? value.toInt() : int.tryParse(value?.toString() ?? '') ?? 0;
}

class _QuarkShare {
  const _QuarkShare(this.id, this.passcode);
  final String id;
  final String passcode;
}

class _QuarkSharedEntry {
  const _QuarkSharedEntry({
    required this.fid,
    required this.token,
    required this.name,
    required this.parentFid,
    required this.isDirectory,
  });

  final String fid;
  final String token;
  final String name;
  final String parentFid;
  final bool isDirectory;
}

class QuarkShareException implements Exception {
  const QuarkShareException(this.message);
  final String message;

  @override
  String toString() => message;
}
