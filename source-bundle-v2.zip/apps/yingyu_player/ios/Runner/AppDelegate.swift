import Flutter
import UIKit
import Security

@main
@objc class AppDelegate: FlutterAppDelegate, FlutterImplicitEngineDelegate {
  private var secureCredentialChannel: FlutterMethodChannel?

  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }

  func didInitializeImplicitFlutterEngine(_ engineBridge: FlutterImplicitEngineBridge) {
    GeneratedPluginRegistrant.register(with: engineBridge.pluginRegistry)

    let channel = FlutterMethodChannel(
      name: "yingyu/secure_credentials",
      binaryMessenger: engineBridge.applicationRegistrar.messenger()
    )
    secureCredentialChannel = channel
    channel.setMethodCallHandler { [weak self] call, result in
      guard let self else {
        result(FlutterError(code: "unavailable", message: "安全存储不可用。", details: nil))
        return
      }
      guard
        let arguments = call.arguments as? [String: Any],
        let key = arguments["key"] as? String,
        !key.isEmpty
      else {
        result(FlutterError(code: "invalid_key", message: "安全存储键无效。", details: nil))
        return
      }

      switch call.method {
      case "read":
        result(self.readCredential(key: key))
      case "write":
        guard let value = arguments["value"] as? String else {
          result(FlutterError(code: "invalid_value", message: "安全存储值无效。", details: nil))
          return
        }
        do {
          try self.writeCredential(key: key, value: value)
          result(nil)
        } catch {
          result(FlutterError(code: "keychain_write", message: error.localizedDescription, details: nil))
        }
      case "delete":
        do {
          try self.deleteCredential(key: key)
          result(nil)
        } catch {
          result(FlutterError(code: "keychain_delete", message: error.localizedDescription, details: nil))
        }
      default:
        result(FlutterMethodNotImplemented)
      }
    }
  }

  private var keychainService: String {
    Bundle.main.bundleIdentifier ?? "com.yingyu.player"
  }

  private func keychainQuery(key: String) -> [String: Any] {
    [
      kSecClass as String: kSecClassGenericPassword,
      kSecAttrService as String: keychainService,
      kSecAttrAccount as String: key,
    ]
  }

  private func readCredential(key: String) -> String? {
    var query = keychainQuery(key: key)
    query[kSecReturnData as String] = true
    query[kSecMatchLimit as String] = kSecMatchLimitOne
    var item: CFTypeRef?
    let status = SecItemCopyMatching(query as CFDictionary, &item)
    guard
      status == errSecSuccess,
      let data = item as? Data
    else {
      return nil
    }
    return String(data: data, encoding: .utf8)
  }

  private func writeCredential(key: String, value: String) throws {
    try deleteCredential(key: key)
    var query = keychainQuery(key: key)
    query[kSecValueData as String] = Data(value.utf8)
    let status = SecItemAdd(query as CFDictionary, nil)
    guard status == errSecSuccess else {
      throw NSError(domain: NSOSStatusErrorDomain, code: Int(status))
    }
  }

  private func deleteCredential(key: String) throws {
    let status = SecItemDelete(keychainQuery(key: key) as CFDictionary)
    guard status == errSecSuccess || status == errSecItemNotFound else {
      throw NSError(domain: NSOSStatusErrorDomain, code: Int(status))
    }
  }
}
